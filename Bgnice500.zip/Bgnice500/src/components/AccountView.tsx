import React, { useState } from 'react';
import {
  Copy,
  Check,
  RefreshCw,
  Wallet,
  ArrowDownToLine,
  ArrowUpFromLine,
  Crown,
  ShieldCheck,
  History,
  FileText,
  Bell,
  Gift,
  BarChart2,
  Globe,
  Settings,
  HelpCircle,
  LogOut,
  ChevronRight,
  UserCheck,
  Download,
  Users,
  Award,
  Sparkles,
  Edit3
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useLanguage } from '../context/LanguageContext';
import { TabType } from './BottomNav';
import { BrandLogo } from './BrandLogo';
import { AvatarSelectorModal } from './AvatarSelectorModal';
import { HistoryModal } from './HistoryModal';
import { SubordinateDataModal } from './SubordinateDataModal';
import { getAvatarById } from '../utils/avatars';

interface AccountViewProps {
  onNavigate: (tab: TabType | 'settings' | 'gameHistory' | 'support') => void;
  onOpenAuth: () => void;
}

export const AccountView: React.FC<AccountViewProps> = ({ onNavigate, onOpenAuth }) => {
  const {
    user,
    userTurnovers,
    activeTurnoverReq,
    activeTurnoverDone,
    activeTurnoverRemaining,
    logout,
    refreshBalance,
    isRefreshingBalance,
    showToast,
    downloadApp,
    settings,
    updateAvatar,
    updateNickname
  } = useApp();
  const { language, setLanguage, t } = useLanguage();
  const [copiedUid, setCopiedUid] = useState(false);
  const [showTurnoverDetails, setShowTurnoverDetails] = useState(false);
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);

  // Modals
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
  const [isNicknameModalOpen, setIsNicknameModalOpen] = useState(false);
  const [nicknameInput, setNicknameInput] = useState(user?.nickname || '');
  const [isSavingNickname, setIsSavingNickname] = useState(false);
  const [historyModalTab, setHistoryModalTab] = useState<'game' | 'deposit' | 'withdraw' | 'transactions' | null>(null);
  const [isSubordinateModalOpen, setIsSubordinateModalOpen] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const currentAvatar = getAvatarById(user?.avatar);
  const displayUid = user?.numericUid || user?.uid?.slice(0, 8) || '---';

  const handleCopyUid = () => {
    if (displayUid) {
      navigator.clipboard.writeText(displayUid);
      setCopiedUid(true);
      showToast('UID copied to clipboard', 'info');
      setTimeout(() => setCopiedUid(false), 2000);
    }
  };

  const handleRefreshClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    refreshBalance();
  };

  const formattedDate = user?.createdAt
    ? new Date(user.createdAt).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
    : 'Recently';

  const turnoverReq = activeTurnoverReq > 0 ? activeTurnoverReq : Number(user?.turnoverReq || 0);
  const turnoverDone = activeTurnoverReq > 0 ? activeTurnoverDone : Number(user?.turnoverDone || 0);
  const turnoverRemaining = activeTurnoverReq > 0 ? activeTurnoverRemaining : Math.max(0, turnoverReq - turnoverDone);
  const turnoverPercent = turnoverReq > 0 ? Math.min(100, Math.round((turnoverDone / turnoverReq) * 100)) : 100;

  return (
    <div className="min-h-screen bg-[#0b0e14] pb-24 text-slate-200 select-none">
      {/* Top Profile Header */}
      <div className="bg-gradient-to-b from-[#161f2e] via-[#1a2332] to-[#121824] pt-4 pb-8 px-4 text-white rounded-b-3xl border-b border-slate-800 shadow-md">
        <div className="flex items-center space-x-3.5 max-w-md mx-auto">
          {/* Avatar (Clickable to change) */}
          <button
            onClick={() => setIsAvatarModalOpen(true)}
            className="relative group text-left shrink-0"
            id="account-change-avatar-btn"
            title="Change Avatar"
          >
            <div
              className="w-16 h-16 rounded-full overflow-hidden bg-slate-900 border-2 border-slate-700 flex items-center justify-center shadow-md transition-transform active:scale-95 group-hover:scale-105"
            >
              {currentAvatar.photoUrl ? (
                <img
                  src={currentAvatar.photoUrl}
                  alt="Avatar"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="text-3xl">{currentAvatar.emoji || '👤'}</span>
              )}
            </div>
            <div className="absolute -bottom-1 -right-1 bg-amber-400 text-slate-950 rounded-full px-1.5 py-0.2 text-[9px] font-black border border-slate-900 flex items-center space-x-0.5 shadow-xs">
              <Crown className="w-2.5 h-2.5 fill-current" />
              <span>VIP{user?.vipLevel ?? 0}</span>
            </div>
          </button>

          {/* User Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2">
              <h2 className="font-black text-base sm:text-lg text-white truncate">
                {user?.nickname || 'Member'}
              </h2>
              <button
                onClick={() => {
                  setNicknameInput(user?.nickname || '');
                  setIsNicknameModalOpen(true);
                }}
                className="p-1 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"
                title="Change Nickname"
                id="edit-nickname-header-btn"
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
              <span className="bg-amber-400/20 text-amber-300 border border-amber-400/30 font-extrabold text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider">
                VIP{user?.vipLevel ?? 0}
              </span>
            </div>

            <div className="flex items-center space-x-2 mt-1">
              <span className="text-xs text-slate-300 font-mono font-bold">UID: {displayUid}</span>
              <button
                onClick={handleCopyUid}
                className="text-slate-400 hover:text-white p-0.5 active:scale-90 transition-colors"
                id="copy-uid-btn"
                title="Copy UID"
              >
                {copiedUid ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            <div className="text-[10px] text-slate-400 mt-0.5">
              Member since: {formattedDate}
            </div>
          </div>

          {/* Settings Icon Button - Right side of Nickname and UID */}
          <button
            onClick={() => onNavigate('settings')}
            className="p-2.5 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white active:scale-95 transition-all shrink-0 flex items-center justify-center border border-slate-700 shadow-sm"
            title="Account Settings"
            id="acc-header-settings-btn"
          >
            <Settings className="w-5 h-5 text-amber-400" />
          </button>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 -mt-5 space-y-4">
        {/* Total Balance Card with dedicated refresh button (Strictly no page reload) */}
        <div className="bg-[#161f2e] rounded-3xl p-5 shadow-lg border border-slate-800/90 space-y-4">
          <div>
            <div className="text-xs text-slate-400 font-medium">Total balance</div>
            <div className="flex items-center space-x-2 mt-1">
              <span className="text-3xl font-black text-white tracking-tight">
                ৳{(user?.balance ?? 0).toFixed(2)}
              </span>
              <button
                onClick={handleRefreshClick}
                disabled={isRefreshingBalance}
                className="p-1.5 text-slate-400 hover:text-white active:scale-90 transition-all rounded-full hover:bg-slate-800"
                id="account-refresh-balance-btn"
                title="Refresh Balance"
              >
                <RefreshCw
                  className={`w-4 h-4 ${isRefreshingBalance ? 'animate-spin text-amber-400' : ''}`}
                />
              </button>
            </div>
          </div>

          {/* Turnover requirement progress */}
          {turnoverReq > 0 && turnoverRemaining > 0 && (
            <div className="bg-amber-950/20 border border-amber-500/30 rounded-2xl p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-amber-300 flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-amber-400" />
                  Turnover Requirement
                </span>
                <span className="font-mono font-bold text-amber-300">
                  ৳{turnoverDone.toFixed(2)} / ৳{turnoverReq.toFixed(2)} ({turnoverPercent}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-400 rounded-full transition-all duration-500"
                  style={{ width: `${turnoverPercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] text-amber-200/80">
                <span>Remaining: <strong className="text-white">৳{turnoverRemaining.toFixed(2)}</strong></span>
                {userTurnovers.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setShowTurnoverDetails(!showTurnoverDetails)}
                    className="underline text-amber-400 font-bold hover:text-amber-300"
                  >
                    {showTurnoverDetails ? 'Hide breakdown' : `View events (${userTurnovers.filter(t => t.status === 'active').length})`}
                  </button>
                )}
              </div>

              {showTurnoverDetails && userTurnovers.length > 0 && (
                <div className="pt-1 space-y-1 text-[10px] border-t border-amber-500/20">
                  {userTurnovers.filter(t => t.status === 'active').map((t) => (
                    <div key={t.id} className="flex items-center justify-between py-0.5 text-amber-100 font-mono">
                      <span className="capitalize">{t.sourceType}: {t.sourceId.slice(0, 14)}</span>
                      <span>Rem: ৳{(t.remainingAmount ?? (t.requiredAmount - t.completedAmount)).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 4 Action Circle Buttons */}
          <div className="grid grid-cols-4 gap-2 pt-2 border-t border-slate-800/80">
            {/* Wallet */}
            <button
              onClick={() => onNavigate('wallet')}
              className="flex flex-col items-center justify-center space-y-1 group"
              id="acc-btn-wallet"
            >
              <div className="w-11 h-11 rounded-2xl bg-blue-500/15 text-blue-400 border border-blue-500/20 flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                <Wallet className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-bold text-slate-300">Wallet</span>
            </button>

            {/* Deposit */}
            <button
              onClick={() => onNavigate('deposit')}
              className="flex flex-col items-center justify-center space-y-1 group"
              id="acc-btn-deposit"
            >
              <div className="w-11 h-11 rounded-2xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                <ArrowDownToLine className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-bold text-slate-300">Deposit</span>
            </button>

            {/* Withdraw */}
            <button
              onClick={() => onNavigate('withdraw')}
              className="flex flex-col items-center justify-center space-y-1 group"
              id="acc-btn-withdraw"
            >
              <div className="w-11 h-11 rounded-2xl bg-amber-500/15 text-amber-400 border border-amber-500/20 flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                <ArrowUpFromLine className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-bold text-slate-300">Withdraw</span>
            </button>

            {/* VIP */}
            <button
              onClick={() => onNavigate('vip')}
              className="flex flex-col items-center justify-center space-y-1 group"
              id="acc-btn-vip"
            >
              <div className="w-11 h-11 rounded-2xl bg-purple-500/15 text-purple-400 border border-purple-500/20 flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                <Crown className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-bold text-slate-300">VIP</span>
            </button>
          </div>
        </div>

        {/* Safe Vault Card Widget */}
        <button
          onClick={() => onNavigate('safe')}
          className="w-full bg-[#161f2e] rounded-2xl p-4 shadow-sm border border-slate-800/90 flex items-center justify-between hover:bg-slate-800/80 transition-colors text-left"
          id="acc-safe-widget"
        >
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="font-bold text-xs text-white">Safe Vault</div>
              <div className="text-[10px] text-slate-400">Daily interest rate 0.006%</div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <span className="font-extrabold text-sm text-amber-400">
              ৳{(user?.safeBalance ?? 0).toFixed(2)}
            </span>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </div>
        </button>

        {/* Account Menu List */}
        <div className="bg-[#161f2e] rounded-3xl shadow-sm border border-slate-800/90 divide-y divide-slate-800 text-xs text-slate-300 overflow-hidden">
          {/* Game History */}
          <button
            onClick={() => setHistoryModalTab('game')}
            className="w-full p-3.5 flex items-center justify-between hover:bg-slate-800/50 transition-colors"
            id="acc-btn-game-history"
          >
            <div className="flex items-center space-x-3">
              <History className="w-4 h-4 text-amber-400" />
              <span className="font-semibold text-slate-200">My Game History</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* Deposit history */}
          <button
            onClick={() => setHistoryModalTab('deposit')}
            className="w-full p-3.5 flex items-center justify-between hover:bg-slate-800/50 transition-colors"
            id="acc-btn-deposit-history"
          >
            <div className="flex items-center space-x-3">
              <ArrowDownToLine className="w-4 h-4 text-emerald-400" />
              <span className="font-semibold text-slate-200">Deposit History</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* Withdraw history */}
          <button
            onClick={() => setHistoryModalTab('withdraw')}
            className="w-full p-3.5 flex items-center justify-between hover:bg-slate-800/50 transition-colors"
            id="acc-btn-withdraw-history"
          >
            <div className="flex items-center space-x-3">
              <ArrowUpFromLine className="w-4 h-4 text-blue-400" />
              <span className="font-semibold text-slate-200">Withdraw History</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* Full Transaction Records */}
          <button
            onClick={() => setHistoryModalTab('transactions')}
            className="w-full p-3.5 flex items-center justify-between hover:bg-slate-800/50 transition-colors"
            id="acc-btn-transactions"
          >
            <div className="flex items-center space-x-3">
              <FileText className="w-4 h-4 text-purple-400" />
              <span className="font-semibold text-slate-200">Financial & Transaction Records</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* Subordinate Data */}
          <button
            onClick={() => setIsSubordinateModalOpen(true)}
            className="w-full p-3.5 flex items-center justify-between hover:bg-slate-800/50 transition-colors"
            id="acc-btn-subordinates"
          >
            <div className="flex items-center space-x-3">
              <Users className="w-4 h-4 text-indigo-400" />
              <span className="font-semibold text-slate-200">Subordinate & Referral Data</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* Gifts & Redemption */}
          <button
            onClick={() => onNavigate('activity')}
            className="w-full p-3.5 flex items-center justify-between hover:bg-slate-800/50 transition-colors"
            id="acc-btn-gifts"
          >
            <div className="flex items-center space-x-3">
              <Gift className="w-4 h-4 text-pink-400" />
              <span className="font-semibold text-slate-200">Gifts & Redemption</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* Download Official App (without Install badge) */}
          <button
            onClick={downloadApp}
            className="w-full p-3.5 flex items-center justify-between hover:bg-slate-800/50 transition-colors"
            id="acc-btn-download-app"
          >
            <div className="flex items-center space-x-3">
              <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Download className="w-3.5 h-3.5" />
              </div>
              <div className="text-left">
                <span className="font-semibold block text-slate-200">Download App</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          <button
            onClick={() => setIsLanguageModalOpen(true)}
            className="w-full p-3.5 flex items-center justify-between hover:bg-slate-800/50 transition-colors cursor-pointer text-left"
            id="acc-language-btn"
          >
            <div className="flex items-center space-x-3">
              <Globe className="w-4 h-4 text-purple-400" />
              <span className="font-semibold text-slate-200">{t('language')}</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="text-slate-300 font-bold text-xs bg-slate-800 px-2 py-0.5 rounded-full border border-slate-700">
                {language === 'bn' ? 'বাংলা (Bengali)' : 'English'}
              </span>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </div>
          </button>

          <button
            onClick={() => onNavigate('support')}
            className="w-full p-3.5 flex items-center justify-between hover:bg-slate-800/50 transition-colors cursor-pointer text-left"
            id="acc-customer-service-btn"
          >
            <div className="flex items-center space-x-3">
              <HelpCircle className="w-4 h-4 text-amber-400" />
              <span className="font-semibold text-slate-200">Customer Service (Live Chat)</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-[10px] text-emerald-400 font-bold">24/7 Live</span>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </div>
          </button>
        </div>

        {/* Security Footer (without Official Verified text) */}
        <div className="bg-[#161f2e] rounded-2xl p-3.5 border border-slate-800/90 shadow-xs flex items-center justify-center">
          <BrandLogo variant="compact" showBadge={false} />
        </div>

        {/* Log out / Switch Account button */}
        <div className="pt-2">
          <button
            onClick={() => setShowLogoutConfirm(true)}
            className="w-full py-3 bg-[#161f2e] hover:bg-slate-800 text-rose-400 font-bold rounded-2xl border border-rose-900/40 shadow-xs flex items-center justify-center space-x-2 active:scale-98 transition-all text-sm cursor-pointer"
            id="acc-logout-btn"
          >
            <LogOut className="w-4 h-4" />
            <span>Log out / Switch Account</span>
          </button>
        </div>
      </div>

      {/* In-app Logout Confirmation Modal */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#161f2e] rounded-3xl p-6 max-w-xs w-full shadow-2xl space-y-4 text-center border border-slate-800 animate-in zoom-in-95 text-slate-200">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30 mx-auto flex items-center justify-center">
              <LogOut className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">Log Out</h3>
              <p className="text-xs text-slate-400 mt-1">
                Are you sure you want to log out of BGNICE?
              </p>
            </div>
            <div className="flex space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowLogoutConfirm(false)}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs active:scale-95 transition-all"
                id="cancel-logout-btn"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={async () => {
                  setShowLogoutConfirm(false);
                  await logout();
                  showToast('Logged out successfully', 'info');
                  onOpenAuth();
                }}
                className="flex-1 py-2.5 bg-gradient-to-r from-rose-600 to-red-600 hover:bg-red-700 text-white font-extrabold rounded-xl text-xs shadow-md shadow-red-500/20 active:scale-95 transition-all"
                id="confirm-logout-btn"
              >
                Log Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Avatar Selector Modal */}
      <AvatarSelectorModal
        isOpen={isAvatarModalOpen}
        onClose={() => setIsAvatarModalOpen(false)}
        currentAvatarId={user?.avatar}
        onSelectAvatar={async (avatarId) => {
          await updateAvatar(avatarId);
        }}
      />

      {/* History Modal */}
      <HistoryModal
        isOpen={historyModalTab !== null}
        onClose={() => setHistoryModalTab(null)}
        initialTab={historyModalTab || 'game'}
      />

      {/* Subordinate Data Modal */}
      <SubordinateDataModal
        isOpen={isSubordinateModalOpen}
        onClose={() => setIsSubordinateModalOpen(false)}
      />

      {/* Language Selector Modal */}
      {isLanguageModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#161f2e] rounded-3xl p-5 max-w-xs w-full shadow-2xl space-y-4 border border-slate-800 animate-in zoom-in-95 text-slate-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <Globe className="w-5 h-5 text-purple-400" />
                <h3 className="font-bold text-sm text-white">{t('selectLanguage')}</h3>
              </div>
              <button
                onClick={() => setIsLanguageModalOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2.5">
              {/* Bengali */}
              <button
                onClick={() => {
                  setLanguage('bn');
                  showToast('ভাষা পরিবর্তিত হয়েছে: বাংলা', 'success');
                  setIsLanguageModalOpen(false);
                }}
                className={`w-full p-3.5 rounded-2xl border flex items-center justify-between text-left transition-all ${
                  language === 'bn'
                    ? 'border-amber-400 bg-amber-400/10 text-white font-black ring-1 ring-amber-400/50'
                    : 'border-slate-800 hover:bg-slate-800/60 text-slate-300 font-semibold'
                }`}
                id="select-lang-bn-btn"
              >
                <div className="flex items-center space-x-3">
                  <span className="text-xl">🇧🇩</span>
                  <div>
                    <div className="text-sm font-bold">বাংলা (Bengali)</div>
                    <div className="text-[10px] text-slate-400 font-normal">বাংলাদেশি ইউজারদের জন্য</div>
                  </div>
                </div>
                {language === 'bn' && <Check className="w-4 h-4 text-amber-400" />}
              </button>

              {/* English */}
              <button
                onClick={() => {
                  setLanguage('en');
                  showToast('Language changed to English', 'success');
                  setIsLanguageModalOpen(false);
                }}
                className={`w-full p-3.5 rounded-2xl border flex items-center justify-between text-left transition-all ${
                  language === 'en'
                    ? 'border-amber-400 bg-amber-400/10 text-white font-black ring-1 ring-amber-400/50'
                    : 'border-slate-800 hover:bg-slate-800/60 text-slate-300 font-semibold'
                }`}
                id="select-lang-en-btn"
              >
                <div className="flex items-center space-x-3">
                  <span className="text-xl">🇬🇧</span>
                  <div>
                    <div className="text-sm font-bold">English (UK/US)</div>
                    <div className="text-[10px] text-slate-400 font-normal">Default Global Language</div>
                  </div>
                </div>
                {language === 'en' && <Check className="w-4 h-4 text-amber-400" />}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick Edit Nickname Modal */}
      {isNicknameModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 select-none animate-fadeIn">
          <div className="bg-[#161f2e] rounded-3xl max-w-sm w-full p-5 shadow-2xl space-y-4 border border-slate-800 text-slate-200">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div>
                <h3 className="text-base font-black text-white">Change Nickname</h3>
                <p className="text-[11px] text-slate-400">Set your personal gaming nickname</p>
              </div>
              <button
                onClick={() => setIsNicknameModalOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-white"
                id="close-nickname-modal-btn"
              >
                ✕
              </button>
            </div>

            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const trimmed = nicknameInput.trim();
                if (!trimmed) {
                  showToast('Please enter a nickname', 'error');
                  return;
                }
                setIsSavingNickname(true);
                const res = await updateNickname(trimmed);
                setIsSavingNickname(false);
                if (res.success) {
                  showToast('Nickname updated successfully!', 'success');
                  setIsNicknameModalOpen(false);
                } else {
                  showToast(res.message, 'error');
                }
              }}
              className="space-y-3.5"
            >
              <div>
                <label className="text-xs text-slate-400 font-semibold block mb-1">New Nickname</label>
                <input
                  type="text"
                  value={nicknameInput}
                  onChange={(e) => setNicknameInput(e.target.value)}
                  placeholder="e.g. M_V8899 or DragonPro"
                  maxLength={20}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-700 bg-slate-900 text-xs font-bold text-white focus:outline-none focus:border-amber-400"
                  required
                />
                <span className="text-[10px] text-slate-500 block mt-1">Between 3 to 20 characters</span>
              </div>

              <div className="flex items-center space-x-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsNicknameModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingNickname}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-extrabold text-xs hover:from-amber-400 hover:to-amber-500 active:scale-95 disabled:opacity-50 shadow-sm"
                  id="submit-nickname-change-btn"
                >
                  {isSavingNickname ? 'Saving...' : 'Save Nickname'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
