import React, { useState } from 'react';
import {
  Gift,
  CalendarCheck,
  Award,
  Sparkles,
  Users,
  TrendingUp,
  Trophy,
  ExternalLink,
  ChevronRight,
  FileText,
  CheckCircle2,
  Calendar,
  Zap,
  Tag
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ActivityBanner } from '../types';

interface ActivityViewProps {
  onNavigate?: (tab: any) => void;
}

export const ActivityView: React.FC<ActivityViewProps> = ({ onNavigate }) => {
  const {
    user,
    userGiftClaims,
    deposits,
    settings,
    activityBanners,
    activeTurnoverRemaining,
    claimGiftCode,
    claimDailyAttendance,
    showToast
  } = useApp();

  const [giftCodeInput, setGiftCodeInput] = useState('');
  const [isClaimingGift, setIsClaimingGift] = useState(false);
  const [activeModal, setActiveModal] = useState<'rebate' | 'jackpot' | null>(null);

  const todayStr = new Date().toISOString().slice(0, 10);
  const isClaimedToday = user?.lastAttendanceDate === todayStr;
  const currentStreak = user?.attendanceStreak || 0;
  const nextDayToClaim = isClaimedToday ? currentStreak : ((currentStreak % 7) + 1);

  const attConfig = settings.attendance || {
    enabled: true,
    minDeposit: 500,
    totalDepositTarget: 20000,
    requiredDays: 7,
    rewards: [20, 30, 50, 70, 100, 150, 300],
    turnoverMultiplier: 1,
    cooldownHours: 24
  };

  const defaultRewards = [20, 30, 50, 70, 100, 150, 300];
  const rewardList = attConfig.rewards && attConfig.rewards.length >= 7 ? attConfig.rewards : defaultRewards;

  const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const userDeposits7Day = (deposits || []).filter(
    (d) => d.uid === user?.uid && d.status === 'completed' && (d.createdAt || 0) >= sevenDaysAgo
  );
  const total7DayDeposits = userDeposits7Day.reduce((acc, d) => acc + (d.amount || 0), 0);
  const minDepositMet = (deposits || []).some(
    (d) => d.uid === user?.uid && d.status === 'completed' && d.amount >= attConfig.minDeposit
  ) || total7DayDeposits >= attConfig.minDeposit;

  const ATTENDANCE_SCHEDULE = [
    { day: 1, reward: rewardList[0] || 20 },
    { day: 2, reward: rewardList[1] || 30 },
    { day: 3, reward: rewardList[2] || 50 },
    { day: 4, reward: rewardList[3] || 70 },
    { day: 5, reward: rewardList[4] || 100 },
    { day: 6, reward: rewardList[5] || 150 },
    { day: 7, reward: rewardList[6] || 300 }
  ];

  const handleRedeem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!giftCodeInput.trim()) return;
    setIsClaimingGift(true);
    const res = await claimGiftCode(giftCodeInput.trim());
    setIsClaimingGift(false);
    showToast(res.message, res.success ? 'success' : 'error');
    if (res.success) {
      setGiftCodeInput('');
    }
  };

  const handleAttendance = async (day?: number) => {
    if (isClaimedToday) {
      showToast('You have already claimed today’s attendance bonus!', 'info');
      return;
    }
    const target = day || nextDayToClaim;
    if (target > nextDayToClaim) {
      showToast(`Cannot claim Day ${target} yet! Complete Day ${nextDayToClaim} first.`, 'error');
      return;
    }
    await claimDailyAttendance(target);
  };

  const handleBannerAction = (banner: ActivityBanner) => {
    if (banner.actionType === 'attendance') {
      const el = document.getElementById('activity-attendance-section');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (banner.actionType === 'url' && banner.linkUrl) {
      window.open(banner.linkUrl, '_blank', 'noopener,noreferrer');
    } else if (banner.actionType === 'game' && banner.targetGame && onNavigate) {
      onNavigate(banner.targetGame);
    }
  };

  // Filter active banners
  const displayBanners = (activityBanners || []).filter((b) => b.active !== false);

  return (
    <div className="min-h-screen bg-[#f7f8fc] pb-24 text-slate-800 select-none font-sans">
      {/* Red Header (Matching Screenshot 2) */}
      <div className="sticky top-0 z-30 bg-gradient-to-r from-[#ea4335] via-[#e53935] to-[#d32f2f] text-white px-4 py-3.5 shadow-md">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-black tracking-wide">Activity</h1>
            <p className="text-[11px] text-white/85 font-medium">Please remember to follow the event page</p>
          </div>
          <div className="w-9 h-9 rounded-full bg-white/15 flex items-center justify-center backdrop-blur-xs">
            <Gift className="w-5 h-5 text-white" />
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* 4 Feature Quick Cards (2x2 Grid Matching Screenshot 2) */}
        <div className="grid grid-cols-2 gap-2.5">
          {/* 1. Activity Award */}
          <button
            onClick={() => {
              const el = document.getElementById('activity-attendance-section');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="bg-gradient-to-r from-orange-500 to-amber-500 rounded-2xl p-3 text-white text-left shadow-sm hover:opacity-95 active:scale-98 transition-all flex items-center justify-between group"
            id="quick-act-award"
          >
            <div>
              <div className="text-xs font-black tracking-wide">Activity Award</div>
              <div className="text-[10px] text-orange-100 mt-0.5">Daily Attendance</div>
            </div>
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <Gift className="w-5 h-5 text-white group-hover:scale-110 transition-transform" />
            </div>
          </button>

          {/* 2. Invitation bonus */}
          <button
            onClick={() => onNavigate && onNavigate('promotion')}
            className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-3 text-white text-left shadow-sm hover:opacity-95 active:scale-98 transition-all flex items-center justify-between group"
            id="quick-act-invitation"
          >
            <div>
              <div className="text-xs font-black tracking-wide">Invitation bonus</div>
              <div className="text-[10px] text-blue-100 mt-0.5">Invite friends & earn</div>
            </div>
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <Users className="w-5 h-5 text-white group-hover:scale-110 transition-transform" />
            </div>
          </button>

          {/* 3. Betting rebate */}
          <button
            onClick={() => setActiveModal('rebate')}
            className="bg-gradient-to-r from-purple-600 to-violet-600 rounded-2xl p-3 text-white text-left shadow-sm hover:opacity-95 active:scale-98 transition-all flex items-center justify-between group"
            id="quick-act-rebate"
          >
            <div>
              <div className="text-xs font-black tracking-wide">Betting rebate</div>
              <div className="text-[10px] text-purple-100 mt-0.5">Real-time cashback</div>
            </div>
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <TrendingUp className="w-5 h-5 text-white group-hover:scale-110 transition-transform" />
            </div>
          </button>

          {/* 4. Super Jackpot */}
          <button
            onClick={() => setActiveModal('jackpot')}
            className="bg-gradient-to-r from-rose-500 to-red-600 rounded-2xl p-3 text-white text-left shadow-sm hover:opacity-95 active:scale-98 transition-all flex items-center justify-between group"
            id="quick-act-jackpot"
          >
            <div>
              <div className="text-xs font-black tracking-wide">Super Jackpot</div>
              <div className="text-[10px] text-rose-100 mt-0.5">Win big prizes</div>
            </div>
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <Trophy className="w-5 h-5 text-white group-hover:scale-110 transition-transform" />
            </div>
          </button>
        </div>

        {/* Activity Promotional Banners (Managed by Admin in real-time) */}
        {displayBanners.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h2 className="text-xs font-black text-slate-700 uppercase tracking-wider flex items-center space-x-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Special Events & Promotions</span>
              </h2>
              <span className="text-[11px] text-slate-400 font-bold">{displayBanners.length} Events</span>
            </div>

            <div className="space-y-3">
              {displayBanners.map((banner) => {
                const cleanTitle = (banner.title || '').replace(/hgnice/gi, 'BGNICE');
                const cleanSubtitle = (banner.subtitle || '').replace(/hgnice/gi, 'BGNICE');
                const cleanBadge = (banner.badge || '').replace(/hgnice/gi, 'BGNICE');

                return (
                  <div
                    key={banner.id}
                    onClick={() => handleBannerAction(banner)}
                    className="bg-white rounded-2xl overflow-hidden shadow-xs border border-slate-200/80 hover:shadow-md transition-all cursor-pointer group flex flex-col"
                  >
                    {/* Separate Image Container on Top */}
                    <div className="relative w-full aspect-21/9 bg-slate-900 overflow-hidden border-b border-slate-100">
                      <img
                        src={banner.imageUrl || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80'}
                        alt={cleanTitle}
                        className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80';
                        }}
                      />
                      {cleanBadge && (
                        <span className="absolute top-2.5 left-2.5 bg-red-600/95 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-md flex items-center space-x-1">
                          <Tag className="w-3 h-3" />
                          <span>{cleanBadge}</span>
                        </span>
                      )}
                    </div>

                    {/* Separate Text Content Container Below */}
                    <div className="p-3 bg-white">
                      <h3 className="font-bold text-xs sm:text-[13px] text-slate-800 leading-snug group-hover:text-red-600 transition-colors">
                        {cleanTitle}
                      </h3>
                      {cleanSubtitle && (
                        <p className="text-[11px] text-slate-500 mt-1 font-medium leading-relaxed">
                          {cleanSubtitle}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Daily Attendance / Check-in Section (Matching Screenshot 3) */}
        <div
          id="activity-attendance-section"
          className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80 space-y-3"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center space-x-2.5">
              <div className="w-9 h-9 rounded-2xl bg-amber-500/15 text-amber-600 flex items-center justify-center font-bold">
                <CalendarCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-slate-900">Daily Attendance Bonus</h3>
                <p className="text-[11px] text-slate-400">Claim daily rewards consecutively for 7 days</p>
              </div>
            </div>
            <button
              onClick={() => handleAttendance(nextDayToClaim)}
              disabled={isClaimedToday}
              className={`px-4 py-1.5 rounded-full text-xs font-black transition-all ${
                isClaimedToday
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-[#ea4335] to-[#d32f2f] text-white shadow-sm active:scale-95'
              }`}
              id="attendance-claim-btn"
            >
              {isClaimedToday ? 'Signed Today' : `Sign In (Day ${nextDayToClaim})`}
            </button>
          </div>

          {/* Deposit Requirements Banner */}
          <div className="bg-slate-50 border border-slate-200/70 rounded-2xl p-3 space-y-2 text-xs">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-600 font-medium">7-Day Cumulative Deposit Progress</span>
              <span className="font-bold text-slate-900 font-mono">
                ৳{total7DayDeposits.toLocaleString()} / ৳{(attConfig.totalDepositTarget || 20000).toLocaleString()}
              </span>
            </div>
            <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min(
                    100,
                    (total7DayDeposits / Math.max(1, attConfig.totalDepositTarget || 20000)) * 100
                  )}%`
                }}
              />
            </div>
            <div className="flex items-center justify-between pt-0.5 text-[10px] text-slate-500">
              <span className="flex items-center space-x-1">
                <span
                  className={`w-2 h-2 rounded-full ${
                    minDepositMet ? 'bg-emerald-500' : 'bg-amber-500'
                  }`}
                />
                <span>Min Deposit Req: ৳{attConfig.minDeposit || 500}</span>
              </span>
              <span className="font-semibold text-slate-700">
                {minDepositMet ? '✓ Min deposit verified' : 'Deposit required'}
              </span>
            </div>
          </div>

          {/* 7 Days Matrix */}
          <div className="grid grid-cols-7 gap-1.5 text-center">
            {ATTENDANCE_SCHEDULE.map((d) => {
              const isDone = currentStreak >= d.day && (isClaimedToday || currentStreak > d.day);
              const isNext = d.day === nextDayToClaim && !isClaimedToday;
              const isLocked = d.day > nextDayToClaim;

              return (
                <button
                  key={d.day}
                  type="button"
                  onClick={() => handleAttendance(d.day)}
                  disabled={isDone || isLocked || isClaimedToday}
                  className={`rounded-xl p-2 flex flex-col items-center justify-center border transition-all ${
                    isDone
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-700 cursor-default'
                      : isNext
                      ? 'bg-red-50 border-[#ea4335] ring-1 ring-[#ea4335] text-[#ea4335] shadow-xs cursor-pointer hover:bg-red-100'
                      : 'bg-slate-50 border-slate-100 text-slate-400 cursor-not-allowed opacity-75'
                  }`}
                  title={
                    isDone
                      ? `Day ${d.day} Completed`
                      : isNext
                      ? `Claim Day ${d.day}`
                      : `Locked: Complete Day ${nextDayToClaim} first`
                  }
                >
                  <span className="text-[10px] font-medium">Day {d.day}</span>
                  <span className="text-xs font-black mt-1">৳{d.reward}</span>
                  {isDone && <span className="text-[9px] font-bold text-emerald-600 mt-0.5">✓ Done</span>}
                  {isNext && <span className="text-[9px] font-bold text-[#ea4335] mt-0.5">Claim</span>}
                  {isLocked && <span className="text-[9px] text-slate-400 mt-0.5">Locked</span>}
                </button>
              );
            })}
          </div>

          {/* Turnover Policy Note */}
          <div className="border-t border-slate-100 pt-2.5 flex items-center justify-between text-[11px] text-slate-500">
            <span>Bonus Turnover Multiplier: <strong className="text-slate-800">{attConfig.turnoverMultiplier || 1}x</strong></span>
            <span>Active Remaining: <strong className="text-amber-600 font-mono">৳{activeTurnoverRemaining.toFixed(2)}</strong></span>
          </div>
        </div>

        {/* Gift Code Box */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80 space-y-3">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-2xl bg-red-100 text-[#ea4335] flex items-center justify-center font-bold">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-slate-900">Redeem Gift Code</h3>
              <p className="text-[11px] text-slate-400">
                Enter promotional or admin generated gift code
              </p>
            </div>
          </div>

          <form onSubmit={handleRedeem} className="space-y-3">
            <input
              type="text"
              value={giftCodeInput}
              onChange={(e) => setGiftCodeInput(e.target.value)}
              placeholder="Enter 30-character gift code"
              className="w-full px-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono font-bold uppercase tracking-wider focus:outline-none focus:border-[#ea4335]"
              id="gift-code-input"
            />
            <button
              type="submit"
              disabled={isClaimingGift || !giftCodeInput.trim()}
              className="w-full py-2.5 bg-gradient-to-r from-[#ea4335] to-[#d32f2f] text-white font-black rounded-xl text-xs shadow-md active:scale-95 transition-all disabled:opacity-50"
              id="redeem-gift-code-btn"
            >
              {isClaimingGift ? 'Redeeming...' : 'Claim Gift Code'}
            </button>
          </form>
        </div>

        {/* Gift Code Claim History (Real data from Firebase) */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div className="flex items-center space-x-2">
              <div className="w-7 h-7 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center">
                <FileText className="w-3.5 h-3.5" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-900">Gift Code Claim History</h4>
                <span className="text-[10px] text-slate-400">Your personal redemptions</span>
              </div>
            </div>
            <span className="text-[10px] font-bold text-slate-400">
              {userGiftClaims.length} records
            </span>
          </div>

          {userGiftClaims.length > 0 ? (
            <div className="space-y-2.5">
              {userGiftClaims.map((claim) => {
                const dateObj = new Date(claim.claimedAt);
                const dateStr = dateObj.toLocaleDateString('en-US', {
                  day: '2-digit',
                  month: 'short',
                  year: 'numeric'
                });
                const timeStr = dateObj.toLocaleTimeString('en-US', {
                  hour: '2-digit',
                  minute: '2-digit'
                });

                return (
                  <div
                    key={claim.id}
                    className="bg-slate-50 border border-slate-100 rounded-2xl p-3 space-y-1.5 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-slate-800 text-[11px] truncate max-w-[180px]">
                        {claim.code}
                      </span>
                      <span className="font-black text-emerald-600 text-xs">
                        +৳{claim.amount}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span>{dateStr} {timeStr}</span>
                      <span className="bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded-sm font-semibold">
                        Claimed
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-6 text-center text-slate-400 text-xs">
              No gift codes claimed yet. Enter a code above!
            </div>
          )}
        </div>
      </div>

      {/* Rebate Modal */}
      {activeModal === 'rebate' && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-purple-600" />
                <h3 className="font-bold text-sm text-slate-900">Real-time Betting Rebate</h3>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold"
              >
                ✕
              </button>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Every bet you make earns rebate cash returned directly to your account based on your VIP tier. Higher VIP ranks receive up to 1.5% instant rebate rate!
            </p>
            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-2.5 bg-purple-600 text-white rounded-xl text-xs font-bold"
            >
              Got It
            </button>
          </div>
        </div>
      )}

      {/* Super Jackpot Modal */}
      {activeModal === 'jackpot' && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div className="flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold text-sm text-slate-900">Super Jackpot Event</h3>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold"
              >
                ✕
              </button>
            </div>
            <div className="text-center py-2">
              <div className="text-2xl font-black text-amber-500 font-mono">৳8,888,888</div>
              <p className="text-[11px] text-slate-400 mt-1">Current Progressive Prize Pool</p>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Play Win Go, Aviator, or lottery games with valid bets to trigger random multiplier jackpot envelopes!
            </p>
            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-2.5 bg-amber-500 text-white rounded-xl text-xs font-bold"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
