import React, { useState } from 'react';
import {
  Sparkles,
  Plus,
  RotateCcw,
  Edit2,
  Trash2,
  Upload,
  X,
  Tag,
  ExternalLink,
  CalendarCheck,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ActivityBanner } from '../types';
import { uploadToImgBB } from '../utils/imgbb';

export const AdminActivityBannerManagement: React.FC = () => {
  const {
    activityBanners,
    adminAddActivityBanner,
    adminUpdateActivityBanner,
    adminDeleteActivityBanner,
    adminToggleActivityBannerStatus,
    adminResetDefaultActivityBanners,
    showToast
  } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  const [form, setForm] = useState<Omit<ActivityBanner, 'id'>>({
    title: '',
    subtitle: '',
    imageUrl: '',
    badge: 'Check-in Bonus',
    actionType: 'attendance',
    linkUrl: '',
    targetGame: 'wingo',
    order: 1,
    active: true
  });

  const openNewModal = () => {
    setEditingId(null);
    setForm({
      title: '',
      subtitle: '',
      imageUrl: '',
      badge: 'Check-in Bonus',
      actionType: 'attendance',
      linkUrl: '',
      targetGame: 'wingo',
      order: (activityBanners?.length || 0) + 1,
      active: true
    });
    setIsModalOpen(true);
  };

  const openEditModal = (b: ActivityBanner) => {
    setEditingId(b.id);
    setForm({
      title: b.title,
      subtitle: b.subtitle || '',
      imageUrl: b.imageUrl,
      badge: b.badge || '',
      actionType: b.actionType || 'attendance',
      linkUrl: b.linkUrl || '',
      targetGame: b.targetGame || 'wingo',
      order: b.order || 1,
      active: b.active !== false
    });
    setIsModalOpen(true);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingImage(true);
    try {
      const url = await uploadToImgBB(file);
      setForm((prev) => ({ ...prev, imageUrl: url }));
      showToast('Banner image uploaded to ImgBB successfully!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Image upload failed', 'error');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleQuickUpload = async (b: ActivityBanner, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      showToast('Uploading new banner image...', 'info');
      const url = await uploadToImgBB(file);
      await adminUpdateActivityBanner(b.id, { imageUrl: url });
      showToast('Activity banner image updated!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Image upload failed', 'error');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) {
      showToast('Please enter a banner title', 'error');
      return;
    }
    if (!form.imageUrl.trim()) {
      showToast('Please provide an image URL or upload via ImgBB', 'error');
      return;
    }

    try {
      if (editingId) {
        await adminUpdateActivityBanner(editingId, form);
        showToast('Activity banner updated successfully!', 'success');
      } else {
        await adminAddActivityBanner(form);
        showToast('New activity banner added successfully!', 'success');
      }
      setIsModalOpen(false);
    } catch (err: any) {
      showToast(err.message || 'Failed to save banner', 'error');
    }
  };

  const handleDelete = async (id: string, title: string) => {
    if (window.confirm(`Delete activity banner "${title}"?`)) {
      await adminDeleteActivityBanner(id);
      showToast('Banner deleted successfully', 'info');
    }
  };

  return (
    <div className="space-y-4">
      {/* Header bar */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Activity Page Promotional Banners</span>
          </h3>
          <span className="text-[11px] text-slate-400">
            Manage dynamic promotional event banners displayed in the Activity section
          </span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={async () => {
              if (window.confirm('Restore standard default activity banners?')) {
                await adminResetDefaultActivityBanners();
                showToast('Default activity banners restored!', 'success');
              }
            }}
            className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs font-bold flex items-center space-x-1.5 active:scale-95 transition-all"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
            <span>Restore Defaults</span>
          </button>

          <button
            onClick={openNewModal}
            className="px-3.5 py-2 bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-500 hover:to-orange-400 text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 shadow-md active:scale-95 transition-all"
            id="admin-add-activity-banner-btn"
          >
            <Plus className="w-4 h-4" />
            <span>Add Event Banner</span>
          </button>
        </div>
      </div>

      {/* Grid of Banners */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {(activityBanners || [])
          .slice()
          .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
          .map((b) => (
            <div
              key={b.id}
              className="bg-slate-800 rounded-2xl overflow-hidden border border-slate-700 shadow-sm flex flex-col justify-between"
            >
              <div className="relative aspect-21/9 bg-slate-900 overflow-hidden">
                <img
                  src={b.imageUrl || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80'}
                  alt={b.title}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80';
                  }}
                />
                <div className="absolute top-2 left-2 flex items-center space-x-1.5">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-black/70 text-white border border-white/20">
                    Order #{b.order}
                  </span>
                  {b.badge && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-red-600 text-white">
                      {b.badge}
                    </span>
                  )}
                </div>
                <div className="absolute top-2 right-2">
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                      b.active !== false
                        ? 'bg-emerald-500/90 text-white'
                        : 'bg-slate-600/90 text-slate-300'
                    }`}
                  >
                    {b.active !== false ? 'Active' : 'Paused'}
                  </span>
                </div>
              </div>

              <div className="p-3.5 space-y-2 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="font-extrabold text-sm text-white leading-snug">{b.title}</h4>
                  {b.subtitle && (
                    <p className="text-xs text-slate-400 mt-1 font-medium">{b.subtitle}</p>
                  )}
                  <div className="flex items-center space-x-2 mt-2 text-[11px] text-slate-400">
                    <span className="bg-slate-900 px-2 py-0.5 rounded text-amber-400 font-mono font-bold">
                      Action: {b.actionType || 'none'}
                    </span>
                    {b.actionType === 'url' && b.linkUrl && (
                      <span className="truncate max-w-[150px] text-blue-400">{b.linkUrl}</span>
                    )}
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between gap-1.5 flex-wrap">
                  <button
                    onClick={() => adminToggleActivityBannerStatus(b.id, b.active !== false)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      b.active !== false
                        ? 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                        : 'bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30'
                    }`}
                  >
                    {b.active !== false ? 'Pause' : 'Activate'}
                  </button>

                  <label className="px-2.5 py-1.5 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 rounded-xl text-xs font-bold flex items-center space-x-1 cursor-pointer transition-all">
                    <Upload className="w-3 h-3" />
                    <span>ImgBB</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleQuickUpload(b, e)}
                    />
                  </label>

                  <button
                    onClick={() => openEditModal(b)}
                    className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-bold flex items-center space-x-1"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </button>

                  <button
                    onClick={() => handleDelete(b.id, b.title)}
                    className="px-3 py-1.5 bg-red-600/20 hover:bg-red-600 text-red-300 hover:text-white rounded-xl text-xs font-bold flex items-center space-x-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl max-w-md w-full p-5 space-y-4 text-xs shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-700 pb-2">
              <h3 className="font-bold text-sm text-white flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>{editingId ? 'Edit Activity Banner' : 'New Activity Banner'}</span>
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="text-slate-400 font-semibold block mb-1">Banner Title:</label>
                <input
                  type="text"
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="e.g. BGNICE MEMBERS GET REWARDS ON EXECUTING DAILY CHECK-IN"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white font-bold outline-none focus:border-red-500"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 font-semibold block mb-1">Subtitle / Details:</label>
                <input
                  type="text"
                  value={form.subtitle}
                  onChange={(e) => setForm({ ...form, subtitle: e.target.value })}
                  placeholder="e.g. 💰 Recharge and Get Daily Check-in Bonus 💰"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="text-slate-400 font-semibold block mb-1">Badge Tag:</label>
                <input
                  type="text"
                  value={form.badge}
                  onChange={(e) => setForm({ ...form, badge: e.target.value })}
                  placeholder="e.g. Check-in Bonus, Winning Streak, YouTube Video"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white outline-none focus:border-red-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-400 font-semibold">Image URL:</label>
                  <label className="text-[11px] text-amber-400 hover:underline cursor-pointer flex items-center space-x-1">
                    <Upload className="w-3 h-3" />
                    <span>{uploadingImage ? 'Uploading...' : 'Upload via ImgBB'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleImageUpload}
                      disabled={uploadingImage}
                    />
                  </label>
                </div>
                <input
                  type="url"
                  value={form.imageUrl}
                  onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
                  placeholder="https://i.ibb.co/... or https://images.unsplash.com/..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white outline-none focus:border-red-500 font-mono text-[11px]"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 font-semibold block mb-1">Click Action:</label>
                  <select
                    value={form.actionType}
                    onChange={(e) => setForm({ ...form, actionType: e.target.value as any })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white outline-none focus:border-red-500 font-bold"
                  >
                    <option value="attendance">Open Attendance (Check-in)</option>
                    <option value="url">Open External Link</option>
                    <option value="game">Launch Game</option>
                    <option value="none">No Action</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 font-semibold block mb-1">Display Order:</label>
                  <input
                    type="number"
                    value={form.order}
                    onChange={(e) => setForm({ ...form, order: parseInt(e.target.value) || 1 })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white outline-none focus:border-red-500 font-mono"
                  />
                </div>
              </div>

              {form.actionType === 'url' && (
                <div>
                  <label className="text-slate-400 font-semibold block mb-1">External Link URL:</label>
                  <input
                    type="url"
                    value={form.linkUrl}
                    onChange={(e) => setForm({ ...form, linkUrl: e.target.value })}
                    placeholder="https://t.me/... or https://youtube.com/..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white outline-none focus:border-red-500 font-mono text-[11px]"
                  />
                </div>
              )}

              {form.actionType === 'game' && (
                <div>
                  <label className="text-slate-400 font-semibold block mb-1">Target Game:</label>
                  <select
                    value={form.targetGame}
                    onChange={(e) => setForm({ ...form, targetGame: e.target.value as any })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white outline-none focus:border-red-500 font-bold"
                  >
                    <option value="wingo">Win Go Lottery</option>
                    <option value="k3">K3 Lottery</option>
                    <option value="fiveD">5D Lottery</option>
                    <option value="trx">TRX Win Go</option>
                    <option value="aviator">Aviator</option>
                    <option value="aviatorX">Aviator X</option>
                  </select>
                </div>
              )}

              <div className="flex items-center space-x-2 pt-1">
                <input
                  type="checkbox"
                  id="act-banner-active-cb"
                  checked={form.active}
                  onChange={(e) => setForm({ ...form, active: e.target.checked })}
                  className="rounded text-red-600 bg-slate-900 border-slate-700"
                />
                <label htmlFor="act-banner-active-cb" className="text-slate-300 font-semibold cursor-pointer">
                  Banner is Active and Visible to Players
                </label>
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-700">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-red-600 to-orange-500 text-white rounded-xl font-bold shadow-md hover:from-red-500 hover:to-orange-400"
                >
                  {editingId ? 'Save Changes' : 'Create Banner'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
