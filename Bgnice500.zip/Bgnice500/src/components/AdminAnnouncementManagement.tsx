import React, { useState } from 'react';
import {
  Volume2,
  Plus,
  Trash2,
  Edit2,
  Upload,
  ExternalLink,
  Eye,
  CheckCircle,
  XCircle,
  Sparkles,
  RefreshCw,
  Image as ImageIcon
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AnnouncementItem } from '../types';
import { uploadToImgBB } from '../utils/imgbb';

interface AdminAnnouncementManagementProps {
  onShowToast: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const AdminAnnouncementManagement: React.FC<AdminAnnouncementManagementProps> = ({
  onShowToast
}) => {
  const { settings, adminUpdateSettings } = useApp();

  const announcementsMap = settings?.announcements || {};
  const rawList = Object.values(announcementsMap) as AnnouncementItem[];
  const announcementsList: AnnouncementItem[] = rawList.sort(
    (a, b) => (b.priority || 0) - (a.priority || 0) || b.createdAt - a.createdAt
  );

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  // Form state
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formLink, setFormLink] = useState('');
  const [formPriority, setFormPriority] = useState<number>(10);
  const [formActive, setFormActive] = useState<boolean>(true);

  const openNewModal = () => {
    setEditingId(null);
    setFormTitle('');
    setFormContent('');
    setFormImageUrl('');
    setFormLink('');
    setFormPriority(10);
    setFormActive(true);
    setIsModalOpen(true);
  };

  const openEditModal = (item: AnnouncementItem) => {
    setEditingId(item.id);
    setFormTitle(item.title);
    setFormContent(item.content);
    setFormImageUrl(item.imageUrl || '');
    setFormLink(item.link || '');
    setFormPriority(item.priority ?? 10);
    setFormActive(item.active !== false);
    setIsModalOpen(true);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingImage(true);
    try {
      const res = await uploadToImgBB(file);
      if (res.success && res.url) {
        setFormImageUrl(res.url);
        onShowToast('Announcement photo uploaded successfully!', 'success');
      } else {
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            setFormImageUrl(reader.result);
            onShowToast('Announcement photo uploaded successfully!', 'success');
          }
        };
        reader.readAsDataURL(file);
      }
    } catch {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setFormImageUrl(reader.result);
          onShowToast('Announcement photo uploaded successfully!', 'success');
        }
      };
      reader.readAsDataURL(file);
    } finally {
      setUploadingImage(false);
      e.target.value = '';
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) {
      onShowToast('Please enter both title and content for announcement', 'error');
      return;
    }

    const id = editingId || `ann_${Date.now()}`;
    const newAnnouncement: AnnouncementItem = {
      id,
      title: formTitle.trim(),
      content: formContent.trim(),
      ...(formImageUrl.trim() ? { imageUrl: formImageUrl.trim() } : {}),
      ...(formLink.trim() ? { link: formLink.trim() } : {}),
      priority: Number(formPriority) || 0,
      active: formActive,
      createdAt: editingId ? announcementsMap[editingId]?.createdAt || Date.now() : Date.now()
    };

    const updated = {
      ...announcementsMap,
      [id]: newAnnouncement
    };

    await adminUpdateSettings({ announcements: updated });
    onShowToast(
      editingId ? 'Announcement updated successfully!' : 'New announcement added to home dashboard!',
      'success'
    );
    setIsModalOpen(false);
  };

  const handleDelete = async (id: string, title: string) => {
    if (!window.confirm(`Are you sure you want to delete announcement "${title}"?`)) return;
    const updated = { ...announcementsMap };
    delete updated[id];
    await adminUpdateSettings({ announcements: updated });
    onShowToast('Announcement deleted from system', 'info');
  };

  const handleToggleActive = async (item: AnnouncementItem) => {
    const nextActive = !item.active;
    const updated = {
      ...announcementsMap,
      [item.id]: {
        ...item,
        active: nextActive
      }
    };
    await adminUpdateSettings({ announcements: updated });
    onShowToast(
      `Announcement "${item.title}" is now ${nextActive ? 'Active (Live)' : 'Inactive (Hidden)'}`,
      'info'
    );
  };

  return (
    <div className="space-y-4 select-none">
      {/* Top Banner Header */}
      <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center space-x-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-red-500 to-orange-500 text-white flex items-center justify-center shadow-lg shadow-red-500/20 shrink-0">
            <Volume2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-white flex items-center space-x-2">
              <span>Home Dashboard Unlimited Announcements</span>
              <span className="text-[10px] bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded-full font-bold">
                Unlimited Photos & Text
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Add unlimited photo & text announcements to home dashboard with full admin control
            </p>
          </div>
        </div>

        <button
          onClick={openNewModal}
          className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-400 hover:to-orange-400 text-white font-black text-xs flex items-center space-x-2 shadow-lg active:scale-95 transition-all shrink-0 cursor-pointer"
          id="add-new-announcement-btn"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Announcement</span>
        </button>
      </div>

      {/* Announcements List */}
      <div className="bg-slate-950 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 px-1">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-black text-white uppercase tracking-wider">
              Live Active Announcements
            </span>
            <span className="text-[11px] font-mono font-bold text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2 py-0.2 rounded-full">
              {announcementsList.length} total
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            Higher priority announcements appear first on player screens
          </span>
        </div>

        {announcementsList.length === 0 ? (
          <div className="py-12 text-center text-slate-500 space-y-3">
            <div className="w-14 h-14 mx-auto rounded-3xl bg-slate-900 border border-slate-800 flex items-center justify-center text-2xl">
              📢
            </div>
            <p className="text-xs text-slate-400">No custom announcements created yet.</p>
            <button
              onClick={openNewModal}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold rounded-xl border border-slate-700 transition-all cursor-pointer"
            >
              + Create First Photo Announcement
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {announcementsList.map((item) => (
              <div
                key={item.id}
                className={`p-4 rounded-2xl border transition-all flex flex-col justify-between space-y-3 ${
                  item.active !== false
                    ? 'bg-slate-900/90 border-slate-800 hover:border-slate-700 shadow-md'
                    : 'bg-slate-950/60 border-slate-900 opacity-60'
                }`}
                id={`announcement-card-${item.id}`}
              >
                {/* Image if present */}
                {Boolean(item.imageUrl && item.imageUrl.trim()) && (
                  <div className="relative w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800/80 max-h-60 flex items-center justify-center p-1">
                    <img
                      src={item.imageUrl}
                      alt={item.title}
                      className="w-full h-auto max-h-56 object-contain rounded-lg"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                    <div className="absolute top-2 right-2 bg-black/70 backdrop-blur-xs text-[10px] font-bold text-white px-2 py-0.5 rounded-full flex items-center space-x-1">
                      <ImageIcon className="w-3 h-3 text-amber-400" />
                      <span>Photo Attached</span>
                    </div>
                  </div>
                )}

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-black text-sm text-white truncate">{item.title}</h3>
                    <div className="flex items-center space-x-1.5 shrink-0">
                      <span className="text-[10px] font-mono text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                        P:{item.priority ?? 10}
                      </span>
                      {item.active !== false ? (
                        <span className="text-[10px] font-bold text-green-400 bg-green-500/10 border border-green-500/30 px-1.5 py-0.5 rounded flex items-center space-x-1">
                          <CheckCircle className="w-2.5 h-2.5" />
                          <span>Active</span>
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded flex items-center space-x-1">
                          <XCircle className="w-2.5 h-2.5" />
                          <span>Inactive</span>
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 line-clamp-3 leading-relaxed whitespace-pre-line bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/60 font-sans">
                    {item.content}
                  </p>

                  {item.link && (
                    <div className="flex items-center space-x-1 text-[11px] text-amber-400 truncate pt-0.5">
                      <ExternalLink className="w-3 h-3 shrink-0" />
                      <span className="truncate">{item.link}</span>
                    </div>
                  )}
                </div>

                {/* Bottom Action Controls */}
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                  <button
                    onClick={() => handleToggleActive(item)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      item.active !== false
                        ? 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                        : 'bg-green-600 hover:bg-green-500 text-white'
                    }`}
                  >
                    {item.active !== false ? 'Hide Announcement' : 'Set Active (Show)'}
                  </button>

                  <div className="flex items-center space-x-1.5">
                    <button
                      onClick={() => openEditModal(item)}
                      className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 transition-colors cursor-pointer"
                      title="Edit"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(item.id, item.title)}
                      className="p-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors cursor-pointer"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add/Edit Announcement Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 shrink-0">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center">
                  <Volume2 className="w-4 h-4" />
                </div>
                <h3 className="font-black text-sm text-white">
                  {editingId ? 'Edit Announcement' : 'Add New Photo & Text Announcement'}
                </h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="overflow-y-auto space-y-3.5 flex-1 pr-1">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Announcement Title <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g., 24/7 Automated Nagad & bKash Deposit Active"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:border-red-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Announcement Content / Text Details <span className="text-red-400">*</span>
                </label>
                <textarea
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  placeholder="Enter the full announcement text message for players..."
                  rows={4}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:border-red-500 outline-none resize-none font-sans"
                  required
                />
              </div>

              {/* Photo Upload or Direct URL */}
              <div className="space-y-2 bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800/80">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                    <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
                    <span>Announcement Photo (Optional)</span>
                  </label>
                  <label className="px-3 py-1 bg-red-600 hover:bg-red-500 text-white rounded-xl text-[11px] font-bold flex items-center space-x-1 cursor-pointer transition-colors">
                    <Upload className="w-3 h-3" />
                    <span>{uploadingImage ? 'Uploading...' : 'Upload Image (ImgBB)'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      disabled={uploadingImage}
                      className="hidden"
                    />
                  </label>
                </div>

                <input
                  type="url"
                  value={formImageUrl}
                  onChange={(e) => setFormImageUrl(e.target.value)}
                  placeholder="Or enter direct image URL (https://...)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-red-500 outline-none"
                />

                {Boolean(formImageUrl && formImageUrl.trim()) && (
                  <div className="relative w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800 mt-2 max-h-72 flex items-center justify-center p-1">
                    <img
                      src={formImageUrl}
                      alt="Preview"
                      className="w-full h-auto max-h-68 object-contain rounded-lg"
                      onError={() => onShowToast('Image failed to load, check URL', 'warning')}
                    />
                    <button
                      type="button"
                      onClick={() => setFormImageUrl('')}
                      className="absolute top-2 right-2 bg-rose-600 text-white px-2 py-0.5 rounded-lg text-[10px] font-bold shadow-md"
                    >
                      Remove Photo
                    </button>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Action Link (Optional)
                  </label>
                  <input
                    type="url"
                    value={formLink}
                    onChange={(e) => setFormLink(e.target.value)}
                    placeholder="https://t.me/... or official link"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-red-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Priority Sort Order
                  </label>
                  <input
                    type="number"
                    value={formPriority}
                    onChange={(e) => setFormPriority(Number(e.target.value))}
                    min={1}
                    max={999}
                    placeholder="10"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-red-500 outline-none font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2 pt-1">
                <input
                  type="checkbox"
                  id="ann-active-check"
                  checked={formActive}
                  onChange={(e) => setFormActive(e.target.checked)}
                  className="rounded bg-slate-950 border-slate-700 text-red-600 focus:ring-0 cursor-pointer"
                />
                <label htmlFor="ann-active-check" className="text-xs font-bold text-slate-300 cursor-pointer">
                  Show Announcement to Players Immediately (Active Live)
                </label>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end space-x-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-400 hover:to-orange-400 text-white rounded-xl text-xs font-black shadow-lg cursor-pointer"
                >
                  {editingId ? 'Save Changes' : 'Publish Announcement'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
