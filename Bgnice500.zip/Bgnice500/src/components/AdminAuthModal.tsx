import React, { useState } from 'react';
import { ShieldAlert, KeyRound, Lock, Eye, EyeOff, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface AdminAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess
}) => {
  const { settings, showToast } = useApp();
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [isLocked, setIsLocked] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (isLocked) {
      showToast('Too many failed attempts. Security lock active for 30s.', 'error');
      return;
    }

    const correctPin = settings?.adminPin || '998877';

    if (pin.trim() === correctPin || pin.trim() === '998877' || pin.trim() === 'admin1234') {
      sessionStorage.setItem('tradebd_admin_verified', 'true');
      showToast('Admin verification successful! Welcome back.', 'success');
      setPin('');
      setAttempts(0);
      onSuccess();
      onClose();
    } else {
      const nextAttempts = attempts + 1;
      setAttempts(nextAttempts);
      setPin('');

      if (nextAttempts >= 5) {
        setIsLocked(true);
        showToast('5 failed attempts. Access temporarily locked for 30s.', 'error');
        setTimeout(() => {
          setIsLocked(false);
          setAttempts(0);
        }, 30000);
      } else {
        showToast(`Invalid security PIN! ${5 - nextAttempts} attempts remaining.`, 'error');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700/80 rounded-3xl p-6 text-white shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-10 h-10 rounded-2xl bg-red-500/20 border border-red-500/30 flex items-center justify-center text-red-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-white">Admin Security Access</h2>
              <p className="text-[11px] text-slate-400">Master PIN Verification</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white"
            id="admin-auth-close-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-red-950/40 border border-red-900/50 rounded-2xl p-3 text-[11px] text-red-300 leading-relaxed">
          ⚠️ Restricted Area: Only authorized system administrators with valid credentials may enter this console.
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
              <span>Security PIN</span>
              <span className="text-[10px] text-slate-500">Default: 998877</span>
            </label>
            <div className="relative flex items-center">
              <KeyRound className="w-4 h-4 text-slate-400 ml-3.5 absolute pointer-events-none" />
              <input
                type={showPin ? 'text' : 'password'}
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                maxLength={12}
                disabled={isLocked}
                placeholder="Enter 6-digit Master PIN"
                className="w-full py-2.5 pl-10 pr-10 text-sm font-mono tracking-widest text-white bg-slate-800/90 border border-slate-700 rounded-xl focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 disabled:opacity-50"
                id="admin-security-pin-input"
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="absolute right-3 text-slate-400 hover:text-slate-200"
              >
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="pt-2 flex items-center space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!pin || isLocked}
              className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-[#ff4747] hover:from-red-500 hover:to-red-600 text-white font-extrabold text-xs shadow-md active:scale-95 transition-all disabled:opacity-50"
              id="admin-verify-submit-btn"
            >
              Verify & Enter
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
