import React, { useState, useEffect, useRef } from 'react';
import {
  MessageCircle,
  Send,
  CheckCheck,
  Clock,
  User,
  Search,
  RefreshCw,
  Phone,
  Mail,
  ShieldCheck,
  CheckCircle,
  XCircle,
  AlertCircle,
  Image as ImageIcon,
  ZoomIn,
  Trash2,
  Loader2,
  X
} from 'lucide-react';
import { ref, onValue, push, set, update } from 'firebase/database';
import { rtdb } from '../lib/firebase';
import { SupportChat, SupportMessage } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { stripUndefined } from '../context/AppContext';
import { uploadToImgBB } from '../utils/imgbb';

interface AdminChatManagementProps {
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const AdminChatManagement: React.FC<AdminChatManagementProps> = ({ onShowToast }) => {
  const { language } = useLanguage();
  const [chats, setChats] = useState<SupportChat[]>([]);
  const [selectedChat, setSelectedChat] = useState<SupportChat | null>(null);
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [replyText, setReplyText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'closed'>('all');
  const [adminAgentName, setAdminAgentName] = useState('BGNICE Official Admin');

  // Image upload state for Admin
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [selectedImagePreview, setSelectedImagePreview] = useState<string | null>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      onShowToast(language === 'bn' ? 'দয়া করে একটি সঠিক ছবি সিলেক্ট করুন' : 'Please select a valid image file', 'error');
      return;
    }

    setSelectedImageFile(file);
    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const removeSelectedImage = () => {
    setSelectedImageFile(null);
    setSelectedImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // 1. Fetch all live support chats from root RTDB index
  useEffect(() => {
    const indexRef = ref(rtdb, 'supportChatsIndex');
    const unsub = onValue(indexRef, (snapshot) => {
      if (snapshot.exists()) {
        const raw = snapshot.val();
        const list: SupportChat[] = [];
        if (raw && typeof raw === 'object') {
          Object.entries(raw).forEach(([key, val]: [string, any]) => {
            if (key === 'undefined' || key === 'null') return;
            if (val && typeof val === 'object') {
              const safeChatId = val.chatId && val.chatId !== 'undefined' ? String(val.chatId) : key;
              list.push({
                ...val,
                chatId: safeChatId
              });
            }
          });
        }
        list.sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0));
        setChats(list);

        // Keep selectedChat updated with fresh metadata if selected
        if (selectedChat) {
          const fresh = list.find((c) => c.chatId === selectedChat.chatId);
          if (fresh) setSelectedChat(fresh);
        }
      } else {
        setChats([]);
      }
    });

    return () => unsub();
  }, [selectedChat?.chatId]);

  // 2. Fetch messages for selected chat
  useEffect(() => {
    if (!selectedChat?.chatId || selectedChat.chatId === 'undefined') {
      setMessages([]);
      return;
    }

    const messagesRef = ref(rtdb, `messages/${selectedChat.chatId}`);
    const unsub = onValue(messagesRef, (snapshot) => {
      if (snapshot.exists()) {
        const raw = snapshot.val();
        const list: SupportMessage[] = [];
        if (raw && typeof raw === 'object') {
          Object.entries(raw).forEach(([k, v]: [string, any]) => {
            if (v && typeof v === 'object') {
              list.push({
                ...v,
                id: v.id || k
              });
            }
          });
        }
        list.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
        setMessages(list);
        setTimeout(scrollToBottom, 100);
      } else {
        setMessages([]);
      }
    });

    return () => unsub();
  }, [selectedChat?.chatId]);

  // 3. Send admin reply
  const handleSendReply = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!replyText.trim() && !selectedImageFile) || !selectedChat?.chatId || selectedChat.chatId === 'undefined') return;

    const textToSend = replyText.trim();
    setReplyText('');
    setIsSending(true);

    try {
      let uploadedImageUrl: string | undefined = undefined;
      if (selectedImageFile) {
        setIsUploadingImage(true);
        onShowToast(language === 'bn' ? 'ImgBB তে ছবি আপলোড হচ্ছে...' : 'Uploading image to ImgBB...', 'info');
        const uploadRes = await uploadToImgBB(selectedImageFile);
        if (!uploadRes.success || !uploadRes.url) {
          throw new Error(uploadRes.error || 'ImgBB upload failed');
        }
        uploadedImageUrl = uploadRes.url;
        removeSelectedImage();
      }

      const chatId = selectedChat.chatId;
      const userUid = selectedChat.userUid || selectedChat.userId;

      const newMsgRef = push(ref(rtdb, `messages/${chatId}`));
      const newMsg: SupportMessage = {
        id: newMsgRef.key || `msg_${Date.now()}`,
        chatId,
        senderId: 'admin_official',
        senderType: 'admin',
        message: textToSend || (uploadedImageUrl ? '📷 Image' : ''),
        ...(uploadedImageUrl ? { imageUrl: uploadedImageUrl } : {}),
        timestamp: Date.now(),
        read: true
      };
      await set(newMsgRef, stripUndefined(newMsg));

      // Update chat meta in user's support chats and root index
      const updates: any = {};
      const displayMsg = textToSend || (uploadedImageUrl ? '📷 Image Attachment' : 'Admin Reply');
      const updatedMeta = {
        lastMessage: displayMsg,
        updatedAt: Date.now(),
        status: 'active',
        agentName: adminAgentName
      };

      if (userUid) {
        updates[`supportChats/${userUid}/${chatId}/lastMessage`] = displayMsg;
        updates[`supportChats/${userUid}/${chatId}/updatedAt`] = Date.now();
        updates[`supportChats/${userUid}/${chatId}/agentName`] = adminAgentName;
      }
      updates[`supportChatsIndex/${chatId}/lastMessage`] = displayMsg;
      updates[`supportChatsIndex/${chatId}/updatedAt`] = Date.now();
      updates[`supportChatsIndex/${chatId}/agentName`] = adminAgentName;

      await update(ref(rtdb), updates);

      onShowToast(language === 'bn' ? 'রিপ্লাই সফলভাবে পাঠানো হয়েছে!' : 'Reply sent successfully!', 'success');
      setTimeout(scrollToBottom, 100);
    } catch (err: any) {
      onShowToast(err?.message || 'Failed to send reply', 'error');
    } finally {
      setIsSending(false);
      setIsUploadingImage(false);
    }
  };

  // 4. Close or reopen chat
  const handleToggleChatStatus = async (chat: SupportChat) => {
    try {
      const newStatus = chat.status === 'active' ? 'closed' : 'active';
      const userUid = chat.userUid || chat.userId;
      const updates: any = {};

      if (userUid) {
        updates[`supportChats/${userUid}/${chat.chatId}/status`] = newStatus;
        if (newStatus === 'closed') {
          updates[`supportChats/${userUid}/${chat.chatId}/closedAt`] = Date.now();
        }
      }
      updates[`supportChatsIndex/${chat.chatId}/status`] = newStatus;
      if (newStatus === 'closed') {
        updates[`supportChatsIndex/${chat.chatId}/closedAt`] = Date.now();
      }

      await update(ref(rtdb), updates);
      onShowToast(
        newStatus === 'closed'
          ? (language === 'bn' ? 'চ্যাট বন্ধ করা হয়েছে' : 'Chat marked as closed')
          : (language === 'bn' ? 'চ্যাট সক্রিয় করা হয়েছে' : 'Chat reopened'),
        'info'
      );
    } catch (err: any) {
      onShowToast(err?.message || 'Failed to update status', 'error');
    }
  };

  // Filtered chats
  const filteredChats = chats.filter((c) => {
    if (statusFilter !== 'all' && c.status !== statusFilter) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      (c.username && c.username.toLowerCase().includes(q)) ||
      (c.userId && c.userId.toLowerCase().includes(q)) ||
      (c.userPhone && c.userPhone.includes(q)) ||
      (c.chatId && c.chatId.toLowerCase().includes(q))
    );
  });

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl text-slate-100 space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-600 to-amber-500 text-white flex items-center justify-center shadow-md">
            <MessageCircle className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-black text-white flex items-center space-x-2">
              <span>{language === 'bn' ? 'লাইভ চ্যাট ম্যানেজমেন্ট ও রিপ্লাই' : 'Live Chat Management & Admin Reply'}</span>
              <span className="bg-red-500/20 text-red-400 border border-red-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full">
                {chats.filter((c) => c.status === 'active').length} Active
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              {language === 'bn'
                ? 'ইউজারদের লাইভ সাপোর্ট মেসেজের সরাসরি উত্তর দিন'
                : 'Directly manage user support conversations and send real-time replies'}
            </p>
          </div>
        </div>

        {/* Admin display name configurator */}
        <div className="flex items-center space-x-2 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700/60 text-xs">
          <span className="text-slate-400 font-bold">{language === 'bn' ? 'অ্যাডমিন নাম:' : 'Agent Name:'}</span>
          <input
            type="text"
            value={adminAgentName}
            onChange={(e) => setAdminAgentName(e.target.value)}
            className="bg-transparent text-white font-bold focus:outline-none w-36 text-xs"
            placeholder="Agent Name"
          />
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 min-h-[480px]">
        {/* Left Column: Chat List */}
        <div className="md:col-span-5 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3 flex flex-col space-y-3">
          {/* Search & Status Filter */}
          <div className="space-y-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={language === 'bn' ? 'ইউজার বা ফোন খুঁজুন...' : 'Search user, phone or ID...'}
                className="w-full pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-700/70 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <div className="flex items-center space-x-1.5">
              {(['all', 'active', 'closed'] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold capitalize transition-all ${
                    statusFilter === s
                      ? 'bg-red-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {s === 'all'
                    ? (language === 'bn' ? 'সকল' : 'All')
                    : s === 'active'
                    ? (language === 'bn' ? 'সক্রিয়' : 'Active')
                    : (language === 'bn' ? 'বন্ধ' : 'Closed')}
                </button>
              ))}
            </div>
          </div>

          {/* Conversation List */}
          <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 max-h-[400px]">
            {filteredChats.length === 0 ? (
              <div className="text-center py-10 text-slate-500 text-xs">
                <MessageCircle className="w-8 h-8 mx-auto mb-2 opacity-30" />
                {language === 'bn' ? 'কোনো চ্যাট পাওয়া যায়নি' : 'No support conversations found'}
              </div>
            ) : (
              filteredChats.map((chat, cIdx) => {
                const isSelected = selectedChat?.chatId === chat.chatId;
                return (
                  <div
                    key={`adm-chat-${chat.chatId || cIdx}-${cIdx}`}
                    onClick={() => setSelectedChat(chat)}
                    className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-start justify-between space-x-2 ${
                      isSelected
                        ? 'bg-red-600/20 border-red-500/80 text-white'
                        : 'bg-slate-900/80 border-slate-800 hover:bg-slate-800/60 text-slate-300'
                    }`}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-1.5">
                        <span className="font-bold text-xs truncate text-white">
                          {chat.username || 'User'}
                        </span>
                        <span
                          className={`text-[9px] font-extrabold px-1.5 py-0.2 rounded-full uppercase ${
                            chat.status === 'active'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {chat.status}
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-400 truncate mt-0.5">
                        {chat.lastMessage || 'Conversation started'}
                      </p>

                      <div className="flex items-center space-x-2 text-[10px] text-slate-500 mt-1 font-mono">
                        <span>UID: {chat.userId || chat.userUid?.slice(0, 6)}</span>
                        {chat.userPhone && <span>• {chat.userPhone}</span>}
                      </div>
                    </div>

                    <div className="text-[9px] text-slate-500 whitespace-nowrap">
                      {new Date(chat.updatedAt || chat.createdAt || Date.now()).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Chat Box & Reply Area */}
        <div className="md:col-span-7 bg-slate-950/60 border border-slate-800/80 rounded-2xl flex flex-col overflow-hidden">
          {selectedChat ? (
            <>
              {/* Active Chat Top Header */}
              <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-red-600 to-amber-500 text-white flex items-center justify-center font-bold text-xs">
                    {selectedChat.username?.charAt(0)?.toUpperCase() || 'U'}
                  </div>
                  <div>
                    <h3 className="font-bold text-xs text-white flex items-center space-x-1.5">
                      <span>{selectedChat.username || 'User'}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        (UID: {selectedChat.userId || selectedChat.userUid?.slice(0, 6)})
                      </span>
                    </h3>
                    <div className="flex items-center space-x-2 text-[10px] text-slate-400">
                      {selectedChat.userPhone && (
                        <span className="flex items-center space-x-0.5">
                          <Phone className="w-2.5 h-2.5" />
                          <span>{selectedChat.userPhone}</span>
                        </span>
                      )}
                      {selectedChat.userEmail && (
                        <span className="flex items-center space-x-0.5">
                          <Mail className="w-2.5 h-2.5" />
                          <span>{selectedChat.userEmail}</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Status Toggle Button */}
                <button
                  onClick={() => handleToggleChatStatus(selectedChat)}
                  className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all flex items-center space-x-1 ${
                    selectedChat.status === 'active'
                      ? 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                      : 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30'
                  }`}
                >
                  {selectedChat.status === 'active' ? (
                    <>
                      <XCircle className="w-3.5 h-3.5 text-red-400" />
                      <span>{language === 'bn' ? 'চ্যাট বন্ধ করুন' : 'Close Chat'}</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{language === 'bn' ? 'পুনরায় সক্রিয় করুন' : 'Reopen Chat'}</span>
                    </>
                  )}
                </button>
              </div>

              {/* Messages Scroll Area */}
              <div className="flex-1 p-3 overflow-y-auto space-y-2.5 max-h-[340px] bg-slate-950/40">
                {messages.length === 0 ? (
                  <div className="text-center py-12 text-slate-500 text-xs">
                    {language === 'bn' ? 'বার্তা লোড হচ্ছে...' : 'Loading messages...'}
                  </div>
                ) : (
                  messages.map((msg, mIdx) => {
                    const isAdmin = msg.senderType === 'admin';
                    return (
                      <div
                        key={`adm-msg-${msg.id || mIdx}-${mIdx}`}
                        className={`flex flex-col ${isAdmin ? 'items-end' : 'items-start'}`}
                      >
                        <div className="text-[10px] text-slate-500 mb-0.5 px-1 font-bold">
                          {isAdmin ? adminAgentName : (selectedChat.username || 'User')}
                        </div>
                        <div
                          className={`max-w-[80%] rounded-2xl p-2.5 text-xs leading-relaxed shadow-sm ${
                            isAdmin
                              ? 'bg-gradient-to-r from-red-600 to-[#ff4747] text-white rounded-br-none'
                              : 'bg-slate-800 text-slate-100 rounded-bl-none border border-slate-700/80'
                          }`}
                        >
                          {Boolean(msg.imageUrl && msg.imageUrl.trim()) && (
                            <div
                              className="mb-1.5 rounded-xl overflow-hidden bg-black/20 relative group cursor-pointer"
                              onClick={() => setLightboxImage(msg.imageUrl || null)}
                            >
                              <img
                                src={msg.imageUrl}
                                alt="Attachment"
                                className="max-h-48 max-w-full rounded-xl object-contain hover:scale-102 transition-transform duration-200"
                                loading="lazy"
                              />
                              <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-xl">
                                <span className="text-[10px] bg-black/70 text-white px-2 py-0.5 rounded-full flex items-center gap-1 font-sans">
                                  <ZoomIn className="w-3 h-3" /> Zoom
                                </span>
                              </div>
                            </div>
                          )}
                          {msg.message && (
                            <p className="whitespace-pre-wrap break-words">{msg.message}</p>
                          )}
                        </div>
                        <span className="text-[9px] text-slate-500 mt-0.5 px-1">
                          {new Date(msg.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Admin Image Attachment Preview */}
              {Boolean(selectedImagePreview && selectedImagePreview.trim()) && (
                <div className="px-3 py-1.5 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <img
                      src={selectedImagePreview}
                      alt="Selected preview"
                      className="w-10 h-10 object-cover rounded-lg border border-slate-700"
                    />
                    <span className="text-[11px] text-slate-300 font-medium">Image attached (ImgBB)</span>
                  </div>
                  <button
                    type="button"
                    onClick={removeSelectedImage}
                    className="p-1 text-red-400 hover:bg-slate-800 rounded-md"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Reply Form */}
              <form
                onSubmit={handleSendReply}
                className="p-2.5 bg-slate-900 border-t border-slate-800 flex items-center space-x-2"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageFileChange}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isSending || isUploadingImage}
                  className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-colors disabled:opacity-50 shrink-0"
                  title="Attach image (ImgBB)"
                >
                  <ImageIcon className="w-4 h-4" />
                </button>

                <input
                  type="text"
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder={
                    selectedImagePreview
                      ? (language === 'bn' ? 'ছবির সাথে বিবরণ লিখুন (ঐচ্ছিক)...' : 'Add image description...')
                      : (language === 'bn' ? 'অ্যাডমিন হিসেবে রিপ্লাই লিখুন...' : 'Type official admin reply...')
                  }
                  className="flex-1 px-3 py-2 bg-slate-950 border border-slate-700/70 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
                <button
                  type="submit"
                  disabled={isSending || isUploadingImage || (!replyText.trim() && !selectedImageFile)}
                  className="px-4 py-2 bg-gradient-to-r from-red-600 to-[#ff4747] hover:from-red-500 hover:to-red-600 text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all disabled:opacity-40 active:scale-95 shadow-md cursor-pointer"
                >
                  {isSending || isUploadingImage ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Send className="w-3.5 h-3.5" />
                  )}
                  <span>{language === 'bn' ? 'পাঠান' : 'Reply'}</span>
                </button>
              </form>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-500">
              <MessageCircle className="w-12 h-12 mb-3 text-slate-600 opacity-40" />
              <h4 className="text-sm font-bold text-slate-300">
                {language === 'bn' ? 'কোনো চ্যাট নির্বাচিত হয়নি' : 'No Chat Selected'}
              </h4>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">
                {language === 'bn'
                  ? 'বামপাশের তালিকা থেকে যেকোনো ইউজারের চ্যাটে ক্লিক করে বার্তা দেখুন ও উত্তর দিন।'
                  : 'Select a conversation from the left panel to review messages and reply in real-time.'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Lightbox Modal */}
      {Boolean(lightboxImage && lightboxImage.trim()) && (
        <div
          className="fixed inset-0 z-[100000] bg-black/90 flex items-center justify-center p-4 backdrop-blur-xs"
          onClick={() => setLightboxImage(null)}
        >
          <div className="relative max-w-xl max-h-[85vh] flex flex-col items-center">
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute -top-10 right-0 p-2 text-white/80 hover:text-white bg-white/10 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={lightboxImage}
              alt="Full size attachment"
              className="max-h-[80vh] max-w-full rounded-2xl shadow-2xl object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        </div>
      )}
    </div>
  );
};
