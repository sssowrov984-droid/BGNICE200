import React, { useState } from 'react';
import {
  Gamepad2,
  Dice5,
  Plane,
  Sparkles,
  RefreshCw,
  Check,
  X,
  Upload,
  Image as ImageIcon,
  Sliders,
  RotateCcw,
  Power,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DEFAULT_FEATURED_GAMES } from '../data/featuredGames';
import { uploadToImgBB } from '../utils/imgbb';

interface AdminGameControlsProps {
  onShowToast: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const AdminGameControls: React.FC<AdminGameControlsProps> = ({ onShowToast }) => {
  const { settings, adminUpdateSettings } = useApp();
  const gameControls = settings?.gameControls || {};
  const gameCardImages = settings?.gameCardImages || {};

  // Enabled / Disabled Game status (Default true if not specified)
  const enabledGames = {
    wingo: settings?.enabledGames?.wingo !== false,
    k3: settings?.enabledGames?.k3 !== false,
    fiveD: settings?.enabledGames?.fiveD !== false,
    trx: settings?.enabledGames?.trx !== false,
    aviator: settings?.enabledGames?.aviator !== false,
    aviatorX: settings?.enabledGames?.aviatorX !== false,
  };

  const [togglingGameId, setTogglingGameId] = useState<string | null>(null);

  const handleToggleGame = async (
    gameId: 'wingo' | 'k3' | 'fiveD' | 'trx' | 'aviator' | 'aviatorX',
    gameName: string
  ) => {
    try {
      setTogglingGameId(gameId);
      const nextState = !enabledGames[gameId];
      const updated = {
        ...(settings?.enabledGames || {}),
        [gameId]: nextState
      };
      await adminUpdateSettings({ enabledGames: updated });
      onShowToast(
        `${gameName} is now ${nextState ? 'ON (সচল/চালু)' : 'OFF (বন্ধ/মেইনটেন্যান্স)'}`,
        nextState ? 'success' : 'warning'
      );
    } catch (e: any) {
      onShowToast(e.message || 'Failed to update game status', 'error');
    } finally {
      setTogglingGameId(null);
    }
  };

  // K3 Dice Forced Outcomes (3 dice, 1-6)
  const currentK3 = gameControls.k3Dice || null;
  const [k3Die1, setK3Die1] = useState<number>(currentK3 ? currentK3[0] : 1);
  const [k3Die2, setK3Die2] = useState<number>(currentK3 ? currentK3[1] : 2);
  const [k3Die3, setK3Die3] = useState<number>(currentK3 ? currentK3[2] : 3);

  // 5D Numbers (5 digits, 0-9)
  const current5D = gameControls.fiveDNumbers || null;
  const [fiveDNums, setFiveDNums] = useState<number[]>(current5D || [2, 4, 6, 8, 9]);

  // TRX WinGo Number (0-9)
  const currentTrx = gameControls.trxWinningNumber ?? null;
  const [trxNum, setTrxNum] = useState<number>(currentTrx !== null ? currentTrx : 5);

  // Aviator Crash Multiplier
  const currentAviator = gameControls.aviatorCrash ?? null;
  const [aviatorCrash, setAviatorCrash] = useState<string>(currentAviator ? currentAviator.toFixed(2) : '2.50');

  // Aviator X Crash Multiplier
  const currentAviatorX = gameControls.aviatorXCrash ?? null;
  const [aviatorXCrash, setAviatorXCrash] = useState<string>(currentAviatorX ? currentAviatorX.toFixed(2) : '5.00');

  // Category Cards Images
  const [uploadingCardId, setUploadingCardId] = useState<string | null>(null);

  // Handlers for K3
  const handleSaveK3 = async () => {
    const dice = [Number(k3Die1), Number(k3Die2), Number(k3Die3)];
    await adminUpdateSettings({
      gameControls: {
        ...gameControls,
        k3Dice: dice
      }
    });
    onShowToast(`K3 next round forced to dice: [${dice.join(', ')}] (Sum: ${dice.reduce((a, b) => a + b, 0)})`, 'success');
  };

  const handleClearK3 = async () => {
    const updated = { ...gameControls };
    delete updated.k3Dice;
    await adminUpdateSettings({ gameControls: updated });
    onShowToast('K3 forced result cleared - now 100% fair random', 'info');
  };

  // Handlers for 5D
  const handleSave5D = async () => {
    await adminUpdateSettings({
      gameControls: {
        ...gameControls,
        fiveDNumbers: fiveDNums
      }
    });
    onShowToast(`5D next round forced to numbers: ${fiveDNums.join(' ')}`, 'success');
  };

  const handleClear5D = async () => {
    const updated = { ...gameControls };
    delete updated.fiveDNumbers;
    await adminUpdateSettings({ gameControls: updated });
    onShowToast('5D forced result cleared - now 100% fair random', 'info');
  };

  // Handlers for TRX
  const handleSaveTrx = async () => {
    await adminUpdateSettings({
      gameControls: {
        ...gameControls,
        trxWinningNumber: Number(trxNum)
      }
    });
    onShowToast(`TRX WinGo next round forced to number: ${trxNum}`, 'success');
  };

  const handleClearTrx = async () => {
    const updated = { ...gameControls };
    delete updated.trxWinningNumber;
    await adminUpdateSettings({ gameControls: updated });
    onShowToast('TRX WinGo forced result cleared - now 100% fair hash random', 'info');
  };

  // Handlers for Aviator
  const handleSaveAviator = async () => {
    const val = parseFloat(aviatorCrash);
    if (isNaN(val) || val < 1.0) {
      onShowToast('Please enter a valid multiplier ≥ 1.00x', 'error');
      return;
    }
    await adminUpdateSettings({
      gameControls: {
        ...gameControls,
        aviatorCrash: val
      }
    });
    onShowToast(`Aviator next flight crash forced to ${val.toFixed(2)}x`, 'success');
  };

  const handleClearAviator = async () => {
    const updated = { ...gameControls };
    delete updated.aviatorCrash;
    await adminUpdateSettings({ gameControls: updated });
    onShowToast('Aviator forced crash cleared - now random trajectory', 'info');
  };

  // Handlers for Aviator X
  const handleSaveAviatorX = async () => {
    const val = parseFloat(aviatorXCrash);
    if (isNaN(val) || val < 1.0) {
      onShowToast('Please enter a valid multiplier ≥ 1.00x', 'error');
      return;
    }
    await adminUpdateSettings({
      gameControls: {
        ...gameControls,
        aviatorXCrash: val
      }
    });
    onShowToast(`Aviator X next flight crash forced to ${val.toFixed(2)}x`, 'success');
  };

  const handleClearAviatorX = async () => {
    const updated = { ...gameControls };
    delete updated.aviatorXCrash;
    await adminUpdateSettings({ gameControls: updated });
    onShowToast('Aviator X forced crash cleared - now random trajectory', 'info');
  };

  // Category Cards Image Management
  const handleUploadCardImage = async (cardId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingCardId(cardId);
    try {
      const res = await uploadToImgBB(file);
      if (res.success && res.url) {
        const updated = { ...gameCardImages, [cardId]: res.url };
        await adminUpdateSettings({ gameCardImages: updated });
        onShowToast(`Card "${cardId}" image updated with ImgBB!`, 'success');
      } else {
        onShowToast(res.error || 'ImgBB upload failed', 'error');
      }
    } catch {
      onShowToast('Image upload failed', 'error');
    } finally {
      setUploadingCardId(null);
      e.target.value = '';
    }
  };

  const handleSetCardImageUrl = async (cardId: string, url: string) => {
    const updated = { ...gameCardImages, [cardId]: url.trim() };
    await adminUpdateSettings({ gameCardImages: updated });
    onShowToast(`Card image URL updated`, 'success');
  };

  const handleResetCardImage = async (cardId: string) => {
    const updated = { ...gameCardImages };
    delete (updated as any)[cardId];
    await adminUpdateSettings({ gameCardImages: updated });
    onShowToast(`Reset card image to platform default`, 'info');
  };

  return (
    <div className="space-y-5 select-none">
      {/* Top Banner */}
      <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5 flex items-center space-x-3.5 shadow-xl">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-red-500 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-amber-500/20 shrink-0">
          <Gamepad2 className="w-6 h-6 text-slate-950" />
        </div>
        <div>
          <h2 className="text-base sm:text-lg font-black text-white flex items-center space-x-2">
            <span>All Games Full Working & Admin Management Control</span>
          </h2>
          <p className="text-xs text-slate-400">
            Realtime outcome control for K3, 5D, TRX WinGo, Aviator, Aviator X, plus Game Category Image Link management
          </p>
        </div>
      </div>

      {/* 0. GAME AVAILABILITY CONTROLS (ON / OFF SWITCHES FOR 6 GAMES) */}
      <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3.5">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-500/20 border border-blue-500/40 text-blue-400 flex items-center justify-center font-black shrink-0">
              <Power className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-white flex items-center space-x-2">
                <span>Game On / Off Controls (গেম চালু ও বন্ধ সিস্টেম)</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Wingo, K3, 5D, TRX, Aviator, Aviator X — turn any game ON or OFF in real-time
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-[10px] text-slate-400 bg-slate-900 border border-slate-800 px-3 py-1 rounded-full font-mono">
              Total 6 Games
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            { id: 'wingo', name: 'Win Go Lottery', bn: 'উইন গো লটারি', icon: '🎰', desc: '1M, 3M, 5M, 10M Colors & Numbers' },
            { id: 'k3', name: 'K3 Lotre', bn: 'কে৩ ডাইস লটারি', icon: '🎲', desc: '3-Dice Total, 2 Same, 3 Same, Consecutive' },
            { id: 'fiveD', name: '5D Lotre', bn: 'ফাইভ-ডি লটারি', icon: '🔢', desc: '5 Digits (A, B, C, D, E & Sum) Big/Small' },
            { id: 'trx', name: 'TRX Win Go', bn: 'টিআরএক্স উইন গো', icon: '⚡', desc: 'TRON Block Hash Crypto Color Game' },
            { id: 'aviator', name: 'Aviator Crash', bn: 'অ্যাভিয়েটর ক্র্যাশ', icon: '✈️', desc: 'Live Airplane Multiplier Cashout' },
            { id: 'aviatorX', name: 'Aviator X (Super)', bn: 'অ্যাভিয়েটর এক্স', icon: '🚀', desc: 'Dual-Bet Pro Aviator Flight Multiplier' },
          ].map((game) => {
            const isOnline = enabledGames[game.id as keyof typeof enabledGames];
            const isToggling = togglingGameId === game.id;
            return (
              <div
                key={game.id}
                className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between ${
                  isOnline
                    ? 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
                    : 'bg-red-950/20 border-red-900/40 hover:border-red-800/60'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-2.5">
                    <span className="text-2xl">{game.icon}</span>
                    <div>
                      <div className="text-xs font-black text-white">{game.name}</div>
                      <div className="text-[10px] text-slate-400">{game.bn}</div>
                    </div>
                  </div>
                  <span
                    className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${
                      isOnline
                        ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                        : 'bg-red-500/20 text-red-400 border-red-500/40'
                    }`}
                  >
                    {isOnline ? 'Online (চালু)' : 'Offline (বন্ধ)'}
                  </span>
                </div>

                <p className="text-[10px] text-slate-400 mt-2 line-clamp-1">{game.desc}</p>

                <div className="pt-3 border-t border-slate-800/80 mt-3 flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-slate-300">
                    Status: {isOnline ? 'Active' : 'Maintenance'}
                  </span>

                  <button
                    onClick={() => handleToggleGame(game.id as any, game.name)}
                    disabled={isToggling}
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center space-x-1.5 transition-all shadow-sm ${
                      isOnline
                        ? 'bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40 active:scale-95'
                        : 'bg-emerald-500 hover:bg-emerald-600 text-white active:scale-95'
                    }`}
                    id={`toggle-game-${game.id}-btn`}
                  >
                    <Power className="w-3.5 h-3.5" />
                    <span>{isOnline ? 'Turn OFF' : 'Turn ON'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Grid of Game Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 1. K3 LOTTERY CONTROL */}
        <div className="bg-slate-950 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl space-y-3.5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center space-x-2">
              <span className="text-xl">🎲</span>
              <div>
                <h3 className="text-xs font-black text-white uppercase tracking-wider">
                  K3 Lottery Control
                </h3>
                <span className="text-[10px] text-slate-400">3 Dice Outcome (1 to 6 each)</span>
              </div>
            </div>
            {currentK3 ? (
              <span className="text-[10px] font-mono font-black text-amber-300 bg-amber-500/20 border border-amber-500/40 px-2 py-0.5 rounded-full">
                FORCED: [{currentK3.join(',')}]
              </span>
            ) : (
              <span className="text-[10px] font-bold text-green-400 bg-green-500/10 border border-green-500/30 px-2 py-0.5 rounded-full">
                Fair Random
              </span>
            )}
          </div>

          <div className="space-y-2.5">
            <label className="text-xs font-bold text-slate-300">Set Next 3 Dice:</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { val: k3Die1, set: setK3Die1, label: 'Die 1' },
                { val: k3Die2, set: setK3Die2, label: 'Die 2' },
                { val: k3Die3, set: setK3Die3, label: 'Die 3' }
              ].map((d, i) => (
                <div key={i} className="bg-slate-900 p-2 rounded-xl border border-slate-800 text-center">
                  <span className="text-[10px] text-slate-400 block mb-1">{d.label}</span>
                  <select
                    value={d.val}
                    onChange={(e) => d.set(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg p-1.5 text-xs font-mono font-bold text-center outline-none"
                  >
                    {[1, 2, 3, 4, 5, 6].map((n) => (
                      <option key={n} value={n}>
                        {n}
                      </option>
                    ))}
                  </select>
                </div>
              ))}
            </div>

            <div className="text-[11px] text-amber-400/90 font-medium bg-slate-900/60 p-2 rounded-xl border border-slate-800 flex items-center justify-between">
              <span>Total Sum: <strong>{k3Die1 + k3Die2 + k3Die3}</strong></span>
              <span>Result: <strong>{k3Die1 + k3Die2 + k3Die3 <= 10 ? 'Small' : 'Big'}</strong></span>
            </div>

            <div className="flex items-center space-x-2 pt-1">
              <button
                onClick={handleSaveK3}
                className="flex-1 py-2 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white rounded-xl text-xs font-black shadow-md cursor-pointer transition-all"
              >
                Force Next K3 Dice
              </button>
              {currentK3 && (
                <button
                  onClick={handleClearK3}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>
          </div>
        </div>

        {/* 2. 5D LOTTERY CONTROL */}
        <div className="bg-slate-950 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl space-y-3.5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center space-x-2">
              <span className="text-xl">🎰</span>
              <div>
                <h3 className="text-xs font-black text-white uppercase tracking-wider">
                  5D Lottery Control
                </h3>
                <span className="text-[10px] text-slate-400">5 Reel Numbers (A, B, C, D, E)</span>
              </div>
            </div>
            {current5D ? (
              <span className="text-[10px] font-mono font-black text-amber-300 bg-amber-500/20 border border-amber-500/40 px-2 py-0.5 rounded-full">
                FORCED: {current5D.join('')}
              </span>
            ) : (
              <span className="text-[10px] font-bold text-green-400 bg-green-500/10 border border-green-500/30 px-2 py-0.5 rounded-full">
                Fair Random
              </span>
            )}
          </div>

          <div className="space-y-2.5">
            <label className="text-xs font-bold text-slate-300">Set 5 Numbers (0-9):</label>
            <div className="grid grid-cols-5 gap-1.5">
              {['A', 'B', 'C', 'D', 'E'].map((label, idx) => (
                <div key={label} className="bg-slate-900 p-1.5 rounded-xl border border-slate-800 text-center">
                  <span className="text-[9px] text-slate-400 block mb-0.5">{label}</span>
                  <select
                    value={fiveDNums[idx] ?? 0}
                    onChange={(e) => {
                      const next = [...fiveDNums];
                      next[idx] = Number(e.target.value);
                      setFiveDNums(next);
                    }}
                    className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg p-1 text-xs font-mono font-bold text-center outline-none"
                  >
                    {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
                      <option key={n} value={n}>
                        {n}
                      </option>
                    ))}
                  </select>
                </div>
              ))}
            </div>

            <div className="text-[11px] text-amber-400/90 font-medium bg-slate-900/60 p-2 rounded-xl border border-slate-800 flex items-center justify-between">
              <span>Total Sum: <strong>{fiveDNums.reduce((a, b) => a + b, 0)}</strong></span>
              <span>Outcome: <strong>{fiveDNums.reduce((a, b) => a + b, 0) <= 22 ? 'Small' : 'Big'}</strong></span>
            </div>

            <div className="flex items-center space-x-2 pt-1">
              <button
                onClick={handleSave5D}
                className="flex-1 py-2 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white rounded-xl text-xs font-black shadow-md cursor-pointer transition-all"
              >
                Force Next 5D Outcome
              </button>
              {current5D && (
                <button
                  onClick={handleClear5D}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>
          </div>
        </div>

        {/* 3. TRX WINGO CONTROL */}
        <div className="bg-slate-950 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl space-y-3.5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center space-x-2">
              <span className="text-xl">⚡</span>
              <div>
                <h3 className="text-xs font-black text-white uppercase tracking-wider">
                  TRX WinGo Lottery Control
                </h3>
                <span className="text-[10px] text-slate-400">Winning Number (0 to 9)</span>
              </div>
            </div>
            {currentTrx !== null ? (
              <span className="text-[10px] font-mono font-black text-amber-300 bg-amber-500/20 border border-amber-500/40 px-2 py-0.5 rounded-full">
                FORCED: {currentTrx}
              </span>
            ) : (
              <span className="text-[10px] font-bold text-green-400 bg-green-500/10 border border-green-500/30 px-2 py-0.5 rounded-full">
                Fair Hash Random
              </span>
            )}
          </div>

          <div className="space-y-2.5">
            <label className="text-xs font-bold text-slate-300">Select Winning Number (0-9):</label>
            <div className="grid grid-cols-5 gap-1.5">
              {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => {
                const isSelected = trxNum === n;
                const isGreen = n === 1 || n === 3 || n === 7 || n === 9;
                const isRed = n === 2 || n === 4 || n === 6 || n === 8;
                return (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setTrxNum(n)}
                    className={`py-2 rounded-xl font-mono font-black text-sm transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-400 text-slate-950 scale-105 shadow-md ring-2 ring-amber-300'
                        : isGreen
                        ? 'bg-emerald-950/60 border border-emerald-700/50 text-emerald-400 hover:bg-emerald-900/50'
                        : isRed
                        ? 'bg-rose-950/60 border border-rose-700/50 text-rose-400 hover:bg-rose-900/50'
                        : 'bg-purple-950/60 border border-purple-700/50 text-purple-400 hover:bg-purple-900/50'
                    }`}
                  >
                    {n}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center space-x-2 pt-1">
              <button
                onClick={handleSaveTrx}
                className="flex-1 py-2 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white rounded-xl text-xs font-black shadow-md cursor-pointer transition-all"
              >
                Force TRX Outcome ({trxNum})
              </button>
              {currentTrx !== null && (
                <button
                  onClick={handleClearTrx}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>
          </div>
        </div>

        {/* 4. AVIATOR & AVIATOR X CONTROLS */}
        <div className="bg-slate-950 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl space-y-3.5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center space-x-2">
              <span className="text-xl">✈️</span>
              <div>
                <h3 className="text-xs font-black text-white uppercase tracking-wider">
                  Aviator & Aviator X Crash Multipliers
                </h3>
                <span className="text-[10px] text-slate-400">Flight Crash Points</span>
              </div>
            </div>
            {(currentAviator || currentAviatorX) ? (
              <span className="text-[10px] font-mono font-black text-amber-300 bg-amber-500/20 border border-amber-500/40 px-2 py-0.5 rounded-full">
                FORCED
              </span>
            ) : (
              <span className="text-[10px] font-bold text-green-400 bg-green-500/10 border border-green-500/30 px-2 py-0.5 rounded-full">
                Dynamic Random
              </span>
            )}
          </div>

          <div className="space-y-3">
            {/* Aviator Classic */}
            <div className="bg-slate-900/80 p-2.5 rounded-2xl border border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-200">Aviator (Red Flight):</span>
                <span className="font-mono text-amber-400 font-bold">
                  {currentAviator ? `${currentAviator.toFixed(2)}x` : 'Dynamic'}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="number"
                  step="0.01"
                  min="1.00"
                  value={aviatorCrash}
                  onChange={(e) => setAviatorCrash(e.target.value)}
                  placeholder="2.50"
                  className="flex-1 bg-slate-950 border border-slate-700 text-white rounded-xl px-2.5 py-1.5 text-xs font-mono font-bold outline-none"
                />
                <button
                  onClick={handleSaveAviator}
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold"
                >
                  Force
                </button>
                {currentAviator && (
                  <button
                    onClick={handleClearAviator}
                    className="px-2.5 py-1.5 bg-slate-800 text-slate-300 rounded-xl text-xs"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>

            {/* Aviator X */}
            <div className="bg-slate-900/80 p-2.5 rounded-2xl border border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-200">Aviator X (High Multiplier):</span>
                <span className="font-mono text-amber-400 font-bold">
                  {currentAviatorX ? `${currentAviatorX.toFixed(2)}x` : 'Dynamic'}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="number"
                  step="0.01"
                  min="1.00"
                  value={aviatorXCrash}
                  onChange={(e) => setAviatorXCrash(e.target.value)}
                  placeholder="5.00"
                  className="flex-1 bg-slate-950 border border-slate-700 text-white rounded-xl px-2.5 py-1.5 text-xs font-mono font-bold outline-none"
                />
                <button
                  onClick={handleSaveAviatorX}
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold"
                >
                  Force
                </button>
                {currentAviatorX && (
                  <button
                    onClick={handleClearAviatorX}
                    className="px-2.5 py-1.5 bg-slate-800 text-slate-300 rounded-xl text-xs"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 5. GAME CATEGORY CARDS IMAGE LINKS CONTROL */}
      <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <ImageIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wide">
                Game Category Cards Image Links Control
              </h3>
              <span className="text-[11px] text-slate-400">
                Customize or upload new images for the 6 home dashboard featured game cards
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
          {DEFAULT_FEATURED_GAMES.map((card) => {
            const currentImg = gameCardImages[card.id] || card.defaultImage;
            const isCustom = !!gameCardImages[card.id];

            return (
              <div
                key={card.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2.5 flex flex-col justify-between"
              >
                <div className="flex items-center justify-between">
                  <span className="font-black text-xs text-white truncate">{card.name}</span>
                  <span className="text-[9px] font-bold text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded">
                    {card.badge}
                  </span>
                </div>

                {/* Preview */}
                <div className="relative aspect-video w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
                  <img
                    src={currentImg || card.defaultImage}
                    alt={card.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = card.defaultImage;
                    }}
                  />
                  {isCustom && (
                    <span className="absolute top-1 right-1 bg-green-500 text-slate-950 font-black text-[9px] px-1.5 py-0.2 rounded">
                      Custom
                    </span>
                  )}
                </div>

                {/* Direct URL input */}
                <input
                  type="url"
                  defaultValue={currentImg}
                  onBlur={(e) => handleSetCardImageUrl(card.id, e.target.value)}
                  placeholder="Direct image URL"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-[11px] text-white outline-none"
                />

                {/* ImgBB upload and reset button */}
                <div className="flex items-center space-x-2 pt-1">
                  <label className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-400 text-[11px] font-bold rounded-xl flex items-center justify-center space-x-1 cursor-pointer transition-colors">
                    <Upload className="w-3 h-3" />
                    <span>{uploadingCardId === card.id ? 'Uploading...' : 'Upload File'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleUploadCardImage(card.id, e)}
                      disabled={uploadingCardId === card.id}
                      className="hidden"
                    />
                  </label>

                  {isCustom && (
                    <button
                      onClick={() => handleResetCardImage(card.id)}
                      className="px-2.5 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 rounded-xl text-[11px] font-bold transition-colors"
                      title="Reset to default image"
                    >
                      <RotateCcw className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
