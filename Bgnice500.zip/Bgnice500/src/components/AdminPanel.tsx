import React, { useState } from 'react';
import {
  Check,
  X,
  RefreshCw,
  Users,
  CreditCard,
  Gift,
  ArrowLeft,
  Search,
  Gamepad2,
  Plus,
  Trash2,
  Edit2,
  Ban,
  ShieldCheck,
  Sliders,
  DollarSign,
  Image as ImageIcon,
  Copy,
  Sparkles,
  Smartphone,
  Download,
  ExternalLink,
  MessageSquare,
  Menu,
  LayoutDashboard,
  TrendingUp,
  TrendingDown,
  UserPlus,
  BarChart3,
  Flame,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  ChevronRight,
  Crown,
  RotateCcw,
  AlertTriangle,
  Upload
} from 'lucide-react';
import { AdminChatManagement } from './AdminChatManagement';
import { AdminVipManagement } from './AdminVipManagement';
import { AdminAnnouncementManagement } from './AdminAnnouncementManagement';
import { AdminGameControls } from './AdminGameControls';
import { AdminActivityBannerManagement } from './AdminActivityBannerManagement';
import { useApp } from '../context/AppContext';
import { GameType, UserProfile, GameItem, PaymentChannelConfig, BannerItem, DepositItem, WithdrawalItem, BetItem, DepositChannel } from '../types';
import { DEFAULT_DEPOSIT_CHANNELS, EWALLET_DEFAULT_IMAGE } from '../utils/defaultChannels';
import { PAYMENT_LOGOS } from '../utils/paymentLogos';
import { DEFAULT_FEATURED_GAMES, FeaturedGameCard } from '../data/featuredGames';
import { uploadToImgBB } from '../utils/imgbb';

export const AdminPanel: React.FC = () => {
  const {
    setIsAdmin,
    gameType,
    setGameType,
    periodId,
    timeLeft,
    allBets,
    deposits,
    withdrawals,
    allUsers,
    settings,
    games,
    banners,
    giftCodes,
    showToast,
    adminApproveDeposit,
    adminRejectDeposit,
    adminApproveWithdrawal,
    adminRejectWithdrawal,
    adminSetForcedResult,
    adminUpdateSettings,
    adminAdjustUserBalance,
    adminUpdateUserVip,
    adminToggleUserBan,
    adminGenerate30CharGiftCode,
    adminSaveGiftCode,
    adminDeleteGiftCode,
    adminToggleGiftCodeStatus,
    adminAddGame,
    adminUpdateGame,
    adminDeleteGame,
    adminToggleGameStatus,
    adminAddBanner,
    adminUpdateBanner,
    adminDeleteBanner,
    adminToggleBannerStatus,
    adminResetDefaultBanners,
    adminToggleMaintenanceMode,
    adminUpdateSignupBonus,
    adminUpdatePaymentChannel,
    depositChannels,
    adminSaveDepositChannel,
    adminDeleteDepositChannel,
    adminResetDefaultChannels
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'wingo' | 'games' | 'gameControls' | 'banners' | 'announcements' | 'deposits' | 'withdrawals' | 'users' | 'vip' | 'channels' | 'settings' | 'gifts' | 'livechat'
  >('dashboard');

  const [is3LineMenuOpen, setIs3LineMenuOpen] = useState<boolean>(false);

  // Withdrawal Rejection Modal with Remark
  const [rejectingWithdrawal, setRejectingWithdrawal] = useState<WithdrawalItem | null>(null);
  const [rejectionRemark, setRejectionRemark] = useState<string>('');

  // Maintenance Mode & Signup Bonus States
  const [isMaintenance, setIsMaintenance] = useState<boolean>(settings?.isMaintenanceMode ?? false);
  const [maintMessage, setMaintMessage] = useState<string>(
    settings?.maintenanceMessage || 'BGNICE প্ল্যাটফর্ম সাময়িক রক্ষণাবেক্ষণের জন্য বন্ধ আছে। দ্রুততম সময়ে সার্ভিস পুনরায় চালু করা হবে।'
  );
  const [signupBonusOn, setSignupBonusOn] = useState<boolean>(settings?.signupBonusEnabled ?? true);
  const [signupBonusAmt, setSignupBonusAmt] = useState<string>((settings?.signupBonusAmount ?? 50).toString());
  const [signupBonusTurnover, setSignupBonusTurnover] = useState<string>((settings?.signupBonusTurnoverMultiplier ?? 1).toString());

  // Deposit Filters
  const [depositStatusFilter, setDepositStatusFilter] = useState<'all' | 'pending' | 'completed' | 'rejected'>('all');
  const [depositMethodFilter, setDepositMethodFilter] = useState<'all' | 'bkash' | 'nagad' | 'rocket' | 'usdt'>('all');

  // Deposit Channel Editor State
  const [editingChannel, setEditingChannel] = useState<DepositChannel | null>(null);
  const [isChannelModalOpen, setIsChannelModalOpen] = useState<boolean>(false);
  const [isUploadingChannelLogo, setIsUploadingChannelLogo] = useState<boolean>(false);
  const [isUploadingStep1, setIsUploadingStep1] = useState<boolean>(false);
  const [isUploadingStep2, setIsUploadingStep2] = useState<boolean>(false);
  const channelLogoFileRef = React.useRef<HTMLInputElement | null>(null);
  const channelStep1FileRef = React.useRef<HTMLInputElement | null>(null);
  const channelStep2FileRef = React.useRef<HTMLInputElement | null>(null);

  // Win Go prediction state
  const currentForced = settings.forcedResults?.[gameType];

  // Settings form state
  const [nagadNum, setNagadNum] = useState(settings.nagadNumber);
  const [bkashNum, setBkashNum] = useState(settings.bkashNumber);
  const [rocketNum, setRocketNum] = useState(settings.rocketNumber || '01771234430');
  const [usdtAddr, setUsdtAddr] = useState(settings.usdtAddress);
  const [usdtRate, setUsdtRate] = useState((settings.usdtRate ?? 125).toString());
  const [minWithdrawUsdt, setMinWithdrawUsdt] = useState((settings.minWithdrawUsdt ?? 10).toString());
  const [announcementText, setAnnouncementText] = useState(settings.platformAnnouncement);
  const [appDownloadUrl, setAppDownloadUrl] = useState(settings.appDownloadUrl || 'https://trade-bd.app/download/trade-bd.apk');
  const [appVersion, setAppVersion] = useState(settings.appVersion || 'v2.6 Official');

  // Attendance & Turnover settings state
  const [attendanceEnabled, setAttendanceEnabled] = useState(settings.attendance?.enabled ?? true);
  const [attMinDeposit, setAttMinDeposit] = useState((settings.attendance?.minDeposit ?? 500).toString());
  const [attTotalDepositTarget, setAttTotalDepositTarget] = useState((settings.attendance?.totalDepositTarget ?? 20000).toString());
  const [attTurnoverMultiplier, setAttTurnoverMultiplier] = useState((settings.attendance?.turnoverMultiplier ?? 1).toString());
  const [attRewards, setAttRewards] = useState<number[]>(
    settings.attendance?.rewards || [20, 30, 50, 70, 100, 150, 300]
  );

  // Keep form state in sync with realtime settings
  React.useEffect(() => {
    if (settings.appDownloadUrl !== undefined) {
      setAppDownloadUrl(settings.appDownloadUrl);
    }
    if (settings.appVersion !== undefined) {
      setAppVersion(settings.appVersion);
    }
    if (settings.isMaintenanceMode !== undefined) {
      setIsMaintenance(settings.isMaintenanceMode);
    }
    if (settings.maintenanceMessage !== undefined) {
      setMaintMessage(settings.maintenanceMessage);
    }
    if (settings.signupBonusEnabled !== undefined) {
      setSignupBonusOn(settings.signupBonusEnabled);
    }
    if (settings.signupBonusAmount !== undefined) {
      setSignupBonusAmt(settings.signupBonusAmount.toString());
    }
    if (settings.signupBonusTurnoverMultiplier !== undefined) {
      setSignupBonusTurnover(settings.signupBonusTurnoverMultiplier.toString());
    }
    if (settings.usdtRate !== undefined) {
      setUsdtRate(settings.usdtRate.toString());
    }
    if (settings.minWithdrawUsdt !== undefined) {
      setMinWithdrawUsdt(settings.minWithdrawUsdt.toString());
    }
    if (settings.attendance) {
      setAttendanceEnabled(settings.attendance.enabled ?? true);
      setAttMinDeposit((settings.attendance.minDeposit ?? 500).toString());
      setAttTotalDepositTarget((settings.attendance.totalDepositTarget ?? 20000).toString());
      setAttTurnoverMultiplier((settings.attendance.turnoverMultiplier ?? 1).toString());
      if (settings.attendance.rewards && settings.attendance.rewards.length >= 7) {
        setAttRewards(settings.attendance.rewards);
      }
    }
  }, [settings.appDownloadUrl, settings.appVersion, settings.attendance, settings.isMaintenanceMode, settings.maintenanceMessage, settings.signupBonusEnabled, settings.signupBonusAmount, settings.signupBonusTurnoverMultiplier, settings.usdtRate, settings.minWithdrawUsdt]);

  // User search & balance adjustment
  const [searchQuery, setSearchQuery] = useState('');
  const [adjustUid, setAdjustUid] = useState<string | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<string>('');
  const [selectedUserDetail, setSelectedUserDetail] = useState<UserProfile | null>(null);

  // Gift code generator state
  const [newCode, setNewCode] = useState('');
  const [newCodeReward, setNewCodeReward] = useState<string>('500');
  const [newCodeMax, setNewCodeMax] = useState<string>('100');

  // Game Management form state
  const [isGameModalOpen, setIsGameModalOpen] = useState(false);
  const [editingGameId, setEditingGameId] = useState<string | null>(null);
  const [gameForm, setGameForm] = useState({
    name: '',
    image: '',
    category: 'Popular',
    gamePath: 'games/aviator/index.html',
    badge: 'HOT',
    provider: 'JILI',
    rtp: 96.8,
    sortOrder: 1,
    status: true,
    integrationType: 'html5' as 'html5' | 'api',
    apiProvider: 'JILI',
    apiGameCode: '',
    apiEndpoint: '',
    apiAuthType: 'direct_url',
    apiAutoSession: true
  });

  // Banner Management form state (5 banners)
  const [bannerCategory, setBannerCategory] = useState<'home' | 'activity'>('home');
  const [isBannerModalOpen, setIsBannerModalOpen] = useState(false);
  const [editingBannerId, setEditingBannerId] = useState<string | null>(null);
  const [bannerForm, setBannerForm] = useState({
    title: '',
    subtitle: '',
    image: '',
    buttonText: 'Play Now',
    action: 'wingo',
    active: true,
    order: 1
  });

  // 6 Featured Game Cards state management (Wingo Lottery, K3 Lottery, 5D Lottery, TRX Wingo, Aviator, Aviator X)
  const [gameCardUrls, setGameCardUrls] = useState<Record<string, string>>(() => {
    return settings?.gameCardImages || {};
  });
  const [uploadingCardId, setUploadingCardId] = useState<string | null>(null);
  const [uploadingBanner, setUploadingBanner] = useState<boolean>(false);

  // Sync game card urls when settings update
  React.useEffect(() => {
    if (settings?.gameCardImages) {
      setGameCardUrls(settings.gameCardImages);
    }
  }, [settings?.gameCardImages]);

  const handleCardImageUpload = async (cardId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingCardId(cardId);
    try {
      const res = await uploadToImgBB(file);
      if (res.success && res.url) {
        const updated = { ...gameCardUrls, [cardId]: res.url };
        setGameCardUrls(updated);
        await adminUpdateSettings({ gameCardImages: updated });
        showToast('Game card image updated & saved with ImgBB!', 'success');
      } else {
        showToast(res.error || 'ImgBB upload failed', 'error');
      }
    } catch (err) {
      showToast('Failed to upload image to ImgBB', 'error');
    } finally {
      setUploadingCardId(null);
      e.target.value = '';
    }
  };

  const handleSaveCardImageUrl = async (cardId: string, url: string) => {
    const updated = { ...gameCardUrls, [cardId]: url.trim() };
    setGameCardUrls(updated);
    await adminUpdateSettings({ gameCardImages: updated });
    showToast('Game card image URL updated successfully!', 'success');
  };

  const handleResetCardImage = async (cardId: string) => {
    const updated = { ...gameCardUrls };
    delete updated[cardId];
    setGameCardUrls(updated);
    await adminUpdateSettings({ gameCardImages: updated });
    showToast('Reset to original default card image', 'info');
  };

  const handleBannerImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingBanner(true);
    try {
      const res = await uploadToImgBB(file);
      if (res.success && res.url) {
        setBannerForm((prev) => ({ ...prev, image: res.url! }));
        showToast('Banner image uploaded successfully!', 'success');
      } else {
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            setBannerForm((prev) => ({ ...prev, image: reader.result as string }));
            showToast('Banner image loaded successfully!', 'success');
          }
        };
        reader.readAsDataURL(file);
      }
    } catch (err) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setBannerForm((prev) => ({ ...prev, image: reader.result as string }));
          showToast('Banner image loaded successfully!', 'success');
        }
      };
      reader.readAsDataURL(file);
    } finally {
      setUploadingBanner(false);
      e.target.value = '';
    }
  };

  const handleQuickBannerImageUpload = async (banner: BannerItem, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const res = await uploadToImgBB(file);
      if (res.success && res.url) {
        await adminUpdateBanner(banner.id, { image: res.url });
        showToast(`Banner "${banner.title}" image updated successfully!`, 'success');
      } else {
        const reader = new FileReader();
        reader.onload = async () => {
          if (typeof reader.result === 'string') {
            await adminUpdateBanner(banner.id, { image: reader.result });
            showToast(`Banner "${banner.title}" image updated successfully!`, 'success');
          }
        };
        reader.readAsDataURL(file);
      }
    } catch (err) {
      const reader = new FileReader();
      reader.onload = async () => {
        if (typeof reader.result === 'string') {
          await adminUpdateBanner(banner.id, { image: reader.result });
          showToast(`Banner "${banner.title}" image updated successfully!`, 'success');
        }
      };
      reader.readAsDataURL(file);
    } finally {
      e.target.value = '';
    }
  };

  const handleChannelLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editingChannel) return;
    setIsUploadingChannelLogo(true);
    try {
      const res = await uploadToImgBB(file);
      if (res.success && res.url) {
        setEditingChannel({ ...editingChannel, logo: res.url });
        showToast('Channel logo uploaded via ImgBB!', 'success');
      } else {
        showToast(res.error || 'Failed to upload logo', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'Error uploading logo', 'error');
    } finally {
      setIsUploadingChannelLogo(false);
      e.target.value = '';
    }
  };

  const handleChannelStep1Upload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editingChannel) return;
    setIsUploadingStep1(true);
    try {
      const res = await uploadToImgBB(file);
      if (res.success && res.url) {
        setEditingChannel({ ...editingChannel, step1Image: res.url });
        showToast('Step 1 Screenshot uploaded via ImgBB!', 'success');
      } else {
        showToast(res.error || 'Failed to upload screenshot 1', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'Error uploading screenshot 1', 'error');
    } finally {
      setIsUploadingStep1(false);
      e.target.value = '';
    }
  };

  const handleChannelStep2Upload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editingChannel) return;
    setIsUploadingStep2(true);
    try {
      const res = await uploadToImgBB(file);
      if (res.success && res.url) {
        setEditingChannel({ ...editingChannel, step2Image: res.url });
        showToast('Step 2 Screenshot uploaded via ImgBB!', 'success');
      } else {
        showToast(res.error || 'Failed to upload screenshot 2', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'Error uploading screenshot 2', 'error');
    } finally {
      setIsUploadingStep2(false);
      e.target.value = '';
    }
  };

  const safeDeposits: DepositItem[] = React.useMemo(() => {
    if (!deposits) return [];
    return Array.isArray(deposits) ? deposits : Object.values(deposits);
  }, [deposits]);

  const safeWithdrawals: WithdrawalItem[] = React.useMemo(() => {
    if (!withdrawals) return [];
    return Array.isArray(withdrawals) ? withdrawals : Object.values(withdrawals);
  }, [withdrawals]);

  const safeAllBets: BetItem[] = React.useMemo(() => {
    if (!allBets) return [];
    return Array.isArray(allBets) ? allBets : Object.values(allBets);
  }, [allBets]);

  const safeUsersList: UserProfile[] = React.useMemo(() => {
    if (!allUsers) return [];
    if (Array.isArray(allUsers)) return allUsers;
    return Object.values(allUsers);
  }, [allUsers]);

  // Midnight timestamp for today (local time)
  const startOfTodayMs = React.useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d.getTime();
  }, []);

  // 1. Total User
  const totalUsersCount = safeUsersList.length;

  // 2. Today User Register
  const todayUserRegisterCount = React.useMemo(() => {
    return safeUsersList.filter((u) => {
      const ts = u.createdAt || 0;
      return ts >= startOfTodayMs;
    }).length;
  }, [safeUsersList, startOfTodayMs]);

  // 3. Total Deposit (Completed / success)
  const totalDepositAmount = React.useMemo(() => {
    return safeDeposits
      .filter((d) => d && (d.status === 'completed' || d.status === 'success'))
      .reduce((sum, d) => sum + (Number(d.amount) || 0), 0);
  }, [safeDeposits]);

  // 4. Today Deposit (Completed / success today)
  const todayDepositAmount = React.useMemo(() => {
    return safeDeposits
      .filter((d) => {
        if (!d) return false;
        const ok = d.status === 'completed' || d.status === 'success';
        const ts = d.processedAt || d.createdAt || 0;
        return ok && ts >= startOfTodayMs;
      })
      .reduce((sum, d) => sum + (Number(d.amount) || 0), 0);
  }, [safeDeposits, startOfTodayMs]);

  // 5. Total Withdraw (Completed)
  const totalWithdrawAmount = React.useMemo(() => {
    return safeWithdrawals
      .filter((w) => w && w.status === 'completed')
      .reduce((sum, w) => sum + (Number(w.amount) || 0), 0);
  }, [safeWithdrawals]);

  // 6. Today Withdraw (Completed today)
  const todayWithdrawAmount = React.useMemo(() => {
    return safeWithdrawals
      .filter((w) => {
        if (!w) return false;
        const ok = w.status === 'completed';
        const ts = w.processedAt || w.createdAt || 0;
        return ok && ts >= startOfTodayMs;
      })
      .reduce((sum, w) => sum + (Number(w.amount) || 0), 0);
  }, [safeWithdrawals, startOfTodayMs]);

  const pendingDeposits = safeDeposits.filter((d) => d && d.status === 'pending');
  const pendingWithdrawals = safeWithdrawals.filter((w) => w && w.status === 'pending');
  const currentPeriodBets = safeAllBets.filter((b) => b && b.periodId === periodId && b.gameType === gameType);
  const totalBetPool = currentPeriodBets.reduce((acc, b) => acc + (b.totalAmount || 0), 0);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    await adminUpdateSettings({
      nagadNumber: nagadNum,
      bkashNumber: bkashNum,
      rocketNumber: rocketNum,
      usdtAddress: usdtAddr,
      usdtRate: parseFloat(usdtRate) || 125,
      minWithdrawUsdt: parseFloat(minWithdrawUsdt) || 10,
      platformAnnouncement: announcementText,
      appDownloadUrl: appDownloadUrl.trim(),
      appVersion: appVersion.trim(),
      isMaintenanceMode: isMaintenance,
      maintenanceMessage: maintMessage.trim(),
      signupBonusEnabled: signupBonusOn,
      signupBonusAmount: parseFloat(signupBonusAmt) || 50,
      signupBonusTurnoverMultiplier: parseFloat(signupBonusTurnover) || 1,
      attendance: {
        enabled: attendanceEnabled,
        minDeposit: parseFloat(attMinDeposit) || 500,
        totalDepositTarget: parseFloat(attTotalDepositTarget) || 20000,
        requiredDays: 7,
        turnoverMultiplier: parseFloat(attTurnoverMultiplier) || 1,
        rewards: attRewards
      }
    });
    showToast('Platform, Maintenance, Signup Bonus & App settings saved successfully!', 'success');
  };

  const handleAdjustBalance = async (uid: string) => {
    const val = parseFloat(adjustAmount);
    if (isNaN(val) || val === 0) {
      showToast('Enter valid amount (+ to add, - to deduct)', 'error');
      return;
    }
    await adminAdjustUserBalance(uid, val);
    showToast(`Adjusted balance for user ${uid} by ৳${val}!`, 'success');
    setAdjustUid(null);
    setAdjustAmount('');
  };

  const handleCreateCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCode.trim()) return;
    await adminSaveGiftCode(newCode.trim(), parseFloat(newCodeReward) || 100, parseInt(newCodeMax) || 50);
    setNewCode('');
  };

  const handleGenerate30Char = async () => {
    const code = await adminGenerate30CharGiftCode();
    setNewCode(code);
    showToast('30-character unique gift code generated!', 'success');
  };

  // Open Game Modal for create or edit
  const openNewGameModal = () => {
    setEditingGameId(null);
    setGameForm({
      name: '',
      image: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80',
      category: 'Popular',
      gamePath: 'games/aviator/index.html',
      badge: 'HOT',
      provider: 'JILI',
      rtp: 97.2,
      sortOrder: (games.length + 1),
      status: true,
      integrationType: 'html5',
      apiProvider: 'JILI',
      apiGameCode: '',
      apiEndpoint: '',
      apiAuthType: 'direct_url',
      apiAutoSession: true
    });
    setIsGameModalOpen(true);
  };

  const openEditGameModal = (game: GameItem) => {
    setEditingGameId(game.id);
    const isApi = game.integrationType === 'api' || (game.gamePath && (game.gamePath.startsWith('http://') || game.gamePath.startsWith('https://')));
    setGameForm({
      name: game.name,
      image: game.image,
      category: game.category,
      gamePath: game.gamePath,
      badge: (game.badge as any) || 'HOT',
      provider: game.provider || 'JILI',
      rtp: game.rtp || 96.5,
      sortOrder: game.sortOrder || 1,
      status: game.status !== false,
      integrationType: isApi ? 'api' : 'html5',
      apiProvider: (game.apiProvider || game.provider || 'JILI') as any,
      apiGameCode: game.apiGameCode || '',
      apiEndpoint: game.apiEndpoint || (isApi ? game.gamePath : ''),
      apiAuthType: game.apiAuthType || 'direct_url',
      apiAutoSession: game.apiAutoSession ?? true
    });
    setIsGameModalOpen(true);
  };

  const handleSaveGame = async (e: React.FormEvent) => {
    e.preventDefault();
    let rawPath = gameForm.integrationType === 'api'
      ? (gameForm.apiEndpoint?.trim() || gameForm.gamePath?.trim() || '')
      : gameForm.gamePath?.trim();

    // Auto-normalize if admin writes "public/games/..." or "/public/..."
    if (rawPath && gameForm.integrationType === 'html5') {
      if (rawPath.startsWith('public/')) {
        rawPath = rawPath.replace(/^public\//, '');
      } else if (rawPath.startsWith('/public/')) {
        rawPath = rawPath.replace(/^\/public\//, '');
      }
    }

    const finalLaunchPath = rawPath;

    if (!gameForm.name.trim() || !finalLaunchPath) {
      showToast('Please fill all required game fields (Name & Game Path / API Endpoint).', 'error');
      return;
    }

    const payload: Partial<GameItem> = {
      ...gameForm,
      gamePath: finalLaunchPath,
      provider: gameForm.integrationType === 'api' ? gameForm.apiProvider : (gameForm.provider || 'Original')
    };

    if (editingGameId) {
      await adminUpdateGame(editingGameId, payload);
      showToast(`Game "${gameForm.name}" updated successfully!`, 'success');
    } else {
      await adminAddGame(payload as any);
      showToast(`Game "${gameForm.name}" added to platform!`, 'success');
    }

    setIsGameModalOpen(false);
  };

  const handleDeleteGame = async (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete "${name}" from Firebase?`)) {
      await adminDeleteGame(id);
    }
  };

  // Banner modal handlers
  const openNewBannerModal = () => {
    setEditingBannerId(null);
    setBannerForm({
      title: '',
      subtitle: '',
      image: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80',
      buttonText: 'Play Now',
      action: 'wingo',
      active: true,
      order: banners.length + 1
    });
    setIsBannerModalOpen(true);
  };

  const openEditBannerModal = (banner: BannerItem) => {
    setEditingBannerId(banner.id);
    setBannerForm({
      title: banner.title,
      subtitle: banner.subtitle,
      image: banner.image,
      buttonText: banner.buttonText || 'Play Now',
      action: banner.action || 'wingo',
      active: banner.active !== false,
      order: banner.order || 1
    });
    setIsBannerModalOpen(true);
  };

  const handleSaveBanner = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bannerForm.title.trim()) {
      showToast('Please enter a banner title.', 'error');
      return;
    }
    if (editingBannerId) {
      await adminUpdateBanner(editingBannerId, bannerForm);
    } else {
      await adminAddBanner(bannerForm);
    }
    setIsBannerModalOpen(false);
  };

  const handleDeleteBanner = async (id: string, title: string) => {
    if (window.confirm(`Are you sure you want to delete banner "${title}"?`)) {
      await adminDeleteBanner(id);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 pb-20 select-none">
      {/* Admin Top Header */}
      <div className="sticky top-0 z-40 bg-slate-950 border-b border-slate-800 px-4 py-3 flex items-center justify-between shadow-md">
        <div className="flex items-center space-x-3">
          {/* 3-Line Menu Button - The unified master control launcher */}
          <button
            onClick={() => setIs3LineMenuOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-lg active:scale-95 transition-all cursor-pointer"
            title="3-Line Menu: All Control Systems (অল কন্ট্রোল সিস্টেম)"
            id="admin-3line-menu-btn"
          >
            <Menu className="w-5 h-5 text-slate-950 shrink-0" />
            <span className="tracking-wide">☰ ৩ লাইন মেনু (All Controls)</span>
          </button>
          
          <div className="hidden md:flex items-center space-x-2 border-l border-slate-800 pl-3">
            <div className="w-7 h-7 rounded-lg bg-red-600 text-white flex items-center justify-center font-black text-xs">
              ⚙️
            </div>
            <div>
              <h1 className="font-black text-xs tracking-wide text-white">BGNICE ADMIN COMMAND CENTER</h1>
              <span className="text-[10px] text-green-400 font-mono">● RTDB Live Connected</span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {activeTab !== 'dashboard' && (
            <button
              onClick={() => setActiveTab('dashboard')}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700 text-xs font-bold flex items-center space-x-1.5 transition-all"
              title="Return to Home Dashboard"
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Dashboard</span>
            </button>
          )}

          <button
            onClick={() => {
              setIsAdmin(false);
              if (window.location.hash || window.location.search) {
                window.history.replaceState(null, '', window.location.pathname);
              }
            }}
            className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center space-x-1 transition-all cursor-pointer"
            id="admin-exit-btn"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Exit to App</span>
          </button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-4">
        {/* Active Control Bar - Clear context with instant switch to 3-line menu */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl px-4 py-2.5 flex items-center justify-between gap-2 shadow-sm">
          <div className="flex items-center space-x-2 min-w-0">
            <span className="text-[11px] text-slate-400 font-bold hidden sm:inline">Current Control:</span>
            <div className="flex items-center space-x-1.5 text-xs font-black text-amber-400 bg-amber-400/10 border border-amber-400/30 px-3 py-1 rounded-xl truncate">
              {activeTab === 'dashboard' && <span>📊 Home Dashboard (হোম ড্যাশবোর্ড)</span>}
              {activeTab === 'wingo' && <span>🎱 Wingo Prediction Control (উইন গো প্রেডিকশন)</span>}
              {activeTab === 'gameControls' && <span>🎮 All Games Outcome & Card Control (সকল গেম ও রেজাল্ট কন্ট্রোল)</span>}
              {activeTab === 'games' && <span>🕹️ Game Management (গেম কার্ড ও নতুন গেম যোগ)</span>}
              {activeTab === 'announcements' && <span>📢 Unlimited Announcements (ঘোষণা ও ছবি সিস্টেম)</span>}
              {activeTab === 'banners' && <span>🖼️ Banner Management (ব্যানার ৫টি ইমেজ ও লিঙ্ক)</span>}
              {activeTab === 'users' && <span>👥 Users & Fast VIP (ইউজার ম্যানেজমেন্ট ও ব্যালেন্স)</span>}
              {activeTab === 'vip' && <span>👑 10 VIP Bonus System (ভিআইপি ১-১০ বোনাস ফুল কন্ট্রোল)</span>}
              {activeTab === 'channels' && <span>💳 Payment Channels (পেমেন্ট চ্যানেল ও ওয়ালেট)</span>}
              {activeTab === 'deposits' && <span>📥 Deposit Requests (ডিপোজিট রিকোয়েস্ট ও অনুমোদন)</span>}
              {activeTab === 'withdrawals' && <span>📤 Withdrawal Requests (উইথড্রয়াল রিকোয়েস্ট ও অনুমোদন)</span>}
              {activeTab === 'settings' && <span>⚙️ Platform & App APK (প্ল্যাটফর্ম ও অ্যাপ ডাউনলোড)</span>}
              {activeTab === 'gifts' && <span>🎁 Gift Code Generator (৩০ ক্যারেক্টার গিফট কোড)</span>}
              {activeTab === 'livechat' && <span>💬 Live Chat Support & Reply (লাইভ চ্যাট সাপোর্ট)</span>}
            </div>
          </div>

          <button
            onClick={() => setIs3LineMenuOpen(true)}
            className="text-xs text-amber-400 hover:text-amber-300 font-black flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-xl border border-slate-700 active:scale-95 transition-all shrink-0 cursor-pointer"
            id="switch-control-btn"
          >
            <Menu className="w-4 h-4 text-amber-400" />
            <span>Open 3-Line Menu (অল কন্ট্রোল)</span>
          </button>
        </div>

        {/* 0. Home Dashboard Tab (Stats: Total User, Total Withdraw, Total Deposit, Today Deposit, Today Withdraw, Today User Register) */}
        {activeTab === 'dashboard' && (
          <div className="space-y-4 animate-fadeIn">
            {/* Top Dashboard Banner */}
            <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-center space-x-3.5">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-red-600 via-rose-500 to-amber-500 p-0.5 shadow-lg flex items-center justify-center">
                  <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-amber-400">
                    <LayoutDashboard className="w-6 h-6" />
                  </div>
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h2 className="text-lg font-black text-white">Admin Control Home Dashboard</h2>
                    <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-black text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider">
                      Live Realtime
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Complete executive overview of users, deposits, payouts, and gaming operations
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setIs3LineMenuOpen(true)}
                  className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center space-x-1.5 shadow-md active:scale-95 transition-all"
                  id="dash-open-all-controls-btn"
                >
                  <Menu className="w-4 h-4" />
                  <span>3-Line All Controls</span>
                </button>
              </div>
            </div>

            {/* Critical Alert Banners if any pending requests */}
            {(pendingDeposits.length > 0 || pendingWithdrawals.length > 0) && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {pendingDeposits.length > 0 && (
                  <div
                    onClick={() => setActiveTab('deposits')}
                    className="p-3.5 bg-amber-500/10 border border-amber-500/40 hover:bg-amber-500/20 rounded-2xl cursor-pointer flex items-center justify-between transition-all"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                        <CreditCard className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-bold text-xs text-amber-300">
                          {pendingDeposits.length} Pending Deposit{pendingDeposits.length > 1 ? 's' : ''}
                        </div>
                        <div className="text-[11px] text-slate-400">Click to approve or reject deposits</div>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-amber-400" />
                  </div>
                )}

                {pendingWithdrawals.length > 0 && (
                  <div
                    onClick={() => setActiveTab('withdrawals')}
                    className="p-3.5 bg-rose-500/10 border border-rose-500/40 hover:bg-rose-500/20 rounded-2xl cursor-pointer flex items-center justify-between transition-all"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
                        <ArrowDownRight className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-bold text-xs text-rose-300">
                          {pendingWithdrawals.length} Pending Withdrawal{pendingWithdrawals.length > 1 ? 's' : ''}
                        </div>
                        <div className="text-[11px] text-slate-400">Click to process payout requests</div>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-rose-400" />
                  </div>
                )}
              </div>
            )}

            {/* 6 Essential KPI Cards: Total User, Total Withdraw, Total Deposit, Today Deposit, Today Withdraw, Today User Register */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {/* 1. Total User */}
              <div
                onClick={() => setActiveTab('users')}
                className="bg-slate-800/90 border border-slate-700/80 hover:border-blue-500/50 rounded-2xl p-4 shadow-lg flex flex-col justify-between cursor-pointer group transition-all"
                id="stat-total-user"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Total User
                  </span>
                  <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Users className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-black text-white tracking-tight font-mono">
                    {totalUsersCount.toLocaleString()}
                  </div>
                  <div className="flex items-center space-x-1 mt-1 text-[11px] text-blue-400 font-bold">
                    <UserPlus className="w-3 h-3" />
                    <span>+{todayUserRegisterCount} registered today</span>
                  </div>
                </div>
              </div>

              {/* 2. Total Deposit */}
              <div
                onClick={() => setActiveTab('deposits')}
                className="bg-slate-800/90 border border-slate-700/80 hover:border-emerald-500/50 rounded-2xl p-4 shadow-lg flex flex-col justify-between cursor-pointer group transition-all"
                id="stat-total-deposit"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Total Deposit
                  </span>
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-black text-emerald-400 tracking-tight font-mono">
                    ৳{totalDepositAmount.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    All-time approved deposits
                  </div>
                </div>
              </div>

              {/* 3. Total Withdraw */}
              <div
                onClick={() => setActiveTab('withdrawals')}
                className="bg-slate-800/90 border border-slate-700/80 hover:border-rose-500/50 rounded-2xl p-4 shadow-lg flex flex-col justify-between cursor-pointer group transition-all"
                id="stat-total-withdraw"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Total Withdraw
                  </span>
                  <div className="w-8 h-8 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <ArrowDownRight className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-black text-rose-400 tracking-tight font-mono">
                    ৳{totalWithdrawAmount.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    All-time approved payouts
                  </div>
                </div>
              </div>

              {/* 4. Today Deposit */}
              <div
                onClick={() => setActiveTab('deposits')}
                className="bg-slate-800/90 border border-slate-700/80 hover:border-green-400/50 rounded-2xl p-4 shadow-lg flex flex-col justify-between cursor-pointer group transition-all"
                id="stat-today-deposit"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Today Deposit
                  </span>
                  <div className="w-8 h-8 rounded-xl bg-green-500/10 text-green-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-black text-green-400 tracking-tight font-mono">
                    ৳{todayDepositAmount.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-green-300 font-bold mt-1">
                    Approved since 12:00 AM
                  </div>
                </div>
              </div>

              {/* 5. Today Withdraw */}
              <div
                onClick={() => setActiveTab('withdrawals')}
                className="bg-slate-800/90 border border-slate-700/80 hover:border-amber-400/50 rounded-2xl p-4 shadow-lg flex flex-col justify-between cursor-pointer group transition-all"
                id="stat-today-withdraw"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Today Withdraw
                  </span>
                  <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <TrendingDown className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-black text-amber-400 tracking-tight font-mono">
                    ৳{todayWithdrawAmount.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-amber-300 font-bold mt-1">
                    Processed since 12:00 AM
                  </div>
                </div>
              </div>

              {/* 6. Today User Register */}
              <div
                onClick={() => setActiveTab('users')}
                className="bg-slate-800/90 border border-slate-700/80 hover:border-purple-400/50 rounded-2xl p-4 shadow-lg flex flex-col justify-between cursor-pointer group transition-all"
                id="stat-today-user-register"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Today User Register
                  </span>
                  <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <UserPlus className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-black text-purple-400 tracking-tight font-mono">
                    {todayUserRegisterCount.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-purple-300 font-bold mt-1">
                    Registered with Refer Code
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Live Win Go Status & Bet Pool */}
            <div className="bg-slate-800 border border-slate-700 rounded-3xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center space-x-3.5">
                <div className="w-10 h-10 rounded-2xl bg-red-600 text-white flex items-center justify-center font-black text-sm">
                  {gameType}
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-400">Live Win Go Round</div>
                  <div className="font-mono text-sm font-black text-white">
                    Period: <span className="text-amber-400">{periodId}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Current Round Bet Pool</div>
                  <div className="text-base font-black text-green-400 font-mono">৳{totalBetPool.toLocaleString()}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Time Remaining</div>
                  <div className="text-lg font-black text-red-500 font-mono">{timeLeft}s</div>
                </div>
                <button
                  onClick={() => setActiveTab('wingo')}
                  className="px-3.5 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                >
                  Predict Result
                </button>
              </div>
            </div>

            {/* Recent Registered Users */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-1.5 h-4 bg-purple-500 rounded-full"></div>
                  <h3 className="font-black text-sm text-white">Recent Registered Users (সাম্প্রতিক রেজিস্টার্ড ইউজার)</h3>
                </div>
                <button
                  onClick={() => setActiveTab('users')}
                  className="text-xs text-purple-400 font-bold hover:underline"
                >
                  View All ({totalUsersCount})
                </button>
              </div>

              {safeUsersList.length === 0 ? (
                <div className="text-center py-6 text-xs text-slate-400">No users registered yet.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 font-bold">
                        <th className="pb-2">UID</th>
                        <th className="pb-2">Phone / Username</th>
                        <th className="pb-2">Referrer Code</th>
                        <th className="pb-2">VIP Level</th>
                        <th className="pb-2">Balance</th>
                        <th className="pb-2">Registered At</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {safeUsersList.slice(0, 5).map((u) => (
                        <tr key={u.uid} className="hover:bg-slate-800/40">
                          <td className="py-2.5 font-mono text-amber-400 font-bold">{u.uid}</td>
                          <td className="py-2.5 text-white font-medium">{u.phone || u.username || 'User'}</td>
                          <td className="py-2.5 text-slate-300 font-mono text-[11px]">{u.referredBy || 'N/A'}</td>
                          <td className="py-2.5">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-slate-950">
                              VIP {u.vipLevel || 0}
                            </span>
                          </td>
                          <td className="py-2.5 font-mono font-bold text-emerald-400">
                            ৳{(u.balance || 0).toLocaleString()}
                          </td>
                          <td className="py-2.5 text-slate-400 text-[11px]">
                            {u.createdAt ? new Date(u.createdAt).toLocaleString() : 'Recent'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 1. Win Go Controller Tab (30s, 1m, 2m, 3m, 5m) */}
        {activeTab === 'wingo' && (
          <div className="space-y-4">
            <div className="bg-slate-800 rounded-2xl p-4 border border-slate-700 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-slate-400 font-bold">Wingo Cycle:</span>
                  <div className="flex items-center space-x-1 bg-slate-900 p-1 rounded-xl border border-slate-700">
                    {(['30s', '1m', '2m', '3m', '5m'] as GameType[]).map((t) => (
                      <button
                        key={t}
                        onClick={() => setGameType(t)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                          gameType === t ? 'bg-red-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="font-mono text-xs text-slate-400">
                  Period: <span className="text-amber-400 font-bold">{periodId}</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-700">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">
                    Time Remaining
                  </div>
                  <div className="text-3xl font-black text-red-500 font-mono mt-1">
                    {timeLeft}s
                  </div>
                </div>

                <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-700">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">
                    Current Period Bets
                  </div>
                  <div className="text-2xl font-black text-green-400 mt-1">
                    ৳{totalBetPool.toFixed(2)}
                  </div>
                </div>

                <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-700">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">
                    Active Bets Count
                  </div>
                  <div className="text-2xl font-black text-blue-400 mt-1">
                    {currentPeriodBets.length}
                  </div>
                </div>
              </div>

              {/* Force Outcome Control */}
              <div className="pt-2 border-t border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-xs font-bold text-slate-200">
                    Set Predetermined Result for <span className="text-red-400 font-black">{gameType}</span>:
                  </div>
                  {typeof currentForced === 'number' && (
                    <span className="text-[11px] bg-red-600/30 border border-red-500 text-red-300 px-2 py-0.5 rounded-md font-bold">
                      Forced Next: {currentForced}
                    </span>
                  )}
                </div>

                <div className="flex items-center space-x-1.5 flex-wrap gap-y-2">
                  <button
                    onClick={() => adminSetForcedResult(gameType, null)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                      currentForced === null || currentForced === undefined
                        ? 'bg-blue-600 text-white ring-2 ring-blue-400'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    Random (Default)
                  </button>

                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => {
                    const isForced = currentForced === num;
                    const isRed = [2, 4, 6, 8].includes(num);
                    const isGreen = [1, 3, 7, 9].includes(num);

                    return (
                      <button
                        key={num}
                        onClick={() => adminSetForcedResult(gameType, num)}
                        className={`w-8 h-8 rounded-lg text-xs font-black transition-all flex items-center justify-center ${
                          isForced
                            ? 'bg-amber-400 text-slate-950 ring-2 ring-white scale-110 shadow-lg'
                            : isRed
                            ? 'bg-red-700/60 hover:bg-red-600 text-white'
                            : isGreen
                            ? 'bg-green-700/60 hover:bg-green-600 text-white'
                            : 'bg-purple-700/60 hover:bg-purple-600 text-white'
                        }`}
                      >
                        {num}
                      </button>
                    );
                  })}
                </div>
                <p className="text-[11px] text-slate-400 mt-2">
                  * Selecting a number guarantees that the next round of {gameType} will resolve with that exact number.
                </p>
              </div>
            </div>

            {/* Current Period Live Bets List */}
            <div className="bg-slate-800 rounded-2xl p-4 border border-slate-700 space-y-3">
              <h3 className="font-bold text-xs text-slate-200">
                Live Placed Bets ({currentPeriodBets.length})
              </h3>
              {currentPeriodBets.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-4">
                  No bets placed for current round yet.
                </p>
              ) : (
                <div className="divide-y divide-slate-700 text-xs max-h-60 overflow-y-auto">
                  {currentPeriodBets.map((b, bIdx) => (
                    <div key={`live-bet-${b.id || b.periodId || 'b'}-${bIdx}`} className="py-2 flex items-center justify-between">
                      <div>
                        <span className="font-bold text-white">
                          UID: {b.uid} ({b.phone})
                        </span>
                        <div className="text-slate-400 text-[11px]">
                          Pick: <span className="text-amber-400 font-bold uppercase">{b.selectValue}</span> ({b.selectType})
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-green-400">৳{b.totalAmount.toFixed(2)}</div>
                        <div className="text-[10px] text-slate-400">X{b.multiplier}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* 2. Game Management Tab */}
        {activeTab === 'games' && (
          <div className="space-y-5">
            {/* 6 Featured Game Cards Image Management (User Requested) */}
            <div className="bg-slate-800/95 rounded-2xl p-4 border-2 border-red-500/40 shadow-lg space-y-3.5">
              <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-700 pb-2.5">
                <div>
                  <h2 className="font-black text-sm text-white flex items-center space-x-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>Featured 6 Game Cards Image Control (ImgBB & Direct URL)</span>
                  </h2>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    এই ৬টি কার্ড ফিক্সড (এডমিন থেকে এড করার প্রয়োজন নেই)। আপনি শুধু প্রতিটি কার্ডের ইমেজ লিংক পরিবর্তন করতে পারবেন অথবা সরাসরি ছবি আপলোড করতে পারবেন।
                  </p>
                </div>
                <span className="text-[10px] font-bold bg-amber-400/20 text-amber-300 border border-amber-500/40 px-2.5 py-1 rounded-full">
                  ImgBB Key: af0fb4...8a5
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {DEFAULT_FEATURED_GAMES.map((card) => {
                  const currentImg = gameCardUrls[card.id] || card.defaultImage;
                  const isUploading = uploadingCardId === card.id;

                  return (
                    <div
                      key={`admin-feat-card-${card.id}`}
                      className="bg-slate-900/90 rounded-2xl p-3 border border-slate-700/80 flex flex-col justify-between space-y-2.5"
                    >
                      <div className="flex items-start space-x-3">
                        {/* Thumbnail Preview */}
                        <div className="relative w-16 h-16 rounded-xl overflow-hidden bg-slate-950 border border-red-500/50 shrink-0">
                          <img
                            src={currentImg || card.defaultImage}
                            alt={card.name}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = card.defaultImage;
                            }}
                          />
                          <span className="absolute top-0.5 right-0.5 text-[8px] font-black bg-amber-400 text-slate-950 px-1 py-0.2 rounded">
                            {card.badge}
                          </span>
                        </div>

                        {/* Title & Info */}
                        <div className="min-w-0 flex-1 space-y-0.5">
                          <h4 className="font-extrabold text-xs text-white truncate">{card.name}</h4>
                          <span className="inline-block text-[10px] text-slate-400">
                            Category: <strong className="text-amber-300">{card.category}</strong>
                          </span>
                          <p className="text-[10px] text-slate-400 truncate">{card.description}</p>
                          <span className="text-[9px] text-green-400 font-bold block">
                            Target: {card.actionType === 'aviator' ? 'Aviator Crash' : 'Win Go Direct'}
                          </span>
                        </div>
                      </div>

                      {/* Image URL Input & Controls */}
                      <div className="space-y-2 pt-1 border-t border-slate-800">
                        <div>
                          <label className="text-[10px] text-slate-400 block mb-0.5 font-semibold">
                            Image Link (ImgBB / Web URL):
                          </label>
                          <input
                            type="text"
                            value={gameCardUrls[card.id] || ''}
                            onChange={(e) =>
                              setGameCardUrls((prev) => ({ ...prev, [card.id]: e.target.value }))
                            }
                            placeholder={card.defaultImage}
                            className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-xl text-[11px] text-white font-mono placeholder:text-slate-600 focus:outline-none focus:border-red-500"
                          />
                        </div>

                        <div className="flex items-center space-x-1.5">
                          {/* Save URL button */}
                          <button
                            type="button"
                            onClick={() =>
                              handleSaveCardImageUrl(card.id, gameCardUrls[card.id] || card.defaultImage)
                            }
                            className="flex-1 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-[11px] font-bold shadow-xs active:scale-95 transition-all cursor-pointer text-center"
                          >
                            Save Link
                          </button>

                          {/* Direct ImgBB File Upload button */}
                          <label
                            className={`flex-1 py-1.5 px-2 rounded-xl text-[11px] font-bold text-center flex items-center justify-center space-x-1 transition-all cursor-pointer ${
                              isUploading
                                ? 'bg-amber-600 text-white animate-pulse'
                                : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
                            }`}
                            title="Upload directly to ImgBB"
                          >
                            <Upload className="w-3 h-3 shrink-0" />
                            <span>{isUploading ? 'Uploading...' : 'Upload'}</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              disabled={isUploading}
                              onChange={(e) => handleCardImageUpload(card.id, e)}
                            />
                          </label>

                          {/* Reset to default */}
                          {gameCardUrls[card.id] && (
                            <button
                              type="button"
                              onClick={() => handleResetCardImage(card.id)}
                              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl text-[10px]"
                              title="Reset to default image"
                            >
                              <RotateCcw className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Existing Custom Games Catalog */}
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-bold text-sm text-white">Custom Dynamic Games Catalog</h2>
                <p className="text-[11px] text-slate-400">
                  Additional HTML5 or API games to feature in More Games section
                </p>
              </div>
              <button
                onClick={openNewGameModal}
                className="px-3.5 py-1.5 rounded-xl bg-green-600 hover:bg-green-500 text-white font-bold text-xs flex items-center space-x-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
                id="admin-add-game-btn"
              >
                <Plus className="w-4 h-4" />
                <span>Add Extra Game</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {games.map((g, gIdx) => {
                const isApi = g.integrationType === 'api' || (g.gamePath && (g.gamePath.startsWith('http://') || g.gamePath.startsWith('https://')));
                return (
                  <div
                    key={`game-${g.id || g.name || 'g'}-${gIdx}`}
                    className="bg-slate-800 rounded-2xl p-3 border border-slate-700 flex space-x-3 items-center"
                  >
                    <img
                      src={g.image || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80'}
                      alt={g.name}
                      className="w-16 h-16 rounded-xl object-cover bg-slate-900 shrink-0 border border-slate-700"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src =
                          'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80';
                      }}
                    />

                    <div className="flex-1 min-w-0 text-xs space-y-1">
                      <div className="flex items-center space-x-1.5">
                        <h4 className="font-bold text-white truncate">{g.name}</h4>
                        {g.badge && (
                          <span className="text-[9px] bg-red-600 text-white font-black px-1.5 py-0.2 rounded">
                            {g.badge}
                          </span>
                        )}
                        <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${
                          isApi
                            ? 'bg-blue-950/70 text-blue-300 border-blue-600/50'
                            : 'bg-emerald-950/70 text-emerald-300 border-emerald-600/50'
                        }`}>
                          {isApi ? `API: ${g.provider || 'Provider'}` : 'HTML5'}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Category: <span className="text-amber-400 font-bold">{g.category}</span> • Order: #{g.sortOrder || 1} • RTP: {g.rtp || 96.8}%
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono truncate">
                        {isApi ? (g.apiEndpoint || g.gamePath) : `/${g.gamePath}`}
                      </div>
                    </div>

                    <div className="flex flex-col space-y-1 shrink-0">
                      <button
                        onClick={() => adminToggleGameStatus(g.id, g.status !== false)}
                        className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                          g.status !== false
                            ? 'bg-green-600/20 text-green-400 border border-green-600/50'
                            : 'bg-red-600/20 text-red-400 border border-red-600/50'
                        }`}
                      >
                        {g.status !== false ? 'Active' : 'Disabled'}
                      </button>
                      <div className="flex items-center space-x-1">
                        <button
                          onClick={() => {
                            const url = isApi ? (g.apiEndpoint || g.gamePath) : `/${g.gamePath}`;
                            if (url) window.open(url, '_blank');
                          }}
                          className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg"
                          title="Test Launch Game"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => openEditGameModal(g)}
                          className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg"
                          title="Edit Game"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteGame(g.id, g.name)}
                          className="p-1.5 bg-red-600/30 hover:bg-red-600 text-red-400 hover:text-white rounded-lg"
                          title="Delete Game"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Game Add/Edit Modal (HTML5 & API Provider Integration) */}
            {isGameModalOpen && (
              <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
                <div className="bg-slate-800 border border-slate-700 rounded-3xl max-w-lg w-full p-5 space-y-4 text-xs max-h-[92vh] overflow-y-auto shadow-2xl">
                  <div className="flex items-center justify-between border-b border-slate-700 pb-2.5">
                    <div>
                      <h3 className="font-bold text-sm text-white">
                        {editingGameId ? 'Edit Game Configuration' : 'Add New Dynamic Game'}
                      </h3>
                      <p className="text-[10px] text-slate-400">
                        Select HTML5 file or API Provider integration
                      </p>
                    </div>
                    <button
                      onClick={() => setIsGameModalOpen(false)}
                      className="text-slate-400 hover:text-white p-1 rounded-lg bg-slate-700/50"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                    {/* System Switcher Tab: Public HTML Game vs API Gaming System */}
                    <div className="grid grid-cols-2 gap-2 bg-slate-900 p-1 rounded-2xl border border-slate-700">
                      <button
                        type="button"
                        onClick={() => setGameForm({ ...gameForm, integrationType: 'html5' })}
                        className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-1.5 transition-all ${
                          gameForm.integrationType === 'html5'
                            ? 'bg-emerald-600 text-white shadow-md'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <Gamepad2 className="w-4 h-4" />
                        <span>Public HTML Game (পাবলিক HTML ফাইল)</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setGameForm({ ...gameForm, integrationType: 'api' })}
                        className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-1.5 transition-all ${
                          gameForm.integrationType === 'api'
                            ? 'bg-blue-600 text-white shadow-md'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <Sparkles className="w-4 h-4" />
                        <span>API Gaming System (NEW)</span>
                      </button>
                    </div>

                    <form onSubmit={handleSaveGame} className="space-y-3">
                      <div>
                        <label className="text-slate-400 font-semibold block mb-1">Game Name:</label>
                        <input
                          type="text"
                          value={gameForm.name}
                          onChange={(e) => setGameForm({ ...gameForm, name: e.target.value })}
                          placeholder="e.g. Aviator Pro, Super Ace, Fortune Tiger"
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold"
                          required
                        />
                      </div>

                      <div>
                        <label className="text-slate-400 font-semibold block mb-1">Thumbnail Image URL:</label>
                        <input
                          type="url"
                          value={gameForm.image}
                          onChange={(e) => setGameForm({ ...gameForm, image: e.target.value })}
                          placeholder="https://..."
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono"
                          required
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-slate-400 font-semibold block mb-1">Category:</label>
                          <select
                            value={gameForm.category}
                            onChange={(e) => setGameForm({ ...gameForm, category: e.target.value })}
                            className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold"
                          >
                            <option value="Popular">Popular</option>
                            <option value="Lottery">Lottery</option>
                            <option value="Slots">Slots</option>
                            <option value="Sports">Sports</option>
                            <option value="Casino">Casino</option>
                            <option value="Rummy">Rummy</option>
                            <option value="Fishing">Fishing</option>
                            <option value="Original">Original</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-slate-400 font-semibold block mb-1">Badge Tag:</label>
                          <select
                            value={gameForm.badge}
                            onChange={(e) => setGameForm({ ...gameForm, badge: e.target.value })}
                            className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold"
                          >
                            <option value="HOT">HOT</option>
                            <option value="NEW">NEW</option>
                            <option value="TOP">TOP</option>
                            <option value="LIVE">LIVE</option>
                            <option value="FAST">FAST</option>
                            <option value="">None</option>
                          </select>
                        </div>
                      </div>

                      {/* Dynamic Fields Based on System (HTML5 vs API) */}
                      {gameForm.integrationType === 'html5' ? (
                        <div className="p-3 bg-emerald-950/30 border border-emerald-800/40 rounded-2xl space-y-2">
                          <div className="flex items-center space-x-2 text-emerald-400 font-bold">
                            <Gamepad2 className="w-4 h-4" />
                            <span>Public HTML Game File Configuration</span>
                          </div>
                          <p className="text-[10px] text-slate-400">
                            Enter file path from public directory (e.g., games/aviator/index.html or public/games/mygame.html)
                          </p>
                          <div>
                            <label className="text-slate-400 font-semibold block mb-1">Public HTML Game Path:</label>
                            <input
                              type="text"
                              value={gameForm.gamePath}
                              onChange={(e) => setGameForm({ ...gameForm, gamePath: e.target.value })}
                              placeholder="games/aviator/index.html or games/slot/index.html"
                              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-xs"
                              required
                            />
                          </div>
                          {/* Preset Quick HTML Links */}
                          <div className="flex flex-wrap gap-1.5 pt-1">
                            <span className="text-[10px] text-slate-400 self-center">Presets:</span>
                            <button
                              type="button"
                              onClick={() => setGameForm({ ...gameForm, gamePath: 'games/aviator/index.html' })}
                              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-mono"
                            >
                              games/aviator/index.html
                            </button>
                          </div>
                        </div>
                      ) : (
                      <div className="p-3 bg-blue-950/30 border border-blue-800/40 rounded-2xl space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2 text-blue-400 font-bold">
                            <Sparkles className="w-4 h-4" />
                            <span>API Gaming System Configuration</span>
                          </div>
                          <span className="text-[9px] bg-blue-500/20 text-blue-300 font-bold px-2 py-0.5 rounded-full border border-blue-400/30">
                            Live Gateway
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="text-slate-400 font-semibold block mb-1">API Provider:</label>
                            <select
                              value={gameForm.apiProvider}
                              onChange={(e) => setGameForm({
                                ...gameForm,
                                apiProvider: e.target.value,
                                provider: e.target.value
                              })}
                              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold"
                            >
                              <option value="JILI">JILI Games</option>
                              <option value="PG Soft">PG Soft (Pocket Games)</option>
                              <option value="Pragmatic Play">Pragmatic Play</option>
                              <option value="Spribe">Spribe (Aviator/Mines)</option>
                              <option value="Evolution">Evolution Gaming</option>
                              <option value="FastSpin">FastSpin</option>
                              <option value="CQ9">CQ9 Gaming</option>
                              <option value="JDB">JDB Gaming</option>
                              <option value="Custom API">Custom API Gateway</option>
                            </select>
                          </div>

                          <div>
                            <label className="text-slate-400 font-semibold block mb-1">API Game Code / Slug:</label>
                            <input
                              type="text"
                              value={gameForm.apiGameCode || ''}
                              onChange={(e) => setGameForm({ ...gameForm, apiGameCode: e.target.value })}
                              placeholder="e.g. jili_super_ace"
                              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-xs"
                            />
                          </div>
                        </div>

                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-slate-400 font-semibold block">API Launch Endpoint / Game URL:</label>
                            {gameForm.apiEndpoint && (
                              <button
                                type="button"
                                onClick={() => window.open(gameForm.apiEndpoint, '_blank')}
                                className="text-blue-400 hover:text-blue-300 flex items-center space-x-1 text-[10px] font-bold"
                              >
                                <ExternalLink className="w-3 h-3" />
                                <span>Test Launch</span>
                              </button>
                            )}
                          </div>
                          <input
                            type="url"
                            value={gameForm.apiEndpoint || ''}
                            onChange={(e) => setGameForm({ ...gameForm, apiEndpoint: e.target.value })}
                            placeholder="https://api.provider.com/launch?game=... or direct URL"
                            className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-xs"
                            required={gameForm.integrationType === 'api'}
                          />
                        </div>

                        <div className="flex items-center space-x-2 pt-0.5">
                          <input
                            type="checkbox"
                            id="game-api-auto-session"
                            checked={gameForm.apiAutoSession !== false}
                            onChange={(e) => setGameForm({ ...gameForm, apiAutoSession: e.target.checked })}
                            className="rounded accent-blue-600"
                          />
                          <label htmlFor="game-api-auto-session" className="text-slate-300 text-[11px] font-semibold">
                            Auto append player parameters (<span className="text-blue-300 font-mono text-[10px]">&uid=...&token=...&currency=BDT</span>)
                          </label>
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-slate-400 font-semibold block mb-1">Game Provider Brand:</label>
                        <input
                          type="text"
                          value={gameForm.provider || ''}
                          onChange={(e) => setGameForm({ ...gameForm, provider: e.target.value })}
                          placeholder="e.g. JILI, PG Soft, Spribe, Original"
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-slate-400 font-semibold block mb-1">RTP % (Return to Player):</label>
                        <input
                          type="number"
                          step="0.1"
                          value={gameForm.rtp || 96.8}
                          onChange={(e) => setGameForm({ ...gameForm, rtp: parseFloat(e.target.value) || 96.8 })}
                          placeholder="97.2"
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-xs"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-400 font-semibold block mb-1">Display Sort Order:</label>
                      <input
                        type="number"
                        value={gameForm.sortOrder}
                        onChange={(e) => setGameForm({ ...gameForm, sortOrder: parseInt(e.target.value) || 1 })}
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold"
                      />
                    </div>

                    <div className="flex items-center space-x-2 pt-1">
                      <input
                        type="checkbox"
                        id="game-active-status"
                        checked={gameForm.status}
                        onChange={(e) => setGameForm({ ...gameForm, status: e.target.checked })}
                        className="rounded accent-red-600"
                      />
                      <label htmlFor="game-active-status" className="text-slate-300 font-bold">
                        Game Active & Visible to Players
                      </label>
                    </div>

                    <div className="flex space-x-2 pt-3">
                      <button
                        type="button"
                        onClick={() => setIsGameModalOpen(false)}
                        className="flex-1 py-2 bg-slate-700 text-white rounded-xl font-bold cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="flex-1 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl font-bold shadow-md cursor-pointer"
                      >
                        {editingGameId ? 'Save Changes' : 'Create Game'}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 2.1 Banner Management Tab (5 Banners & Activity Banners) */}
        {activeTab === 'banners' && (
          <div className="space-y-4">
            {/* Sub-tab switcher */}
            <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded-2xl border border-slate-800">
              <button
                type="button"
                onClick={() => setBannerCategory('home')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-2 ${
                  bannerCategory === 'home'
                    ? 'bg-gradient-to-r from-red-600 to-orange-500 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Homepage Banners (5 Carousel)</span>
              </button>
              <button
                type="button"
                onClick={() => setBannerCategory('activity')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-2 ${
                  bannerCategory === 'activity'
                    ? 'bg-gradient-to-r from-red-600 to-orange-500 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Activity Page Banners (Events & Promotions)</span>
              </button>
            </div>

            {bannerCategory === 'activity' ? (
              <AdminActivityBannerManagement />
            ) : (
              <>
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <h2 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                      <ImageIcon className="w-4 h-4 text-red-500" />
                      <span>Homepage Banner Management (5 Banners)</span>
                    </h2>
                    <span className="text-[11px] text-slate-400">
                      Manage the official promotional carousel displayed on user dashboard (5 banners max recommended)
                    </span>
                  </div>

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={async () => {
                    if (window.confirm('Restore 5 official default banners to homepage?')) {
                      await adminResetDefaultBanners();
                      showToast('5 Official Default Banners restored successfully!', 'success');
                    }
                  }}
                  className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs font-bold flex items-center space-x-1.5 active:scale-95 transition-all"
                  title="Reset 5 Default Banners"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                  <span>Restore 5 Banners</span>
                </button>

                <button
                  onClick={openNewBannerModal}
                  className="px-3.5 py-2 bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-500 hover:to-orange-400 text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 shadow-md active:scale-95 transition-all"
                  id="admin-add-banner-btn"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Banner</span>
                </button>
              </div>
            </div>

            {/* Banner List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {banners
                .slice()
                .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
                .map((b, bIdx) => (
                  <div
                    key={`banner-${b.id || b.order || 'b'}-${bIdx}`}
                    className="bg-slate-800 rounded-2xl overflow-hidden border border-slate-700 shadow-sm flex flex-col justify-between"
                  >
                    {/* Banner Image Preview */}
                    <div className="relative aspect-[21/9] bg-slate-900 overflow-hidden">
                      <img
                        src={b.image || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80'}
                        alt={b.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src =
                            'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80';
                        }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-3">
                        <div>
                          <span className="text-[10px] font-black bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full uppercase">
                            Order #{b.order ?? 1}
                          </span>
                          <h4 className="font-extrabold text-xs text-white drop-shadow mt-1">
                            {b.title}
                          </h4>
                          <p className="text-[11px] text-slate-200 line-clamp-1">
                            {b.subtitle}
                          </p>
                        </div>
                      </div>

                      <span
                        className={`absolute top-2 right-2 text-[10px] font-black px-2 py-0.5 rounded-full uppercase ${
                          b.active !== false
                            ? 'bg-green-500 text-white'
                            : 'bg-slate-700 text-slate-300'
                        }`}
                      >
                        {b.active !== false ? 'Active' : 'Inactive'}
                      </span>
                    </div>

                    {/* Banner Info & Actions */}
                    <div className="p-3 space-y-2">
                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span>
                          Action: <strong className="text-white uppercase">{b.action || 'wingo'}</strong>
                        </span>
                        <span>
                          Button: <strong className="text-white">{b.buttonText || 'Play Now'}</strong>
                        </span>
                      </div>

                      <div className="flex items-center space-x-2 pt-1 border-t border-slate-700/60">
                        <button
                          onClick={() => adminToggleBannerStatus(b.id, b.active !== false)}
                          className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all ${
                            b.active !== false
                              ? 'bg-amber-600/20 text-amber-400 hover:bg-amber-600/30'
                              : 'bg-green-600/20 text-green-400 hover:bg-green-600/30'
                          }`}
                        >
                          {b.active !== false ? 'Pause Banner' : 'Activate'}
                        </button>

                        <label
                          className="px-2.5 py-1.5 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 rounded-xl text-xs font-bold flex items-center space-x-1 cursor-pointer transition-all"
                          title="Upload replacement image to ImgBB"
                        >
                          <Upload className="w-3 h-3" />
                          <span>ImgBB</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => handleQuickBannerImageUpload(b, e)}
                          />
                        </label>

                        <button
                          onClick={() => openEditBannerModal(b)}
                          className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-bold flex items-center space-x-1"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>

                        <button
                          onClick={() => handleDeleteBanner(b.id, b.title)}
                          className="px-3 py-1.5 bg-red-600/20 hover:bg-red-600 text-red-300 hover:text-white rounded-xl text-xs font-bold flex items-center space-x-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
            </div>

            {/* Banner Modal */}
            {isBannerModalOpen && (
              <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
                <div className="bg-slate-800 border border-slate-700 rounded-3xl max-w-md w-full p-5 space-y-4 text-xs shadow-2xl">
                  <div className="flex items-center justify-between border-b border-slate-700 pb-2">
                    <h3 className="font-bold text-sm text-white flex items-center space-x-2">
                      <ImageIcon className="w-4 h-4 text-red-500" />
                      <span>{editingBannerId ? 'Edit Banner' : 'Create New Banner'}</span>
                    </h3>
                    <button
                      onClick={() => setIsBannerModalOpen(false)}
                      className="p-1 rounded-lg text-slate-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <form onSubmit={handleSaveBanner} className="space-y-3">
                    <div>
                      <label className="text-slate-400 font-semibold block mb-1">
                        Banner Headline:
                      </label>
                      <input
                        type="text"
                        value={bannerForm.title}
                        onChange={(e) => setBannerForm({ ...bannerForm, title: e.target.value })}
                        placeholder="e.g. Largest Online Entertainment Hub"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-slate-400 font-semibold block mb-1">
                        Subtitle / Description:
                      </label>
                      <input
                        type="text"
                        value={bannerForm.subtitle}
                        onChange={(e) => setBannerForm({ ...bannerForm, subtitle: e.target.value })}
                        placeholder="e.g. Instant Nagad & bKash payouts"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <label className="text-slate-400 font-semibold block text-xs">
                          Banner Image (ImgBB / URL):
                        </label>
                        <span className="text-[10px] text-amber-400 font-mono font-bold">
                          ImgBB Key: af0fb4...8a5
                        </span>
                      </div>

                      <div className="flex items-center space-x-2">
                        <input
                          type="url"
                          value={bannerForm.image}
                          onChange={(e) => setBannerForm({ ...bannerForm, image: e.target.value })}
                          placeholder="https://i.ibb.co/... or image URL"
                          className="flex-1 px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-[11px] focus:outline-none focus:border-red-500"
                        />
                        <label
                          className={`px-3 py-2 rounded-xl text-xs font-bold text-center flex items-center justify-center space-x-1 transition-all cursor-pointer shrink-0 ${
                            uploadingBanner
                              ? 'bg-amber-600 text-white animate-pulse'
                              : 'bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-500 hover:to-orange-400 text-white shadow-md'
                          }`}
                          title="Upload image directly to ImgBB"
                        >
                          <Upload className="w-3.5 h-3.5" />
                          <span>{uploadingBanner ? 'Uploading...' : 'Upload ImgBB'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            disabled={uploadingBanner}
                            onChange={handleBannerImageUpload}
                          />
                        </label>
                      </div>

                      {Boolean(bannerForm.image && bannerForm.image.trim()) && (
                        <div className="relative aspect-[21/9] rounded-xl overflow-hidden bg-slate-950 border border-slate-700 mt-2">
                          <img
                            src={bannerForm.image}
                            alt="Banner Preview"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src =
                                'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80';
                            }}
                          />
                          <span className="absolute bottom-1 right-2 text-[9px] bg-slate-950/80 text-white px-2 py-0.5 rounded font-mono">
                            Live Preview
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-slate-400 font-semibold block mb-1">
                          Button Text:
                        </label>
                        <input
                          type="text"
                          value={bannerForm.buttonText}
                          onChange={(e) => setBannerForm({ ...bannerForm, buttonText: e.target.value })}
                          placeholder="Play Now"
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold"
                        />
                      </div>

                      <div>
                        <label className="text-slate-400 font-semibold block mb-1">
                          Target Action:
                        </label>
                        <select
                          value={bannerForm.action}
                          onChange={(e) => setBannerForm({ ...bannerForm, action: e.target.value })}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold"
                        >
                          <option value="wingo">Play Win Go</option>
                          <option value="deposit">Deposit Page</option>
                          <option value="withdraw">Withdraw Page</option>
                          <option value="activity">Activity / Gifts</option>
                          <option value="promotion">Promotion / VIP</option>
                          <option value="safe">Safe Vault</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-slate-400 font-semibold block mb-1">
                          Display Priority / Order:
                        </label>
                        <input
                          type="number"
                          min={1}
                          value={bannerForm.order}
                          onChange={(e) => setBannerForm({ ...bannerForm, order: parseInt(e.target.value) || 1 })}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold"
                        />
                      </div>

                      <div className="flex items-center space-x-2 pt-5">
                        <input
                          type="checkbox"
                          id="banner-active"
                          checked={bannerForm.active}
                          onChange={(e) => setBannerForm({ ...bannerForm, active: e.target.checked })}
                          className="rounded accent-red-600"
                        />
                        <label htmlFor="banner-active" className="text-slate-200 font-bold">
                          Active & Visible
                        </label>
                      </div>
                    </div>

                    <div className="flex space-x-2 pt-3">
                      <button
                        type="button"
                        onClick={() => setIsBannerModalOpen(false)}
                        className="flex-1 py-2 bg-slate-700 text-white rounded-xl font-bold"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="flex-1 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl font-bold shadow-md"
                      >
                        {editingBannerId ? 'Save Changes' : 'Create Banner'}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
              </>
            )}
          </div>
        )}

        {/* 3. Users & VIP Control Tab */}
        {activeTab === 'users' && (
          <div className="space-y-3">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search user by UID, phone, username or email..."
                className="w-full pl-9 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none"
              />
            </div>

            <div className="space-y-2.5">
              {(() => {
                const rawList = (Array.isArray(allUsers)
                  ? allUsers
                  : Object.entries(allUsers || {}).map(([key, val]: [string, any]) => ({
                      ...val,
                      uid: val?.uid || key
                    }))
                );
                const seenUids = new Set<string>();
                return rawList.filter((u) => {
                  const uid = u?.uid || '';
                  if (uid && seenUids.has(uid)) return false;
                  if (uid) seenUids.add(uid);
                  const q = searchQuery.toLowerCase().trim();
                  if (!q) return true;
                  const uidStr = uid.toLowerCase();
                  return (
                    uidStr.includes(q) ||
                    u.phone?.toLowerCase().includes(q) ||
                    u.email?.toLowerCase().includes(q) ||
                    u.username?.toLowerCase().includes(q) ||
                    u.nickname?.toLowerCase().includes(q)
                  );
                });
              })()
                .map((u, uIdx) => (
                  <div
                    key={`admin-u-${u.uid || 'u'}-${uIdx}`}
                    className="bg-slate-800 rounded-2xl p-4 border border-slate-700 space-y-2.5 text-xs"
                  >
                    <div className="flex items-start justify-between flex-wrap gap-2">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-white text-sm">
                            {u.nickname || u.username || 'Member'}
                          </span>
                          <span className="text-[10px] font-black bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full">
                            VIP {u.vipLevel || 1}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              u.status === 'banned'
                                ? 'bg-red-500/20 text-red-400 border border-red-500'
                                : 'bg-green-500/20 text-green-400'
                            }`}
                          >
                            {u.status === 'banned' ? 'BANNED' : 'ACTIVE'}
                          </span>
                        </div>
                        <div className="text-slate-400 text-[11px] font-mono mt-1 space-x-2">
                          <span>UID: {u.uid}</span>
                          <span>•</span>
                          <span>Phone: {u.phone}</span>
                          <span>•</span>
                          <span>Email: {u.email || 'N/A'}</span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          Referral Code: <span className="text-amber-400 font-mono font-bold">{u.inviteCode}</span>
                          {u.invitedBy && (
                            <span className="ml-2">(Invited by: {u.invitedBy})</span>
                          )}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-green-400 font-extrabold text-base">
                          ৳{u.balance?.toFixed(2) || '0.00'}
                        </div>
                        <div className="text-slate-400 text-[10px]">
                          Safe Balance: ৳{u.safeBalance?.toFixed(2) || '0.00'}
                        </div>
                        <div className="text-slate-400 text-[10px]">
                          Total Bets: ৳{u.totalBets?.toFixed(2) || '0.00'}
                        </div>
                      </div>
                    </div>

                    {/* Saved Withdrawal Numbers (Max 3) */}
                    <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-700/60 space-y-1">
                      <span className="text-[10px] font-bold uppercase text-slate-400">
                        Saved Withdrawal Accounts ({u.savedWithdrawAccounts?.length || 0}/3):
                      </span>
                      {u.savedWithdrawAccounts && u.savedWithdrawAccounts.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {u.savedWithdrawAccounts.map((acc, accIdx) => (
                            <span
                              key={`acc-${acc.id || u.uid || 'a'}-${accIdx}`}
                              className="text-[11px] bg-slate-800 border border-slate-700 px-2 py-0.5 rounded-lg text-slate-300 font-mono"
                            >
                              <strong className="text-amber-400">{acc.type}:</strong> {acc.accountNumber} ({acc.accountName})
                            </span>
                          ))}
                        </div>
                      ) : (
                        <span className="text-[11px] text-slate-500 italic block">
                          No saved withdrawal numbers yet.
                        </span>
                      )}
                    </div>

                    {/* Controls */}
                    <div className="flex items-center space-x-2 pt-1 border-t border-slate-700/60">
                      <button
                        onClick={() => setAdjustUid(u.uid)}
                        className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 rounded-xl text-xs font-bold text-white flex items-center space-x-1"
                      >
                        <DollarSign className="w-3.5 h-3.5 text-green-400" />
                        <span>Adjust Balance</span>
                      </button>

                      {/* Change VIP Level Quick Dropdown */}
                      <div className="flex items-center space-x-1">
                        <span className="text-[11px] text-slate-400">Set VIP:</span>
                        <select
                          value={u.vipLevel || 1}
                          onChange={(e) => adminUpdateUserVip(u.uid, parseInt(e.target.value))}
                          className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-amber-400 font-bold"
                        >
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((lvl) => (
                            <option key={lvl} value={lvl}>
                              VIP {lvl}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Ban / Unban */}
                      <button
                        onClick={() => adminToggleUserBan(u.uid, u.status)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1 ${
                          u.status === 'banned'
                            ? 'bg-green-600 hover:bg-green-500 text-white'
                            : 'bg-red-600/30 hover:bg-red-600 text-red-300 hover:text-white'
                        }`}
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>{u.status === 'banned' ? 'Unban User' : 'Ban User'}</span>
                      </button>
                    </div>
                  </div>
                ))}
            </div>

            {/* Adjust Balance Modal */}
            {adjustUid && (
              <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
                <div className="bg-slate-800 border border-slate-700 rounded-2xl max-w-xs w-full p-5 space-y-3">
                  <h4 className="font-bold text-sm text-white">Adjust Balance for UID {adjustUid}</h4>
                  <p className="text-xs text-slate-400">
                    Enter amount to add (+500) or deduct (-200):
                  </p>
                  <input
                    type="number"
                    value={adjustAmount}
                    onChange={(e) => setAdjustAmount(e.target.value)}
                    placeholder="+500 or -200"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-xl text-sm font-bold text-white"
                  />
                  <div className="flex space-x-2 pt-2">
                    <button
                      onClick={() => setAdjustUid(null)}
                      className="flex-1 py-2 bg-slate-700 text-white rounded-xl text-xs font-bold"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleAdjustBalance(adjustUid)}
                      className="flex-1 py-2 bg-green-600 text-white rounded-xl text-xs font-bold"
                    >
                      Apply
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 10 VIP Levels & Bonus Management Tab */}
        {activeTab === 'vip' && <AdminVipManagement />}

        {/* 4. Payment Channels Management Tab */}
        {activeTab === 'channels' && (
          <div className="space-y-4 text-xs">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-2 border-b border-slate-700">
              <div>
                <h2 className="font-bold text-sm text-white flex items-center space-x-2">
                  <CreditCard className="w-4 h-4 text-orange-400" />
                  <span>Admin Deposit Channel Management Control</span>
                </h2>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Configure dynamic payment gateways, Min/Max limits, wallet numbers, and Request Page templates (A, B, C, D)
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    setEditingChannel({
                      channelId: `ch_${Date.now()}`,
                      channelName: 'New Deposit Channel',
                      paymentType: 'Nagad',
                      currency: 'BDT',
                      minimumDeposit: 300,
                      maximumDeposit: 25000,
                      paymentNumber: '01700000000',
                      accountType: 'Agent',
                      network: 'TRC20',
                      requestPage: 'A',
                      transactionRequired: true,
                      instructions: 'Send money or cash out to the agent number above and submit Transaction ID.',
                      warningText: 'Do not deposit through personal number if agent is specified.',
                      title: 'Official Deposit Gateway',
                      logo: EWALLET_DEFAULT_IMAGE,
                      countdownMinutes: 15,
                      buttonText: 'CONFIRM & SUBMIT DEPOSIT',
                      enabled: true,
                      sortOrder: (depositChannels?.length || 0) + 1
                    });
                    setIsChannelModalOpen(true);
                  }}
                  className="px-3 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold rounded-xl flex items-center space-x-1.5 shadow-md active:scale-95 transition-all"
                  id="admin-add-channel-btn"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Channel</span>
                </button>
                <button
                  onClick={async () => {
                    if (window.confirm('Reset all deposit channels to official default presets?')) {
                      await adminResetDefaultChannels();
                    }
                  }}
                  className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 font-bold rounded-xl flex items-center space-x-1.5 active:scale-95 transition-all"
                  id="admin-reset-channels-btn"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reset Presets</span>
                </button>
              </div>
            </div>

            {/* List of Active & Configured Channels */}
            {(!depositChannels || depositChannels.length === 0) ? (
              <div className="bg-slate-800/80 rounded-2xl p-8 text-center text-slate-400 space-y-3 border border-slate-700">
                <p>No deposit channels configured yet.</p>
                <button
                  onClick={adminResetDefaultChannels}
                  className="px-4 py-2 bg-orange-600 text-white font-bold rounded-xl shadow-md"
                >
                  Initialize Default Channels
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {depositChannels.map((ch, chIdx) => (
                  <div
                    key={`ch-${ch.channelId || chIdx}-${chIdx}`}
                    className={`bg-slate-800/90 rounded-2xl p-4 border transition-all space-y-3 ${
                      ch.enabled !== false ? 'border-slate-700' : 'border-red-900/50 opacity-60'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center p-1.5 overflow-hidden shrink-0">
                          <img
                            src={ch.logo || EWALLET_DEFAULT_IMAGE}
                            alt={ch.channelName}
                            className="w-full h-full object-contain"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = EWALLET_DEFAULT_IMAGE;
                            }}
                          />
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <h4 className="font-black text-sm text-white">{ch.channelName}</h4>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                ch.paymentType === 'Nagad'
                                  ? 'bg-orange-900/60 text-orange-300 border border-orange-700/50'
                                  : ch.paymentType === 'bKash'
                                  ? 'bg-pink-900/60 text-pink-300 border border-pink-700/50'
                                  : ch.paymentType === 'Rocket'
                                  ? 'bg-purple-900/60 text-purple-300 border border-purple-700/50'
                                  : 'bg-emerald-900/60 text-emerald-300 border border-emerald-700/50'
                              }`}
                            >
                              {ch.paymentType}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                            ID: {ch.channelId} • Template {ch.requestPage || 'A'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-1.5">
                        <button
                          onClick={() => adminSaveDepositChannel({ ...ch, enabled: !ch.enabled })}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                            ch.enabled !== false
                              ? 'bg-green-600/90 hover:bg-green-600 text-white'
                              : 'bg-slate-700 hover:bg-slate-600 text-slate-400'
                          }`}
                          title="Toggle Active Status"
                        >
                          {ch.enabled !== false ? 'Active' : 'Disabled'}
                        </button>
                        <button
                          onClick={() => {
                            setEditingChannel({ ...ch });
                            setIsChannelModalOpen(true);
                          }}
                          className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg active:scale-95 transition-all"
                          title="Edit Channel"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={async () => {
                            if (window.confirm(`Delete deposit channel "${ch.channelName}"?`)) {
                              await adminDeleteDepositChannel(ch.channelId);
                            }
                          }}
                          className="p-1.5 bg-red-900/40 hover:bg-red-800 text-red-300 rounded-lg active:scale-95 transition-all"
                          title="Delete Channel"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Details Box */}
                    <div className="bg-slate-900/80 rounded-xl p-2.5 border border-slate-700/60 space-y-1.5 text-[11px]">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400 font-medium">Payment Target:</span>
                        <span className="text-white font-mono font-bold select-all">
                          {ch.paymentNumber || ch.walletAddress || 'Not configured'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400 font-medium">Channel Min/Max:</span>
                        <span className="text-amber-400 font-bold font-mono">
                          {ch.currency === 'USDT' ? '$' : '৳'}{ch.minimumDeposit.toLocaleString()} - {ch.currency === 'USDT' ? '$' : '৳'}{ch.maximumDeposit.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400 font-medium">Account Type & Network:</span>
                        <span className="text-slate-200 font-semibold">
                          {ch.accountType} {ch.network ? `(${ch.network})` : ''}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400 font-medium">TxID Required:</span>
                        <span className={ch.transactionRequired ? 'text-green-400 font-bold' : 'text-slate-400'}>
                          {ch.transactionRequired ? 'Yes (Mandatory)' : 'No'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Modal for Add / Edit Deposit Channel */}
            {isChannelModalOpen && editingChannel && (
              <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
                <div className="bg-slate-900 border border-slate-700 rounded-3xl p-5 w-full max-w-lg text-white space-y-4 shadow-2xl my-6 max-h-[90vh] overflow-y-auto">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-700">
                    <h3 className="text-base font-black text-white flex items-center space-x-2">
                      <CreditCard className="w-5 h-5 text-orange-400" />
                      <span>Edit Deposit Channel Configuration</span>
                    </h3>
                    <button
                      onClick={() => {
                        setIsChannelModalOpen(false);
                        setEditingChannel(null);
                      }}
                      className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    {/* Channel ID */}
                    <div>
                      <label className="text-slate-400 font-semibold block mb-1">Channel ID (unique):</label>
                      <input
                        type="text"
                        value={editingChannel.channelId}
                        onChange={(e) =>
                          setEditingChannel({ ...editingChannel, channelId: e.target.value })
                        }
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-mono font-bold"
                      />
                    </div>

                    {/* Channel Name */}
                    <div>
                      <label className="text-slate-400 font-semibold block mb-1">Channel Name:</label>
                      <input
                        type="text"
                        value={editingChannel.channelName}
                        onChange={(e) =>
                          setEditingChannel({ ...editingChannel, channelName: e.target.value })
                        }
                        placeholder="e.g. StarPago-NAGAD"
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-bold"
                      />
                    </div>

                    {/* Payment Type */}
                    <div>
                      <label className="text-slate-400 font-semibold block mb-1">Payment Type:</label>
                      <select
                        value={editingChannel.paymentType}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            paymentType: e.target.value as any,
                            currency: e.target.value === 'USDT' ? 'USDT' : 'BDT'
                          })
                        }
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-bold"
                      >
                        <option value="Nagad">Nagad</option>
                        <option value="bKash">bKash</option>
                        <option value="Rocket">Rocket</option>
                        <option value="USDT">USDT</option>
                      </select>
                    </div>

                    {/* Currency */}
                    <div>
                      <label className="text-slate-400 font-semibold block mb-1">Currency:</label>
                      <select
                        value={editingChannel.currency}
                        onChange={(e) =>
                          setEditingChannel({ ...editingChannel, currency: e.target.value as any })
                        }
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-bold"
                      >
                        <option value="BDT">BDT (৳)</option>
                        <option value="USDT">USDT ($)</option>
                      </select>
                    </div>

                    {/* Minimum Deposit */}
                    <div>
                      <label className="text-slate-400 font-semibold block mb-1">
                        Minimum Deposit ({editingChannel.currency === 'USDT' ? '$' : '৳'}):
                      </label>
                      <input
                        type="number"
                        value={editingChannel.minimumDeposit}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            minimumDeposit: Math.max(1, parseFloat(e.target.value) || 0)
                          })
                        }
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-amber-300 font-bold font-mono"
                      />
                    </div>

                    {/* Maximum Deposit */}
                    <div>
                      <label className="text-slate-400 font-semibold block mb-1">
                        Maximum Deposit ({editingChannel.currency === 'USDT' ? '$' : '৳'}):
                      </label>
                      <input
                        type="number"
                        value={editingChannel.maximumDeposit}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            maximumDeposit: Math.max(1, parseFloat(e.target.value) || 0)
                          })
                        }
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-amber-300 font-bold font-mono"
                      />
                    </div>

                    {/* Request Page Template */}
                    <div>
                      <label className="text-slate-400 font-semibold block mb-1">
                        Request Page Template:
                      </label>
                      <select
                        value={editingChannel.requestPage || 'A'}
                        onChange={(e) =>
                          setEditingChannel({ ...editingChannel, requestPage: e.target.value as any })
                        }
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-bold"
                      >
                        <option value="A">Template A (Orange GoPay/Nagad)</option>
                        <option value="B">Template B (Pink/Red bKash)</option>
                        <option value="C">Template C (Green Premium Payment)</option>
                        <option value="D">Template D (USDT Crypto Dark)</option>
                      </select>
                    </div>

                    {/* Account Type */}
                    <div>
                      <label className="text-slate-400 font-semibold block mb-1">Account Type:</label>
                      <select
                        value={editingChannel.accountType}
                        onChange={(e) => {
                          const newAccType = e.target.value;
                          setEditingChannel({
                            ...editingChannel,
                            accountType: newAccType,
                            transferType: newAccType === 'Agent' ? 'Cash Out' : 'Send Money'
                          });
                        }}
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-bold"
                      >
                        <option value="Agent">Agent (Cash Out)</option>
                        <option value="Personal">Personal (Send Money)</option>
                        <option value="Merchant">Merchant (Payment)</option>
                      </select>
                    </div>

                    {/* Transfer Method (Send Money vs Cash Out) */}
                    <div>
                      <label className="text-slate-400 font-semibold block mb-1">
                        Transfer Method (পেমেন্টের ধরণ):
                      </label>
                      <select
                        value={editingChannel.transferType || (editingChannel.accountType === 'Agent' ? 'Cash Out' : 'Send Money')}
                        onChange={(e) =>
                          setEditingChannel({ ...editingChannel, transferType: e.target.value as any })
                        }
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-bold"
                      >
                        <option value="Cash Out">Cash Out (ক্যাশ আউট)</option>
                        <option value="Send Money">Send Money (সেন্ড মানি)</option>
                      </select>
                    </div>

                    {/* Payment Target Number / Wallet */}
                    <div className="sm:col-span-2">
                      <label className="text-slate-400 font-semibold block mb-1">
                        Payment Number / Wallet Address:
                      </label>
                      <input
                        type="text"
                        value={editingChannel.paymentNumber}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            paymentNumber: e.target.value,
                            walletAddress: e.target.value
                          })
                        }
                        placeholder="e.g. 01800000000 or T..."
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-mono font-bold"
                      />
                    </div>

                    {/* Network for USDT */}
                    {editingChannel.paymentType === 'USDT' && (
                      <div>
                        <label className="text-slate-400 font-semibold block mb-1">Crypto Network:</label>
                        <select
                          value={editingChannel.network || 'TRC20'}
                          onChange={(e) =>
                            setEditingChannel({ ...editingChannel, network: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-bold"
                        >
                          <option value="TRC20">TRC20 (Tron)</option>
                          <option value="BEP20">BEP20 (BNB Smart Chain)</option>
                          <option value="ERC20">ERC20 (Ethereum)</option>
                        </select>
                      </div>
                    )}

                    {/* Logo URL & ImgBB Upload */}
                    <div className="sm:col-span-2">
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-slate-400 font-semibold">
                          Logo / Icon URL (লোগো ইমেজ লিঙ্ক বা ImgBB আপলোড):
                        </label>
                        <button
                          type="button"
                          onClick={() =>
                            setEditingChannel({ ...editingChannel, logo: EWALLET_DEFAULT_IMAGE })
                          }
                          className="text-[10px] text-orange-400 hover:underline font-bold"
                        >
                          Use E-Wallet Preset Icon
                        </button>
                      </div>
                      <div className="flex items-center space-x-2 mb-2">
                        {Boolean(editingChannel.logo) && (
                          <div className="w-10 h-10 rounded-lg bg-slate-900 border border-slate-700 p-1 flex items-center justify-center shrink-0">
                            <img
                              src={editingChannel.logo}
                              alt="Channel Logo"
                              className="w-full h-full object-contain"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        )}
                        <input
                          type="text"
                          value={editingChannel.logo || ''}
                          onChange={(e) =>
                            setEditingChannel({ ...editingChannel, logo: e.target.value })
                          }
                          placeholder="https://i.ibb.co/..."
                          className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-xs font-mono"
                        />
                        <input
                          type="file"
                          ref={channelLogoFileRef}
                          onChange={handleChannelLogoUpload}
                          accept="image/*"
                          className="hidden"
                        />
                        <button
                          type="button"
                          disabled={isUploadingChannelLogo}
                          onClick={() => channelLogoFileRef.current?.click()}
                          className="px-3 py-2 bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shrink-0 flex items-center space-x-1 shadow-sm"
                        >
                          {isUploadingChannelLogo ? (
                            <span>Uploading...</span>
                          ) : (
                            <>
                              <Upload className="w-3.5 h-3.5" />
                              <span>ImgBB Upload</span>
                            </>
                          )}
                        </button>
                      </div>
                      <div className="flex items-center space-x-1.5 flex-wrap gap-y-1">
                        <span className="text-[10px] text-slate-400 font-medium">Quick Logo Presets:</span>
                        <button
                          type="button"
                          onClick={() => setEditingChannel({ ...editingChannel, logo: PAYMENT_LOGOS.bkash })}
                          className="px-2 py-0.5 rounded-lg bg-pink-900/50 hover:bg-pink-800 text-pink-300 text-[10px] font-bold border border-pink-700/50"
                        >
                          bKash Logo
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingChannel({ ...editingChannel, logo: PAYMENT_LOGOS.nagad })}
                          className="px-2 py-0.5 rounded-lg bg-orange-900/50 hover:bg-orange-800 text-orange-300 text-[10px] font-bold border border-orange-700/50"
                        >
                          Nagad Logo
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingChannel({ ...editingChannel, logo: PAYMENT_LOGOS.rocket })}
                          className="px-2 py-0.5 rounded-lg bg-purple-900/50 hover:bg-purple-800 text-purple-300 text-[10px] font-bold border border-purple-700/50"
                        >
                          Rocket Logo
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingChannel({ ...editingChannel, logo: PAYMENT_LOGOS.usdt })}
                          className="px-2 py-0.5 rounded-lg bg-emerald-900/50 hover:bg-emerald-800 text-emerald-300 text-[10px] font-bold border border-emerald-700/50"
                        >
                          USDT Logo
                        </button>
                      </div>
                    </div>

                    {/* Title / Header */}
                    <div className="sm:col-span-2">
                      <label className="text-slate-400 font-semibold block mb-1">Title / Header Text:</label>
                      <input
                        type="text"
                        value={editingChannel.title || ''}
                        onChange={(e) =>
                          setEditingChannel({ ...editingChannel, title: e.target.value })
                        }
                        placeholder="e.g. Official Instant Gateway"
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white"
                      />
                    </div>

                    {/* Instructions */}
                    <div className="sm:col-span-2">
                      <label className="text-slate-400 font-semibold block mb-1">
                        Step-by-step Instructions:
                      </label>
                      <textarea
                        rows={3}
                        value={editingChannel.instructions || ''}
                        onChange={(e) =>
                          setEditingChannel({ ...editingChannel, instructions: e.target.value })
                        }
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-xs leading-relaxed"
                      />
                    </div>

                    {/* Warning Text */}
                    <div className="sm:col-span-2">
                      <label className="text-slate-400 font-semibold block mb-1">Warning Note:</label>
                      <input
                        type="text"
                        value={editingChannel.warningText || ''}
                        onChange={(e) =>
                          setEditingChannel({ ...editingChannel, warningText: e.target.value })
                        }
                        placeholder="e.g. Do not save this number for future transactions."
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-xs"
                      />
                    </div>

                    {/* 2 Screenshot Guides with ImgBB Upload (User Request) */}
                    <div className="sm:col-span-2 border-t border-slate-700/80 pt-3.5 space-y-3.5">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-orange-400 uppercase tracking-wider flex items-center space-x-1.5">
                          <ImageIcon className="w-4 h-4" />
                          <span>২টি স্ক্রিনশট গাইড ও ImgBB আপলোড (Tutorial Screenshots)</span>
                        </h4>
                        <span className="text-[10px] text-slate-400">পেমেন্ট পেজে ইউজারদের দেখার জন্য</span>
                      </div>

                      {/* Step 1 Screenshot */}
                      <div className="bg-slate-900/70 p-3 rounded-2xl border border-slate-800 space-y-2.5">
                        <div className="flex items-center justify-between">
                          <label className="text-white font-bold text-xs">
                            ধাপ ১ স্ক্রিনশট (Send Money / Cash Out অপশন):
                          </label>
                          <span className="text-[10px] text-slate-400">ImgBB Upload or URL</span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <input
                            type="text"
                            value={editingChannel.step1Title || ''}
                            onChange={(e) =>
                              setEditingChannel({ ...editingChannel, step1Title: e.target.value })
                            }
                            placeholder={
                              editingChannel.transferType === 'Send Money'
                                ? 'Send Money নির্বাচন করুন'
                                : 'Cash Out নির্বাচন করুন'
                            }
                            className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-xs font-bold"
                          />
                          <div className="flex items-center space-x-2">
                            <input
                              type="text"
                              value={editingChannel.step1Image || ''}
                              onChange={(e) =>
                                setEditingChannel({ ...editingChannel, step1Image: e.target.value })
                              }
                              placeholder="https://i.ibb.co/..."
                              className="flex-1 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-xs font-mono"
                            />
                            <input
                              type="file"
                              ref={channelStep1FileRef}
                              onChange={handleChannelStep1Upload}
                              accept="image/*"
                              className="hidden"
                            />
                            <button
                              type="button"
                              disabled={isUploadingStep1}
                              onClick={() => channelStep1FileRef.current?.click()}
                              className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shrink-0 flex items-center space-x-1"
                            >
                              {isUploadingStep1 ? <span>Uploading...</span> : <span>ImgBB Upload</span>}
                            </button>
                          </div>
                        </div>

                        {editingChannel.step1Image && (
                          <div className="flex items-center space-x-2 pt-1">
                            <div className="w-16 h-16 rounded-xl bg-slate-800 border border-slate-700 overflow-hidden shrink-0">
                              <img
                                src={editingChannel.step1Image}
                                alt="Step 1 Preview"
                                className="w-full h-full object-contain"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                            <div className="text-[10px] text-slate-400">
                              <div className="text-emerald-400 font-bold">✓ Screenshot 1 Loaded</div>
                              <button
                                type="button"
                                onClick={() => setEditingChannel({ ...editingChannel, step1Image: '' })}
                                className="text-red-400 hover:underline mt-0.5"
                              >
                                Remove Image
                              </button>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Step 2 Screenshot */}
                      <div className="bg-slate-900/70 p-3 rounded-2xl border border-slate-800 space-y-2.5">
                        <div className="flex items-center justify-between">
                          <label className="text-white font-bold text-xs">
                            ধাপ ২ স্ক্রিনশট (Transaction ID রশিদ পাওয়ার স্ক্রিনশট):
                          </label>
                          <span className="text-[10px] text-slate-400">ImgBB Upload or URL</span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <input
                            type="text"
                            value={editingChannel.step2Title || ''}
                            onChange={(e) =>
                              setEditingChannel({ ...editingChannel, step2Title: e.target.value })
                            }
                            placeholder="Transaction ID কোথায় পাবেন দেখুন"
                            className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-xs font-bold"
                          />
                          <div className="flex items-center space-x-2">
                            <input
                              type="text"
                              value={editingChannel.step2Image || ''}
                              onChange={(e) =>
                                setEditingChannel({ ...editingChannel, step2Image: e.target.value })
                              }
                              placeholder="https://i.ibb.co/..."
                              className="flex-1 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-xs font-mono"
                            />
                            <input
                              type="file"
                              ref={channelStep2FileRef}
                              onChange={handleChannelStep2Upload}
                              accept="image/*"
                              className="hidden"
                            />
                            <button
                              type="button"
                              disabled={isUploadingStep2}
                              onClick={() => channelStep2FileRef.current?.click()}
                              className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shrink-0 flex items-center space-x-1"
                            >
                              {isUploadingStep2 ? <span>Uploading...</span> : <span>ImgBB Upload</span>}
                            </button>
                          </div>
                        </div>

                        {editingChannel.step2Image && (
                          <div className="flex items-center space-x-2 pt-1">
                            <div className="w-16 h-16 rounded-xl bg-slate-800 border border-slate-700 overflow-hidden shrink-0">
                              <img
                                src={editingChannel.step2Image}
                                alt="Step 2 Preview"
                                className="w-full h-full object-contain"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                            <div className="text-[10px] text-slate-400">
                              <div className="text-emerald-400 font-bold">✓ Screenshot 2 Loaded</div>
                              <button
                                type="button"
                                onClick={() => setEditingChannel({ ...editingChannel, step2Image: '' })}
                                className="text-red-400 hover:underline mt-0.5"
                              >
                                Remove Image
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Transaction ID & Countdown */}
                    <div className="flex items-center space-x-2 pt-2">
                      <input
                        type="checkbox"
                        id="txnReq"
                        checked={editingChannel.transactionRequired}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            transactionRequired: e.target.checked
                          })
                        }
                        className="w-4 h-4 rounded text-orange-600 focus:ring-0"
                      />
                      <label htmlFor="txnReq" className="text-white font-bold text-xs">
                        Transaction ID (TxID) Mandatory
                      </label>
                    </div>

                    <div className="flex items-center space-x-2 pt-2">
                      <input
                        type="checkbox"
                        id="channelEnabled"
                        checked={editingChannel.enabled !== false}
                        onChange={(e) =>
                          setEditingChannel({ ...editingChannel, enabled: e.target.checked })
                        }
                        className="w-4 h-4 rounded text-green-600 focus:ring-0"
                      />
                      <label htmlFor="channelEnabled" className="text-white font-bold text-xs">
                        Channel Active & Enabled
                      </label>
                    </div>
                  </div>

                  <div className="flex items-center justify-end space-x-2 pt-3 border-t border-slate-700">
                    <button
                      type="button"
                      onClick={() => {
                        setIsChannelModalOpen(false);
                        setEditingChannel(null);
                      }}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl active:scale-95"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        if (!editingChannel.channelName || !editingChannel.channelId) {
                          showToast('Channel Name and ID are required', 'error');
                          return;
                        }
                        await adminSaveDepositChannel(editingChannel);
                        setIsChannelModalOpen(false);
                        setEditingChannel(null);
                      }}
                      className="px-5 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold rounded-xl shadow-lg active:scale-95"
                    >
                      Save Channel
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 5. Deposits Tab */}
        {activeTab === 'deposits' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-2 border-b border-slate-700">
              <div>
                <h2 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                  <CreditCard className="w-4 h-4 text-emerald-400" />
                  <span>Deposit Requests Management</span>
                </h2>
                <p className="text-[11px] text-slate-400">
                  Verify user transaction IDs and approve balance credits.
                </p>
              </div>

              {/* Status & Method Filters */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex bg-slate-800 p-1 rounded-xl border border-slate-700 text-[11px] font-bold">
                  {(['all', 'pending', 'completed', 'rejected'] as const).map((st) => (
                    <button
                      key={st}
                      onClick={() => setDepositStatusFilter(st)}
                      className={`px-2.5 py-1 rounded-lg capitalize transition-all ${
                        depositStatusFilter === st
                          ? 'bg-orange-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {st === 'completed' ? 'Success' : st === 'rejected' ? 'Failed' : st}
                    </button>
                  ))}
                </div>

                <select
                  value={depositMethodFilter}
                  onChange={(e) => setDepositMethodFilter(e.target.value as any)}
                  className="bg-slate-800 border border-slate-700 text-white text-[11px] font-bold px-2.5 py-1.5 rounded-xl focus:outline-none"
                >
                  <option value="all">All Methods</option>
                  <option value="bkash">bKash</option>
                  <option value="nagad">Nagad</option>
                  <option value="rocket">Rocket</option>
                  <option value="usdt">USDT</option>
                </select>
              </div>
            </div>

            {(() => {
              const filteredList = deposits.filter((d) => {
                const statusMatch =
                  depositStatusFilter === 'all'
                    ? true
                    : depositStatusFilter === 'pending'
                    ? d.status === 'pending'
                    : depositStatusFilter === 'completed'
                    ? d.status === 'completed' || d.status === 'success'
                    : d.status === 'rejected' || d.status === 'failed';

                const methodMatch =
                  depositMethodFilter === 'all'
                    ? true
                    : d.method?.toLowerCase() === depositMethodFilter.toLowerCase();

                return statusMatch && methodMatch;
              });

              if (filteredList.length === 0) {
                return (
                  <div className="bg-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs border border-slate-700">
                    No deposit requests match your filter criteria.
                  </div>
                );
              }

              return (
                <div className="space-y-3">
                  {filteredList.map((d, dIdx) => {
                    const userProfile = allUsers[d.uid];
                    const isPending = d.status === 'pending';
                    const isSuccess = d.status === 'completed' || d.status === 'success';

                    return (
                      <div
                        key={`dep-${d.id || d.uid || 'd'}-${dIdx}`}
                        className="bg-slate-800/90 rounded-2xl p-4 border border-slate-700 space-y-2.5 text-xs shadow-md"
                      >
                        <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
                          <div className="flex items-center space-x-2">
                            <span className="font-extrabold text-white text-sm">
                              {d.channel || d.method.toUpperCase()}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                                isSuccess
                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/50'
                                  : isPending
                                  ? 'bg-amber-950 text-amber-300 border border-amber-700/50'
                                  : 'bg-rose-950 text-rose-300 border border-rose-700/50'
                              }`}
                            >
                              {isSuccess ? 'Success' : isPending ? 'Pending' : 'Failed'}
                            </span>
                          </div>

                          <span className="text-amber-400 font-black text-base">
                            ৳{d.amount.toFixed(2)}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-slate-400 text-[11px]">
                          <div>
                            <span className="block text-slate-500 text-[10px] uppercase font-bold">Username</span>
                            <span className="text-white font-bold">
                              {d.username || userProfile?.username || userProfile?.nickname || 'Member'}
                            </span>
                          </div>
                          <div>
                            <span className="block text-slate-500 text-[10px] uppercase font-bold">UID / Phone</span>
                            <span className="text-white font-mono">
                              {userProfile?.numericUid || d.uid.slice(0, 8)} ({d.phone || 'N/A'})
                            </span>
                          </div>
                          <div>
                            <span className="block text-slate-500 text-[10px] uppercase font-bold">Time</span>
                            <span className="text-slate-300">
                              {d.createdAt ? new Date(d.createdAt).toLocaleTimeString() : 'Recent'}
                            </span>
                          </div>
                          <div>
                            <span className="block text-slate-500 text-[10px] uppercase font-bold">Transaction ID</span>
                            <div className="flex items-center space-x-1">
                              <span className="font-mono text-emerald-400 font-bold select-all break-all">
                                {d.txnId}
                              </span>
                              <button
                                onClick={() => {
                                  navigator.clipboard.writeText(d.txnId);
                                  showToast('Copied Transaction ID', 'success');
                                }}
                                className="text-slate-400 hover:text-white"
                                title="Copy TxID"
                              >
                                <Copy className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* Action Buttons: Only pending requests can be approved/rejected */}
                        {isPending ? (
                          <div className="flex items-center space-x-2 pt-2 border-t border-slate-700/60">
                            <button
                              onClick={() => adminApproveDeposit(d.id)}
                              className="flex-1 py-2.5 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-black rounded-xl flex items-center justify-center space-x-1.5 shadow-md active:scale-98 transition-all text-xs"
                            >
                              <Check className="w-4 h-4 stroke-[3]" />
                              <span>APPROVE & CREDIT ৳{d.amount.toFixed(2)}</span>
                            </button>
                            <button
                              onClick={() => adminRejectDeposit(d.id)}
                              className="px-5 py-2.5 bg-rose-700/80 hover:bg-rose-700 text-white font-extrabold rounded-xl flex items-center justify-center space-x-1.5 active:scale-98 transition-all text-xs"
                            >
                              <X className="w-4 h-4 stroke-[3]" />
                              <span>REJECT</span>
                            </button>
                          </div>
                        ) : (
                          <div className="pt-1 text-[11px] text-slate-400 flex items-center justify-between">
                            <span>Status: {isSuccess ? 'Approved and credited once' : 'Request rejected'}</span>
                            {d.processedAt && (
                              <span className="font-mono text-[10px]">
                                Processed at {new Date(d.processedAt).toLocaleTimeString()}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </div>
        )}

        {/* 6. Withdrawals Tab */}
        {activeTab === 'withdrawals' && (
          <div className="space-y-3">
            <h2 className="font-bold text-sm text-slate-100">
              Pending Withdrawals ({pendingWithdrawals.length})
            </h2>

            {pendingWithdrawals.length === 0 ? (
              <div className="bg-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs">
                No pending withdrawal requests.
              </div>
            ) : (
              pendingWithdrawals.map((w, wIdx) => (
                <div
                  key={`with-${w.id || w.uid || 'w'}-${wIdx}`}
                  className="bg-slate-800 rounded-2xl p-4 border border-slate-700 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">ID: {w.id}</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-red-400 font-extrabold text-sm">৳{w.amount.toFixed(2)}</span>
                      {(w.usdtAmount || w.type === 'USDT' || w.walletMethod === 'USDT') && (
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono font-bold text-xs border border-emerald-500/30 flex items-center space-x-1">
                          <span>₮</span>
                          <span>${(w.usdtAmount || (w.amount / (w.dollarRate || 125))).toFixed(2)} USDT</span>
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-slate-400 text-[11px]">
                    <div>
                      User UID: <span className="text-white font-mono">{w.uid}</span> ({w.phone})
                    </div>
                    <div>
                      Method: <span className="text-white uppercase font-bold">{w.walletMethod} {w.type === 'USDT' && '(TRC20)'}</span>
                    </div>
                    <div>
                      Account Name: <span className="text-white">{w.accountName || 'N/A'}</span>
                    </div>
                    <div className="flex items-center space-x-1 min-w-0">
                      <span className="shrink-0">{w.type === 'USDT' || w.walletMethod === 'USDT' ? 'TRC20 Address' : 'Target'}:</span>
                      <span className="font-mono text-white select-all truncate">{w.accountNumber}</span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(w.accountNumber);
                          showToast('Address/Number copied to clipboard!', 'success');
                        }}
                        className="p-1 text-slate-400 hover:text-emerald-400 shrink-0 cursor-pointer"
                        title="Copy"
                      >
                        <Copy className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 pt-2">
                    <button
                      onClick={() => adminApproveWithdrawal(w.id)}
                      className="flex-1 py-2 bg-green-600 hover:bg-green-500 text-white font-bold rounded-xl flex items-center justify-center space-x-1 transition-all"
                    >
                      <Check className="w-4 h-4" />
                      <span>Approve & Complete</span>
                    </button>
                    <button
                      onClick={() => {
                        setRejectingWithdrawal(w);
                        setRejectionRemark('ভুল বা অকার্যকর ওয়ালেট নম্বর (Invalid or unverified account number)');
                      }}
                      className="px-4 py-2 bg-rose-600/80 hover:bg-rose-600 text-white font-bold rounded-xl flex items-center justify-center space-x-1 active:scale-95 transition-all"
                    >
                      <X className="w-4 h-4" />
                      <span>Reject with Remark</span>
                    </button>
                  </div>
                </div>
              ))
            )}

            {/* Rejection Remark Modal */}
            {rejectingWithdrawal && (
              <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
                <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-3xl p-5 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
                        <AlertTriangle className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">Reject Withdrawal & Send Remark</h3>
                        <span className="text-[11px] text-rose-400 font-medium">উইথড্রয়াল বাতিল এবং কারণ উল্লেখ</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setRejectingWithdrawal(null)}
                      className="text-slate-400 hover:text-white p-1 rounded-lg"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Summary of target request */}
                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Order / Request ID:</span>
                      <span className="font-mono text-white font-bold">{rejectingWithdrawal.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Amount:</span>
                      <span className="text-rose-400 font-extrabold font-mono text-sm">৳{rejectingWithdrawal.amount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">User Account / Method:</span>
                      <span className="text-slate-200 uppercase font-bold">{rejectingWithdrawal.walletMethod} - {rejectingWithdrawal.accountNumber}</span>
                    </div>
                  </div>

                  {/* Quick preset buttons */}
                  <div>
                    <label className="text-slate-400 text-[11px] font-bold block mb-1.5">
                      Quick Reason Presets (দ্রুত কারণ সিলেক্ট করুন):
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                      {[
                        'ভুল বা অকার্যকর ওয়ালেট নম্বর',
                        'টার্নওভার বা বাজির শর্ত অপূর্ণ',
                        'সন্দেহজনক কার্যকলাপ / একাধিক আইডি',
                        'ব্যাংক গেটওয়ে সার্ভারে সমস্যা'
                      ].map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => setRejectionRemark(preset)}
                          className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] text-left border border-slate-700 transition-colors"
                        >
                          {preset}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Custom Remark text field */}
                  <div>
                    <label className="text-slate-300 text-xs font-bold block mb-1">
                      Rejection Reason / Remark (ইউজার দেখতে পাবে):
                    </label>
                    <textarea
                      value={rejectionRemark}
                      onChange={(e) => setRejectionRemark(e.target.value)}
                      rows={3}
                      placeholder="এখানে বাতিলের নির্দিষ্ট কারণ লিখুন..."
                      className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs placeholder:text-slate-500 focus:border-rose-500 outline-none"
                    />
                    <span className="text-[10px] text-slate-400 mt-1 block">
                      Note: Amount ৳{rejectingWithdrawal.amount.toFixed(2)} will be instantly refunded to user balance and the reason will be displayed on their History page.
                    </span>
                  </div>

                  {/* Modal Action Buttons */}
                  <div className="flex items-center space-x-2 pt-2 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={() => setRejectingWithdrawal(null)}
                      className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold text-xs transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        const reason = rejectionRemark.trim() || 'উইথড্রয়াল বাতিল করা হয়েছে (অ্যাকাউন্ট ভেরিফিকেশন সমস্যা)';
                        await adminRejectWithdrawal(rejectingWithdrawal.id, reason);
                        showToast(`Withdrawal rejected with remark & ৳${rejectingWithdrawal.amount} refunded!`, 'info');
                        setRejectingWithdrawal(null);
                        setRejectionRemark('');
                      }}
                      className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-bold text-xs shadow-lg active:scale-95 transition-all flex items-center justify-center space-x-1.5"
                    >
                      <X className="w-4 h-4" />
                      <span>Confirm Reject</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 7. System Settings Tab */}
        {activeTab === 'settings' && (
          <form
            onSubmit={handleSaveSettings}
            className="bg-slate-800 rounded-2xl p-5 border border-slate-700 space-y-5 text-xs"
          >
            {/* App Download Link Section */}
            <div className="bg-slate-900/90 rounded-xl p-4 border border-red-500/30 space-y-3.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-lg bg-red-600/20 text-red-400 flex items-center justify-center">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-1.5">
                      <span>Home Dashboard App Download Link</span>
                      <span className="text-[10px] bg-red-500/20 text-red-400 px-1.5 py-0.2 rounded font-mono font-bold">
                        DIRECT APK
                      </span>
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      When users click &quot;Download&quot; on the Home dashboard or Header, this link triggers instant download.
                    </p>
                  </div>
                </div>

                {appDownloadUrl && (
                  <button
                    type="button"
                    onClick={() => window.open(appDownloadUrl, '_blank')}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold flex items-center space-x-1 border border-slate-700 transition-colors"
                    title="Test download link now"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Test Link</span>
                  </button>
                )}
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  App Download URL / Direct APK Link:
                </label>
                <div className="relative">
                  <input
                    type="url"
                    value={appDownloadUrl}
                    onChange={(e) => setAppDownloadUrl(e.target.value)}
                    placeholder="https://trade-bd.app/download/trade-bd.apk"
                    className="w-full pl-3.5 pr-20 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-xs focus:border-red-500 outline-none"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setAppDownloadUrl('https://trade-bd.app/download/trade-bd.apk')}
                    className="absolute right-1.5 top-1.5 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-slate-300 rounded-lg"
                  >
                    Set Default
                  </button>
                </div>
                <div className="flex items-center space-x-2 mt-1 text-[10px] text-slate-400">
                  <span>💡 Tip: You can enter any direct APK URL, Google Drive download link, or server file URL.</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    App Version / Tag Display:
                  </label>
                  <input
                    type="text"
                    value={appVersion}
                    onChange={(e) => setAppVersion(e.target.value)}
                    placeholder="v2.6 Official"
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-xs focus:border-red-500 outline-none"
                  />
                </div>

                <div className="flex flex-col justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      if (!appDownloadUrl.trim()) {
                        showToast('Please enter a download URL first', 'error');
                        return;
                      }
                      const link = document.createElement('a');
                      link.href = appDownloadUrl.trim();
                      link.setAttribute('download', 'TRADE_BD.apk');
                      link.setAttribute('target', '_blank');
                      document.body.appendChild(link);
                      link.click();
                      setTimeout(() => {
                        if (document.body.contains(link)) document.body.removeChild(link);
                      }, 200);
                      showToast('Triggered download test', 'info');
                    }}
                    className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center space-x-1.5 border border-slate-700 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5 text-amber-400" />
                    <span>Simulate User Click Download</span>
                  </button>
                </div>
              </div>

              {/* Live Preview on Home Dashboard */}
              <div className="pt-2 border-t border-slate-800">
                <span className="text-[10px] font-bold text-slate-400 block mb-1.5 uppercase tracking-wider">
                  Live Home Dashboard Member Preview:
                </span>
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center space-x-2 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 via-red-500 to-red-600 flex items-center justify-center text-slate-950 font-black text-xs shrink-0">
                      TB
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center space-x-1">
                        <span className="font-bold text-xs text-white">BGNICE Official App</span>
                        <span className="text-[9px] bg-amber-400 text-slate-950 font-black px-1 rounded">
                          {appVersion || 'APK v2.6'}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 truncate block">
                        Direct Download • 24/7 Fast Payouts • Low Data
                      </span>
                    </div>
                  </div>
                  <div className="px-3 py-1 bg-red-600 text-white rounded-lg font-bold text-[11px] flex items-center space-x-1 shrink-0">
                    <Download className="w-3 h-3" />
                    <span>Download</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Site Maintenance Mode Control Section */}
            <div className="bg-slate-900/90 rounded-2xl p-4 border border-amber-500/30 space-y-3.5">
              <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2.5">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${isMaintenance ? 'bg-rose-500/20 text-rose-400' : 'bg-emerald-500/20 text-emerald-400'}`}>
                    <Sliders className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                      <span>Site Maintenance Mode Control (সাইট অন/অফ)</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider ${isMaintenance ? 'bg-rose-500/30 text-rose-300 border border-rose-500/40' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'}`}>
                        {isMaintenance ? '● MAINTENANCE ACTIVE (সাইট অফ)' : '● LIVE ONLINE (সাইট অন)'}
                      </span>
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      When Maintenance Mode is ON, normal users will see a maintenance notice screen while admin retains full access.
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={async () => {
                      const next = !isMaintenance;
                      setIsMaintenance(next);
                      await adminToggleMaintenanceMode(next, maintMessage);
                      showToast(`Site Maintenance Mode is now ${next ? 'ACTIVATED (OFFLINE)' : 'DEACTIVATED (ONLINE)'}`, next ? 'info' : 'success');
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center space-x-1.5 shadow-md active:scale-95 ${
                      isMaintenance
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                        : 'bg-rose-600 hover:bg-rose-500 text-white'
                    }`}
                  >
                    <span>{isMaintenance ? 'Turn Site ONLINE (সাইট সচল করুন)' : 'Turn Site OFFLINE (রক্ষণাবেক্ষণ চালু করুন)'}</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Maintenance Notice Message (ব্যবহারকারীদের প্রদর্শিত নোটিশ):
                </label>
                <textarea
                  value={maintMessage}
                  onChange={(e) => setMaintMessage(e.target.value)}
                  rows={2}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-medium text-xs focus:border-amber-500 outline-none"
                  placeholder="BGNICE প্ল্যাটফর্ম সাময়িক রক্ষণাবেক্ষণের জন্য বন্ধ আছে। দ্রুততম সময়ে সার্ভিস পুনরায় চালু করা হবে।"
                />
              </div>
            </div>

            {/* Signup Bonus System & Admin Control Section */}
            <div className="bg-slate-900/90 rounded-2xl p-4 border border-purple-500/30 space-y-3.5">
              <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                    <Gift className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                      <span>Registration / Signup Bonus System (রেজিস্ট্রেশন বোনাস কন্ট্রোল)</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider ${signupBonusOn ? 'bg-purple-500/30 text-purple-300 border border-purple-500/40' : 'bg-slate-700 text-slate-400'}`}>
                        {signupBonusOn ? '● ENABLED (বোনাস চালু)' : '● DISABLED (বোনাস বন্ধ)'}
                      </span>
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Instantly credit new registered users with welcome cash reward upon successful phone registration.
                    </p>
                  </div>
                </div>

                <label className="flex items-center space-x-2 cursor-pointer bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700">
                  <span className="text-xs font-bold text-slate-200">
                    {signupBonusOn ? 'System ON' : 'System OFF'}
                  </span>
                  <input
                    type="checkbox"
                    checked={signupBonusOn}
                    onChange={(e) => setSignupBonusOn(e.target.checked)}
                    className="w-4 h-4 rounded text-purple-600 bg-slate-900 border-slate-600"
                  />
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Signup Bonus Amount (৳ নগদ বোনাস):
                  </label>
                  <input
                    type="number"
                    value={signupBonusAmt}
                    onChange={(e) => setSignupBonusAmt(e.target.value)}
                    placeholder="50"
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono font-bold text-xs focus:border-purple-500 outline-none"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">Recommended: ৳50 or ৳100</span>
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Bonus Turnover Multiplier (বাজির শর্ত গুণক):
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={signupBonusTurnover}
                    onChange={(e) => setSignupBonusTurnover(e.target.value)}
                    placeholder="1"
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono font-bold text-xs focus:border-purple-500 outline-none"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">e.g. 1x means user must wager ৳{parseFloat(signupBonusAmt) || 50} before payout</span>
                </div>
              </div>

              <div className="pt-1">
                <button
                  type="button"
                  onClick={async () => {
                    const amt = parseFloat(signupBonusAmt) || 50;
                    const mul = parseFloat(signupBonusTurnover) || 1;
                    await adminUpdateSignupBonus(signupBonusOn, amt, mul);
                    showToast(`Signup Bonus settings updated (৳${amt}, ${mul}x turnover)!`, 'success');
                  }}
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold active:scale-95 transition-all"
                >
                  Save Signup Bonus Configuration
                </button>
              </div>
            </div>

            {/* USDT TRC20 Dollar Rate & Minimum Withdrawal Settings */}
            <div className="bg-slate-900/90 rounded-2xl p-4 border border-emerald-500/30 space-y-3.5">
              <div className="flex items-center space-x-2.5 border-b border-slate-800 pb-3">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-sm">
                  ₮
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                    <span>USDT TRC20 Dollar Exchange Rate & Withdrawal Controls</span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full font-mono font-bold">
                      LIVE CONVERSION
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Set the Dollar exchange rate ($1 = ? BDT) and minimum withdrawal amount in dollars for user withdrawals.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    USDT Dollar Rate (1 USDT = ? BDT):
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-2 text-emerald-400 font-bold text-xs">৳</span>
                    <input
                      type="number"
                      step="0.01"
                      value={usdtRate}
                      onChange={(e) => setUsdtRate(e.target.value)}
                      placeholder="125"
                      className="w-full pl-8 pr-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono font-bold text-xs focus:border-emerald-500 outline-none"
                    />
                  </div>
                  <span className="text-[10px] text-slate-500 mt-0.5 block">
                    Current rate: $1.00 = ৳{parseFloat(usdtRate) || 125} BDT
                  </span>
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Minimum USDT Withdrawal ($):
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-2 text-emerald-400 font-bold text-xs">$</span>
                    <input
                      type="number"
                      step="1"
                      value={minWithdrawUsdt}
                      onChange={(e) => setMinWithdrawUsdt(e.target.value)}
                      placeholder="10"
                      className="w-full pl-8 pr-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono font-bold text-xs focus:border-emerald-500 outline-none"
                    />
                  </div>
                  <span className="text-[10px] text-slate-500 mt-0.5 block">
                    Minimum in BDT: ৳{((parseFloat(minWithdrawUsdt) || 10) * (parseFloat(usdtRate) || 125)).toFixed(2)}
                  </span>
                </div>
              </div>

              <div>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold active:scale-95 transition-all cursor-pointer"
                >
                  Save USDT Dollar Rate & Limits
                </button>
              </div>
            </div>

            <div>
              <label className="text-slate-400 font-semibold block mb-1">
                Platform Announcement Text:
              </label>
              <textarea
                value={announcementText}
                onChange={(e) => setAnnouncementText(e.target.value)}
                rows={3}
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-medium"
              />
            </div>

            {/* Attendance & 7-Day Bonus Configuration */}
            <div className="bg-slate-900/80 border border-slate-700/80 rounded-2xl p-4 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-700/60 pb-3">
                <div>
                  <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                    <span>🎁 7-Day Attendance & Bonus Controls</span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Configure streak rewards, minimum deposit, 7-day cumulative target, and turnover multiplier
                  </p>
                </div>
                <label className="flex items-center space-x-2 cursor-pointer">
                  <span className="text-xs font-semibold text-slate-300">
                    {attendanceEnabled ? 'System Enabled' : 'Disabled'}
                  </span>
                  <input
                    type="checkbox"
                    checked={attendanceEnabled}
                    onChange={(e) => setAttendanceEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-red-600 bg-slate-800 border-slate-600"
                  />
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-400 font-semibold block mb-1">
                    Min Deposit Requirement (৳):
                  </label>
                  <input
                    type="number"
                    value={attMinDeposit}
                    onChange={(e) => setAttMinDeposit(e.target.value)}
                    placeholder="500"
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-mono font-bold"
                  />
                  <span className="text-[10px] text-slate-500">Default: ৳500</span>
                </div>

                <div>
                  <label className="text-slate-400 font-semibold block mb-1">
                    7-Day Deposit Target (৳):
                  </label>
                  <input
                    type="number"
                    value={attTotalDepositTarget}
                    onChange={(e) => setAttTotalDepositTarget(e.target.value)}
                    placeholder="20000"
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-mono font-bold"
                  />
                  <span className="text-[10px] text-slate-500">Default: ৳20,000</span>
                </div>

                <div>
                  <label className="text-slate-400 font-semibold block mb-1">
                    Turnover Multiplier (x):
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={attTurnoverMultiplier}
                    onChange={(e) => setAttTurnoverMultiplier(e.target.value)}
                    placeholder="1"
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-mono font-bold"
                  />
                  <span className="text-[10px] text-slate-500">Default: 1x (Bonus amount)</span>
                </div>
              </div>

              {/* Day 1 - Day 7 Rewards */}
              <div>
                <label className="text-slate-400 font-semibold block mb-1.5">
                  Day 1 to Day 7 Reward Schedule (৳):
                </label>
                <div className="grid grid-cols-7 gap-1.5">
                  {[1, 2, 3, 4, 5, 6, 7].map((dayNum) => (
                    <div key={dayNum} className="text-center">
                      <span className="text-[10px] text-slate-400 block mb-1">Day {dayNum}</span>
                      <input
                        type="number"
                        value={attRewards[dayNum - 1] ?? 20}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value) || 0;
                          const updated = [...attRewards];
                          updated[dayNum - 1] = val;
                          setAttRewards(updated);
                        }}
                        className="w-full px-1.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono font-bold text-center text-xs"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs shadow-md transition-all"
            >
              Save Settings to Realtime Database
            </button>
          </form>
        )}

        {/* 8. Gift Codes Tab */}
        {activeTab === 'gifts' && (
          <div className="space-y-4">
            <div className="bg-slate-800 rounded-2xl p-5 border border-slate-700 space-y-4 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                    <Gift className="w-4 h-4 text-red-500" />
                    <span>Create Redemption Gift Code</span>
                  </h2>
                  <p className="text-[11px] text-slate-400">
                    Generate 30-character alphanumeric promotional codes or custom promo codes
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleGenerate30Char}
                  className="px-3 py-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black rounded-xl text-xs flex items-center space-x-1.5 shadow-md active:scale-95 transition-all"
                  id="admin-generate-30char-btn"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Generate 30-Char Code</span>
                </button>
              </div>

              <form onSubmit={handleCreateCode} className="space-y-3">
                <div>
                  <label className="text-slate-400 font-semibold block mb-1">
                    Code Name (or 30-Char String):
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={newCode}
                      onChange={(e) => setNewCode(e.target.value)}
                      placeholder="e.g. WELCOME500 or 30-character code"
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono font-bold uppercase tracking-wider text-xs"
                      required
                    />
                    {newCode && (
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(newCode);
                          showToast('Code copied to clipboard!', 'success');
                        }}
                        className="absolute right-2.5 top-2 p-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
                        title="Copy code"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-400 font-semibold block mb-1">
                      Cash Reward (৳):
                    </label>
                    <input
                      type="number"
                      value={newCodeReward}
                      onChange={(e) => setNewCodeReward(e.target.value)}
                      className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 font-semibold block mb-1">
                      Max Total Claims:
                    </label>
                    <input
                      type="number"
                      value={newCodeMax}
                      onChange={(e) => setNewCodeMax(e.target.value)}
                      className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-green-600 hover:bg-green-500 text-white font-bold rounded-xl shadow-md active:scale-98 transition-all"
                  id="admin-save-gift-btn"
                >
                  Save & Publish Gift Code to RTDB
                </button>
              </form>
            </div>

            {/* Gift Codes List */}
            <div className="space-y-3">
              <h3 className="font-bold text-xs text-slate-200">
                Active & Past Gift Codes ({giftCodes.length})
              </h3>

              {giftCodes.length === 0 ? (
                <div className="bg-slate-800 rounded-2xl p-6 text-center text-slate-400 text-xs">
                  No gift codes created yet. Use the generator above to create one.
                </div>
              ) : (
                <div className="space-y-2">
                  {giftCodes.map((gift, gIdx) => {
                    const claims = gift.claimCount ?? gift.totalClaims ?? 0;
                    return (
                      <div
                        key={`gift-${gift.code || 'g'}-${gIdx}`}
                        className="bg-slate-800 rounded-2xl p-3.5 border border-slate-700 flex items-center justify-between flex-wrap gap-2 text-xs"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <span className="font-mono font-black text-amber-400 text-sm tracking-wider">
                              {gift.code}
                            </span>
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(gift.code);
                                showToast('Gift code copied!', 'success');
                              }}
                              className="p-1 rounded bg-slate-700 text-slate-300 hover:text-white"
                              title="Copy code"
                            >
                              <Copy className="w-3 h-3" />
                            </button>
                            <span
                              className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase ${
                                gift.status === 'active'
                                  ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                                  : 'bg-slate-700 text-slate-400'
                              }`}
                            >
                              {gift.status}
                            </span>
                          </div>

                          <div className="text-[11px] text-slate-400 flex items-center space-x-3">
                            <span>
                              Reward: <strong className="text-white">৳{gift.amount || gift.rewardAmount || 0}</strong>
                            </span>
                            <span>•</span>
                            <span>
                              Claims: <strong className="text-white">{claims} / {gift.maxClaims}</strong>
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => adminToggleGiftCodeStatus(gift.code, gift.status)}
                            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                              gift.status === 'active'
                                ? 'bg-amber-600/20 text-amber-400 hover:bg-amber-600/30'
                                : 'bg-green-600/20 text-green-400 hover:bg-green-600/30'
                            }`}
                          >
                            {gift.status === 'active' ? 'Deactivate' : 'Activate'}
                          </button>

                          <button
                            onClick={() => {
                              if (window.confirm(`Delete gift code "${gift.code}"?`)) {
                                adminDeleteGiftCode(gift.code);
                              }
                            }}
                            className="p-1.5 bg-red-600/20 hover:bg-red-600 text-red-300 hover:text-white rounded-xl transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Live Chat Support Management & Reply Section */}
        {activeTab === 'livechat' && (
          <AdminChatManagement
            onShowToast={(msg, type) => showToast(msg, type)}
          />
        )}

        {/* 10 VIP Bonus Admin Management Control */}
        {activeTab === 'vip' && (
          <AdminVipManagement
            onShowToast={(msg, type) => showToast(msg, type)}
          />
        )}

        {/* Unlimited Announcements Photo & Text Admin Management */}
        {activeTab === 'announcements' && (
          <AdminAnnouncementManagement
            onShowToast={(msg, type) => showToast(msg, type)}
          />
        )}

        {/* All Games Outcome & Card Image Controls */}
        {activeTab === 'gameControls' && (
          <AdminGameControls
            onShowToast={(msg, type) => showToast(msg, type)}
          />
        )}
      </div>

      {/* 3-Line Menu Drawer / Modal System (অল কন্ট্রোল সিস্টেম) */}
      {is3LineMenuOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex justify-start animate-fadeIn">
          {/* Backdrop dismiss */}
          <div
            className="fixed inset-0"
            onClick={() => setIs3LineMenuOpen(false)}
            aria-label="Close menu backdrop"
          />

          {/* Slide-over Drawer Panel */}
          <div className="relative z-10 w-full max-w-sm sm:max-w-md bg-slate-900 border-r border-slate-800 h-full flex flex-col shadow-2xl overflow-hidden">
            {/* Drawer Header */}
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-black">
                  <Menu className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-white flex items-center space-x-1.5">
                    <span>All Control Systems</span>
                  </h3>
                  <span className="text-[11px] text-amber-400 font-bold">অল কন্ট্রোল সিস্টেম</span>
                </div>
              </div>

              <button
                onClick={() => setIs3LineMenuOpen(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
                id="close-3line-menu-btn"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Live Stats Strip inside Drawer */}
            <div className="bg-slate-950/60 border-b border-slate-800/80 px-4 py-2.5 grid grid-cols-3 gap-2 text-center text-[10px]">
              <div className="bg-slate-900/80 rounded-xl p-1.5 border border-slate-800">
                <div className="text-slate-400">Total Users</div>
                <div className="font-black text-white font-mono text-xs">{totalUsersCount}</div>
              </div>
              <div className="bg-slate-900/80 rounded-xl p-1.5 border border-slate-800">
                <div className="text-slate-400">Total Dep</div>
                <div className="font-black text-emerald-400 font-mono text-xs truncate">৳{totalDepositAmount.toLocaleString()}</div>
              </div>
              <div className="bg-slate-900/80 rounded-xl p-1.5 border border-slate-800">
                <div className="text-slate-400">Pending</div>
                <div className="font-black text-amber-400 font-mono text-xs">
                  {pendingDeposits.length + pendingWithdrawals.length} reqs
                </div>
              </div>
            </div>

            {/* Navigation List of All Control Systems */}
            <div className="flex-1 overflow-y-auto p-4 space-y-1.5">
              <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider px-2 pb-1">
                Admin Modules & Controls
              </div>

              {[
                {
                  id: 'dashboard',
                  title: 'Home Dashboard',
                  bn: 'হোম ড্যাশবোর্ড',
                  desc: 'Total users, deposits, payouts & today metrics',
                  icon: LayoutDashboard,
                  color: 'text-amber-400',
                  bg: 'bg-amber-400/10',
                  badge: 'Overview',
                  badgeColor: 'bg-amber-400/20 text-amber-300'
                },
                {
                  id: 'wingo',
                  title: 'Wingo Prediction',
                  bn: 'উইন গো প্রেডিকশন কন্ট্রোল',
                  desc: 'Manage colors, numbers, and live rounds',
                  icon: Gamepad2,
                  color: 'text-red-400',
                  bg: 'bg-red-400/10',
                  badge: `${timeLeft}s left`,
                  badgeColor: 'bg-red-500/20 text-red-300'
                },
                {
                  id: 'gameControls',
                  title: 'All Games Outcome & Card Control',
                  bn: 'সকল গেম রেজাল্ট ও কার্ড ইমেজ কন্ট্রোল',
                  desc: 'K3 dice, 5D numbers, TRX, Aviator crash & cards',
                  icon: Sliders,
                  color: 'text-rose-400',
                  bg: 'bg-rose-400/10',
                  badge: 'Realtime',
                  badgeColor: 'bg-rose-500/20 text-rose-300'
                },
                {
                  id: 'announcements',
                  title: 'Unlimited Announcements',
                  bn: 'ঘোষণা ও ছবি সিস্টেম (আনলিমিটেড)',
                  desc: 'Add unlimited photo & text announcements for dashboard',
                  icon: Sparkles,
                  color: 'text-amber-400',
                  bg: 'bg-amber-400/10',
                  badge: 'Photos & Text',
                  badgeColor: 'bg-amber-500/20 text-amber-300'
                },
                {
                  id: 'vip',
                  title: '👑 10 VIP Bonus Control',
                  bn: 'ভিআইপি ১-১০ বোনাস ফুল কন্ট্রোল',
                  desc: 'Targets, level-up bonus, monthly gifts',
                  icon: Crown,
                  color: 'text-amber-300',
                  bg: 'bg-amber-400/10',
                  badge: '10 Tiers',
                  badgeColor: 'bg-amber-500/20 text-amber-200'
                },
                {
                  id: 'games',
                  title: 'Game Card & Add Management',
                  bn: 'গেম কার্ড ও নতুন গেম যোগ কন্ট্রোল',
                  desc: `${games.length} games live, no demo cards`,
                  icon: Gamepad2,
                  color: 'text-emerald-400',
                  bg: 'bg-emerald-400/10',
                  badge: `${games.length} Games`,
                  badgeColor: 'bg-emerald-500/20 text-emerald-300'
                },
                {
                  id: 'banners',
                  title: 'Banner Management',
                  bn: 'ব্যানার ৫টি ইমেজ ও অ্যাকশন',
                  desc: `${banners.length} carousel promotion banners`,
                  icon: ImageIcon,
                  color: 'text-blue-400',
                  bg: 'bg-blue-400/10',
                  badge: `${banners.length}/5`,
                  badgeColor: 'bg-blue-500/20 text-blue-300'
                },
                {
                  id: 'users',
                  title: 'User Management & Fast VIP',
                  bn: 'ইউজার ম্যানেজমেন্ট ও ফাস্ট ভিআইপি',
                  desc: 'Search accounts, adjust balances, assign VIP',
                  icon: Users,
                  color: 'text-purple-400',
                  bg: 'bg-purple-400/10',
                  badge: `${totalUsersCount} Users`,
                  badgeColor: 'bg-purple-500/20 text-purple-300'
                },
                {
                  id: 'deposits',
                  title: 'Deposit Requests',
                  bn: 'ডিপোজিট রিকোয়েস্ট ও অনুমোদন',
                  desc: 'Approve or reject bKash, Nagad, Rocket, USDT',
                  icon: ArrowUpRight,
                  color: 'text-green-400',
                  bg: 'bg-green-400/10',
                  badge: pendingDeposits.length > 0 ? `${pendingDeposits.length} Pending` : 'All done',
                  badgeColor: pendingDeposits.length > 0 ? 'bg-amber-500 text-slate-950 font-black' : 'bg-slate-800 text-slate-400'
                },
                {
                  id: 'withdrawals',
                  title: 'Withdrawal Requests',
                  bn: 'উইথড্রয়াল রিকোয়েস্ট ও অনুমোদন',
                  desc: 'Review and process player cashouts',
                  icon: ArrowDownRight,
                  color: 'text-rose-400',
                  bg: 'bg-rose-400/10',
                  badge: pendingWithdrawals.length > 0 ? `${pendingWithdrawals.length} Pending` : 'All done',
                  badgeColor: pendingWithdrawals.length > 0 ? 'bg-rose-500 text-white font-black' : 'bg-slate-800 text-slate-400'
                },
                {
                  id: 'channels',
                  title: 'Payment Channels & Wallets',
                  bn: 'পেমেন্ট চ্যানেল ও ওয়ালেট নম্বর',
                  desc: 'bKash, Nagad, Rocket numbers & USDT address',
                  icon: CreditCard,
                  color: 'text-cyan-400',
                  bg: 'bg-cyan-400/10',
                  badge: 'Wallets',
                  badgeColor: 'bg-cyan-500/20 text-cyan-300'
                },
                {
                  id: 'gifts',
                  title: 'Gift Code Generator',
                  bn: 'গিফট কোড জেনারেটর (৩০ ক্যারেক্টার)',
                  desc: 'Create 30-char unique codes with limits',
                  icon: Gift,
                  color: 'text-pink-400',
                  bg: 'bg-pink-400/10',
                  badge: `${giftCodes.length} Codes`,
                  badgeColor: 'bg-pink-500/20 text-pink-300'
                },
                {
                  id: 'livechat',
                  title: 'Live Chat Support & Reply',
                  bn: 'লাইভ চ্যাট সাপোর্ট ও মেসেজ উত্তর',
                  desc: 'Real-time player support and inquiries',
                  icon: MessageSquare,
                  color: 'text-indigo-400',
                  bg: 'bg-indigo-400/10',
                  badge: 'Support',
                  badgeColor: 'bg-indigo-500/20 text-indigo-300'
                },
                {
                  id: 'settings',
                  title: 'Platform, Maintenance & Signup Bonus',
                  bn: 'সাইট অন/অফ, সাইনআপ বোনাস ও APK সেটিংস',
                  desc: 'Site On/Off, Registration bonus, APK URL & Notices',
                  icon: Sliders,
                  color: 'text-amber-300',
                  bg: 'bg-amber-400/10',
                  badge: isMaintenance ? 'Maintenance' : 'Live Online',
                  badgeColor: isMaintenance ? 'bg-rose-500 text-white font-black' : 'bg-emerald-500/20 text-emerald-300'
                },
              ].map((item) => {
                const Icon = item.icon;
                const isSelected = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id as any);
                      setIs3LineMenuOpen(false);
                    }}
                    className={`w-full p-3 rounded-2xl border text-left transition-all flex items-center justify-between group ${
                      isSelected
                        ? 'bg-slate-800 border-amber-500/50 shadow-md ring-1 ring-amber-500/30'
                        : 'bg-slate-900/80 hover:bg-slate-800/60 border-slate-800/80 hover:border-slate-700'
                    }`}
                    id={`menu-item-${item.id}`}
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className={`w-9 h-9 rounded-xl ${item.bg} ${item.color} flex items-center justify-center shrink-0`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center space-x-1.5">
                          <span className={`text-xs font-bold truncate ${isSelected ? 'text-amber-400' : 'text-white'}`}>
                            {item.title}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 truncate">{item.bn}</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 shrink-0 ml-2">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${item.badgeColor}`}>
                        {item.badge}
                      </span>
                      <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-white transition-colors" />
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Drawer Footer */}
            <div className="p-4 bg-slate-950 border-t border-slate-800 space-y-2">
              <button
                onClick={() => {
                  setIs3LineMenuOpen(false);
                  setIsAdmin(false);
                }}
                className="w-full py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold flex items-center justify-center space-x-2 transition-all shadow-md"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Exit Admin & Return to App</span>
              </button>
              <div className="text-center text-[10px] text-slate-400 font-mono">
                Trade BD Master Admin v2.6 • Connected Live
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
