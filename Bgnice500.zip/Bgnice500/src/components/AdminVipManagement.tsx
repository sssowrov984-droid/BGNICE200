import React, { useState, useEffect } from 'react';
import { Crown, Save, RotateCcw, Award, CheckCircle2, DollarSign, Users, Gift, ShieldAlert, Sparkles, Sliders } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { VipLevelConfig, UserProfile } from '../types';
import { DEFAULT_VIP_LEVELS } from '../utils/defaultVip';

export const AdminVipManagement: React.FC = () => {
  const { settings, adminUpdateSettings, allUsers, adminUpdateUserVip, adminAdjustUserBalance, showToast } = useApp();

  const [vipLevels, setVipLevels] = useState<Record<number, VipLevelConfig>>(() => {
    return settings.vipLevels && Object.keys(settings.vipLevels).length > 0
      ? settings.vipLevels
      : DEFAULT_VIP_LEVELS;
  });

  const [isSaving, setIsSaving] = useState(false);
  const [userSearch, setUserSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [targetVipLevel, setTargetVipLevel] = useState<number>(1);
  const [customBonusAmount, setCustomBonusAmount] = useState<string>('500');

  useEffect(() => {
    if (settings.vipLevels && Object.keys(settings.vipLevels).length > 0) {
      setVipLevels(settings.vipLevels);
    }
  }, [settings.vipLevels]);

  const handleFieldChange = (
    level: number,
    field: keyof VipLevelConfig,
    value: string | number | boolean
  ) => {
    setVipLevels((prev) => {
      const current = prev[level] || DEFAULT_VIP_LEVELS[level];
      return {
        ...prev,
        [level]: {
          ...current,
          [field]: value
        }
      };
    });
  };

  const handleSaveAll = async () => {
    setIsSaving(true);
    try {
      await adminUpdateSettings({
        vipLevels
      });
      showToast('10 VIP Levels and Bonus configuration saved successfully to database!', 'success');
    } catch (err) {
      showToast('Failed to save VIP settings.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetDefaults = async () => {
    if (window.confirm('Reset all 10 VIP levels and bonuses to standard official defaults?')) {
      setVipLevels(DEFAULT_VIP_LEVELS);
      await adminUpdateSettings({
        vipLevels: DEFAULT_VIP_LEVELS
      });
      showToast('10 VIP Levels reset to standard defaults.', 'info');
    }
  };

  const handleApplyUserVip = async () => {
    if (!selectedUser) {
      showToast('Please search and select a user first.', 'error');
      return;
    }
    try {
      await adminUpdateUserVip(selectedUser.uid, targetVipLevel);
      showToast(`User UID ${selectedUser.uid} updated to VIP ${targetVipLevel}!`, 'success');
    } catch (err) {
      showToast('Failed to update user VIP level.', 'error');
    }
  };

  const handleSendVipBonus = async () => {
    if (!selectedUser) {
      showToast('Please search and select a user first.', 'error');
      return;
    }
    const amount = parseFloat(customBonusAmount);
    if (isNaN(amount) || amount <= 0) {
      showToast('Enter a valid VIP bonus amount.', 'error');
      return;
    }
    try {
      await adminAdjustUserBalance(selectedUser.uid, amount, 'credit');
      showToast(`৳${amount.toLocaleString()} VIP Bonus credited to User UID ${selectedUser.uid}!`, 'success');
      setCustomBonusAmount('500');
    } catch (err) {
      showToast('Failed to grant VIP bonus.', 'error');
    }
  };

  const safeUsersList: UserProfile[] = React.useMemo(() => {
    if (!allUsers) return [];
    if (Array.isArray(allUsers)) return allUsers;
    return Object.values(allUsers);
  }, [allUsers]);

  const filteredUsers = safeUsersList.filter((u) => {
    if (!userSearch.trim()) return false;
    const q = userSearch.toLowerCase();
    return (
      (u.uid && u.uid.toLowerCase().includes(q)) ||
      (u.phone && u.phone.toLowerCase().includes(q)) ||
      (u.nickname && u.nickname.toLowerCase().includes(q)) ||
      (u.username && u.username.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-600 p-0.5 shadow-lg flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-amber-400">
              <Crown className="w-6 h-6" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg font-black text-white">10 VIP Bonus & Level Management</h2>
              <span className="bg-amber-400 text-slate-950 font-black text-[10px] px-2 py-0.5 rounded-full uppercase">
                Admin Control
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Manage deposit thresholds, betting targets, level-up gifts, weekly & monthly rewards for VIP 1 - 10
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 w-full md:w-auto">
          <button
            onClick={handleResetDefaults}
            className="flex-1 md:flex-none px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center justify-center space-x-1.5 transition-all"
            title="Reset to official standard defaults"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Defaults</span>
          </button>
          <button
            onClick={handleSaveAll}
            disabled={isSaving}
            className="flex-1 md:flex-none px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs shadow-md flex items-center justify-center space-x-1.5 active:scale-95 transition-all disabled:opacity-50"
            id="save-vip-settings-btn"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Saving...' : 'Save All VIP Changes'}</span>
          </button>
        </div>
      </div>

      {/* User VIP Manual Assign & Bonus Credit Widget */}
      <div className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-5 shadow-lg space-y-4">
        <div className="flex items-center space-x-2 text-amber-400 font-extrabold text-sm">
          <Sparkles className="w-4 h-4" />
          <span>Quick User VIP Grant & Instant Bonus Credit</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* User Search */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300">Find User (UID / Phone)</label>
            <input
              type="text"
              value={userSearch}
              onChange={(e) => setUserSearch(e.target.value)}
              placeholder="Search user UID or phone..."
              className="w-full py-2 px-3 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white outline-none focus:border-amber-400"
            />
            {filteredUsers.length > 0 && (
              <div className="bg-slate-800 border border-slate-700 rounded-xl max-h-36 overflow-y-auto mt-1 p-1 space-y-1">
                {filteredUsers.slice(0, 5).map((u) => (
                  <div
                    key={u.uid}
                    onClick={() => {
                      setSelectedUser(u);
                      setTargetVipLevel(u.vipLevel || 1);
                      setUserSearch('');
                    }}
                    className="p-1.5 hover:bg-slate-700/80 rounded-lg cursor-pointer text-xs flex items-center justify-between"
                  >
                    <span className="font-bold text-white">UID: {u.uid}</span>
                    <span className="text-[10px] text-amber-300 font-bold">VIP {u.vipLevel || 0}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Selected User & VIP Assignment */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300">
              Selected: {selectedUser ? `UID ${selectedUser.uid}` : 'None'}
            </label>
            <div className="flex space-x-2">
              <select
                value={targetVipLevel}
                onChange={(e) => setTargetVipLevel(parseInt(e.target.value))}
                className="flex-1 py-2 px-3 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white outline-none focus:border-amber-400 font-bold"
              >
                {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((lvl) => (
                  <option key={lvl} value={lvl}>
                    {lvl === 0 ? 'VIP 0 (Regular)' : `VIP ${lvl}`}
                  </option>
                ))}
              </select>
              <button
                onClick={handleApplyUserVip}
                disabled={!selectedUser}
                className="px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-xs disabled:opacity-40"
              >
                Set VIP
              </button>
            </div>
          </div>

          {/* Instant VIP Bonus Credit */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300">Instant VIP Bonus (৳)</label>
            <div className="flex space-x-2">
              <input
                type="number"
                value={customBonusAmount}
                onChange={(e) => setCustomBonusAmount(e.target.value)}
                placeholder="Amount (e.g. 500)"
                className="flex-1 py-2 px-3 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white outline-none focus:border-emerald-400 font-mono"
              />
              <button
                onClick={handleSendVipBonus}
                disabled={!selectedUser}
                className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow-xs disabled:opacity-40"
              >
                Grant Bonus
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 10 VIP Levels Grid (VIP 1 to VIP 10) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((level) => {
          const cfg = vipLevels[level] || DEFAULT_VIP_LEVELS[level];
          return (
            <div
              key={`vip-card-${level}`}
              className="bg-slate-900 border border-slate-800 hover:border-amber-500/50 rounded-3xl p-5 shadow-lg space-y-3.5 transition-all group"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2.5">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 shadow-md flex items-center justify-center font-black text-slate-950 text-xs">
                    V{level}
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white">{cfg.name || `VIP ${level}`}</h3>
                    <span className="text-[10px] text-slate-400">Level {level} Configuration</span>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <label className="text-[11px] font-bold text-slate-300 flex items-center space-x-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={cfg.enabled ?? true}
                      onChange={(e) => handleFieldChange(level, 'enabled', e.target.checked)}
                      className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400 bg-slate-800 border-slate-700"
                    />
                    <span>Active</span>
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5 text-xs">
                {/* Min Recharge */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400">Min Deposit (৳)</label>
                  <input
                    type="number"
                    value={cfg.minRecharge}
                    onChange={(e) => handleFieldChange(level, 'minRecharge', parseFloat(e.target.value) || 0)}
                    className="w-full py-1.5 px-2.5 text-xs font-mono font-bold bg-slate-800/90 border border-slate-700 rounded-lg text-white outline-none focus:border-amber-400"
                  />
                </div>

                {/* Min Betting Turnover */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400">Min Turnover (৳)</label>
                  <input
                    type="number"
                    value={cfg.minBet}
                    onChange={(e) => handleFieldChange(level, 'minBet', parseFloat(e.target.value) || 0)}
                    className="w-full py-1.5 px-2.5 text-xs font-mono font-bold bg-slate-800/90 border border-slate-700 rounded-lg text-white outline-none focus:border-amber-400"
                  />
                </div>

                {/* Level-Up Bonus */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-emerald-400">🎁 Level-Up Bonus (৳)</label>
                  <input
                    type="number"
                    value={cfg.levelUpBonus}
                    onChange={(e) => handleFieldChange(level, 'levelUpBonus', parseFloat(e.target.value) || 0)}
                    className="w-full py-1.5 px-2.5 text-xs font-mono font-extrabold bg-slate-800/90 border border-emerald-500/40 rounded-lg text-emerald-300 outline-none focus:border-emerald-400"
                  />
                </div>

                {/* Daily Rebate Rate */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-amber-400">⚡ Daily Rebate (%)</label>
                  <input
                    type="number"
                    step="0.05"
                    value={cfg.rebateRate}
                    onChange={(e) => handleFieldChange(level, 'rebateRate', parseFloat(e.target.value) || 0)}
                    className="w-full py-1.5 px-2.5 text-xs font-mono font-extrabold bg-slate-800/90 border border-amber-500/40 rounded-lg text-amber-300 outline-none focus:border-amber-400"
                  />
                </div>

                {/* Weekly Bonus */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-sky-400">🗓️ Weekly Reward (৳)</label>
                  <input
                    type="number"
                    value={cfg.weeklyBonus}
                    onChange={(e) => handleFieldChange(level, 'weeklyBonus', parseFloat(e.target.value) || 0)}
                    className="w-full py-1.5 px-2.5 text-xs font-mono font-bold bg-slate-800/90 border border-slate-700 rounded-lg text-white outline-none focus:border-sky-400"
                  />
                </div>

                {/* Monthly Bonus */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-purple-400">👑 Monthly Reward (৳)</label>
                  <input
                    type="number"
                    value={cfg.monthlyBonus}
                    onChange={(e) => handleFieldChange(level, 'monthlyBonus', parseFloat(e.target.value) || 0)}
                    className="w-full py-1.5 px-2.5 text-xs font-mono font-bold bg-slate-800/90 border border-slate-700 rounded-lg text-white outline-none focus:border-purple-400"
                  />
                </div>

                {/* Safe Rate */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-cyan-400">🛡️ Safe Vault Rate (%)</label>
                  <input
                    type="number"
                    step="0.05"
                    value={cfg.safeRate ?? 0.1}
                    onChange={(e) => handleFieldChange(level, 'safeRate', parseFloat(e.target.value) || 0)}
                    className="w-full py-1.5 px-2.5 text-xs font-mono font-bold bg-slate-800/90 border border-cyan-500/40 rounded-lg text-cyan-300 outline-none focus:border-cyan-400"
                  />
                </div>

                {/* Heart Points: Level-Up & Monthly */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-rose-400">❤️ Heart Points (Lvl/Mo)</label>
                  <div className="flex space-x-1">
                    <input
                      type="number"
                      placeholder="Lvl"
                      value={cfg.heartLevelUp ?? 0}
                      onChange={(e) => handleFieldChange(level, 'heartLevelUp', parseInt(e.target.value) || 0)}
                      className="w-1/2 py-1.5 px-1.5 text-xs font-mono font-bold bg-slate-800/90 border border-slate-700 rounded-lg text-rose-300 outline-none focus:border-rose-400"
                    />
                    <input
                      type="number"
                      placeholder="Mo"
                      value={cfg.heartMonthly ?? 0}
                      onChange={(e) => handleFieldChange(level, 'heartMonthly', parseInt(e.target.value) || 0)}
                      className="w-1/2 py-1.5 px-1.5 text-xs font-mono font-bold bg-slate-800/90 border border-slate-700 rounded-lg text-rose-300 outline-none focus:border-rose-400"
                    />
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
