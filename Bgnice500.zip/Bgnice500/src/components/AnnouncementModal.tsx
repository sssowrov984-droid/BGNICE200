import React, { useState, useMemo } from 'react';
import { Volume2, X, ChevronLeft, ChevronRight, ExternalLink } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AnnouncementItem } from '../types';

interface AnnouncementModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AnnouncementModal: React.FC<AnnouncementModalProps> = ({ isOpen, onClose }) => {
  const { settings } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);

  // Parse unlimited announcements from settings
  const announcementList: AnnouncementItem[] = useMemo(() => {
    if (settings?.announcements && typeof settings.announcements === 'object') {
      const list = (Object.values(settings.announcements) as AnnouncementItem[]).filter(
        (a) => a && a.active !== false
      );
      if (list.length > 0) {
        return list.sort((a, b) => (b.priority || 0) - (a.priority || 0) || b.createdAt - a.createdAt);
      }
    }
    // Fallback single default announcement if none added yet
    return [
      {
        id: 'default-1',
        title: settings.activeAnnouncementTitle || 'Official Platform Announcement',
        content:
          settings.platformAnnouncement ||
          'Welcome to the official entertainment platform! Enjoy 24/7 instant deposit and withdrawal services via Nagad and bKash with 100% security guarantee.',
        imageUrl:
          'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
        active: true,
        createdAt: Date.now()
      }
    ];
  }, [settings]);

  if (!isOpen || announcementList.length === 0) return null;

  const currentAnnouncement = announcementList[currentIndex] || announcementList[0];

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % announcementList.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + announcementList.length) % announcementList.length);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200 select-none">
      <div className="relative w-full max-w-sm bg-white rounded-3xl overflow-hidden shadow-2xl border border-slate-100 animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        {/* Header Bar */}
        <div className="bg-gradient-to-r from-[#ff5a4d] to-[#ff4747] px-4 py-3 flex items-center justify-between text-white shrink-0">
          <div className="flex items-center space-x-2 truncate">
            <Volume2 className="w-5 h-5 text-amber-300 shrink-0" />
            <h3 className="font-bold text-sm tracking-wide truncate">
              {currentAnnouncement.title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-white/80 hover:text-white rounded-full hover:bg-white/10 shrink-0"
            id="announcement-close-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto p-4 space-y-3 flex-1">
          {/* Announcement Photo if available - flexible display for any photo dimension */}
          {Boolean(currentAnnouncement.imageUrl && currentAnnouncement.imageUrl.trim()) && (
            <div className="relative w-full rounded-2xl overflow-hidden bg-slate-100 border border-slate-200/80 shadow-xs max-h-[380px] flex items-center justify-center">
              <img
                src={currentAnnouncement.imageUrl}
                alt={currentAnnouncement.title}
                className="w-full h-auto max-h-[360px] object-contain rounded-2xl"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
          )}

          {/* Announcement Text Body */}
          <div className="text-xs text-slate-700 space-y-2 leading-relaxed whitespace-pre-line bg-slate-50 p-3 rounded-2xl border border-slate-100 font-medium">
            {currentAnnouncement.content}
          </div>

          {currentAnnouncement.link && (
            <a
              href={currentAnnouncement.link}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1.5 text-xs text-[#ff4949] font-bold hover:underline"
            >
              <span>Learn more</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}
        </div>

        {/* Footer Navigation & Actions */}
        <div className="p-4 pt-2 border-t border-slate-100 bg-white shrink-0 space-y-2.5">
          {/* Dots and Prev/Next Carousel buttons if multiple announcements */}
          {announcementList.length > 1 && (
            <div className="flex items-center justify-between px-1">
              <button
                onClick={handlePrev}
                className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 active:scale-95 transition-all"
                id="announcement-prev-btn"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <div className="flex items-center space-x-1">
                {announcementList.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentIndex(idx)}
                    className={`h-1.5 rounded-full transition-all ${
                      idx === currentIndex ? 'w-4 bg-[#2196f3]' : 'w-1.5 bg-slate-200'
                    }`}
                  />
                ))}
              </div>

              <button
                onClick={handleNext}
                className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 active:scale-95 transition-all"
                id="announcement-next-btn"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          <button
            onClick={onClose}
            className="w-full py-2.5 bg-gradient-to-r from-[#ff604d] to-[#ff4747] hover:from-[#ff513d] hover:to-[#ff3838] text-white font-bold rounded-xl shadow-md active:scale-98 transition-all text-xs"
            id="announcement-confirm-btn"
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
};
