import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  Smartphone,
  Mail,
  Lock,
  Eye,
  EyeOff,
  Ticket,
  AlertCircle,
  CheckCircle2,
  ChevronDown,
  RefreshCw,
  HelpCircle,
  Check
} from 'lucide-react';
import { ref, get } from 'firebase/database';
import { rtdb } from '../lib/firebase';
import { useApp } from '../context/AppContext';
import { BrandLogo } from './BrandLogo';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  defaultMode?: 'login' | 'signup';
  canClose?: boolean;
}

interface CountryOption {
  code: string;
  name: string;
  flag: string;
  placeholder: string;
}

const COUNTRIES: CountryOption[] = [
  { code: '+880', name: 'Bangladesh', flag: '🇧🇩', placeholder: 'Please enter the phone number' },
  { code: '+92', name: 'Pakistan', flag: '🇵🇰', placeholder: 'Please enter the phone number' },
  { code: '+91', name: 'India', flag: '🇮🇳', placeholder: 'Please enter the phone number' }
];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  defaultMode = 'login',
  canClose = true
}) => {
  const { login, loginWithPhone, register, sendPasswordReset, showToast } = useApp();

  // Mode: 'login' or 'signup'
  const [mode, setMode] = useState<'login' | 'signup'>(defaultMode);

  // Tabs inside Login: 'phone' or 'email'
  const [loginTab, setLoginTab] = useState<'phone' | 'email'>('phone');

  // Tabs inside Register: 'phone' or 'email' (default is 'phone' as in screenshot)
  const [registerTab, setRegisterTab] = useState<'phone' | 'email'>('phone');

  // Country Code selector
  const [selectedCountry, setSelectedCountry] = useState<CountryOption>(COUNTRIES[0]);
  const [isCountryDropdownOpen, setIsCountryDropdownOpen] = useState(false);

  // Phone inputs
  const [phoneInput, setPhoneInput] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [rememberPassword, setRememberPassword] = useState(true);

  // Email login inputs
  const [emailInput, setEmailInput] = useState('');

  // Register inputs
  const [regPhoneInput, setRegPhoneInput] = useState('');
  const [regEmailInput, setRegEmailInput] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showRegConfirmPassword, setShowRegConfirmPassword] = useState(false);
  const [inviteCode, setInviteCode] = useState('');
  const [isInviteLocked, setIsInviteLocked] = useState(false);
  const [agreedToPrivacy, setAgreedToPrivacy] = useState(true);

  // Forgot password state
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);

  // UI state
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Load referral code from URL query params (?ref=... or ?invite=...)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('ref') || params.get('invite') || params.get('refer');
    if (code) {
      setInviteCode(code.trim());
      setIsInviteLocked(true);
      setMode('signup');
    }
  }, []);

  useEffect(() => {
    setMode(defaultMode);
  }, [defaultMode]);

  if (!isOpen) return null;

  // Helper: Normalize phone digits for BD (+880)
  const normalizeDigits = (raw: string) => {
    let digits = raw.replace(/\D/g, '');
    if (digits.startsWith('880')) digits = digits.slice(3);
    if (!digits.startsWith('0') && digits.length === 10) digits = '0' + digits;
    return digits;
  };

  // 1. SUBMIT LOGIN
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (loginTab === 'phone') {
      const cleanDigits = normalizeDigits(phoneInput);
      if (!cleanDigits || cleanDigits.length < 8) {
        setErrorMessage('Please enter a valid phone number');
        return;
      }
      if (!loginPassword) {
        setErrorMessage('Please enter your password');
        return;
      }

      setLoading(true);
      // Attempt login via phone/background email
      const res = await login(cleanDigits, loginPassword);
      setLoading(false);

      if (res.success) {
        onSuccess?.();
        onClose();
      } else {
        setErrorMessage(res.message || 'Invalid phone number or password');
      }
    } else {
      // Email Login
      const cleanEmail = emailInput.trim().toLowerCase();
      if (!cleanEmail || !cleanEmail.includes('@')) {
        setErrorMessage('Please enter a valid email address');
        return;
      }
      if (!loginPassword) {
        setErrorMessage('Please enter your password');
        return;
      }

      setLoading(true);
      const res = await login(cleanEmail, loginPassword);
      setLoading(false);

      if (res.success) {
        onSuccess?.();
        onClose();
      } else {
        setErrorMessage(res.message || 'Invalid email or password');
      }
    }
  };

  // 2. SUBMIT REGISTER (Hidden Background Phone -> Email Conversion)
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    let cleanPhoneDigits = '';
    let backgroundAuthEmail = '';

    if (registerTab === 'phone') {
      cleanPhoneDigits = normalizeDigits(regPhoneInput);
      if (!cleanPhoneDigits || cleanPhoneDigits.length < 9) {
        setErrorMessage('Please enter a valid phone number');
        return;
      }
      // Secret background email conversion: 017XXXXXXXX@mygame.com
      // The user is never aware of this email conversion.
      backgroundAuthEmail = `${cleanPhoneDigits}@mygame.com`;
    } else {
      // Email registration fallback
      backgroundAuthEmail = regEmailInput.trim().toLowerCase();
      if (!backgroundAuthEmail || !backgroundAuthEmail.includes('@') || !backgroundAuthEmail.includes('.')) {
        setErrorMessage('Please enter a valid email address');
        return;
      }
      cleanPhoneDigits = '01' + Date.now().toString().slice(-9);
    }

    if (!regPassword || regPassword.length < 6) {
      setErrorMessage('Password must be at least 6 characters');
      return;
    }
    if (regPassword !== regConfirmPassword) {
      setErrorMessage('Passwords do not match');
      return;
    }
    if (!inviteCode.trim()) {
      setErrorMessage('রেফার কোড ছাড়া রেজিস্টার করা সম্ভব নয় (Invitation code is required)');
      showToast('রেফার কোড দিন (Invite code required)', 'error');
      return;
    }
    if (!agreedToPrivacy) {
      setErrorMessage('Please agree to the Privacy Agreement');
      return;
    }

    try {
      setLoading(true);

      // Verify phone uniqueness in RTDB
      const usersSnap = await get(ref(rtdb, 'users'));
      if (usersSnap.exists()) {
        const usersData = usersSnap.val() as Record<string, any>;
        for (const u of Object.values(usersData)) {
          const existingPhoneDigits = (u?.phone || '').replace(/\D/g, '');
          if (
            (u?.phone && (u.phone === cleanPhoneDigits || u.phone === `${selectedCountry.code}${cleanPhoneDigits}`)) ||
            (existingPhoneDigits && existingPhoneDigits.length >= 8 && existingPhoneDigits === cleanPhoneDigits)
          ) {
            setLoading(false);
            const msg = 'এই ফোন নম্বর দিয়ে ইতিমধ্যে অ্যাকাউন্ট আছে (Phone already registered)';
            setErrorMessage(msg);
            showToast(msg, 'error');
            return;
          }
        }
      }

      // Automatically construct registration with secret backend email
      const res = await register({
        phone: cleanPhoneDigits,
        email: backgroundAuthEmail,
        country: selectedCountry.name,
        countryCode: selectedCountry.code,
        password: regPassword,
        referCode: inviteCode.trim(),
        phoneVerified: true
      });

      setLoading(false);

      if (res.success) {
        showToast('Registration successful! Welcome to BGNICE', 'success');
        onSuccess?.();
        onClose();
      } else {
        setErrorMessage(res.message);
        showToast(res.message, 'error');
      }
    } catch (err: any) {
      setLoading(false);
      const msg = err.message || 'Registration failed. Please try again.';
      setErrorMessage(msg);
      showToast(msg, 'error');
    }
  };

  // 3. SUBMIT FORGOT PASSWORD
  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    const clean = forgotEmail.trim().toLowerCase();
    if (!clean || !clean.includes('@')) {
      setErrorMessage('Please enter your registered Gmail or bound email address');
      return;
    }

    setForgotLoading(true);
    const res = await sendPasswordReset(clean);
    setForgotLoading(false);

    if (res.success) {
      setSuccessMessage(res.message);
      setTimeout(() => {
        setIsForgotPasswordOpen(false);
        setSuccessMessage('');
      }, 3000);
    } else {
      setErrorMessage(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#070e1c] flex flex-col items-center justify-start sm:justify-center p-0 sm:p-4 select-none overflow-y-auto">
      {/* Container - Full screen on mobile, centered card on desktop */}
      <div className="bg-[#0b162b] sm:bg-[#0e1c34] w-full min-h-screen sm:min-h-0 sm:max-w-md sm:rounded-3xl shadow-2xl border-0 sm:border sm:border-[#1d355b] relative flex flex-col justify-between sm:my-auto text-white overflow-hidden">
        
        {/* Top Header Bar with Gradient & Safe Area Clearance */}
        <div 
          className="bg-gradient-to-b from-[#142d54] via-[#0f2240] to-[#0b162b] px-5 pb-3.5 shrink-0 flex items-center justify-between border-b border-[#1a3154] shadow-sm"
          style={{ paddingTop: 'max(1.75rem, calc(env(safe-area-inset-top, 0px) + 0.85rem))' }}
        >
          {/* Back button */}
          <button
            onClick={() => {
              if (isForgotPasswordOpen) {
                setIsForgotPasswordOpen(false);
              } else if (canClose) {
                onClose();
              }
            }}
            className="p-2 -ml-2 text-slate-300 hover:text-white rounded-full hover:bg-white/10 active:scale-90 transition-all cursor-pointer flex items-center justify-center"
            id="auth-back-btn"
            title="Back"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Centered Brand Logo */}
          <div className="flex items-center space-x-1.5 py-0.5">
            <span className="font-black text-xl tracking-tight text-white uppercase drop-shadow-sm font-sans">
              BG
            </span>
            <span className="text-base font-black px-2.5 py-0.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 text-white tracking-wide shadow-md shadow-blue-500/30 uppercase transform -skew-x-6">
              NICE
            </span>
          </div>

          {/* Language Selector: [Flag] EN */}
          <div className="flex items-center space-x-1.5 bg-[#152744] border border-[#23416e] px-2.5 py-1 rounded-full text-xs font-bold text-slate-200 shadow-xs">
            <span>🇺🇸</span>
            <span className="text-[11px] tracking-wider">EN</span>
          </div>
        </div>

        {/* Error / Success Banners */}
        <div className="px-5 pt-3 shrink-0">
          {errorMessage && (
            <div className="flex items-start space-x-2 p-3 bg-red-950/70 border border-red-500/50 rounded-xl text-red-200 text-xs font-medium leading-relaxed animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
              <span className="flex-1">{errorMessage}</span>
            </div>
          )}
          {successMessage && (
            <div className="flex items-start space-x-2 p-3 bg-emerald-950/70 border border-emerald-500/50 rounded-xl text-emerald-200 text-xs font-medium leading-relaxed animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
              <span className="flex-1">{successMessage}</span>
            </div>
          )}
        </div>

        {/* Modal Main Content Area */}
        <div className="px-6 pt-3 pb-12 sm:pb-6 overflow-y-auto flex-1">
          {isForgotPasswordOpen ? (
            /* ==========================================================
               VIEW 1: FORGOT PASSWORD FORM
               ========================================================== */
            <div className="space-y-4 pt-2">
              <div>
                <h1 className="text-2xl font-black text-white tracking-tight">
                  Reset Password
                </h1>
                <p className="text-xs text-slate-400 mt-1">
                  Enter your registered or bound email address to receive password reset instructions.
                </p>
              </div>

              <form onSubmit={handleForgotPasswordSubmit} className="space-y-4 pt-2">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">
                    Email Address
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-3.5 text-slate-400">
                      <Mail className="w-4 h-4" />
                    </span>
                    <input
                      type="email"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      placeholder="Please enter your email"
                      className="w-full pl-10 pr-3.5 py-3 rounded-xl bg-[#12223c] border border-[#1f3861] text-white text-xs font-semibold placeholder:text-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={forgotLoading}
                  className="w-full py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black rounded-full text-xs shadow-lg shadow-blue-500/25 active:scale-98 transition-all flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
                >
                  {forgotLoading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Sending reset email...</span>
                    </>
                  ) : (
                    <span>Send Reset Email</span>
                  )}
                </button>

                <div className="text-center pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsForgotPasswordOpen(false);
                      setErrorMessage('');
                    }}
                    className="text-xs text-blue-400 hover:text-blue-300 font-bold cursor-pointer"
                  >
                    ← Back to Log in
                  </button>
                </div>
              </form>
            </div>
          ) : mode === 'login' ? (
            /* ==========================================================
               VIEW 2: LOG IN VIEW (Matching Screenshot 3)
               ========================================================== */
            <div className="space-y-4">
              {/* Title & Subtitles */}
              <div>
                <h1 className="text-2xl font-black text-white tracking-tight">
                  Log in
                </h1>
                <p className="text-xs text-slate-300 mt-1">
                  Please log in with your phone number or email
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  If you forget your password, please contact customer service
                </p>
              </div>

              {/* Login Tabs: [Phone Icon] Phone Number | [Mail Icon] Email */}
              <div className="flex border-b border-[#1b345b] pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setLoginTab('phone');
                    setErrorMessage('');
                  }}
                  className={`flex-1 pb-3 flex items-center justify-center space-x-2 font-bold text-xs cursor-pointer transition-all border-b-2 ${
                    loginTab === 'phone'
                      ? 'border-blue-400 text-blue-400'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                  id="login-tab-phone-btn"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>Phone Number</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setLoginTab('email');
                    setErrorMessage('');
                  }}
                  className={`flex-1 pb-3 flex items-center justify-center space-x-2 font-bold text-xs cursor-pointer transition-all border-b-2 ${
                    loginTab === 'email'
                      ? 'border-blue-400 text-blue-400'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                  id="login-tab-email-btn"
                >
                  <Mail className="w-4 h-4" />
                  <span>Email</span>
                </button>
              </div>

              {/* Form Body */}
              <form onSubmit={handleLoginSubmit} className="space-y-4 pt-1">
                {loginTab === 'phone' ? (
                  /* Phone Input Field */
                  <div>
                    <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5 mb-1.5">
                      <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                      <span>Phone number</span>
                    </label>

                    <div className="flex items-center space-x-2">
                      {/* Country prefix selector */}
                      <div className="relative shrink-0">
                        <select
                          value={selectedCountry.code}
                          onChange={(e) => {
                            const found = COUNTRIES.find((c) => c.code === e.target.value);
                            if (found) setSelectedCountry(found);
                          }}
                          className="appearance-none bg-[#12223c] border border-[#1f3861] text-white text-xs font-bold py-3 pl-3 pr-7 rounded-xl focus:outline-none focus:border-blue-500 cursor-pointer"
                        >
                          {COUNTRIES.map((c) => (
                            <option key={c.code} value={c.code} className="bg-[#0b162b] text-white">
                              {c.code}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="w-3 h-3 text-slate-400 absolute right-2 top-4 pointer-events-none" />
                      </div>

                      {/* Phone Number Input */}
                      <div className="flex-1 relative">
                        <input
                          type="tel"
                          value={phoneInput}
                          onChange={(e) => setPhoneInput(e.target.value.replace(/\D/g, ''))}
                          placeholder={selectedCountry.placeholder}
                          className="w-full px-3.5 py-3 rounded-xl bg-[#12223c] border border-[#1f3861] text-white text-xs font-mono font-bold placeholder:font-sans placeholder:text-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                          required
                          id="login-phone-input"
                        />
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Email Input Field */
                  <div>
                    <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5 mb-1.5">
                      <Mail className="w-3.5 h-3.5 text-blue-400" />
                      <span>Email</span>
                    </label>
                    <div className="relative">
                      <input
                        type="email"
                        value={emailInput}
                        onChange={(e) => setEmailInput(e.target.value)}
                        placeholder="Please enter your email"
                        className="w-full px-3.5 py-3 rounded-xl bg-[#12223c] border border-[#1f3861] text-white text-xs font-semibold placeholder:text-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                        required
                        id="login-email-input"
                      />
                    </div>
                  </div>
                )}

                {/* Password Field */}
                <div>
                  <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5 mb-1.5">
                    <Lock className="w-3.5 h-3.5 text-blue-400" />
                    <span>Password</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showLoginPassword ? 'text' : 'password'}
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="Password"
                      className="w-full pl-3.5 pr-10 py-3 rounded-xl bg-[#12223c] border border-[#1f3861] text-white text-xs font-semibold placeholder:text-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                      required
                      id="login-password-input"
                    />
                    <button
                      type="button"
                      onClick={() => setShowLoginPassword(!showLoginPassword)}
                      className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-200 cursor-pointer"
                      id="toggle-login-pwd-btn"
                    >
                      {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Remember password + Forgot password */}
                <div className="flex items-center justify-between text-xs pt-0.5">
                  <label className="flex items-center space-x-2 text-slate-400 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={rememberPassword}
                      onChange={(e) => setRememberPassword(e.target.checked)}
                      className="rounded border-[#1f3861] bg-[#12223c] text-blue-500 focus:ring-0 cursor-pointer"
                    />
                    <span>Remember password</span>
                  </label>

                  <button
                    type="button"
                    onClick={() => {
                      setIsForgotPasswordOpen(true);
                      setErrorMessage('');
                    }}
                    className="text-blue-400 hover:text-blue-300 font-bold cursor-pointer"
                    id="login-forgot-pwd-link"
                  >
                    Forgot password?
                  </button>
                </div>

                {/* Buttons: Primary "Log in", Secondary "Register" */}
                <div className="space-y-3 pt-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black rounded-full text-sm shadow-lg shadow-blue-500/25 active:scale-98 transition-all flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
                    id="btn-login-submit"
                  >
                    {loading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Logging in...</span>
                      </>
                    ) : (
                      <span>Log in</span>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setMode('signup');
                      setErrorMessage('');
                      setSuccessMessage('');
                    }}
                    className="w-full py-3 rounded-full border border-blue-500/60 hover:bg-blue-600/10 text-blue-400 font-bold text-sm active:scale-98 transition-all cursor-pointer text-center"
                    id="btn-switch-to-register"
                  >
                    Register
                  </button>
                </div>
              </form>
            </div>
          ) : (
            /* ==========================================================
               VIEW 3: REGISTER VIEW (Matching Screenshot 2)
               ========================================================== */
            <div className="space-y-4">
              {/* Title & Subtitle */}
              <div>
                <h1 className="text-2xl font-black text-white tracking-tight">
                  Register
                </h1>
                <p className="text-xs text-slate-300 mt-1">
                  Please register by phone number or email
                </p>
              </div>

              {/* Tab: [Phone Icon] Register your phone (as seen in screenshot 2) */}
              <div className="flex border-b border-[#1b345b] pt-1">
                <button
                  type="button"
                  onClick={() => setRegisterTab('phone')}
                  className={`pb-3 flex items-center space-x-2 font-bold text-xs cursor-pointer transition-all border-b-2 ${
                    registerTab === 'phone'
                      ? 'border-blue-400 text-blue-400'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                  id="reg-tab-phone-btn"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>Register your phone</span>
                </button>
              </div>

              {/* Register Form */}
              <form onSubmit={handleRegisterSubmit} className="space-y-3.5 pt-1">
                {/* 1. Phone number */}
                <div>
                  <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5 mb-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                    <span>Phone number</span>
                  </label>

                  <div className="flex items-center space-x-2">
                    {/* Country prefix selector */}
                    <div className="relative shrink-0">
                      <select
                        value={selectedCountry.code}
                        onChange={(e) => {
                          const found = COUNTRIES.find((c) => c.code === e.target.value);
                          if (found) setSelectedCountry(found);
                        }}
                        className="appearance-none bg-[#12223c] border border-[#1f3861] text-white text-xs font-bold py-3 pl-3 pr-7 rounded-xl focus:outline-none focus:border-blue-500 cursor-pointer"
                        id="reg-country-select"
                      >
                        {COUNTRIES.map((c) => (
                          <option key={c.code} value={c.code} className="bg-[#0b162b] text-white">
                            {c.code}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="w-3 h-3 text-slate-400 absolute right-2 top-4 pointer-events-none" />
                    </div>

                    {/* Phone Number Input */}
                    <div className="flex-1 relative">
                      <input
                        type="tel"
                        value={regPhoneInput}
                        onChange={(e) => setRegPhoneInput(e.target.value.replace(/\D/g, ''))}
                        placeholder={selectedCountry.placeholder}
                        className="w-full px-3.5 py-3 rounded-xl bg-[#12223c] border border-[#1f3861] text-white text-xs font-mono font-bold placeholder:font-sans placeholder:text-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                        required
                        id="reg-phone-input"
                      />
                    </div>
                  </div>
                </div>

                {/* 2. Set password */}
                <div>
                  <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5 mb-1.5">
                    <Lock className="w-3.5 h-3.5 text-blue-400" />
                    <span>Set password</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showRegPassword ? 'text' : 'password'}
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="Set password"
                      className="w-full pl-3.5 pr-10 py-3 rounded-xl bg-[#12223c] border border-[#1f3861] text-white text-xs font-semibold placeholder:text-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                      required
                      id="reg-password-input"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegPassword(!showRegPassword)}
                      className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-200 cursor-pointer"
                      id="toggle-reg-pwd-btn"
                    >
                      {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* 3. Confirm password */}
                <div>
                  <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5 mb-1.5">
                    <Lock className="w-3.5 h-3.5 text-blue-400" />
                    <span>Confirm password</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showRegConfirmPassword ? 'text' : 'password'}
                      value={regConfirmPassword}
                      onChange={(e) => setRegConfirmPassword(e.target.value)}
                      placeholder="Confirm password"
                      className="w-full pl-3.5 pr-10 py-3 rounded-xl bg-[#12223c] border border-[#1f3861] text-white text-xs font-semibold placeholder:text-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                      required
                      id="reg-confirm-password-input"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegConfirmPassword(!showRegConfirmPassword)}
                      className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-200 cursor-pointer"
                      id="toggle-reg-conf-pwd-btn"
                    >
                      {showRegConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* 4. Invite code */}
                <div>
                  <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5 mb-1.5">
                    <Ticket className="w-3.5 h-3.5 text-blue-400" />
                    <span>Invite code</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={inviteCode}
                      onChange={(e) => !isInviteLocked && setInviteCode(e.target.value.trim())}
                      readOnly={isInviteLocked}
                      placeholder="Please enter the invitation code"
                      className={`w-full px-3.5 py-3 rounded-xl border text-xs font-mono font-bold focus:outline-none transition-all ${
                        isInviteLocked
                          ? 'bg-blue-950/40 border-blue-500/40 text-blue-300 cursor-not-allowed'
                          : 'bg-[#12223c] border-[#1f3861] text-white placeholder:font-sans placeholder:text-slate-500 focus:border-blue-500'
                      }`}
                      required
                      id="reg-invite-code-input"
                    />
                  </div>
                </div>

                {/* Privacy Agreement Checkbox */}
                <div className="flex items-center space-x-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setAgreedToPrivacy(!agreedToPrivacy)}
                    className={`w-4 h-4 rounded-full border flex items-center justify-center transition-all cursor-pointer shrink-0 ${
                      agreedToPrivacy
                        ? 'bg-blue-600 border-blue-500 text-white'
                        : 'border-[#1f3861] bg-[#12223c]'
                    }`}
                    id="privacy-agreement-checkbox"
                  >
                    {agreedToPrivacy && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                  </button>
                  <span className="text-xs text-slate-400 leading-tight">
                    I have read and agree{' '}
                    <span className="text-blue-400 font-semibold cursor-pointer">
                      【Privacy Agreement】
                    </span>
                  </span>
                </div>

                {/* Primary Button: Register */}
                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black rounded-full text-sm shadow-lg shadow-blue-500/25 active:scale-98 transition-all flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
                    id="btn-register-submit"
                  >
                    {loading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Registering...</span>
                      </>
                    ) : (
                      <span>Register</span>
                    )}
                  </button>
                </div>
              </form>

              {/* Bottom switch link */}
              <div className="text-center pt-2">
                <p className="text-xs text-slate-400">
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setMode('login');
                      setErrorMessage('');
                      setSuccessMessage('');
                    }}
                    className="text-blue-400 hover:text-blue-300 font-bold ml-1 cursor-pointer"
                    id="switch-to-login-link"
                  >
                    Log in
                  </button>
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
