import React from 'react';
import { X, Check } from 'lucide-react';
import { PREDEFINED_AVATARS, AvatarOption } from '../utils/avatars';

interface AvatarSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentAvatarId?: string;
  onSelectAvatar: (avatarId: string) => Promise<void>;
}

export const AvatarSelectorModal: React.FC<AvatarSelectorModalProps> = ({
  isOpen,
  onClose,
  currentAvatarId = 'avatar_1',
  onSelectAvatar
}) => {
  const [selectedId, setSelectedId] = React.useState(currentAvatarId);
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (currentAvatarId) {
      setSelectedId(currentAvatarId);
    }
  }, [currentAvatarId]);

  if (!isOpen) return null;

  const handleSave = async () => {
    setSaving(true);
    await onSelectAvatar(selectedId);
    setSaving(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl space-y-4 border border-slate-100">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div>
            <h3 className="text-base font-black text-slate-900">Select Profile Avatar</h3>
            <p className="text-[11px] text-slate-400">Choose from 10 exclusive member avatars</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600"
            id="close-avatar-modal-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-5 gap-3 py-1">
          {PREDEFINED_AVATARS.map((av: AvatarOption) => {
            const isSelected = selectedId === av.id;
            return (
              <button
                key={av.id}
                onClick={() => setSelectedId(av.id)}
                className={`relative flex flex-col items-center p-1.5 rounded-2xl transition-all ${
                  isSelected
                    ? 'ring-2 ring-[#2196f3] scale-105 bg-blue-50/60'
                    : 'hover:bg-slate-50 opacity-85 hover:opacity-100'
                }`}
                id={`avatar-opt-${av.id}`}
              >
                <div
                  className={`w-12 h-12 rounded-full overflow-hidden bg-slate-100 flex items-center justify-center shadow-md border-2 ${
                    isSelected ? 'border-[#2196f3]' : av.border
                  }`}
                >
                  {av.photoUrl ? (
                    <img
                      src={av.photoUrl}
                      alt={av.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.currentTarget as HTMLElement).style.display = 'none';
                      }}
                    />
                  ) : (
                    <span className="text-xl">{av.emoji || '👤'}</span>
                  )}
                </div>
                <span className="text-[9px] font-bold text-slate-700 truncate w-full text-center mt-1">
                  {av.name}
                </span>
                {isSelected && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#2196f3] text-white rounded-full flex items-center justify-center text-[10px] shadow-xs">
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <button
          onClick={handleSave}
          disabled={saving}
          className="w-full py-3 bg-[#2196f3] hover:bg-blue-600 active:scale-98 text-white font-black text-sm rounded-xl shadow-md transition-all disabled:opacity-50"
          id="confirm-avatar-btn"
        >
          {saving ? 'Saving Avatar...' : 'Set Selected Avatar'}
        </button>
      </div>
    </div>
  );
};
