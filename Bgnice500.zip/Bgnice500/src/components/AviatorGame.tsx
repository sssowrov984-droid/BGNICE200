import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  ArrowLeft,
  RefreshCw,
  Volume2,
  VolumeX,
  HelpCircle,
  Clock,
  Zap,
  TrendingUp,
  ShieldCheck,
  RotateCcw,
  ChevronDown,
  ChevronUp,
  Award,
  Flame,
  Check,
  Menu,
  X,
  Info,
  Sliders,
  Sparkles
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ref, get, set, update, push, onValue } from 'firebase/database';
import { rtdb } from '../lib/firebase';
import confetti from 'canvas-confetti';
import { AviatorBetRecord } from '../types';

interface AviatorGameProps {
  onBack: () => void;
  onDepositClick: () => void;
}

interface BetControlState {
  amount: number;
  mode: 'bet' | 'auto';
  isAutoCashout: boolean;
  autoMultiplier: number;
  betPlaced: boolean;
  cashedOut: boolean;
  cashedOutMultiplier: number;
  cashedOutAmount: number;
  activeBetId: string | null;
  queuedForNext?: boolean;
}

interface LiveBetEntry {
  id: string;
  user: string;
  bet: number;
  targetMultiplier: number;
  cashedOut: boolean;
  cashoutMultiplier?: number;
  winAmount?: number;
}

export const AviatorGame: React.FC<AviatorGameProps> = ({ onBack, onDepositClick }) => {
  const {
    user,
    setUser,
    refreshBalance,
    isRefreshingBalance,
    settings,
    fulfillBetTurnover,
    recordGameBet,
    updateGameBetStatus
  } = useApp();

  // Audio synthesis
  const [soundEnabled, setSoundEnabled] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const playChime = (freq = 880, duration = 0.3) => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        const AudioClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioClass) audioCtxRef.current = new AudioClass();
      }
      const ctx = audioCtxRef.current;
      if (ctx) {
        if (ctx.state === 'suspended') ctx.resume().catch(() => {});
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + duration);
      }
    } catch {}
  };

  const playCrashSound = () => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        const AudioClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioClass) audioCtxRef.current = new AudioClass();
      }
      const ctx = audioCtxRef.current;
      if (ctx) {
        if (ctx.state === 'suspended') ctx.resume().catch(() => {});
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.4);
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.4);
      }
    } catch {}
  };

  // Game Engine State
  const [gameState, setGameState] = useState<'waiting' | 'flying' | 'crashed'>('waiting');
  const [multiplier, setMultiplier] = useState<number>(1.0);
  const [crashPoint, setCrashPoint] = useState<number>(2.2);
  const [waitingCountdown, setWaitingCountdown] = useState<number>(5);
  const [roundId, setRoundId] = useState<string>(() => `AV-${Date.now().toString().slice(-6)}`);

  // Multiplier history chips
  const [historyChips, setHistoryChips] = useState<number[]>([
    1.24, 2.85, 1.08, 5.42, 1.95, 12.18, 3.12, 1.45, 1.15, 6.78, 1.82, 4.35
  ]);

  // Dual Bet Panels
  const [bet1, setBet1] = useState<BetControlState>({
    amount: 10,
    mode: 'bet',
    isAutoCashout: false,
    autoMultiplier: 2.0,
    betPlaced: false,
    cashedOut: false,
    cashedOutMultiplier: 0,
    cashedOutAmount: 0,
    activeBetId: null
  });

  const [bet2, setBet2] = useState<BetControlState>({
    amount: 20,
    mode: 'bet',
    isAutoCashout: false,
    autoMultiplier: 3.0,
    betPlaced: false,
    cashedOut: false,
    cashedOutMultiplier: 0,
    cashedOutAmount: 0,
    activeBetId: null
  });

  // Keep refs strictly in sync to eliminate any stale closure during animation loops
  const bet1Ref = useRef(bet1);
  const bet2Ref = useRef(bet2);
  useEffect(() => {
    bet1Ref.current = bet1;
  }, [bet1]);
  useEffect(() => {
    bet2Ref.current = bet2;
  }, [bet2]);

  // Top-right Cashout Win Notification Banner (replaces full-screen WinGo modal)
  const [cashoutNotification, setCashoutNotification] = useState<{
    amount: number;
    multiplier: number;
  } | null>(null);

  // Synchronous lock ref to prevent rapid double/multiple cashout clicks
  const isCashingOutRef = useRef<{ 1: boolean; 2: boolean }>({ 1: false, 2: false });

  // Simple clean text toast
  const [textToast, setTextToast] = useState<string | null>(null);
  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const showToast = (message: string) => {
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    setTextToast(message);
    toastTimeoutRef.current = setTimeout(() => {
      setTextToast(null);
    }, 2200);
  };

  // 3-Line System Menu State
  const [isSystemMenuOpen, setIsSystemMenuOpen] = useState<boolean>(false);
  const [isProvablyFairOpen, setIsProvablyFairOpen] = useState<boolean>(false);

  // Bottom Tabs
  const [activeTab, setActiveTab] = useState<'all' | 'my' | 'top'>('all');
  const [myBetsFilter, setMyBetsFilter] = useState<'all' | 'won' | 'lost'>('all');
  const [myBetsPage, setMyBetsPage] = useState<number>(1);
  const myBetsPageSize = 10;
  const [expandedBetId, setExpandedBetId] = useState<string | null>(null);

  // User Betting History from Firebase RTDB
  const [userAviatorBets, setUserAviatorBets] = useState<AviatorBetRecord[]>([]);

  // Rules Modal
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);

  // Live Simulated Bets
  const [liveBets, setLiveBets] = useState<LiveBetEntry[]>([]);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const flightStartTimeRef = useRef<number>(0);

  // Ensure scroll is at the top when entering Aviator
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
  }, []);

  // Listen to user's Aviator bets from Firebase
  useEffect(() => {
    if (!user?.uid) return;
    const betsRef = ref(rtdb, 'aviator_bets');
    const unsub = onValue(betsRef, (snap) => {
      if (snap.exists()) {
        const data = snap.val();
        const list: AviatorBetRecord[] = Object.entries(data)
          .map(([id, val]: [string, any]) => ({
            ...val,
            id: val.id || id
          }))
          .filter((b) => b.uid === user.uid && b.game === 'aviator')
          .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setUserAviatorBets(list);
      } else {
        setUserAviatorBets([]);
      }
    });

    return () => unsub();
  }, [user?.uid]);

  // Determine crash point - Checks Admin forced value or generates authentic 97% RTP distribution
  const determineCrashPoint = () => {
    const forced = settings?.gameControls?.aviatorCrash;
    if (typeof forced === 'number' && forced >= 1.01) {
      return Number(forced.toFixed(2));
    }

    const r = Math.random();
    if (r < 0.04) return 1.0; // 4% instant crash at 1.00x
    const raw = 0.98 / (1 - r);
    return Math.min(100.0, Math.max(1.01, Number(raw.toFixed(2))));
  };

  // Generate simulated live players with target multipliers
  const generateOtherPlayers = (): LiveBetEntry[] => {
    const names = [
      'Md***an', 'Ta***im', 'Sa***k', 'Ra***el', 'Al***in',
      'Bi***oy', 'Su***on', 'Ka***al', 'Fo***ad', 'Ha***an',
      'Sh***ik', 'Ra***ib', 'Ta***ir', 'Mo***on', 'An***ar',
      'Fa***im', 'Nu***ul', 'Ja***id', 'As***af', 'Ro***el',
      '017***82', '018***31', '019***54', '016***90', '013***18',
      '015***42', 'Ta***ur', 'Sh***on', 'Ab***ah', 'Im***an'
    ];
    return names.map((name, idx) => {
      const betAmounts = [20, 50, 100, 200, 300, 500, 1000, 1500, 2000];
      const bet = betAmounts[Math.floor(Math.random() * betAmounts.length)];
      // Realistic target cashout multipliers between 1.15x and 12x
      const rand = Math.random();
      const targetM =
        rand < 0.35
          ? 1.15 + Math.random() * 0.65
          : rand < 0.7
          ? 1.8 + Math.random() * 1.7
          : 3.5 + Math.random() * 7.5;
      return {
        id: `ply_${idx}_${Date.now()}`,
        user: name,
        bet,
        targetMultiplier: Number(targetM.toFixed(2)),
        cashedOut: false
      };
    });
  };

  // Top players of the day
  const topRecords = useMemo(() => [
    { user: 'Sh***ik', multiplier: 84.32, bet: 100, win: 8432, date: 'Today 14:22' },
    { user: 'Ra***ib', multiplier: 46.15, bet: 250, win: 11537.5, date: 'Today 13:40' },
    { user: 'Ta***ir', multiplier: 32.80, bet: 500, win: 16400, date: 'Today 12:15' },
    { user: 'Mo***on', multiplier: 24.50, bet: 150, win: 3675, date: 'Today 11:04' },
    { user: 'An***ar', multiplier: 19.82, bet: 300, win: 5946, date: 'Today 09:50' },
    { user: 'Fa***im', multiplier: 15.60, bet: 1000, win: 15600, date: 'Today 08:33' }
  ], []);

  // Main Loop
  useEffect(() => {
    if (gameState === 'waiting') {
      setWaitingCountdown(5);
      const countdownInterval = setInterval(() => {
        setWaitingCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(countdownInterval);
            // Launch flight - activate queued bets for current flight
            setBet1((b) => (b.betPlaced ? { ...b, queuedForNext: false } : b));
            setBet2((b) => (b.betPlaced ? { ...b, queuedForNext: false } : b));
            const nextCrash = determineCrashPoint();
            const nextRound = `AV-${Date.now().toString().slice(-6)}`;
            setRoundId(nextRound);
            setCrashPoint(nextCrash);
            setMultiplier(1.0);
            setGameState('flying');
            flightStartTimeRef.current = performance.now();
            setLiveBets(generateOtherPlayers());
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(countdownInterval);
    }

    if (gameState === 'flying') {
      const speedFactor = 0.065; // Classic Aviator realistic ascent

      const stepFlight = () => {
        const elapsedSec = (performance.now() - flightStartTimeRef.current) / 1000;
        const currentM = Math.exp(elapsedSec * speedFactor);

        if (currentM >= crashPoint) {
          // Flight crashed!
          setMultiplier(crashPoint);
          setGameState('crashed');
          setHistoryChips((prev) => [crashPoint, ...prev.slice(0, 19)]);
          playCrashSound();

          // Settle active bets as LOST (silently, NO toast or modal!)
          const settleLosses = async () => {
            isCashingOutRef.current = { 1: false, 2: false };

            const latestBet1 = bet1Ref.current;
            if (latestBet1.betPlaced && !latestBet1.cashedOut && !latestBet1.queuedForNext && !(latestBet1.cashedOutAmount > 0)) {
              if (latestBet1.activeBetId) {
                await update(ref(rtdb, `aviator_bets/${latestBet1.activeBetId}`), {
                  status: 'lost',
                  crashMultiplier: crashPoint,
                  winAmount: 0
                }).catch(() => {});
                await updateGameBetStatus(latestBet1.activeBetId, 'lost', 0, `Crashed @ ${crashPoint.toFixed(2)}x`, crashPoint);
              }
            }

            const latestBet2 = bet2Ref.current;
            if (latestBet2.betPlaced && !latestBet2.cashedOut && !latestBet2.queuedForNext && !(latestBet2.cashedOutAmount > 0)) {
              if (latestBet2.activeBetId) {
                await update(ref(rtdb, `aviator_bets/${latestBet2.activeBetId}`), {
                  status: 'lost',
                  crashMultiplier: crashPoint,
                  winAmount: 0
                }).catch(() => {});
                await updateGameBetStatus(latestBet2.activeBetId, 'lost', 0, `Crashed @ ${crashPoint.toFixed(2)}x`, crashPoint);
              }
            }

            // Reset bet panels for next round (preserve if user queued a bet for next round)
            setBet1((prev) => {
              if (prev.queuedForNext && prev.activeBetId) {
                return {
                  ...prev,
                  betPlaced: true,
                  queuedForNext: false,
                  cashedOut: false,
                  cashedOutMultiplier: 0,
                  cashedOutAmount: 0
                };
              }
              return {
                ...prev,
                betPlaced: false,
                queuedForNext: false,
                cashedOut: false,
                cashedOutMultiplier: 0,
                cashedOutAmount: 0,
                activeBetId: null
              };
            });
            setBet2((prev) => {
              if (prev.queuedForNext && prev.activeBetId) {
                return {
                  ...prev,
                  betPlaced: true,
                  queuedForNext: false,
                  cashedOut: false,
                  cashedOutMultiplier: 0,
                  cashedOutAmount: 0
                };
              }
              return {
                ...prev,
                betPlaced: false,
                queuedForNext: false,
                cashedOut: false,
                cashedOutMultiplier: 0,
                cashedOutAmount: 0,
                activeBetId: null
              };
            });
          };

          settleLosses();

          // Return to waiting after 2.5s
          setTimeout(() => {
            setGameState('waiting');
          }, 2500);
        } else {
          const roundedM = Number(currentM.toFixed(2));
          setMultiplier(roundedM);

          // Update live players dynamically cashing out in real time
          setLiveBets((prev) => {
            let changed = false;
            const updated = prev.map((p) => {
              if (!p.cashedOut && roundedM >= p.targetMultiplier && roundedM < crashPoint) {
                changed = true;
                return {
                  ...p,
                  cashedOut: true,
                  cashoutMultiplier: p.targetMultiplier,
                  winAmount: Number((p.bet * p.targetMultiplier).toFixed(2))
                };
              }
              return p;
            });
            return changed ? updated : prev;
          });

          // Check Auto Cashouts using latest ref state
          const autoBet1 = bet1Ref.current;
          if (
            autoBet1.betPlaced &&
            !autoBet1.cashedOut &&
            autoBet1.isAutoCashout &&
            currentM >= autoBet1.autoMultiplier
          ) {
            handleCashOut(1, currentM);
          }
          const autoBet2 = bet2Ref.current;
          if (
            autoBet2.betPlaced &&
            !autoBet2.cashedOut &&
            autoBet2.isAutoCashout &&
            currentM >= autoBet2.autoMultiplier
          ) {
            handleCashOut(2, currentM);
          }

          animationFrameRef.current = requestAnimationFrame(stepFlight);
        }
      };

      animationFrameRef.current = requestAnimationFrame(stepFlight);

      return () => {
        if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      };
    }
  }, [gameState, crashPoint, roundId]);

  // Place Bet
  const handlePlaceBet = async (betNum: 1 | 2) => {
    if (!user) return;

    const betState = betNum === 1 ? bet1 : bet2;
    if (betState.betPlaced) return;

    const amount = betState.amount;
    if (amount <= 0) return;
    if (user.balance < amount) {
      showToast('Insufficient balance!');
      return;
    }

    const isNextFlight = gameState === 'flying' || gameState === 'crashed';
    const newBetRef = push(ref(rtdb, 'aviator_bets'));
    const betId = newBetRef.key || `av_bet_${Date.now()}`;
    const currentBal = Number(user.balance || 0);
    const newBal = Number((currentBal - amount).toFixed(2));
    const curLoss = Number(user.totalLoss || 0);

    // 1. Instant local optimistic update (0 delay)
    isCashingOutRef.current[betNum] = false;
    setUser((prev) => (prev ? { ...prev, balance: newBal } : null));

    if (betNum === 1) {
      setBet1((prev) => ({
        ...prev,
        betPlaced: true,
        queuedForNext: isNextFlight,
        cashedOut: false,
        cashedOutMultiplier: 0,
        cashedOutAmount: 0,
        activeBetId: betId
      }));
    } else {
      setBet2((prev) => ({
        ...prev,
        betPlaced: true,
        queuedForNext: isNextFlight,
        cashedOut: false,
        cashedOutMultiplier: 0,
        cashedOutAmount: 0,
        activeBetId: betId
      }));
    }

    // 2. Background DB synchronization
    const newRecord: AviatorBetRecord = {
      id: betId,
      uid: user.uid,
      username: user.username || user.nickname || 'User',
      game: 'aviator',
      roundId,
      betPanel: betNum,
      amount,
      status: 'pending',
      createdAt: Date.now()
    };

    Promise.all([
      update(ref(rtdb, `users/${user.uid}`), {
        balance: newBal,
        totalLoss: curLoss + amount
      }),
      fulfillBetTurnover(user.uid, amount),
      set(newBetRef, newRecord),
      recordGameBet({
        betId,
        uid: user.uid,
        gameType: 'aviator',
        gameName: 'Aviator',
        selectType: 'multiplier',
        selectValue: betState.isAutoCashout ? `Auto: ${betState.autoMultiplier}x` : 'Manual Cashout',
        amount,
        totalAmount: amount,
        status: 'pending',
        periodId: roundId
      })
    ]).catch((err) => {
      console.error('Aviator bet placement async sync failed:', err);
    });
  };

  // Cancel Bet (Refunds balance and cancels pending bet anytime before flight takeoff or while queued)
  const handleCancelBet = async (betNum: 1 | 2) => {
    if (!user) return;
    const betState = betNum === 1 ? bet1 : bet2;
    if (!betState.betPlaced || betState.cashedOut) return;
    // Cannot cancel if plane is currently in active flight unless queued for next round
    if (gameState === 'flying' && !betState.queuedForNext) return;

    // Instant local optimistic update (0 delay)
    isCashingOutRef.current[betNum] = false;
    const refundAmount = betState.amount;
    const currentBal = Number(user.balance || 0);
    const newBal = Number((currentBal + refundAmount).toFixed(2));
    const curLoss = Math.max(0, Number(user.totalLoss || 0) - refundAmount);

    setUser((prev) => (prev ? { ...prev, balance: newBal } : null));

    if (betNum === 1) {
      setBet1((prev) => ({
        ...prev,
        betPlaced: false,
        queuedForNext: false,
        activeBetId: null
      }));
    } else {
      setBet2((prev) => ({
        ...prev,
        betPlaced: false,
        queuedForNext: false,
        activeBetId: null
      }));
    }

    showToast('Bet cancelled');

    // Background DB sync
    try {
      await update(ref(rtdb, `users/${user.uid}`), {
        balance: newBal,
        totalLoss: curLoss
      });

      if (betState.activeBetId) {
        await update(ref(rtdb, `aviator_bets/${betState.activeBetId}`), {
          status: 'cancelled'
        });
        await updateGameBetStatus(betState.activeBetId, 'cancelled');
      }

      refreshBalance(true);
    } catch (err) {
      console.error('Aviator cancel bet failed:', err);
    }
  };

  // Cash Out - strictly locked to single execution to prevent duplicate payouts
  const handleCashOut = async (betNum: 1 | 2, currentM: number) => {
    if (!user) return;
    // Synchronous ref check prevents multiple rapid clicks from adding money multiple times
    if (isCashingOutRef.current[betNum]) return;

    const betState = betNum === 1 ? bet1Ref.current : bet2Ref.current;
    if (!betState.betPlaced || betState.cashedOut) return;

    // Immediately lock synchronously
    isCashingOutRef.current[betNum] = true;

    const winAmount = Number((betState.amount * currentM).toFixed(2));

    // Immediately update UI State and ref synchronously so button reflects cashed out state immediately
    if (betNum === 1) {
      bet1Ref.current = {
        ...bet1Ref.current,
        cashedOut: true,
        cashedOutMultiplier: currentM,
        cashedOutAmount: winAmount
      };
      setBet1((prev) => ({
        ...prev,
        cashedOut: true,
        cashedOutMultiplier: currentM,
        cashedOutAmount: winAmount
      }));
    } else {
      bet2Ref.current = {
        ...bet2Ref.current,
        cashedOut: true,
        cashedOutMultiplier: currentM,
        cashedOutAmount: winAmount
      };
      setBet2((prev) => ({
        ...prev,
        cashedOut: true,
        cashedOutMultiplier: currentM,
        cashedOutAmount: winAmount
      }));
    }

    try {
      // 1. Credit balance in Firebase RTDB
      const curBal = Number(user.balance || 0);
      const newBal = Number((curBal + winAmount).toFixed(2));
      const totWon = Number((Number(user.totalWon || 0) + winAmount).toFixed(2));

      await update(ref(rtdb, `users/${user.uid}`), {
        balance: newBal,
        totalWon: totWon
      });

      // 2. Update bet record in aviator_bets & unified bets
      if (betState.activeBetId) {
        await update(ref(rtdb, `aviator_bets/${betState.activeBetId}`), {
          status: 'won',
          cashoutMultiplier: currentM,
          winAmount
        });
        await updateGameBetStatus(betState.activeBetId, 'won', winAmount, `${currentM.toFixed(2)}x`, currentM);
      }

      // 3. Audio & Confetti
      playChime(1050, 0.4);
      try {
        confetti({ particleCount: 60, spread: 65, origin: { y: 0.65 } });
      } catch {}

      refreshBalance(true);

      // 4. Display cashout win amount in top-right corner (NO modal or toast!)
      setCashoutNotification({
        amount: winAmount,
        multiplier: currentM
      });
      setTimeout(() => {
        setCashoutNotification(null);
      }, 4500);
    } catch (err) {
      console.error('Cashout error:', err);
    }
  };

  // Render Flight Canvas Animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = (canvas.width = canvas.parentElement?.clientWidth || 360);
    const h = (canvas.height = 240);

    ctx.clearRect(0, 0, w, h);

    // Subtle dark grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 35) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    if (gameState === 'flying') {
      const progress = Math.min(1.0, (multiplier - 1) / 12);
      const startX = 20;
      const startY = h - 20;
      const targetX = 30 + progress * (w - 70);
      const targetY = h - 30 - progress * (h - 70);

      // Red flight curve gradient
      const gradient = ctx.createLinearGradient(startX, startY, targetX, targetY);
      gradient.addColorStop(0, 'rgba(255, 59, 48, 0.15)');
      gradient.addColorStop(1, '#ff3b30');

      // Draw flight line
      ctx.beginPath();
      ctx.moveTo(startX, startY);
      ctx.quadraticCurveTo(startX + (targetX - startX) * 0.55, startY, targetX, targetY);
      ctx.strokeStyle = '#ff3b30';
      ctx.lineWidth = 4;
      ctx.stroke();

      // Draw shadow area below curve
      ctx.lineTo(targetX, startY);
      ctx.closePath();
      ctx.fillStyle = gradient;
      ctx.globalAlpha = 0.25;
      ctx.fill();
      ctx.globalAlpha = 1.0;

      // Draw Classic Red Airplane at target point
      ctx.save();
      ctx.translate(targetX, targetY);
      ctx.rotate(-0.25);

      // Fuselage (Red plane body)
      ctx.fillStyle = '#ff2e2e';
      ctx.beginPath();
      ctx.moveTo(20, 0);
      ctx.lineTo(-15, -9);
      ctx.lineTo(-9, 0);
      ctx.lineTo(-15, 9);
      ctx.closePath();
      ctx.fill();

      // Propeller spinner & wings
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(2, 0);
      ctx.lineTo(-8, -15);
      ctx.lineTo(-3, 0);
      ctx.closePath();
      ctx.fill();

      // Red tail fin
      ctx.fillStyle = '#b71c1c';
      ctx.beginPath();
      ctx.moveTo(-10, 0);
      ctx.lineTo(-16, -7);
      ctx.lineTo(-13, 0);
      ctx.closePath();
      ctx.fill();

      ctx.restore();
    }
  }, [gameState, multiplier]);

  // Multiplier Chip Badge Color
  const getChipBadgeColor = (val: number) => {
    if (val >= 10) return 'bg-[#eab308] text-black font-black';
    if (val >= 2.0) return 'bg-[#9333ea] text-white font-bold';
    return 'bg-[#2563eb] text-white font-semibold';
  };

  // Filtered bets for My Bets pagination
  const filteredMyBets = useMemo(() => {
    return userAviatorBets.filter((b) => {
      if (myBetsFilter === 'won') return b.status === 'won';
      if (myBetsFilter === 'lost') return b.status === 'lost';
      return true;
    });
  }, [userAviatorBets, myBetsFilter]);

  const totalMyBetsPages = Math.max(1, Math.ceil(filteredMyBets.length / myBetsPageSize));
  const paginatedMyBets = useMemo(() => {
    const start = (myBetsPage - 1) * myBetsPageSize;
    return filteredMyBets.slice(start, start + myBetsPageSize);
  }, [filteredMyBets, myBetsPage]);

  // Live community betting stats
  const activeRemainingPlayersCount = useMemo(() => {
    return liveBets.filter((p) => !p.cashedOut).length;
  }, [liveBets]);

  const liveTotalBetsAmount = useMemo(() => {
    return liveBets.reduce((acc, p) => acc + p.bet, 0);
  }, [liveBets]);

  const liveTotalWinAmount = useMemo(() => {
    return liveBets
      .filter((p) => p.cashedOut)
      .reduce((acc, p) => acc + (p.winAmount || 0), 0);
  }, [liveBets]);

  return (
    <div className="min-h-screen pb-20 text-white select-none bg-[#141518]">
      {/* Top Header */}
      <div className="sticky top-0 z-30 px-3 py-2 flex items-center justify-between border-b bg-[#1b1c21] border-white/10 shadow-md">
        <div className="flex items-center space-x-2">
          <button
            onClick={onBack}
            className="p-1 hover:bg-white/10 rounded-full active:scale-95 transition-transform"
            id="aviator-back-btn"
          >
            <ArrowLeft className="w-5 h-5 text-white stroke-[2.5]" />
          </button>
          <div className="flex items-center space-x-1.5">
            <span className="font-black text-lg tracking-wider text-[#ff3b30]">
              Aviator
            </span>
            <button
              onClick={() => setIsRulesOpen(true)}
              className="text-slate-400 hover:text-white p-0.5"
              title="Game Rules"
              id="aviator-rules-btn"
            >
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Balance, Audio, 3-Line Menu & Deposit */}
        <div className="flex items-center space-x-1.5">
          <div className="flex items-center space-x-1 px-2 py-1 rounded-full bg-black/40 border border-white/10 text-xs">
            <span className="font-bold text-emerald-400">
              ৳{Number(user?.balance || 0).toFixed(2)}
            </span>
            <button
              onClick={refreshBalance}
              className={`p-0.5 hover:bg-white/10 rounded-full ${
                isRefreshingBalance ? 'animate-spin' : ''
              }`}
              id="aviator-refresh-btn"
            >
              <RefreshCw className="w-3 h-3 text-slate-300" />
            </button>
          </div>

          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white"
            id="aviator-sound-toggle-btn"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-amber-300" />
            ) : (
              <VolumeX className="w-4 h-4 text-white/60" />
            )}
          </button>

          {/* 3-Line System Menu Button */}
          <button
            onClick={() => setIsSystemMenuOpen(true)}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white"
            title="System Menu"
            id="aviator-system-menu-btn"
          >
            <Menu className="w-4 h-4 text-slate-200" />
          </button>

          <button
            onClick={onDepositClick}
            className="shrink-0 px-3 py-1 rounded-full text-xs font-black bg-[#ff3b30] text-white hover:bg-[#e0342b] active:scale-95 shadow-xs transition-all"
            id="aviator-deposit-btn"
          >
            Deposit
          </button>
        </div>
      </div>

      {/* Multiplier History Chips Bar */}
      <div className="px-3 py-1.5 overflow-x-auto no-scrollbar flex items-center space-x-1.5 border-b border-white/5 bg-black/30">
        <span className="text-[10px] text-slate-400 uppercase font-bold shrink-0 mr-1">
          History:
        </span>
        {historyChips.map((chip, idx) => (
          <span
            key={idx}
            className={`text-[11px] px-2 py-0.5 rounded-full shrink-0 ${getChipBadgeColor(chip)}`}
          >
            {chip.toFixed(2)}x
          </span>
        ))}
      </div>

      {/* Flight Canvas & Multiplier Screen */}
      <div className="p-3">
        <div className="relative w-full h-60 rounded-3xl overflow-hidden flex flex-col items-center justify-center border bg-gradient-to-b from-[#1b1d24] via-[#16171c] to-[#0f1013] border-white/10 shadow-inner">
          {/* Canvas for Flight Path and Red Plane */}
          <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />

          {/* Top-Right Cashout Win Amount Banner (NO win/loss modal) */}
          {cashoutNotification && (
            <div className="absolute top-2.5 right-2.5 z-30 animate-in fade-in slide-in-from-top-2 duration-200 bg-emerald-600/95 border border-emerald-400 text-white px-3.5 py-1.5 rounded-xl shadow-2xl flex items-center space-x-2 backdrop-blur-xs">
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
              <div>
                <div className="text-[9px] uppercase font-bold text-emerald-100 tracking-wider">Cashed Out!</div>
                <div className="text-xs font-black">
                  +{cashoutNotification.amount.toFixed(2)} ৳{' '}
                  <span className="text-amber-300 font-mono font-bold">
                    ({cashoutNotification.multiplier.toFixed(2)}x)
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Center Floating Text Toast (for bet failed, insufficient balance) */}
          {textToast && (
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-40 bg-black/90 border border-red-500/60 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-2xl backdrop-blur-md animate-in fade-in zoom-in-90 duration-150 flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span>{textToast}</span>
            </div>
          )}

          {/* Central Multiplier Indicator */}
          {gameState === 'flying' && (
            <div className="relative z-10 text-center animate-in zoom-in-95 duration-150">
              <span className="font-black tracking-tight text-5xl md:text-6xl text-white drop-shadow-md">
                {multiplier.toFixed(2)}x
              </span>
            </div>
          )}

          {/* Crashed Notice */}
          {gameState === 'crashed' && (
            <div className="relative z-10 text-center space-y-1 animate-in zoom-in duration-200">
              <span className="text-xs font-black tracking-widest uppercase text-red-400 block">
                FLEW AWAY!
              </span>
              <span className="font-black text-5xl text-[#ff3b30] drop-shadow-lg">
                {multiplier.toFixed(2)}x
              </span>
            </div>
          )}

          {/* Waiting for Next Round Screen */}
          {gameState === 'waiting' && (
            <div className="relative z-10 text-center space-y-2.5">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                WAITING FOR NEXT ROUND
              </span>
              <div className="w-48 h-2 rounded-full bg-white/10 overflow-hidden mx-auto">
                <div
                  className="h-full bg-[#ff3b30] transition-all duration-1000 ease-linear"
                  style={{ width: `${((5 - waitingCountdown) / 5) * 100}%` }}
                />
              </div>
              <span className="text-sm font-black text-white font-mono">
                {waitingCountdown}s
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Dual Bet Controllers */}
      <div className="px-3 space-y-3">
        {/* BET PANEL 1 */}
        <div className="bg-[#1e2027] p-3 rounded-2xl border border-white/10 space-y-2.5 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
            <div className="flex items-center space-x-1.5">
              <button
                onClick={() => setBet1((prev) => ({ ...prev, mode: 'bet' }))}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  bet1.mode === 'bet' ? 'bg-[#ff3b30] text-white' : 'bg-black/30 text-slate-400'
                }`}
              >
                Bet
              </button>
              <button
                onClick={() => setBet1((prev) => ({ ...prev, mode: 'auto' }))}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  bet1.mode === 'auto' ? 'bg-[#ff3b30] text-white' : 'bg-black/30 text-slate-400'
                }`}
              >
                Auto
              </button>
            </div>

            {bet1.mode === 'auto' && (
              <div className="flex items-center space-x-1.5">
                <button
                  onClick={() =>
                    setBet1((prev) => ({ ...prev, isAutoCashout: !prev.isAutoCashout }))
                  }
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    bet1.isAutoCashout ? 'bg-emerald-500 text-slate-950' : 'bg-white/10 text-slate-300'
                  }`}
                >
                  Auto Cash Out
                </button>
                {bet1.isAutoCashout && (
                  <input
                    type="number"
                    step="0.1"
                    min="1.1"
                    value={bet1.autoMultiplier}
                    onChange={(e) =>
                      setBet1((prev) => ({
                        ...prev,
                        autoMultiplier: parseFloat(e.target.value) || 2.0
                      }))
                    }
                    className="w-14 px-1 py-0.5 rounded bg-black/40 border border-white/20 text-center text-[10px] text-white font-bold"
                  />
                )}
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2">
            {/* Amount stepper */}
            <div className="flex items-center space-x-1 bg-black/40 p-1 rounded-xl border border-white/10">
              <button
                onClick={() =>
                  setBet1((prev) => ({ ...prev, amount: Math.max(1, prev.amount - 10) }))
                }
                disabled={bet1.betPlaced && gameState === 'flying'}
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 font-bold text-white flex items-center justify-center active:scale-95 disabled:opacity-40"
              >
                -
              </button>
              <input
                type="number"
                value={bet1.amount}
                disabled={bet1.betPlaced && gameState === 'flying'}
                onChange={(e) =>
                  setBet1((prev) => ({
                    ...prev,
                    amount: Math.max(1, parseInt(e.target.value, 10) || 1)
                  }))
                }
                className="w-full text-center font-bold text-sm bg-transparent text-white focus:outline-none"
              />
              <button
                onClick={() => setBet1((prev) => ({ ...prev, amount: prev.amount + 10 }))}
                disabled={bet1.betPlaced && gameState === 'flying'}
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 font-bold text-white flex items-center justify-center active:scale-95 disabled:opacity-40"
              >
                +
              </button>
            </div>

            {/* Action button: RED when bet placed before flight or queued for next, Live Tk Cashout when flying */}
            {!bet1.betPlaced ? (
              <button
                onClick={() => handlePlaceBet(1)}
                className="py-2.5 px-3 rounded-xl font-black text-sm flex flex-col items-center justify-center text-white shadow-md active:scale-98 transition-all bg-[#10b981] hover:bg-[#059669] cursor-pointer"
                id="aviator-bet1-place-btn"
              >
                <span>{gameState === 'flying' ? 'BET (NEXT)' : 'BET'}</span>
                <span className="text-[10px] opacity-90 font-medium">
                  ৳{bet1.amount.toFixed(2)}
                </span>
              </button>
            ) : bet1.cashedOut ? (
              <div className="py-2 px-3 rounded-xl bg-emerald-600/30 border border-emerald-500 text-emerald-300 font-bold text-xs flex flex-col items-center justify-center">
                <span>CASHED OUT</span>
                <span className="text-[11px] font-black">
                  +{bet1.cashedOutAmount.toFixed(2)}৳
                </span>
              </div>
            ) : gameState === 'flying' && !bet1.queuedForNext ? (
              <button
                onClick={() => handleCashOut(1, multiplier)}
                className="py-2 px-3 rounded-xl bg-[#f59e0b] hover:bg-[#d97706] text-slate-950 font-black text-sm flex flex-col items-center justify-center shadow-lg active:scale-98 animate-pulse cursor-pointer"
                id="aviator-bet1-cashout-btn"
              >
                <span>CASH OUT</span>
                <span className="text-[11px] font-bold">
                  ৳{(bet1.amount * multiplier).toFixed(2)} ({multiplier.toFixed(2)}x)
                </span>
              </button>
            ) : gameState === 'flying' && bet1.queuedForNext ? (
              <div className="flex flex-col space-y-1">
                <button
                  disabled
                  className="py-1.5 px-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-black text-xs flex flex-col items-center justify-center cursor-not-allowed"
                >
                  <span className="tracking-wider text-[11px]">WAITING NEXT ROUND</span>
                  <span className="text-[10px] font-mono opacity-80">৳{bet1.amount.toFixed(2)}</span>
                </button>
                <button
                  onClick={() => handleCancelBet(1)}
                  className="text-[10px] text-red-400 hover:text-red-300 underline font-bold text-center active:scale-95"
                >
                  Cancel
                </button>
              </div>
            ) : (
              /* Bet placed waiting or countdown: RED CANCEL BUTTON with full refund */
              <button
                onClick={() => handleCancelBet(1)}
                className="py-2.5 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs flex flex-col items-center justify-center shadow-lg shadow-red-600/40 active:scale-95 transition-all cursor-pointer animate-pulse"
                id="aviator-bet1-cancel-btn"
                title="Click to cancel bet and refund balance"
              >
                <span className="tracking-wider">CANCEL</span>
                <span className="text-[10px] font-mono opacity-90">৳{bet1.amount.toFixed(2)} (REFUND)</span>
              </button>
            )}
          </div>

          {/* Quick presets */}
          <div className="flex space-x-1.5">
            {[10, 50, 100, 500].map((preset) => (
              <button
                key={preset}
                onClick={() => setBet1((prev) => ({ ...prev, amount: preset }))}
                disabled={bet1.betPlaced && gameState === 'flying'}
                className="flex-1 py-1 rounded bg-black/30 hover:bg-white/10 text-[10px] font-bold text-slate-300 transition-colors"
              >
                +{preset}
              </button>
            ))}
          </div>
        </div>

        {/* BET PANEL 2 */}
        <div className="bg-[#1e2027] p-3 rounded-2xl border border-white/10 space-y-2.5 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
            <div className="flex items-center space-x-1.5">
              <button
                onClick={() => setBet2((prev) => ({ ...prev, mode: 'bet' }))}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  bet2.mode === 'bet' ? 'bg-[#ff3b30] text-white' : 'bg-black/30 text-slate-400'
                }`}
              >
                Bet
              </button>
              <button
                onClick={() => setBet2((prev) => ({ ...prev, mode: 'auto' }))}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  bet2.mode === 'auto' ? 'bg-[#ff3b30] text-white' : 'bg-black/30 text-slate-400'
                }`}
              >
                Auto
              </button>
            </div>

            {bet2.mode === 'auto' && (
              <div className="flex items-center space-x-1.5">
                <button
                  onClick={() =>
                    setBet2((prev) => ({ ...prev, isAutoCashout: !prev.isAutoCashout }))
                  }
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    bet2.isAutoCashout ? 'bg-emerald-500 text-slate-950' : 'bg-white/10 text-slate-300'
                  }`}
                >
                  Auto Cash Out
                </button>
                {bet2.isAutoCashout && (
                  <input
                    type="number"
                    step="0.1"
                    min="1.1"
                    value={bet2.autoMultiplier}
                    onChange={(e) =>
                      setBet2((prev) => ({
                        ...prev,
                        autoMultiplier: parseFloat(e.target.value) || 3.0
                      }))
                    }
                    className="w-14 px-1 py-0.5 rounded bg-black/40 border border-white/20 text-center text-[10px] text-white font-bold"
                  />
                )}
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center space-x-1 bg-black/40 p-1 rounded-xl border border-white/10">
              <button
                onClick={() =>
                  setBet2((prev) => ({ ...prev, amount: Math.max(1, prev.amount - 10) }))
                }
                disabled={bet2.betPlaced && gameState === 'flying'}
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 font-bold text-white flex items-center justify-center active:scale-95 disabled:opacity-40"
              >
                -
              </button>
              <input
                type="number"
                value={bet2.amount}
                disabled={bet2.betPlaced && gameState === 'flying'}
                onChange={(e) =>
                  setBet2((prev) => ({
                    ...prev,
                    amount: Math.max(1, parseInt(e.target.value, 10) || 1)
                  }))
                }
                className="w-full text-center font-bold text-sm bg-transparent text-white focus:outline-none"
              />
              <button
                onClick={() => setBet2((prev) => ({ ...prev, amount: prev.amount + 10 }))}
                disabled={bet2.betPlaced && gameState === 'flying'}
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 font-bold text-white flex items-center justify-center active:scale-95 disabled:opacity-40"
              >
                +
              </button>
            </div>

            {/* Action button 2: RED when bet placed before flight or queued for next, Live Tk Cashout when flying */}
            {!bet2.betPlaced ? (
              <button
                onClick={() => handlePlaceBet(2)}
                className="py-2.5 px-3 rounded-xl font-black text-sm flex flex-col items-center justify-center text-white shadow-md active:scale-98 transition-all bg-[#10b981] hover:bg-[#059669] cursor-pointer"
                id="aviator-bet2-place-btn"
              >
                <span>{gameState === 'flying' ? 'BET (NEXT)' : 'BET'}</span>
                <span className="text-[10px] opacity-90 font-medium">
                  ৳{bet2.amount.toFixed(2)}
                </span>
              </button>
            ) : bet2.cashedOut ? (
              <div className="py-2 px-3 rounded-xl bg-emerald-600/30 border border-emerald-500 text-emerald-300 font-bold text-xs flex flex-col items-center justify-center">
                <span>CASHED OUT</span>
                <span className="text-[11px] font-black">
                  +{bet2.cashedOutAmount.toFixed(2)}৳
                </span>
              </div>
            ) : gameState === 'flying' && !bet2.queuedForNext ? (
              <button
                onClick={() => handleCashOut(2, multiplier)}
                className="py-2 px-3 rounded-xl bg-[#f59e0b] hover:bg-[#d97706] text-slate-950 font-black text-sm flex flex-col items-center justify-center shadow-lg active:scale-98 animate-pulse cursor-pointer"
                id="aviator-bet2-cashout-btn"
              >
                <span>CASH OUT</span>
                <span className="text-[11px] font-bold">
                  ৳{(bet2.amount * multiplier).toFixed(2)} ({multiplier.toFixed(2)}x)
                </span>
              </button>
            ) : gameState === 'flying' && bet2.queuedForNext ? (
              <div className="flex flex-col space-y-1">
                <button
                  disabled
                  className="py-1.5 px-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-black text-xs flex flex-col items-center justify-center cursor-not-allowed"
                >
                  <span className="tracking-wider text-[11px]">WAITING NEXT ROUND</span>
                  <span className="text-[10px] font-mono opacity-80">৳{bet2.amount.toFixed(2)}</span>
                </button>
                <button
                  onClick={() => handleCancelBet(2)}
                  className="text-[10px] text-red-400 hover:text-red-300 underline font-bold text-center active:scale-95"
                >
                  Cancel
                </button>
              </div>
            ) : (
              /* Bet placed waiting or countdown: RED CANCEL BUTTON with full refund */
              <button
                onClick={() => handleCancelBet(2)}
                className="py-2.5 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs flex flex-col items-center justify-center shadow-lg shadow-red-600/40 active:scale-95 transition-all cursor-pointer animate-pulse"
                id="aviator-bet2-cancel-btn"
                title="Click to cancel bet and refund balance"
              >
                <span className="tracking-wider">CANCEL</span>
                <span className="text-[10px] font-mono opacity-90">৳{bet2.amount.toFixed(2)} (REFUND)</span>
              </button>
            )}
          </div>

          <div className="flex space-x-1.5">
            {[20, 100, 200, 1000].map((preset) => (
              <button
                key={preset}
                onClick={() => setBet2((prev) => ({ ...prev, amount: preset }))}
                disabled={bet2.betPlaced && gameState === 'flying'}
                className="flex-1 py-1 rounded bg-black/30 hover:bg-white/10 text-[10px] font-bold text-slate-300 transition-colors"
              >
                +{preset}
              </button>
            ))}
          </div>
        </div>

        {/* Live Players / WinGo-style Bet History / Top Multipliers */}
        <div className="bg-[#1e2027] rounded-2xl border border-white/10 overflow-hidden text-xs shadow-sm">
          {/* Main Tabs */}
          <div className="flex border-b border-white/10 bg-black/30">
            {(['all', 'my', 'top'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => {
                  setActiveTab(tab);
                  setMyBetsPage(1);
                }}
                className={`flex-1 py-2.5 font-bold uppercase tracking-wider transition-colors ${
                  activeTab === tab
                    ? 'text-[#ff3b30] border-b-2 border-[#ff3b30] bg-white/5'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab === 'all' ? 'All Bets' : tab === 'my' ? 'My Bets' : 'Top'}
              </button>
            ))}
          </div>

          {/* TAB 1: ALL BETS (Live community betting with live player count, total bets, total won) */}
          {activeTab === 'all' && (
            <div>
              {/* Live Status Header */}
              <div className="px-3 py-2 bg-black/60 border-b border-white/5 flex items-center justify-between text-[11px]">
                <div className="flex items-center space-x-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="font-bold text-slate-300">
                    <span className="font-mono text-emerald-400 font-black">{activeRemainingPlayersCount}</span> Active
                  </span>
                </div>
                <div className="text-slate-400 text-[10px]">
                  Total Bets: <span className="font-mono font-bold text-white">৳{liveTotalBetsAmount.toLocaleString()}</span>
                </div>
                <div className="text-amber-400 font-bold text-[10px]">
                  Won: <span className="font-mono font-black text-amber-300">৳{liveTotalWinAmount.toFixed(2)}</span>
                </div>
              </div>

              {/* Table Column Headers */}
              <div className="grid grid-cols-4 px-3 py-1.5 bg-black/40 text-[10px] font-bold text-slate-400 border-b border-white/5 uppercase">
                <span>User</span>
                <span>Bet</span>
                <span className="text-center">Multiplier</span>
                <span className="text-right">Cash Out</span>
              </div>

              {/* Player Rows */}
              <div className="divide-y divide-white/5 max-h-72 overflow-y-auto">
                {liveBets.map((b) => (
                  <div
                    key={b.id}
                    className={`grid grid-cols-4 px-3 py-2 items-center text-xs font-mono transition-colors ${
                      b.cashedOut ? 'bg-emerald-950/20' : ''
                    }`}
                  >
                    <span className="text-slate-300 font-sans text-[11px] truncate">{b.user}</span>
                    <span className="text-slate-300 font-bold">৳{b.bet}</span>
                    <div className="text-center">
                      {b.cashedOut ? (
                        <span className="inline-block px-1.5 py-0.2 rounded text-[10px] font-bold bg-[#9333ea]/30 border border-purple-500/40 text-purple-300">
                          {b.cashoutMultiplier?.toFixed(2)}x
                        </span>
                      ) : (
                        <span className="text-slate-600">-</span>
                      )}
                    </div>
                    <div className="text-right">
                      {b.cashedOut ? (
                        <span className="text-emerald-400 font-bold text-[11px]">
                          +৳{b.winAmount?.toFixed(2)}
                        </span>
                      ) : gameState === 'crashed' ? (
                        <span className="text-red-500 text-[10px] font-sans font-bold">Crashed</span>
                      ) : (
                        <span className="text-slate-600">-</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: MY BETS (WinGo-style Bet History with Success / Failed badges, Accordion, & Pagination) */}
          {activeTab === 'my' && (
            <div>
              {paginatedMyBets.length === 0 ? (
                <div className="py-10 text-center text-slate-500 font-medium">
                  No betting history found
                </div>
              ) : (
                <div className="divide-y divide-white/5">
                  {paginatedMyBets.map((b) => {
                    const isExpanded = expandedBetId === b.id;
                    const isWon = b.status === 'won';
                    const isLost = b.status === 'lost';
                    const multDisplay = b.cashoutMultiplier
                      ? `${b.cashoutMultiplier.toFixed(2)}x`
                      : b.crashMultiplier
                      ? `${b.crashMultiplier.toFixed(2)}x`
                      : '-';

                    return (
                      <div key={b.id} className="transition-colors hover:bg-white/5">
                        <div
                          onClick={() => setExpandedBetId(isExpanded ? null : b.id)}
                          className="px-3 py-2.5 flex items-center justify-between cursor-pointer select-none"
                        >
                          <div className="space-y-0.5">
                            <div className="flex items-center space-x-1.5">
                              <span className="font-bold text-white">Aviator</span>
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-white/10 font-mono text-slate-300">
                                {b.roundId}
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400">
                              {new Date(b.createdAt).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                                second: '2-digit'
                              })}
                            </div>
                          </div>

                          {/* Bet Amount, Multiplier, and Win Amount */}
                          <div className="text-right flex items-center space-x-2">
                            <div className="text-right space-y-0.5">
                              <div className="flex items-center justify-end space-x-2">
                                <span className="text-[11px] text-slate-300">
                                  Bet: <strong className="font-bold text-white font-mono">৳{b.amount.toFixed(2)}</strong>
                                </span>
                                <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                                  {multDisplay}
                                </span>
                              </div>
                              <div className="text-xs font-mono font-bold">
                                {isWon ? (
                                  <span className="text-emerald-400">
                                    Win: +৳{(b.winAmount || 0).toFixed(2)}
                                  </span>
                                ) : isLost ? (
                                  <span className="text-slate-400">
                                    Win: ৳0.00
                                  </span>
                                ) : (
                                  <span className="text-amber-400">
                                    In Flight
                                  </span>
                                )}
                              </div>
                            </div>
                            {isExpanded ? (
                              <ChevronUp className="w-4 h-4 text-slate-400" />
                            ) : (
                              <ChevronDown className="w-4 h-4 text-slate-400" />
                            )}
                          </div>
                        </div>

                        {/* Accordion Expanded Order Detail Drawer */}
                        {isExpanded && (
                          <div className="px-3.5 pb-3 pt-1 bg-black/40 border-t border-white/5 text-[11px]">
                            <div className="bg-[#242731] rounded-xl p-3 border border-white/10 space-y-1.5">
                              <div className="font-bold text-white text-xs pb-1 border-b border-white/10 flex items-center justify-between">
                                <span>Order Details</span>
                                <span className="text-[10px] text-slate-400 font-mono">
                                  {b.id}
                                </span>
                              </div>
                              <div className="grid grid-cols-2 gap-y-1 text-slate-300">
                                <div className="text-slate-400">Game:</div>
                                <div className="font-semibold text-right text-white">
                                  Aviator
                                </div>
                                <div className="text-slate-400">Round ID:</div>
                                <div className="font-mono text-right text-slate-300">
                                  {b.roundId}
                                </div>
                                <div className="text-slate-400">Bet Panel:</div>
                                <div className="font-medium text-right text-slate-300">
                                  Panel {b.betPanel}
                                </div>
                                <div className="text-slate-400">Bet Amount:</div>
                                <div className="font-bold text-right text-white font-mono">
                                  ৳{b.amount.toFixed(2)}
                                </div>
                                <div className="text-slate-400">Multiplier:</div>
                                <div className="font-bold text-right text-amber-400 font-mono">
                                  {multDisplay}
                                </div>
                                <div className="text-slate-400">Win Amount:</div>
                                <div className="font-bold text-right font-mono">
                                  {isWon ? (
                                    <span className="text-emerald-400">
                                      +৳{(b.winAmount || 0).toFixed(2)}
                                    </span>
                                  ) : isLost ? (
                                    <span className="text-slate-400">
                                      ৳0.00
                                    </span>
                                  ) : (
                                    <span className="text-amber-400">Waiting for Draw</span>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {/* WinGo-style Pagination Bar */}
              {filteredMyBets.length > 0 && (
                <div className="flex items-center justify-between px-3 py-2.5 bg-black/40 border-t border-white/5 text-xs">
                  <span className="text-slate-400 font-medium text-[11px]">
                    Showing{' '}
                    {Math.min(filteredMyBets.length, (myBetsPage - 1) * myBetsPageSize + 1)} -{' '}
                    {Math.min(filteredMyBets.length, myBetsPage * myBetsPageSize)} of{' '}
                    {filteredMyBets.length}
                  </span>
                  <div className="flex items-center space-x-1.5">
                    <button
                      disabled={myBetsPage <= 1}
                      onClick={() => setMyBetsPage((p) => Math.max(1, p - 1))}
                      className="px-2.5 py-1 rounded-lg bg-white/10 border border-white/10 text-white font-bold disabled:opacity-30 hover:bg-white/20 active:scale-95 transition-all text-xs"
                      id="aviator-mybets-prev-btn"
                    >
                      &lt; Prev
                    </button>
                    <span className="px-2 font-bold text-slate-300 text-xs">
                      {myBetsPage} / {totalMyBetsPages}
                    </span>
                    <button
                      disabled={myBetsPage >= totalMyBetsPages}
                      onClick={() => setMyBetsPage((p) => p + 1)}
                      className="px-3 py-1 rounded-lg bg-[#ff3b30] text-white font-bold disabled:opacity-30 hover:bg-red-600 active:scale-95 shadow-xs transition-all text-xs"
                      id="aviator-mybets-next-btn"
                    >
                      Next &gt;
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: TOP MULTIPLIERS */}
          {activeTab === 'top' && (
            <div className="divide-y divide-white/5 max-h-72 overflow-y-auto">
              <div className="px-3 py-2 bg-black/40 flex items-center justify-between text-[11px] font-bold text-slate-400">
                <span>Player</span>
                <span>Multiplier</span>
                <span>Win Amount</span>
              </div>
              {topRecords.map((t, idx) => (
                <div
                  key={idx}
                  className="px-3 py-2.5 flex items-center justify-between font-mono hover:bg-white/5"
                >
                  <div className="flex items-center space-x-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center text-[10px]">
                      {idx + 1}
                    </span>
                    <span className="text-slate-200 font-sans">{t.user}</span>
                  </div>
                  <span className="text-amber-400 font-bold">{t.multiplier.toFixed(2)}x</span>
                  <span className="text-emerald-400 font-bold">৳{t.win.toLocaleString()}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 3-Line System Menu Drawer */}
      {isSystemMenuOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex justify-end animate-in fade-in">
          <div className="bg-[#1b1c21] w-72 h-full p-4 flex flex-col justify-between border-l border-white/10 shadow-2xl animate-in slide-in-from-right duration-200">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div className="flex items-center space-x-2">
                  <Sliders className="w-5 h-5 text-[#ff3b30]" />
                  <span className="font-black text-sm text-white uppercase tracking-wider">
                    Game Settings
                  </span>
                </div>
                <button
                  onClick={() => setIsSystemMenuOpen(false)}
                  className="p-1 hover:bg-white/10 rounded-full text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Sound Toggle */}
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-black/30 border border-white/5">
                <div className="flex items-center space-x-2">
                  {soundEnabled ? (
                    <Volume2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <VolumeX className="w-4 h-4 text-slate-400" />
                  )}
                  <span className="text-xs font-bold text-slate-200">Sound Effects</span>
                </div>
                <button
                  onClick={() => setSoundEnabled(!soundEnabled)}
                  className={`w-10 h-5 rounded-full transition-colors relative p-0.5 ${
                    soundEnabled ? 'bg-emerald-500' : 'bg-slate-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white transition-transform ${
                      soundEnabled ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Provably Fair */}
              <button
                onClick={() => {
                  setIsSystemMenuOpen(false);
                  setIsProvablyFairOpen(true);
                }}
                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-black/30 hover:bg-white/5 border border-white/5 text-xs font-bold text-slate-200 transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  <span>Provably Fair</span>
                </div>
                <span className="text-[10px] text-cyan-400 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-800/40">
                  Verified
                </span>
              </button>

              {/* Game Rules */}
              <button
                onClick={() => {
                  setIsSystemMenuOpen(false);
                  setIsRulesOpen(true);
                }}
                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-black/30 hover:bg-white/5 border border-white/5 text-xs font-bold text-slate-200 transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <HelpCircle className="w-4 h-4 text-amber-400" />
                  <span>How to Play / Rules</span>
                </div>
                <span className="text-[10px] text-slate-400">&gt;</span>
              </button>

              {/* Game Limits */}
              <div className="p-3 rounded-xl bg-black/30 border border-white/5 space-y-2 text-[11px]">
                <div className="text-slate-400 uppercase font-bold text-[10px] tracking-wider">
                  Game Limits
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Min Bet:</span>
                  <span className="font-mono font-bold text-white">৳10.00</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Max Bet:</span>
                  <span className="font-mono font-bold text-white">৳10,000.00</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Max Multiplier:</span>
                  <span className="font-mono font-bold text-amber-300">100.00x</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>RTP:</span>
                  <span className="font-mono font-bold text-emerald-400">97.00%</span>
                </div>
              </div>
            </div>

            <div className="text-center text-[10px] text-slate-500 pt-3 border-t border-white/10 font-mono">
              Aviator v2.4.0 • Trade BD Certified
            </div>
          </div>
        </div>
      )}

      {/* Provably Fair Modal */}
      {isProvablyFairOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-[#1e2027] rounded-3xl max-w-sm w-full p-5 space-y-3.5 shadow-2xl border border-white/10">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-bold text-white text-base flex items-center space-x-2">
                <ShieldCheck className="w-5 h-5 text-cyan-400" />
                <span>Provably Fair</span>
              </h3>
              <button
                onClick={() => setIsProvablyFairOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="text-xs text-slate-300 space-y-2.5">
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Every game round result is mathematically determined before flight takeoff and is 100% immune to manipulation.
              </p>
              <div className="p-2.5 rounded-xl bg-black/50 border border-white/5 space-y-1.5 font-mono text-[10px]">
                <div className="text-slate-400 font-sans font-bold">Current Round Hash:</div>
                <div className="break-all text-cyan-300 font-bold">
                  {roundId.replace('AV-', '0x8f2d') + 'c94f56a7e02b189d44cf12'}
                </div>
                <div className="text-slate-400 font-sans font-bold pt-1">Server Seed (Active):</div>
                <div className="break-all text-slate-300">
                  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsProvablyFairOpen(false)}
              className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-xl text-xs transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Rules Modal */}
      {isRulesOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-[#1e2027] rounded-3xl max-w-sm w-full p-5 space-y-4 shadow-2xl border border-white/10">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-bold text-white text-base flex items-center space-x-2">
                <ShieldCheck className="w-5 h-5 text-[#ff3b30]" />
                <span>Aviator Rules</span>
              </h3>
              <button
                onClick={() => setIsRulesOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="text-xs text-slate-300 space-y-2.5 leading-relaxed max-h-72 overflow-y-auto">
              <p>
                <strong>1. Objective:</strong> Place one or two bets before the plane takes off.
                Watch the multiplier rise from 1.00x upwards!
              </p>
              <p>
                <strong>2. Cash Out:</strong> You must click <em>Cash Out</em> before the plane
                flies away. If you cash out in time, you win your bet multiplied by the flight
                multiplier!
              </p>
              <p>
                <strong>3. Crash:</strong> If the plane flies away before you cash out, your bet
                is lost.
              </p>
              <p>
                <strong>4. Auto Cash Out:</strong> Set a target multiplier (e.g. 2.00x) and the
                system will automatically cash out for you when the plane reaches it.
              </p>
            </div>
            <button
              onClick={() => setIsRulesOpen(false)}
              className="w-full py-2.5 bg-[#ff3b30] text-white font-bold rounded-xl text-xs"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
