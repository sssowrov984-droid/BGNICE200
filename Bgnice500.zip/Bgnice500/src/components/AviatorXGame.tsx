import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  ArrowLeft,
  RefreshCw,
  Volume2,
  VolumeX,
  HelpCircle,
  Zap,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Cpu,
  Radio,
  Sparkles,
  Menu,
  X,
  Sliders
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ref, get, set, update, push, onValue } from 'firebase/database';
import { rtdb } from '../lib/firebase';
import confetti from 'canvas-confetti';
import { AviatorBetRecord } from '../types';

interface AviatorXGameProps {
  onBack: () => void;
  onDepositClick: () => void;
}

interface BetControlState {
  amount: number;
  mode: 'bet' | 'auto';
  isAutoCashout: boolean;
  autoMultiplier: number;
  betPlaced: boolean;
  cashedOut: boolean;
  cashedOutMultiplier: number;
  cashedOutAmount: number;
  activeBetId: string | null;
  queuedForNext?: boolean;
}

interface LiveBetEntry {
  id: string;
  user: string;
  bet: number;
  cashedOut: boolean;
  cashoutMultiplier?: number;
  winAmount?: number;
  targetMultiplier: number;
}

export const AviatorXGame: React.FC<AviatorXGameProps> = ({ onBack, onDepositClick }) => {
  const {
    user,
    setUser,
    refreshBalance,
    isRefreshingBalance,
    settings,
    fulfillBetTurnover,
    recordGameBet,
    updateGameBetStatus
  } = useApp();

  // Audio synthesis
  const [soundEnabled, setSoundEnabled] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Synchronous lock ref to prevent rapid double/multiple cashout clicks
  const isCashingOutRef = useRef<{ 1: boolean; 2: boolean }>({ 1: false, 2: false });

  const playChime = (freq = 1100, duration = 0.35) => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        const AudioClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioClass) audioCtxRef.current = new AudioClass();
      }
      const ctx = audioCtxRef.current;
      if (ctx) {
        if (ctx.state === 'suspended') ctx.resume().catch(() => {});
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + duration);
      }
    } catch {}
  };

  const playCrashSound = () => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        const AudioClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioClass) audioCtxRef.current = new AudioClass();
      }
      const ctx = audioCtxRef.current;
      if (ctx) {
        if (ctx.state === 'suspended') ctx.resume().catch(() => {});
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(320, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(50, ctx.currentTime + 0.5);
        gain.gain.setValueAtTime(0.25, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
      }
    } catch {}
  };

  // Game Engine State
  const [gameState, setGameState] = useState<'waiting' | 'flying' | 'crashed'>('waiting');
  const [multiplier, setMultiplier] = useState<number>(1.0);
  const [crashPoint, setCrashPoint] = useState<number>(2.5);
  const [waitingCountdown, setWaitingCountdown] = useState<number>(5);
  const [roundId, setRoundId] = useState<string>(() => `AVX-${Date.now().toString().slice(-6)}`);

  // Top-right notification banner for wins (replaces win/loss toasts)
  const [cashoutNotification, setCashoutNotification] = useState<{
    amount: number;
    multiplier: number;
  } | null>(null);

  // Floating text toast (for bet failed, insufficient balance)
  const [textToast, setTextToast] = useState<string | null>(null);
  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const showToast = (msg: string) => {
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    setTextToast(msg);
    toastTimeoutRef.current = setTimeout(() => {
      setTextToast(null);
    }, 2200);
  };

  // 3-Line System Menu State
  const [isSystemMenuOpen, setIsSystemMenuOpen] = useState<boolean>(false);
  const [isProvablyFairOpen, setIsProvablyFairOpen] = useState<boolean>(false);

  // History Chips
  const [historyChips, setHistoryChips] = useState<number[]>([
    2.14, 1.42, 14.85, 3.20, 1.12, 8.45, 1.98, 22.40, 4.15, 1.30, 7.60, 2.80
  ]);

  // Dual Bet Panels
  const [bet1, setBet1] = useState<BetControlState>({
    amount: 20,
    mode: 'bet',
    isAutoCashout: false,
    autoMultiplier: 2.0,
    betPlaced: false,
    cashedOut: false,
    cashedOutMultiplier: 0,
    cashedOutAmount: 0,
    activeBetId: null
  });

  const [bet2, setBet2] = useState<BetControlState>({
    amount: 50,
    mode: 'bet',
    isAutoCashout: false,
    autoMultiplier: 5.0,
    betPlaced: false,
    cashedOut: false,
    cashedOutMultiplier: 0,
    cashedOutAmount: 0,
    activeBetId: null
  });

  // Keep refs strictly in sync to eliminate any stale closure during animation loops
  const bet1Ref = useRef(bet1);
  const bet2Ref = useRef(bet2);
  useEffect(() => {
    bet1Ref.current = bet1;
  }, [bet1]);
  useEffect(() => {
    bet2Ref.current = bet2;
  }, [bet2]);

  // Bottom Tabs
  const [activeTab, setActiveTab] = useState<'all' | 'my' | 'top'>('all');
  const [myBetsFilter, setMyBetsFilter] = useState<'all' | 'won' | 'lost'>('all');
  const [myBetsPage, setMyBetsPage] = useState<number>(1);
  const myBetsPageSize = 10;
  const [expandedBetId, setExpandedBetId] = useState<string | null>(null);

  // User Betting History from Firebase RTDB (aviator_x_bets)
  const [userAviatorXBets, setUserAviatorXBets] = useState<AviatorBetRecord[]>([]);

  // Rules Modal
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);

  // Simulated Live Bets
  const [liveBets, setLiveBets] = useState<LiveBetEntry[]>([]);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const flightStartTimeRef = useRef<number>(0);

  // Real-time synchronization of Aviator X Bets
  // Ensure scroll is at the top when entering Aviator X
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
  }, []);

  useEffect(() => {
    if (!user?.uid) return;
    const betsRef = ref(rtdb, 'aviator_x_bets');
    const unsub = onValue(betsRef, (snap) => {
      if (snap.exists()) {
        const data = snap.val();
        const list: AviatorBetRecord[] = Object.entries(data)
          .map(([id, val]: [string, any]) => ({
            ...val,
            id: val.id || id
          }))
          .filter((b) => b.uid === user.uid && b.game === 'aviatorX')
          .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setUserAviatorXBets(list);
      } else {
        setUserAviatorXBets([]);
      }
    });

    return () => unsub();
  }, [user?.uid]);

  // Crash Point Determination - Checks Admin forced value or generates high-octane 97% RTP curve
  const determineCrashPoint = () => {
    const forced = settings?.gameControls?.aviatorXCrash;
    if (typeof forced === 'number' && forced >= 1.01) {
      return Number(forced.toFixed(2));
    }

    const r = Math.random();
    if (r < 0.035) return 1.0;
    const raw = 0.98 / (1 - r);
    return Math.min(150.0, Math.max(1.01, Number(raw.toFixed(2))));
  };

  const generateOtherPlayers = (): LiveBetEntry[] => {
    const names = [
      'Cy***er', 'Ne***on', 'Vo***ex', 'Xe***on', 'Qu***nt',
      'Hy***ra', 'Bl***ze', 'Ti***an', 'St***rm', 'Ph***nx',
      'As***ro', 'Ze***th', 'Lu***ar', 'Co***sm', 'Ra***er'
    ];
    return names.map((name, i) => {
      const bet = [20, 50, 100, 200, 500, 1000][Math.floor(Math.random() * 6)];
      const target = Number((1.2 + Math.random() * 8.5).toFixed(2));
      return {
        id: `avx_p_${i}_${Date.now()}`,
        user: name,
        bet,
        cashedOut: false,
        targetMultiplier: target
      };
    });
  };

  const topRecords = useMemo(() => [
    { user: 'Cy***er', multiplier: 124.50, bet: 100, win: 12450, date: 'Today 15:10' },
    { user: 'Ne***on', multiplier: 88.20, bet: 300, win: 26460, date: 'Today 14:02' },
    { user: 'Vo***ex', multiplier: 45.60, bet: 500, win: 22800, date: 'Today 13:22' },
    { user: 'Xe***on', multiplier: 33.10, bet: 250, win: 8275, date: 'Today 11:45' },
    { user: 'Bl***ze', multiplier: 21.40, bet: 800, win: 17120, date: 'Today 10:18' }
  ], []);

  // Main Game Cycle
  useEffect(() => {
    if (gameState === 'waiting') {
      setWaitingCountdown(5);
      setLiveBets(generateOtherPlayers());
      const countdownInterval = setInterval(() => {
        setWaitingCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(countdownInterval);
            // Launch flight - activate queued bets for current flight
            setBet1((b) => (b.betPlaced ? { ...b, queuedForNext: false } : b));
            setBet2((b) => (b.betPlaced ? { ...b, queuedForNext: false } : b));
            const nextCrash = determineCrashPoint();
            const nextRound = `AVX-${Date.now().toString().slice(-6)}`;
            setRoundId(nextRound);
            setCrashPoint(nextCrash);
            setMultiplier(1.0);
            setGameState('flying');
            flightStartTimeRef.current = performance.now();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(countdownInterval);
    }

    if (gameState === 'flying') {
      const speedFactor = 0.075; // Supersonic turbo flight

      const stepFlight = () => {
        const elapsedSec = (performance.now() - flightStartTimeRef.current) / 1000;
        const currentM = Math.exp(elapsedSec * speedFactor);

        if (currentM >= crashPoint) {
          setMultiplier(crashPoint);
          setGameState('crashed');
          setHistoryChips((prev) => [crashPoint, ...prev.slice(0, 19)]);
          playCrashSound();

          // Settle active bets as LOST (Silent - no win/loss toast!)
          const settleLosses = async () => {
            isCashingOutRef.current = { 1: false, 2: false };

            const latestBet1 = bet1Ref.current;
            if (latestBet1.betPlaced && !latestBet1.cashedOut && !latestBet1.queuedForNext && !(latestBet1.cashedOutAmount > 0)) {
              if (latestBet1.activeBetId) {
                await update(ref(rtdb, `aviator_x_bets/${latestBet1.activeBetId}`), {
                  status: 'lost',
                  crashMultiplier: crashPoint,
                  winAmount: 0
                }).catch(() => {});
                await updateGameBetStatus(latestBet1.activeBetId, 'lost', 0, `Crashed @ ${crashPoint.toFixed(2)}x`, crashPoint);
              }
            }

            const latestBet2 = bet2Ref.current;
            if (latestBet2.betPlaced && !latestBet2.cashedOut && !latestBet2.queuedForNext && !(latestBet2.cashedOutAmount > 0)) {
              if (latestBet2.activeBetId) {
                await update(ref(rtdb, `aviator_x_bets/${latestBet2.activeBetId}`), {
                  status: 'lost',
                  crashMultiplier: crashPoint,
                  winAmount: 0
                }).catch(() => {});
                await updateGameBetStatus(latestBet2.activeBetId, 'lost', 0, `Crashed @ ${crashPoint.toFixed(2)}x`, crashPoint);
              }
            }

            // Reset bet panels for next round (preserve if user queued for next round)
            setBet1((prev) => {
              if (prev.queuedForNext && prev.activeBetId) {
                return {
                  ...prev,
                  betPlaced: true,
                  queuedForNext: false,
                  cashedOut: false,
                  cashedOutMultiplier: 0,
                  cashedOutAmount: 0
                };
              }
              return {
                ...prev,
                betPlaced: false,
                queuedForNext: false,
                cashedOut: false,
                cashedOutMultiplier: 0,
                cashedOutAmount: 0,
                activeBetId: null
              };
            });
            setBet2((prev) => {
              if (prev.queuedForNext && prev.activeBetId) {
                return {
                  ...prev,
                  betPlaced: true,
                  queuedForNext: false,
                  cashedOut: false,
                  cashedOutMultiplier: 0,
                  cashedOutAmount: 0
                };
              }
              return {
                ...prev,
                betPlaced: false,
                queuedForNext: false,
                cashedOut: false,
                cashedOutMultiplier: 0,
                cashedOutAmount: 0,
                activeBetId: null
              };
            });
          };

          settleLosses();

          setTimeout(() => {
            setGameState('waiting');
          }, 2500);
        } else {
          const formattedM = Number(currentM.toFixed(2));
          setMultiplier(formattedM);

          // Update other live players as they cash out
          setLiveBets((prev) =>
            prev.map((player) => {
              if (!player.cashedOut && currentM >= player.targetMultiplier) {
                return {
                  ...player,
                  cashedOut: true,
                  cashoutMultiplier: player.targetMultiplier,
                  winAmount: Number((player.bet * player.targetMultiplier).toFixed(2))
                };
              }
              return player;
            })
          );

          // Check Auto Cashouts using latest ref state
          const autoBet1 = bet1Ref.current;
          if (
            autoBet1.betPlaced &&
            !autoBet1.cashedOut &&
            autoBet1.isAutoCashout &&
            currentM >= autoBet1.autoMultiplier
          ) {
            handleCashOut(1, currentM);
          }
          const autoBet2 = bet2Ref.current;
          if (
            autoBet2.betPlaced &&
            !autoBet2.cashedOut &&
            autoBet2.isAutoCashout &&
            currentM >= autoBet2.autoMultiplier
          ) {
            handleCashOut(2, currentM);
          }

          animationFrameRef.current = requestAnimationFrame(stepFlight);
        }
      };

      animationFrameRef.current = requestAnimationFrame(stepFlight);

      return () => {
        if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      };
    }
  }, [gameState, crashPoint, roundId]);

  // Place Bet
  const handlePlaceBet = async (betNum: 1 | 2) => {
    if (!user) return;

    const betState = betNum === 1 ? bet1 : bet2;
    if (betState.betPlaced) return;

    const amount = betState.amount;
    if (amount <= 0) return;
    if (user.balance < amount) {
      showToast('Insufficient balance!');
      return;
    }

    const isNextFlight = gameState === 'flying' || gameState === 'crashed';
    const newBetRef = push(ref(rtdb, 'aviator_x_bets'));
    const betId = newBetRef.key || `avx_bet_${Date.now()}`;
    const currentBal = Number(user.balance || 0);
    const newBal = Number((currentBal - amount).toFixed(2));
    const curLoss = Number(user.totalLoss || 0);

    // 1. Instant local optimistic update (0 delay)
    isCashingOutRef.current[betNum] = false;
    setUser((prev) => (prev ? { ...prev, balance: newBal } : null));

    if (betNum === 1) {
      setBet1((prev) => ({
        ...prev,
        betPlaced: true,
        queuedForNext: isNextFlight,
        cashedOut: false,
        cashedOutMultiplier: 0,
        cashedOutAmount: 0,
        activeBetId: betId
      }));
    } else {
      setBet2((prev) => ({
        ...prev,
        betPlaced: true,
        queuedForNext: isNextFlight,
        cashedOut: false,
        cashedOutMultiplier: 0,
        cashedOutAmount: 0,
        activeBetId: betId
      }));
    }

    // 2. Background DB synchronization
    const newRecord: AviatorBetRecord = {
      id: betId,
      uid: user.uid,
      username: user.username || user.nickname || 'User',
      game: 'aviatorX',
      roundId,
      betPanel: betNum,
      amount,
      status: 'pending',
      createdAt: Date.now()
    };

    Promise.all([
      update(ref(rtdb, `users/${user.uid}`), {
        balance: newBal,
        totalLoss: curLoss + amount
      }),
      fulfillBetTurnover(user.uid, amount),
      set(newBetRef, newRecord),
      recordGameBet({
        betId,
        uid: user.uid,
        gameType: 'aviatorX',
        gameName: 'Aviator X',
        selectType: 'multiplier',
        selectValue: betState.isAutoCashout ? `Auto: ${betState.autoMultiplier}x` : 'Manual Cashout',
        amount,
        totalAmount: amount,
        status: 'pending',
        periodId: roundId
      })
    ]).catch((err) => {
      console.error('Aviator X bet placement async sync failed:', err);
    });
  };

  // Cancel Bet (Refunds balance and cancels pending bet anytime before flight takeoff or while queued)
  const handleCancelBet = async (betNum: 1 | 2) => {
    if (!user) return;
    const betState = betNum === 1 ? bet1 : bet2;
    if (!betState.betPlaced || betState.cashedOut) return;
    // Cannot cancel if plane is currently flying unless queued for next round
    if (gameState === 'flying' && !betState.queuedForNext) return;

    // Instant local optimistic update (0 delay)
    isCashingOutRef.current[betNum] = false;
    const refundAmount = betState.amount;
    const currentBal = Number(user.balance || 0);
    const newBal = Number((currentBal + refundAmount).toFixed(2));
    const curLoss = Math.max(0, Number(user.totalLoss || 0) - refundAmount);

    setUser((prev) => (prev ? { ...prev, balance: newBal } : null));

    if (betNum === 1) {
      setBet1((prev) => ({
        ...prev,
        betPlaced: false,
        queuedForNext: false,
        activeBetId: null
      }));
    } else {
      setBet2((prev) => ({
        ...prev,
        betPlaced: false,
        queuedForNext: false,
        activeBetId: null
      }));
    }

    showToast('Bet cancelled');

    // Background DB sync
    try {
      await update(ref(rtdb, `users/${user.uid}`), {
        balance: newBal,
        totalLoss: curLoss
      });

      if (betState.activeBetId) {
        await update(ref(rtdb, `aviator_x_bets/${betState.activeBetId}`), {
          status: 'cancelled'
        });
        await updateGameBetStatus(betState.activeBetId, 'cancelled');
      }

      refreshBalance(true);
    } catch (err) {
      console.error('Aviator X cancel bet failed:', err);
    }
  };

  // Cash Out - strictly locked to single execution to prevent duplicate payouts
  const handleCashOut = async (betNum: 1 | 2, currentM: number) => {
    if (!user) return;
    // Synchronous ref check prevents multiple rapid clicks from adding money multiple times
    if (isCashingOutRef.current[betNum]) return;

    const betState = betNum === 1 ? bet1Ref.current : bet2Ref.current;
    if (!betState.betPlaced || betState.cashedOut) return;

    // Immediately lock synchronously
    isCashingOutRef.current[betNum] = true;

    const winAmount = Number((betState.amount * currentM).toFixed(2));

    // Immediately update UI State and ref synchronously so button reflects cashed out state immediately
    if (betNum === 1) {
      bet1Ref.current = {
        ...bet1Ref.current,
        cashedOut: true,
        cashedOutMultiplier: currentM,
        cashedOutAmount: winAmount
      };
      setBet1((prev) => ({
        ...prev,
        cashedOut: true,
        cashedOutMultiplier: currentM,
        cashedOutAmount: winAmount
      }));
    } else {
      bet2Ref.current = {
        ...bet2Ref.current,
        cashedOut: true,
        cashedOutMultiplier: currentM,
        cashedOutAmount: winAmount
      };
      setBet2((prev) => ({
        ...prev,
        cashedOut: true,
        cashedOutMultiplier: currentM,
        cashedOutAmount: winAmount
      }));
    }

    try {
      // 1. Credit balance in Firebase RTDB
      const curBal = Number(user.balance || 0);
      const newBal = Number((curBal + winAmount).toFixed(2));
      const totWon = Number((Number(user.totalWon || 0) + winAmount).toFixed(2));

      await update(ref(rtdb, `users/${user.uid}`), {
        balance: newBal,
        totalWon: totWon
      });

      // 2. Update bet record in aviator_x_bets & unified bets
      if (betState.activeBetId) {
        await update(ref(rtdb, `aviator_x_bets/${betState.activeBetId}`), {
          status: 'won',
          cashoutMultiplier: currentM,
          winAmount
        });
        await updateGameBetStatus(betState.activeBetId, 'won', winAmount, `${currentM.toFixed(2)}x`, currentM);
      }

      playChime(1300, 0.4);
      try {
        confetti({ particleCount: 70, spread: 75, origin: { y: 0.65 } });
      } catch {}

      refreshBalance(true);

      // Top-right Cashout Notification Banner (NO win/loss toast!)
      setCashoutNotification({
        amount: winAmount,
        multiplier: currentM
      });
      setTimeout(() => {
        setCashoutNotification(null);
      }, 3500);
    } catch (err) {
      console.error('Cashout error:', err);
    }
  };

  // Render Supersonic Stealth Fighter Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = (canvas.width = canvas.parentElement?.clientWidth || 360);
    const h = (canvas.height = 240);

    ctx.clearRect(0, 0, w, h);

    // Neon radar grid
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.08)';
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 36) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    if (gameState === 'flying') {
      const progress = Math.min(1.0, (multiplier - 1) / 14);
      const startX = 20;
      const startY = h - 20;
      const targetX = 30 + progress * (w - 70);
      const targetY = h - 30 - progress * (h - 70);

      // Cyan neon gradient
      const gradient = ctx.createLinearGradient(startX, startY, targetX, targetY);
      gradient.addColorStop(0, 'rgba(0, 240, 255, 0.1)');
      gradient.addColorStop(1, '#00f0ff');

      // Draw neon flight trajectory
      ctx.beginPath();
      ctx.moveTo(startX, startY);
      ctx.quadraticCurveTo(startX + (targetX - startX) * 0.5, startY, targetX, targetY);
      ctx.strokeStyle = '#00f0ff';
      ctx.lineWidth = 4;
      ctx.shadowColor = '#00f0ff';
      ctx.shadowBlur = 12;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Area fill
      ctx.lineTo(targetX, startY);
      ctx.closePath();
      ctx.fillStyle = gradient;
      ctx.globalAlpha = 0.2;
      ctx.fill();
      ctx.globalAlpha = 1.0;

      // Draw Supersonic Stealth Jet at target point
      ctx.save();
      ctx.translate(targetX, targetY);
      ctx.rotate(-0.35);

      // Afterburner cyan exhaust flame
      ctx.fillStyle = '#00f0ff';
      ctx.beginPath();
      ctx.moveTo(-16, 0);
      ctx.lineTo(-28, -4);
      ctx.lineTo(-24, 0);
      ctx.lineTo(-28, 4);
      ctx.closePath();
      ctx.fill();

      // Sleek delta jet body (Deep carbon / cyan edge)
      ctx.fillStyle = '#0ea5e9';
      ctx.beginPath();
      ctx.moveTo(22, 0);
      ctx.lineTo(-14, -12);
      ctx.lineTo(-8, 0);
      ctx.lineTo(-14, 12);
      ctx.closePath();
      ctx.fill();

      // Cockpit visor
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.ellipse(3, 0, 6, 2, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
    }
  }, [gameState, multiplier]);

  const getChipBadgeColor = (val: number) => {
    if (val >= 10) return 'bg-[#facc15] text-black font-black shadow-[0_0_10px_rgba(250,204,21,0.5)]';
    if (val >= 2.0) return 'bg-[#06b6d4] text-slate-950 font-black';
    return 'bg-[#1e293b] text-cyan-300 font-semibold border border-cyan-500/30';
  };

  const filteredMyBets = useMemo(() => {
    return userAviatorXBets.filter((b) => {
      if (myBetsFilter === 'won') return b.status === 'won';
      if (myBetsFilter === 'lost') return b.status === 'lost';
      return true;
    });
  }, [userAviatorXBets, myBetsFilter]);

  const totalMyBetsPages = Math.max(1, Math.ceil(filteredMyBets.length / myBetsPageSize));
  const paginatedMyBets = useMemo(() => {
    const start = (myBetsPage - 1) * myBetsPageSize;
    return filteredMyBets.slice(start, start + myBetsPageSize);
  }, [filteredMyBets, myBetsPage]);

  // Live community betting stats
  const activeRemainingPilotsCount = useMemo(() => {
    return liveBets.filter((p) => !p.cashedOut).length;
  }, [liveBets]);

  const liveTotalBetsAmount = useMemo(() => {
    return liveBets.reduce((acc, p) => acc + p.bet, 0);
  }, [liveBets]);

  const liveTotalWinAmount = useMemo(() => {
    return liveBets
      .filter((p) => p.cashedOut)
      .reduce((acc, p) => acc + (p.winAmount || 0), 0);
  }, [liveBets]);

  return (
    <div className="min-h-screen pb-20 text-white select-none bg-[#080c16]">
      {/* Top Header - Compact layout preventing Deposit button overflow */}
      <div className="sticky top-0 z-30 px-3 py-2 flex items-center justify-between border-b bg-[#0b1120] border-cyan-500/20 shadow-lg">
        <div className="flex items-center space-x-1.5 min-w-0">
          <button
            onClick={onBack}
            className="p-1 hover:bg-cyan-500/10 rounded-full active:scale-95 transition-transform shrink-0"
            id="aviatorx-back-btn"
          >
            <ArrowLeft className="w-5 h-5 text-cyan-400 stroke-[2.5]" />
          </button>
          <div className="flex items-center space-x-1 min-w-0">
            <span className="font-black text-sm sm:text-base tracking-wide bg-gradient-to-r from-cyan-400 via-teal-300 to-amber-300 bg-clip-text text-transparent truncate">
              AVIATOR X
            </span>
            <span className="px-1 py-0.2 rounded text-[8px] font-black bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shrink-0">
              PRO
            </span>
            <button
              onClick={() => setIsRulesOpen(true)}
              className="text-slate-400 hover:text-cyan-300 p-0.5 shrink-0"
              id="aviatorx-rules-btn"
            >
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Balance, Audio, 3-Line Menu & Deposit Button */}
        <div className="flex items-center space-x-1.5 shrink-0">
          <div className="flex items-center space-x-1 px-2 py-0.5 rounded-full bg-slate-900/90 border border-cyan-500/30 text-xs shadow-inner">
            <span className="font-bold text-cyan-400 text-[11px]">
              ৳{Number(user?.balance || 0).toFixed(2)}
            </span>
            <button
              onClick={refreshBalance}
              className={`p-0.5 hover:bg-white/10 rounded-full ${
                isRefreshingBalance ? 'animate-spin' : ''
              }`}
              id="aviatorx-refresh-btn"
            >
              <RefreshCw className="w-3 h-3 text-cyan-300" />
            </button>
          </div>

          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-1 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 hover:bg-cyan-900/40"
            id="aviatorx-sound-toggle-btn"
          >
            {soundEnabled ? (
              <Volume2 className="w-3.5 h-3.5 text-cyan-300" />
            ) : (
              <VolumeX className="w-3.5 h-3.5 text-cyan-700" />
            )}
          </button>

          {/* 3-Line System Menu Button */}
          <button
            onClick={() => setIsSystemMenuOpen(true)}
            className="p-1 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 hover:bg-cyan-900/40"
            title="System Menu"
            id="aviatorx-system-menu-btn"
          >
            <Menu className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onDepositClick}
            className="shrink-0 px-2.5 sm:px-3 py-1 rounded-full text-xs font-black bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 hover:from-cyan-400 hover:to-blue-500 active:scale-95 shadow-[0_0_10px_rgba(6,182,212,0.4)] transition-all"
            id="aviatorx-deposit-btn"
          >
            Deposit
          </button>
        </div>
      </div>

      {/* Multiplier History Chips Bar */}
      <div className="px-3 py-1.5 overflow-x-auto no-scrollbar flex items-center space-x-1.5 border-b border-cyan-500/10 bg-black/40">
        <span className="text-[10px] text-cyan-400 uppercase font-bold shrink-0 mr-1 flex items-center space-x-1">
          <Radio className="w-3 h-3 animate-pulse" />
          <span>X-History:</span>
        </span>
        {historyChips.map((chip, idx) => (
          <span
            key={idx}
            className={`text-[11px] px-2 py-0.5 rounded-full shrink-0 ${getChipBadgeColor(chip)}`}
          >
            {chip.toFixed(2)}x
          </span>
        ))}
      </div>

      {/* Flight Canvas Screen */}
      <div className="p-3">
        <div className="relative w-full h-60 rounded-3xl overflow-hidden flex flex-col items-center justify-center border border-cyan-500/30 bg-gradient-to-b from-[#0b1329] via-[#070b18] to-[#04060d] shadow-[0_0_25px_rgba(6,182,212,0.15)]">
          <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />

          {/* Top-Right Cashout Win Amount Banner (NO win/loss toast) */}
          {cashoutNotification && (
            <div className="absolute top-2.5 right-2.5 z-30 animate-in fade-in slide-in-from-top-2 duration-200 bg-cyan-600/90 border border-cyan-300 text-white px-3.5 py-1.5 rounded-xl shadow-2xl flex items-center space-x-2 backdrop-blur-xs">
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
              <div>
                <div className="text-[9px] uppercase font-bold text-cyan-100 tracking-wider">Turbo Cashout!</div>
                <div className="text-xs font-black">
                  +{cashoutNotification.amount.toFixed(2)} ৳{' '}
                  <span className="text-amber-300 font-mono font-bold">
                    ({cashoutNotification.multiplier.toFixed(2)}x)
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Center Floating Text Toast (for bet failed, insufficient balance) */}
          {textToast && (
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-40 bg-black/90 border border-red-500/60 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-2xl backdrop-blur-md animate-in fade-in zoom-in-90 duration-150 flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span>{textToast}</span>
            </div>
          )}

          {gameState === 'flying' && (
            <div className="relative z-10 text-center animate-in zoom-in-95 duration-150">
              <span className="font-black tracking-tight text-5xl md:text-6xl text-cyan-300 drop-shadow-[0_0_25px_rgba(0,240,255,0.8)]">
                {multiplier.toFixed(2)}x
              </span>
            </div>
          )}

          {gameState === 'crashed' && (
            <div className="relative z-10 text-center space-y-1 animate-in zoom-in duration-200">
              <span className="text-xs font-black tracking-widest uppercase text-red-400 block">
                TURBO CRASHED!
              </span>
              <span className="font-black text-5xl text-red-500 drop-shadow-[0_0_20px_rgba(239,68,68,0.8)]">
                {multiplier.toFixed(2)}x
              </span>
            </div>
          )}

          {gameState === 'waiting' && (
            <div className="relative z-10 text-center space-y-2.5">
              <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider block">
                WARMING UP TURBO ENGINES
              </span>
              <div className="w-48 h-2 rounded-full bg-slate-800 overflow-hidden mx-auto border border-cyan-500/20">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-1000 ease-linear shadow-[0_0_10px_rgba(6,182,212,0.6)]"
                  style={{ width: `${((5 - waitingCountdown) / 5) * 100}%` }}
                />
              </div>
              <span className="text-sm font-black text-cyan-300 font-mono">
                {waitingCountdown}s
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Dual Bet Controllers */}
      <div className="px-3 space-y-3">
        {/* BET PANEL 1 */}
        <div className="bg-[#0f172a]/90 p-3 rounded-2xl border border-cyan-500/20 space-y-2.5 shadow-md">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
            <div className="flex items-center space-x-1.5">
              <button
                onClick={() => setBet1((prev) => ({ ...prev, mode: 'bet' }))}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  bet1.mode === 'bet'
                    ? 'bg-cyan-500 text-slate-950 font-black'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                Bet
              </button>
              <button
                onClick={() => setBet1((prev) => ({ ...prev, mode: 'auto' }))}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  bet1.mode === 'auto'
                    ? 'bg-cyan-500 text-slate-950 font-black'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                Auto
              </button>
            </div>

            {bet1.mode === 'auto' && (
              <div className="flex items-center space-x-1.5">
                <button
                  onClick={() =>
                    setBet1((prev) => ({ ...prev, isAutoCashout: !prev.isAutoCashout }))
                  }
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    bet1.isAutoCashout
                      ? 'bg-emerald-400 text-slate-950 font-black'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Auto Cash Out
                </button>
                {bet1.isAutoCashout && (
                  <input
                    type="number"
                    step="0.1"
                    min="1.1"
                    value={bet1.autoMultiplier}
                    onChange={(e) =>
                      setBet1((prev) => ({
                        ...prev,
                        autoMultiplier: parseFloat(e.target.value) || 2.0
                      }))
                    }
                    className="w-14 px-1 py-0.5 rounded bg-black/50 border border-cyan-500/30 text-center text-[10px] text-cyan-300 font-bold"
                  />
                )}
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center space-x-1 bg-black/50 p-1 rounded-xl border border-cyan-500/20">
              <button
                onClick={() =>
                  setBet1((prev) => ({ ...prev, amount: Math.max(1, prev.amount - 10) }))
                }
                disabled={bet1.betPlaced && gameState === 'flying'}
                className="w-8 h-8 rounded-lg bg-cyan-950 hover:bg-cyan-900 font-bold text-cyan-300 flex items-center justify-center active:scale-95 disabled:opacity-40"
              >
                -
              </button>
              <input
                type="number"
                value={bet1.amount}
                disabled={bet1.betPlaced && gameState === 'flying'}
                onChange={(e) =>
                  setBet1((prev) => ({
                    ...prev,
                    amount: Math.max(1, parseInt(e.target.value, 10) || 1)
                  }))
                }
                className="w-full text-center font-bold text-sm bg-transparent text-cyan-300 focus:outline-none"
              />
              <button
                onClick={() => setBet1((prev) => ({ ...prev, amount: prev.amount + 10 }))}
                disabled={bet1.betPlaced && gameState === 'flying'}
                className="w-8 h-8 rounded-lg bg-cyan-950 hover:bg-cyan-900 font-bold text-cyan-300 flex items-center justify-center active:scale-95 disabled:opacity-40"
              >
                +
              </button>
            </div>

            {/* Action button 1: RED when bet placed before flight or queued for next, Live Tk Cashout when flying */}
            {!bet1.betPlaced ? (
              <button
                onClick={() => handlePlaceBet(1)}
                className="py-2.5 px-3 rounded-xl font-black text-sm flex flex-col items-center justify-center text-slate-950 shadow-md active:scale-98 transition-all bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 cursor-pointer"
                id="aviatorx-bet1-place-btn"
              >
                <span>{gameState === 'flying' ? 'TURBO (NEXT)' : 'TURBO BET'}</span>
                <span className="text-[10px] opacity-90 font-medium">
                  ৳{bet1.amount.toFixed(2)}
                </span>
              </button>
            ) : bet1.cashedOut ? (
              <div className="py-2 px-3 rounded-xl bg-emerald-950/60 border border-emerald-500 text-emerald-300 font-bold text-xs flex flex-col items-center justify-center">
                <span>CASHED OUT</span>
                <span className="text-[11px] font-black">
                  +{bet1.cashedOutAmount.toFixed(2)}৳
                </span>
              </div>
            ) : gameState === 'flying' && !bet1.queuedForNext ? (
              <button
                onClick={() => handleCashOut(1, multiplier)}
                className="py-2 px-3 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-slate-950 font-black text-sm flex flex-col items-center justify-center shadow-lg active:scale-98 animate-pulse cursor-pointer"
                id="aviatorx-bet1-cashout-btn"
              >
                <span>CASH OUT</span>
                <span className="text-[11px] font-bold">
                  ৳{(bet1.amount * multiplier).toFixed(2)} ({multiplier.toFixed(2)}x)
                </span>
              </button>
            ) : gameState === 'flying' && bet1.queuedForNext ? (
              <div className="flex flex-col space-y-1">
                <button
                  disabled
                  className="py-1.5 px-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-black text-xs flex flex-col items-center justify-center cursor-not-allowed"
                >
                  <span className="tracking-wider text-[11px]">WAITING NEXT ROUND</span>
                  <span className="text-[10px] font-mono opacity-80">৳{bet1.amount.toFixed(2)}</span>
                </button>
                <button
                  onClick={() => handleCancelBet(1)}
                  className="text-[10px] text-red-400 hover:text-red-300 underline font-bold text-center active:scale-95"
                >
                  Cancel
                </button>
              </div>
            ) : (
              /* Bet placed waiting or countdown: RED CANCEL BUTTON with full refund */
              <button
                onClick={() => handleCancelBet(1)}
                className="py-2.5 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs flex flex-col items-center justify-center shadow-lg shadow-red-600/40 active:scale-95 transition-all cursor-pointer animate-pulse"
                id="aviatorx-bet1-cancel-btn"
                title="Click to cancel bet and refund balance"
              >
                <span className="tracking-wider">CANCEL</span>
                <span className="text-[10px] font-mono opacity-90">৳{bet1.amount.toFixed(2)} (REFUND)</span>
              </button>
            )}
          </div>

          <div className="flex space-x-1.5">
            {[20, 100, 500, 2000].map((preset) => (
              <button
                key={preset}
                onClick={() => setBet1((prev) => ({ ...prev, amount: preset }))}
                disabled={bet1.betPlaced && gameState === 'flying'}
                className="flex-1 py-1 rounded bg-black/40 hover:bg-cyan-500/10 text-[10px] font-bold text-cyan-300 border border-cyan-500/10 transition-colors"
              >
                +{preset}
              </button>
            ))}
          </div>
        </div>

        {/* BET PANEL 2 */}
        <div className="bg-[#0f172a]/90 p-3 rounded-2xl border border-cyan-500/20 space-y-2.5 shadow-md">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
            <div className="flex items-center space-x-1.5">
              <button
                onClick={() => setBet2((prev) => ({ ...prev, mode: 'bet' }))}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  bet2.mode === 'bet'
                    ? 'bg-cyan-500 text-slate-950 font-black'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                Bet
              </button>
              <button
                onClick={() => setBet2((prev) => ({ ...prev, mode: 'auto' }))}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  bet2.mode === 'auto'
                    ? 'bg-cyan-500 text-slate-950 font-black'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                Auto
              </button>
            </div>

            {bet2.mode === 'auto' && (
              <div className="flex items-center space-x-1.5">
                <button
                  onClick={() =>
                    setBet2((prev) => ({ ...prev, isAutoCashout: !prev.isAutoCashout }))
                  }
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    bet2.isAutoCashout
                      ? 'bg-emerald-400 text-slate-950 font-black'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Auto Cash Out
                </button>
                {bet2.isAutoCashout && (
                  <input
                    type="number"
                    step="0.1"
                    min="1.1"
                    value={bet2.autoMultiplier}
                    onChange={(e) =>
                      setBet2((prev) => ({
                        ...prev,
                        autoMultiplier: parseFloat(e.target.value) || 5.0
                      }))
                    }
                    className="w-14 px-1 py-0.5 rounded bg-black/50 border border-cyan-500/30 text-center text-[10px] text-cyan-300 font-bold"
                  />
                )}
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center space-x-1 bg-black/50 p-1 rounded-xl border border-cyan-500/20">
              <button
                onClick={() =>
                  setBet2((prev) => ({ ...prev, amount: Math.max(1, prev.amount - 10) }))
                }
                disabled={bet2.betPlaced && gameState === 'flying'}
                className="w-8 h-8 rounded-lg bg-cyan-950 hover:bg-cyan-900 font-bold text-cyan-300 flex items-center justify-center active:scale-95 disabled:opacity-40"
              >
                -
              </button>
              <input
                type="number"
                value={bet2.amount}
                disabled={bet2.betPlaced && gameState === 'flying'}
                onChange={(e) =>
                  setBet2((prev) => ({
                    ...prev,
                    amount: Math.max(1, parseInt(e.target.value, 10) || 1)
                  }))
                }
                className="w-full text-center font-bold text-sm bg-transparent text-cyan-300 focus:outline-none"
              />
              <button
                onClick={() => setBet2((prev) => ({ ...prev, amount: prev.amount + 10 }))}
                disabled={bet2.betPlaced && gameState === 'flying'}
                className="w-8 h-8 rounded-lg bg-cyan-950 hover:bg-cyan-900 font-bold text-cyan-300 flex items-center justify-center active:scale-95 disabled:opacity-40"
              >
                +
              </button>
            </div>

            {/* Action button 2: RED when bet placed before flight or queued for next, Live Tk Cashout when flying */}
            {!bet2.betPlaced ? (
              <button
                onClick={() => handlePlaceBet(2)}
                className="py-2.5 px-3 rounded-xl font-black text-sm flex flex-col items-center justify-center text-slate-950 shadow-md active:scale-98 transition-all bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 cursor-pointer"
                id="aviatorx-bet2-place-btn"
              >
                <span>{gameState === 'flying' ? 'TURBO (NEXT)' : 'TURBO BET'}</span>
                <span className="text-[10px] opacity-90 font-medium">
                  ৳{bet2.amount.toFixed(2)}
                </span>
              </button>
            ) : bet2.cashedOut ? (
              <div className="py-2 px-3 rounded-xl bg-emerald-950/60 border border-emerald-500 text-emerald-300 font-bold text-xs flex flex-col items-center justify-center">
                <span>CASHED OUT</span>
                <span className="text-[11px] font-black">
                  +{bet2.cashedOutAmount.toFixed(2)}৳
                </span>
              </div>
            ) : gameState === 'flying' && !bet2.queuedForNext ? (
              <button
                onClick={() => handleCashOut(2, multiplier)}
                className="py-2 px-3 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-slate-950 font-black text-sm flex flex-col items-center justify-center shadow-lg active:scale-98 animate-pulse cursor-pointer"
                id="aviatorx-bet2-cashout-btn"
              >
                <span>CASH OUT</span>
                <span className="text-[11px] font-bold">
                  ৳{(bet2.amount * multiplier).toFixed(2)} ({multiplier.toFixed(2)}x)
                </span>
              </button>
            ) : gameState === 'flying' && bet2.queuedForNext ? (
              <div className="flex flex-col space-y-1">
                <button
                  disabled
                  className="py-1.5 px-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-black text-xs flex flex-col items-center justify-center cursor-not-allowed"
                >
                  <span className="tracking-wider text-[11px]">WAITING NEXT ROUND</span>
                  <span className="text-[10px] font-mono opacity-80">৳{bet2.amount.toFixed(2)}</span>
                </button>
                <button
                  onClick={() => handleCancelBet(2)}
                  className="text-[10px] text-red-400 hover:text-red-300 underline font-bold text-center active:scale-95"
                >
                  Cancel
                </button>
              </div>
            ) : (
              /* Bet placed waiting or countdown: RED CANCEL BUTTON with full refund */
              <button
                onClick={() => handleCancelBet(2)}
                className="py-2.5 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs flex flex-col items-center justify-center shadow-lg shadow-red-600/40 active:scale-95 transition-all cursor-pointer animate-pulse"
                id="aviatorx-bet2-cancel-btn"
                title="Click to cancel bet and refund balance"
              >
                <span className="tracking-wider">CANCEL</span>
                <span className="text-[10px] font-mono opacity-90">৳{bet2.amount.toFixed(2)} (REFUND)</span>
              </button>
            )}
          </div>

          <div className="flex space-x-1.5">
            {[50, 200, 1000, 5000].map((preset) => (
              <button
                key={preset}
                onClick={() => setBet2((prev) => ({ ...prev, amount: preset }))}
                disabled={bet2.betPlaced && gameState === 'flying'}
                className="flex-1 py-1 rounded bg-black/40 hover:bg-cyan-500/10 text-[10px] font-bold text-cyan-300 border border-cyan-500/10 transition-colors"
              >
                +{preset}
              </button>
            ))}
          </div>
        </div>

        {/* Live Players / WinGo-style Bet History / Top Multipliers */}
        <div className="bg-[#0f172a]/90 rounded-2xl border border-cyan-500/20 overflow-hidden text-xs shadow-md">
          {/* Main Tabs */}
          <div className="flex border-b border-cyan-500/20 bg-black/50">
            {(['all', 'my', 'top'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => {
                  setActiveTab(tab);
                  setMyBetsPage(1);
                }}
                className={`flex-1 py-2.5 font-bold uppercase tracking-wider transition-colors ${
                  activeTab === tab
                    ? 'text-cyan-400 border-b-2 border-cyan-400 bg-cyan-500/10'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab === 'all' ? 'All Bets' : tab === 'my' ? 'My Bets' : 'Top X'}
              </button>
            ))}
          </div>

          {/* TAB 1: ALL BETS (Live community betting with active pilots, total bets, live total won) */}
          {activeTab === 'all' && (
            <div>
              {/* Live Status Header */}
              <div className="px-3 py-2 bg-black/60 border-b border-cyan-500/10 flex items-center justify-between text-[11px]">
                <div className="flex items-center space-x-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <span className="font-bold text-slate-300">
                    <span className="font-mono text-cyan-400 font-black">{activeRemainingPilotsCount}</span> Active Pilots
                  </span>
                </div>
                <div className="text-slate-400 text-[10px]">
                  Total: <span className="font-mono font-bold text-white">৳{liveTotalBetsAmount.toLocaleString()}</span>
                </div>
                <div className="text-amber-400 font-bold text-[10px]">
                  Won: <span className="font-mono font-black text-amber-300">৳{liveTotalWinAmount.toFixed(2)}</span>
                </div>
              </div>

              {/* Table Column Headers */}
              <div className="grid grid-cols-4 px-3 py-1.5 bg-black/40 text-[10px] font-bold text-cyan-300 border-b border-cyan-500/10 uppercase">
                <span>Pilot</span>
                <span>Stake</span>
                <span className="text-center">Multiplier</span>
                <span className="text-right">Turbo Cashout</span>
              </div>

              {/* Player Rows */}
              <div className="divide-y divide-cyan-500/10 max-h-72 overflow-y-auto">
                {liveBets.map((b) => (
                  <div
                    key={b.id}
                    className={`grid grid-cols-4 px-3 py-2 items-center text-xs font-mono transition-colors ${
                      b.cashedOut ? 'bg-cyan-950/20' : ''
                    }`}
                  >
                    <span className="text-slate-300 font-sans text-[11px] truncate">{b.user}</span>
                    <span className="text-slate-300 font-bold">৳{b.bet}</span>
                    <div className="text-center">
                      {b.cashedOut ? (
                        <span className="inline-block px-1.5 py-0.2 rounded text-[10px] font-bold bg-cyan-900/40 border border-cyan-400/40 text-cyan-300">
                          {b.cashoutMultiplier?.toFixed(2)}x
                        </span>
                      ) : (
                        <span className="text-slate-600">-</span>
                      )}
                    </div>
                    <div className="text-right">
                      {b.cashedOut ? (
                        <span className="text-emerald-400 font-bold text-[11px]">
                          +৳{b.winAmount?.toFixed(2)}
                        </span>
                      ) : gameState === 'crashed' ? (
                        <span className="text-red-500 text-[10px] font-sans font-bold">Crashed</span>
                      ) : (
                        <span className="text-slate-600">-</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: MY BETS (WinGo-style Bet History with Success / Failed badges, Accordion, & Pagination) */}
          {activeTab === 'my' && (
            <div>
              {paginatedMyBets.length === 0 ? (
                <div className="py-10 text-center text-slate-500 font-medium">
                  No Aviator X betting history found
                </div>
              ) : (
                <div className="divide-y divide-cyan-500/10">
                  {paginatedMyBets.map((b) => {
                    const isExpanded = expandedBetId === b.id;
                    const isWon = b.status === 'won';
                    const isLost = b.status === 'lost';
                    const multDisplay = b.cashoutMultiplier
                      ? `${b.cashoutMultiplier.toFixed(2)}x`
                      : b.crashMultiplier
                      ? `${b.crashMultiplier.toFixed(2)}x`
                      : '-';

                    return (
                      <div key={b.id} className="transition-colors hover:bg-cyan-500/5">
                        <div
                          onClick={() => setExpandedBetId(isExpanded ? null : b.id)}
                          className="px-3 py-2.5 flex items-center justify-between cursor-pointer select-none"
                        >
                          <div className="space-y-0.5">
                            <div className="flex items-center space-x-1.5">
                              <span className="font-bold text-cyan-300">Aviator X</span>
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-950 font-mono text-cyan-400 border border-cyan-500/30">
                                {b.roundId}
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400">
                              {new Date(b.createdAt).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                                second: '2-digit'
                              })}
                            </div>
                          </div>

                          {/* Bet Amount, Multiplier, and Win Amount */}
                          <div className="text-right flex items-center space-x-2">
                            <div className="text-right space-y-0.5">
                              <div className="flex items-center justify-end space-x-2">
                                <span className="text-[11px] text-slate-300">
                                  Bet: <strong className="font-bold text-white font-mono">৳{b.amount.toFixed(2)}</strong>
                                </span>
                                <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-cyan-400/20 text-cyan-300 border border-cyan-400/30">
                                  {multDisplay}
                                </span>
                              </div>
                              <div className="text-xs font-mono font-bold">
                                {isWon ? (
                                  <span className="text-emerald-400">
                                    Win: +৳{(b.winAmount || 0).toFixed(2)}
                                  </span>
                                ) : isLost ? (
                                  <span className="text-slate-400">
                                    Win: ৳0.00
                                  </span>
                                ) : (
                                  <span className="text-amber-400">
                                    In Flight
                                  </span>
                                )}
                              </div>
                            </div>
                            {isExpanded ? (
                              <ChevronUp className="w-4 h-4 text-slate-400" />
                            ) : (
                              <ChevronDown className="w-4 h-4 text-slate-400" />
                            )}
                          </div>
                        </div>

                        {/* Accordion Expanded Order Detail Drawer */}
                        {isExpanded && (
                          <div className="px-3.5 pb-3 pt-1 bg-black/60 border-t border-cyan-500/10 text-[11px]">
                            <div className="bg-[#0b1329] rounded-xl p-3 border border-cyan-500/30 space-y-1.5">
                              <div className="font-bold text-cyan-300 text-xs pb-1 border-b border-cyan-500/20 flex items-center justify-between">
                                <span>Order Details</span>
                                <span className="text-[10px] text-slate-400 font-mono">
                                  {b.id}
                                </span>
                              </div>
                              <div className="grid grid-cols-2 gap-y-1 text-slate-300">
                                <div className="text-slate-400">Game:</div>
                                <div className="font-semibold text-right text-cyan-300">
                                  Aviator X
                                </div>
                                <div className="text-slate-400">Round ID:</div>
                                <div className="font-mono text-right text-slate-300">
                                  {b.roundId}
                                </div>
                                <div className="text-slate-400">Bet Panel:</div>
                                <div className="font-medium text-right text-slate-300">
                                  Panel {b.betPanel}
                                </div>
                                <div className="text-slate-400">Bet Amount:</div>
                                <div className="font-bold text-right text-white font-mono">
                                  ৳{b.amount.toFixed(2)}
                                </div>
                                <div className="text-slate-400">Multiplier:</div>
                                <div className="font-bold text-right text-cyan-300 font-mono">
                                  {multDisplay}
                                </div>
                                <div className="text-slate-400">Win Amount:</div>
                                <div className="font-bold text-right font-mono">
                                  {isWon ? (
                                    <span className="text-emerald-400">
                                      +৳{(b.winAmount || 0).toFixed(2)}
                                    </span>
                                  ) : isLost ? (
                                    <span className="text-slate-400">
                                      ৳0.00
                                    </span>
                                  ) : (
                                    <span className="text-amber-400">Waiting for Draw</span>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {/* WinGo-style Pagination Bar */}
              {filteredMyBets.length > 0 && (
                <div className="flex items-center justify-between px-3 py-2.5 bg-black/60 border-t border-cyan-500/20 text-xs">
                  <span className="text-slate-400 font-medium text-[11px]">
                    Showing{' '}
                    {Math.min(filteredMyBets.length, (myBetsPage - 1) * myBetsPageSize + 1)} -{' '}
                    {Math.min(filteredMyBets.length, myBetsPage * myBetsPageSize)} of{' '}
                    {filteredMyBets.length}
                  </span>
                  <div className="flex items-center space-x-1.5">
                    <button
                      disabled={myBetsPage <= 1}
                      onClick={() => setMyBetsPage((p) => Math.max(1, p - 1))}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 border border-cyan-500/20 text-cyan-300 font-bold disabled:opacity-30 hover:bg-slate-700 active:scale-95 transition-all text-xs"
                      id="aviatorx-mybets-prev-btn"
                    >
                      &lt; Prev
                    </button>
                    <span className="px-2 font-bold text-cyan-300 text-xs">
                      {myBetsPage} / {totalMyBetsPages}
                    </span>
                    <button
                      disabled={myBetsPage >= totalMyBetsPages}
                      onClick={() => setMyBetsPage((p) => p + 1)}
                      className="px-3 py-1 rounded-lg bg-cyan-500 text-slate-950 font-black disabled:opacity-30 hover:bg-cyan-400 active:scale-95 shadow-xs transition-all text-xs"
                      id="aviatorx-mybets-next-btn"
                    >
                      Next &gt;
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: TOP MULTIPLIERS */}
          {activeTab === 'top' && (
            <div className="divide-y divide-cyan-500/10 max-h-72 overflow-y-auto">
              <div className="px-3 py-2 bg-black/60 flex items-center justify-between text-[11px] font-bold text-cyan-300">
                <span>Pilot</span>
                <span>Multiplier</span>
                <span>Turbo Win</span>
              </div>
              {topRecords.map((t, idx) => (
                <div
                  key={idx}
                  className="px-3 py-2.5 flex items-center justify-between font-mono hover:bg-cyan-500/5"
                >
                  <div className="flex items-center space-x-1.5">
                    <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold flex items-center justify-center text-[10px] border border-cyan-500/30">
                      {idx + 1}
                    </span>
                    <span className="text-slate-200 font-sans">{t.user}</span>
                  </div>
                  <span className="text-cyan-400 font-bold">{t.multiplier.toFixed(2)}x</span>
                  <span className="text-emerald-400 font-bold">৳{t.win.toLocaleString()}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 3-Line System Menu Drawer */}
      {isSystemMenuOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex justify-end animate-in fade-in duration-150">
          <div className="w-72 bg-[#0b1329] h-full p-4 border-l border-cyan-500/30 flex flex-col justify-between shadow-2xl animate-in slide-in-from-right duration-200">
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-cyan-500/20 pb-3">
                <div className="flex items-center space-x-2">
                  <Menu className="w-4 h-4 text-cyan-400" />
                  <span className="font-black text-sm text-cyan-300">SYSTEM MENU</span>
                </div>
                <button
                  onClick={() => setIsSystemMenuOpen(false)}
                  className="p-1 rounded-full text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2 text-xs">
                {/* Sound Setting */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/80 border border-cyan-500/20">
                  <div className="flex items-center space-x-2 text-slate-200 font-bold">
                    <Sliders className="w-4 h-4 text-cyan-400" />
                    <span>Sound Effects</span>
                  </div>
                  <button
                    onClick={() => setSoundEnabled(!soundEnabled)}
                    className={`w-11 h-6 rounded-full transition-colors relative ${
                      soundEnabled ? 'bg-cyan-500' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`block w-4 h-4 rounded-full bg-white transition-transform ${
                        soundEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                {/* Provably Fair */}
                <button
                  onClick={() => {
                    setIsSystemMenuOpen(false);
                    setIsProvablyFairOpen(true);
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-900/80 border border-cyan-500/20 hover:bg-cyan-950/40 text-slate-200 font-bold"
                >
                  <div className="flex items-center space-x-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Provably Fair Settings</span>
                  </div>
                  <span className="text-[10px] text-cyan-400 font-mono">SHA-256</span>
                </button>

                {/* Game Rules */}
                <button
                  onClick={() => {
                    setIsSystemMenuOpen(false);
                    setIsRulesOpen(true);
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-900/80 border border-cyan-500/20 hover:bg-cyan-950/40 text-slate-200 font-bold"
                >
                  <div className="flex items-center space-x-2">
                    <HelpCircle className="w-4 h-4 text-cyan-400" />
                    <span>How to Play / Rules</span>
                  </div>
                  <span className="text-[10px] text-slate-400">Guides</span>
                </button>

                {/* Game Limits */}
                <div className="p-2.5 rounded-xl bg-slate-900/80 border border-cyan-500/20 space-y-1">
                  <div className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider">
                    Game Limits
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-300">
                    <span>Min Bet:</span>
                    <span className="font-mono text-cyan-300 font-bold">৳1.00</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-300">
                    <span>Max Bet:</span>
                    <span className="font-mono text-cyan-300 font-bold">৳10,000.00</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-300">
                    <span>Max Win Multiplier:</span>
                    <span className="font-mono text-amber-300 font-bold">150.00x</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-cyan-500/20 text-center text-[10px] text-slate-500 font-mono">
              Round ID: {roundId} | v3.8 PRO
            </div>
          </div>
        </div>
      )}

      {/* Provably Fair Modal */}
      {isProvablyFairOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-[#0b1329] rounded-3xl max-w-sm w-full p-5 space-y-4 shadow-2xl border border-cyan-500/30">
            <div className="flex items-center justify-between border-b border-cyan-500/20 pb-3">
              <h3 className="font-bold text-emerald-400 text-sm flex items-center space-x-2">
                <ShieldCheck className="w-5 h-5" />
                <span>Provably Fair Cryptographic Engine</span>
              </h3>
              <button
                onClick={() => setIsProvablyFairOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="text-xs text-slate-300 space-y-2.5 leading-relaxed">
              <p>
                Every multiplier is generated through a cryptographic combination of the Server Seed and 3 Client Seeds via SHA-256 HMAC.
              </p>
              <div className="bg-black/60 p-2.5 rounded-xl border border-cyan-500/20 space-y-1 font-mono text-[10px]">
                <div className="text-cyan-400 font-bold">Current Round Hash:</div>
                <div className="text-slate-300 truncate">
                  e7c9f8a42b109dc3847291a82f34918230b42fae9
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsProvablyFairOpen(false)}
              className="w-full py-2.5 bg-cyan-500 text-slate-950 font-black rounded-xl text-xs"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Rules Modal */}
      {isRulesOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-[#0b1329] rounded-3xl max-w-sm w-full p-5 space-y-4 shadow-2xl border border-cyan-500/30">
            <div className="flex items-center justify-between border-b border-cyan-500/20 pb-3">
              <h3 className="font-bold text-cyan-300 text-base flex items-center space-x-2">
                <Cpu className="w-5 h-5 text-cyan-400" />
                <span>Aviator X Rules</span>
              </h3>
              <button
                onClick={() => setIsRulesOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="text-xs text-slate-300 space-y-2.5 leading-relaxed max-h-72 overflow-y-auto">
              <p>
                <strong>1. Turbo Mechanics:</strong> Aviator X is a supersonic stealth jet flight
                game engineered for high-altitude multipliers.
              </p>
              <p>
                <strong>2. Dual Controls:</strong> Set two bets independently with manual or
                automated cash out parameters.
              </p>
              <p>
                <strong>3. Real-Time Balance:</strong> Your wallet balance is synced live with the
                secure engine. Winnings are credited immediately to your balance on cashout.
              </p>
            </div>
            <button
              onClick={() => setIsRulesOpen(false)}
              className="w-full py-2.5 bg-cyan-500 text-slate-950 font-black rounded-xl text-xs"
            >
              Ready to Fly
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
