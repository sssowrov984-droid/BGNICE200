import React from 'react';
import { Home, Gift, Wallet, User, Gem } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export type TabType = 'home' | 'activity' | 'promotion' | 'wallet' | 'account' | 'wingo' | 'k3' | 'fiveD' | 'trx' | 'aviator' | 'aviatorX' | 'deposit' | 'withdraw' | 'safe' | 'vip';

interface BottomNavProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  const { t } = useLanguage();

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto z-40 bg-white border-t border-slate-200/80 shadow-[0_-4px_12px_rgba(0,0,0,0.05)] px-2 py-1.5 flex items-center justify-around select-none">
      {/* Home */}
      <button
        onClick={() => setActiveTab('home')}
        className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
          activeTab === 'home' ? 'text-[#2196f3]' : 'text-slate-400 hover:text-slate-600'
        }`}
        id="nav-tab-home"
      >
        <Home className={`w-5 h-5 ${activeTab === 'home' ? 'stroke-[2.5]' : 'stroke-2'}`} />
        <span className="text-[11px] font-medium mt-0.5">{t('home')}</span>
      </button>

      {/* Activity */}
      <button
        onClick={() => setActiveTab('activity')}
        className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
          activeTab === 'activity' ? 'text-[#2196f3]' : 'text-slate-400 hover:text-slate-600'
        }`}
        id="nav-tab-activity"
      >
        <Gift className={`w-5 h-5 ${activeTab === 'activity' ? 'stroke-[2.5]' : 'stroke-2'}`} />
        <span className="text-[11px] font-medium mt-0.5">{t('activity')}</span>
      </button>

      {/* Promotion (Floating Raised Center Diamond) */}
      <div className="flex-1 flex justify-center -mt-6">
        <button
          onClick={() => setActiveTab('promotion')}
          className="relative flex flex-col items-center focus:outline-none group"
          id="nav-tab-promotion"
        >
          <div className="w-13 h-13 rounded-full bg-gradient-to-tr from-[#1976d2] via-[#2196f3] to-[#42a5f5] flex items-center justify-center shadow-[0_4px_14px_rgba(33,150,243,0.45)] border-4 border-white transition-transform active:scale-90">
            <Gem className="w-6 h-6 text-white" strokeWidth={2.2} />
          </div>
          <span
            className={`text-[11px] font-bold mt-1 ${
              activeTab === 'promotion' ? 'text-[#2196f3]' : 'text-slate-500'
            }`}
          >
            {t('promotion')}
          </span>
        </button>
      </div>

      {/* Wallet */}
      <button
        onClick={() => setActiveTab('wallet')}
        className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
          activeTab === 'wallet' || activeTab === 'deposit' || activeTab === 'withdraw'
            ? 'text-[#2196f3]'
            : 'text-slate-400 hover:text-slate-600'
        }`}
        id="nav-tab-wallet"
      >
        <Wallet className={`w-5 h-5 ${activeTab === 'wallet' ? 'stroke-[2.5]' : 'stroke-2'}`} />
        <span className="text-[11px] font-medium mt-0.5">{t('wallet')}</span>
      </button>

      {/* Account */}
      <button
        onClick={() => setActiveTab('account')}
        className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
          activeTab === 'account' ? 'text-[#2196f3]' : 'text-slate-400 hover:text-slate-600'
        }`}
        id="nav-tab-account"
      >
        <User className={`w-5 h-5 ${activeTab === 'account' ? 'stroke-[2.5]' : 'stroke-2'}`} />
        <span className="text-[11px] font-medium mt-0.5">{t('account')}</span>
      </button>
    </nav>
  );
};
