import React from 'react';
import { ShieldCheck, Sparkles, Flame } from 'lucide-react';

interface BrandLogoProps {
  variant?: 'header' | 'auth' | 'compact' | 'light' | 'white';
  showBadge?: boolean;
  className?: string;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  variant = 'header',
  showBadge = true,
  className = ''
}) => {
  if (variant === 'auth') {
    return (
      <div className={`flex flex-col items-center justify-center select-none ${className}`}>
        {/* Stylized Brand Emblem */}
        <div className="relative mb-2.5">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#2196f3] via-[#42a5f5] to-[#64b5f6] p-0.5 shadow-xl shadow-blue-500/25 flex items-center justify-center transform hover:scale-105 transition-transform duration-300">
            <div className="w-full h-full bg-[#1e2530] rounded-[14px] flex items-center justify-center relative overflow-hidden">
              {/* Subtle tech grid background */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#2196f3]/25 via-transparent to-emerald-500/10" />
              {/* Central Geometric Crown/Diamond Monogram */}
              <div className="relative z-10 flex flex-col items-center justify-center">
                <span className="font-black text-xl tracking-tighter text-white font-mono leading-none">
                  BG
                </span>
                <span className="text-[8px] font-black text-[#2196f3] tracking-widest uppercase mt-0.5">
                  PRO
                </span>
              </div>
            </div>
          </div>
          <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#2196f3] opacity-75" />
            <span className="relative inline-flex rounded-full h-4 w-4 bg-[#2196f3] border-2 border-[#1e2530]" />
          </span>
        </div>

        {/* Stylized Brand Typography: BGNICE */}
        <div className="flex items-center space-x-1">
          <span
            className="text-3xl font-black tracking-tight text-white uppercase drop-shadow-md"
            style={{ fontFamily: "'Outfit', 'Plus Jakarta Sans', sans-serif", letterSpacing: '-0.03em' }}
          >
            BG
          </span>
          <span
            className="text-2xl font-black px-2.5 py-0.5 rounded-xl bg-gradient-to-r from-[#2196f3] to-[#1976d2] text-white tracking-wide shadow-lg shadow-blue-500/30 uppercase transform -skew-x-6"
            style={{ fontFamily: "'Outfit', 'Plus Jakarta Sans', sans-serif" }}
          >
            NICE
          </span>
        </div>

        {showBadge && (
          <div className="flex items-center space-x-1.5 mt-1.5 text-xs text-slate-300 font-semibold tracking-wide">
            <ShieldCheck className="w-3.5 h-3.5 text-[#2196f3]" />
            <span>Official Licensed Gaming Network</span>
          </div>
        )}
      </div>
    );
  }

  if (variant === 'light') {
    return (
      <div className={`flex items-center space-x-2 select-none ${className}`}>
        <div className="w-7 h-7 rounded-xl bg-[#2196f3] p-0.5 shadow-sm flex items-center justify-center text-white font-black text-xs font-mono">
          BG
        </div>
        <div className="flex items-baseline space-x-1">
          <span
            className="text-xl font-black tracking-tight text-[#29303d] uppercase"
            style={{ fontFamily: "'Outfit', 'Plus Jakarta Sans', sans-serif" }}
          >
            BG
          </span>
          <span
            className="text-xs font-black px-2 py-0.5 rounded-lg bg-[#2196f3] text-white tracking-wider uppercase transform -skew-x-6"
            style={{ fontFamily: "'Outfit', sans-serif" }}
          >
            NICE
          </span>
        </div>
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <div className={`flex items-center space-x-1.5 select-none ${className}`}>
        <div className="w-6 h-6 rounded-lg bg-[#2196f3] flex items-center justify-center text-white text-[10px] font-black font-mono">
          BG
        </div>
        <span
          className="text-lg font-black tracking-tight text-white uppercase drop-shadow-xs"
          style={{ fontFamily: "'Outfit', 'Plus Jakarta Sans', sans-serif" }}
        >
          BG<span className="text-[#2196f3]">NICE</span>
        </span>
      </div>
    );
  }

  if (variant === 'white') {
    return (
      <div className={`flex items-center space-x-2 select-none ${className}`}>
        <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#2196f3] to-[#42a5f5] p-0.5 shadow-md flex items-center justify-center">
          <div className="w-full h-full bg-[#1e2530] rounded-[10px] flex items-center justify-center text-[#2196f3] font-mono font-black text-xs">
            BG
          </div>
        </div>
        <div className="flex items-center space-x-1">
          <span
            className="text-2xl font-black tracking-tight text-white uppercase drop-shadow-sm"
            style={{ fontFamily: "'Outfit', 'Plus Jakarta Sans', sans-serif", letterSpacing: '-0.02em' }}
          >
            BG
          </span>
          <span
            className="text-xs font-black px-2 py-0.5 rounded-lg bg-[#2196f3] text-white tracking-wider shadow-sm uppercase transform -skew-x-6"
            style={{ fontFamily: "'Outfit', sans-serif" }}
          >
            NICE
          </span>
        </div>
      </div>
    );
  }

  // Default: 'header' variant (Main top bar)
  return (
    <div className={`flex items-center space-x-2 select-none ${className}`}>
      {/* Front Icon Logo Badge */}
      <div className="relative flex items-center justify-center">
        <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#2196f3] via-[#42a5f5] to-cyan-300 p-0.5 shadow-md shadow-blue-500/20 flex items-center justify-center transform active:scale-95 transition-transform">
          <div className="w-full h-full bg-[#1e2530] rounded-[10px] flex items-center justify-center relative overflow-hidden">
            <span className="text-white font-mono font-black text-xs tracking-tighter">
              BG
            </span>
          </div>
        </div>
        <span className="absolute -top-0.5 -right-0.5 flex h-2 w-2">
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400 border border-white" />
        </span>
      </div>

      {/* Styled Brand Typography: BGNICE */}
      <div className="flex items-center space-x-1.5">
        <span
          className="text-2xl font-black tracking-tight text-white uppercase drop-shadow-sm"
          style={{
            fontFamily: "'Outfit', 'Plus Jakarta Sans', sans-serif",
            letterSpacing: '-0.02em'
          }}
        >
          BG
        </span>

        <div className="relative inline-flex items-center">
          <span
            className="text-xs font-black px-2 py-0.5 rounded-lg bg-[#2196f3] text-white tracking-wider shadow-sm uppercase transform -skew-x-6"
            style={{ fontFamily: "'Outfit', sans-serif" }}
          >
            NICE
          </span>
        </div>

        {showBadge && (
          <span className="hidden sm:inline-flex text-[9px] bg-white/15 text-white font-extrabold px-1.5 py-0.5 rounded-full uppercase tracking-wider border border-white/10">
            Official
          </span>
        )}
      </div>
    </div>
  );
};
