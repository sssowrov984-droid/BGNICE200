import React from 'react';

interface CategoryCardViewProps {
  selectedCategory: string;
  onSelectCategory: (catId: string) => void;
}

// 3D Golden Trophy with Purple Gem & Floating Coins for 'Popular'
const Trophy3DIcon = () => (
  <svg viewBox="0 0 100 100" className="w-16 h-16 drop-shadow-lg" fill="none">
    {/* Floating Gold Coins */}
    <ellipse cx="20" cy="30" rx="8" ry="5" fill="#ffd700" stroke="#d4af37" strokeWidth="1.5" />
    <ellipse cx="20" cy="28" rx="6" ry="3.5" fill="#fff3a8" />
    <ellipse cx="82" cy="35" rx="9" ry="5.5" fill="#ffd700" stroke="#d4af37" strokeWidth="1.5" />
    <ellipse cx="82" cy="33" rx="7" ry="4" fill="#fff3a8" />
    {/* Sparkle */}
    <path d="M16 18 L19 23 L24 24 L19 25 L16 30 L13 25 L8 24 L13 23 Z" fill="#ffffff" />
    <path d="M84 14 L86 18 L90 19 L86 20 L84 24 L82 20 L78 19 L82 18 Z" fill="#ffffff" />
    {/* Trophy Handles */}
    <path
      d="M25 32 C12 32 12 56 28 58"
      stroke="url(#trophyGold)"
      strokeWidth="5"
      strokeLinecap="round"
      fill="none"
    />
    <path
      d="M75 32 C88 32 88 56 72 58"
      stroke="url(#trophyGold)"
      strokeWidth="5"
      strokeLinecap="round"
      fill="none"
    />
    {/* Trophy Cup */}
    <path
      d="M26 24 C26 22 74 22 74 24 C74 48 64 62 50 64 C36 62 26 48 26 24 Z"
      fill="url(#trophyGold)"
      stroke="#b8860b"
      strokeWidth="1.5"
    />
    {/* Trophy Rim */}
    <ellipse cx="50" cy="24" rx="24" ry="5" fill="#ffe57f" stroke="#b8860b" strokeWidth="1" />
    <ellipse cx="50" cy="24" rx="20" ry="3.5" fill="#d4af37" />
    {/* Purple Diamond Gem on Trophy */}
    <polygon points="50,34 58,44 50,54 42,44" fill="url(#purpleGem)" stroke="#ffffff" strokeWidth="1" />
    <polygon points="50,34 54,44 50,54 46,44" fill="#d980fa" />
    {/* Trophy Stem & Base */}
    <path d="M46 64 L44 76 L56 76 L54 64 Z" fill="url(#trophyGold)" />
    <ellipse cx="50" cy="76" rx="14" ry="4" fill="#b8860b" />
    <path d="M34 76 L32 86 L68 86 L66 76 Z" fill="url(#trophyGold)" stroke="#b8860b" strokeWidth="1" />
    <ellipse cx="50" cy="86" rx="18" ry="4.5" fill="#996515" />
    {/* Gradients */}
    <defs>
      <linearGradient id="trophyGold" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fff275" />
        <stop offset="50%" stopColor="#ffd700" />
        <stop offset="100%" stopColor="#e6a100" />
      </linearGradient>
      <linearGradient id="purpleGem" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#e056fd" />
        <stop offset="100%" stopColor="#681596" />
      </linearGradient>
    </defs>
  </svg>
);

// 3D Lottery Balls & Bingo Card for 'Lottery'
const Lottery3DIcon = () => (
  <svg viewBox="0 0 100 100" className="w-16 h-16 drop-shadow-lg" fill="none">
    {/* Bingo Card in Background */}
    <rect x="18" y="16" width="38" height="46" rx="4" transform="rotate(-12 37 39)" fill="#ffffff" stroke="#dcdde1" strokeWidth="1.5" />
    <rect x="23" y="24" width="28" height="30" rx="2" transform="rotate(-12 37 39)" fill="#f1f2f6" />
    {/* Ball 1 - Purple (3) */}
    <circle cx="28" cy="62" r="14" fill="url(#ballPurple)" stroke="#4a154b" strokeWidth="1" />
    <circle cx="24" cy="58" r="4" fill="#ffffff" opacity="0.6" />
    <circle cx="28" cy="62" r="7" fill="#ffffff" />
    <text x="28" y="65" fontSize="8" fontWeight="bold" fill="#2c2c54" textAnchor="middle">3</text>
    {/* Ball 2 - Yellow (32) */}
    <circle cx="58" cy="60" r="17" fill="url(#ballYellow)" stroke="#cc8e35" strokeWidth="1" />
    <circle cx="53" cy="54" r="5" fill="#ffffff" opacity="0.7" />
    <circle cx="58" cy="60" r="8.5" fill="#ffffff" />
    <text x="58" y="64" fontSize="9" fontWeight="900" fill="#2c2c54" textAnchor="middle">32</text>
    {/* Ball 3 - Red (10) */}
    <circle cx="76" cy="40" r="13" fill="url(#ballRed)" stroke="#b33939" strokeWidth="1" />
    <circle cx="72" cy="36" r="3.5" fill="#ffffff" opacity="0.6" />
    <circle cx="76" cy="40" r="6" fill="#ffffff" />
    <text x="76" y="43" fontSize="8" fontWeight="bold" fill="#b33939" textAnchor="middle">10</text>
    {/* Sparkle */}
    <path d="M50 14 L52 18 L56 19 L52 20 L50 24 L48 20 L44 19 L48 18 Z" fill="#ffffff" />
    <defs>
      <radialGradient id="ballYellow" cx="35%" cy="35%" r="65%">
        <stop offset="0%" stopColor="#fff3a8" />
        <stop offset="60%" stopColor="#fbc531" />
        <stop offset="100%" stopColor="#e1b12c" />
      </radialGradient>
      <radialGradient id="ballPurple" cx="35%" cy="35%" r="65%">
        <stop offset="0%" stopColor="#e056fd" />
        <stop offset="70%" stopColor="#be2edd" />
        <stop offset="100%" stopColor="#681596" />
      </radialGradient>
      <radialGradient id="ballRed" cx="35%" cy="35%" r="65%">
        <stop offset="0%" stopColor="#ff7675" />
        <stop offset="70%" stopColor="#eb4d4b" />
        <stop offset="100%" stopColor="#b71540" />
      </radialGradient>
    </defs>
  </svg>
);

// 3D 777 Slot Machine Reels & Gold Coins for 'Slots'
const Slots3DIcon = () => (
  <svg viewBox="0 0 100 100" className="w-16 h-16 drop-shadow-lg" fill="none">
    {/* Slot Frame Body */}
    <rect x="15" y="24" width="70" height="52" rx="10" fill="url(#slotBody)" stroke="#f5cd79" strokeWidth="2" />
    {/* Reel Screen */}
    <rect x="22" y="32" width="56" height="34" rx="6" fill="#1e272e" stroke="#f7d794" strokeWidth="1" />
    {/* 3 Reels Dividers */}
    <line x1="40" y1="32" x2="40" y2="66" stroke="#485460" strokeWidth="1.5" />
    <line x1="60" y1="32" x2="60" y2="66" stroke="#485460" strokeWidth="1.5" />
    {/* Golden "7" on Reel 1 */}
    <text x="31" y="56" fontSize="20" fontWeight="900" fill="url(#gold7)" textAnchor="middle" filter="drop-shadow(0px 1px 2px rgba(0,0,0,0.8))">7</text>
    {/* Golden "7" on Reel 2 */}
    <text x="50" y="56" fontSize="20" fontWeight="900" fill="url(#gold7)" textAnchor="middle" filter="drop-shadow(0px 1px 2px rgba(0,0,0,0.8))">7</text>
    {/* Golden "7" on Reel 3 */}
    <text x="69" y="56" fontSize="20" fontWeight="900" fill="url(#gold7)" textAnchor="middle" filter="drop-shadow(0px 1px 2px rgba(0,0,0,0.8))">7</text>
    {/* Side Pull Lever */}
    <path d="M85 45 C90 45 92 35 92 28" stroke="#d2dae2" strokeWidth="3" strokeLinecap="round" fill="none" />
    <circle cx="92" cy="27" r="5" fill="#eb4d4b" stroke="#c0392b" strokeWidth="1" />
    {/* Spilling Gold Coins at Bottom */}
    <ellipse cx="32" cy="78" rx="8" ry="4.5" fill="#ffd700" stroke="#d4af37" strokeWidth="1" />
    <ellipse cx="50" cy="80" rx="10" ry="5" fill="#ffd700" stroke="#d4af37" strokeWidth="1" />
    <ellipse cx="68" cy="78" rx="8" ry="4.5" fill="#ffd700" stroke="#d4af37" strokeWidth="1" />
    <defs>
      <linearGradient id="slotBody" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#d63031" />
        <stop offset="100%" stopColor="#80061b" />
      </linearGradient>
      <linearGradient id="gold7" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#fff3a8" />
        <stop offset="40%" stopColor="#ffd700" />
        <stop offset="100%" stopColor="#e6a100" />
      </linearGradient>
    </defs>
  </svg>
);

// 3D Classic Football / Soccer for 'Sports'
const Sports3DIcon = () => (
  <svg viewBox="0 0 60 60" className="w-10 h-10 drop-shadow-md" fill="none">
    <circle cx="30" cy="30" r="24" fill="#f5f6fa" stroke="#dcdde1" strokeWidth="1.5" />
    {/* Center Red/Pink Pentagon */}
    <polygon points="30,20 38,26 35,36 25,36 22,26" fill="#e84118" />
    {/* Radiating Lines to Outer Pentagons */}
    <line x1="30" y1="20" x2="30" y2="8" stroke="#2f3640" strokeWidth="1.5" />
    <line x1="38" y1="26" x2="48" y2="20" stroke="#2f3640" strokeWidth="1.5" />
    <line x1="35" y1="36" x2="44" y2="46" stroke="#2f3640" strokeWidth="1.5" />
    <line x1="25" y1="36" x2="16" y2="46" stroke="#2f3640" strokeWidth="1.5" />
    <line x1="22" y1="26" x2="12" y2="20" stroke="#2f3640" strokeWidth="1.5" />
    {/* Outer Accent Patches */}
    <polygon points="26,6 34,6 30,8" fill="#e84118" />
    <polygon points="50,18 54,26 48,20" fill="#e84118" />
    <polygon points="46,48 40,53 44,46" fill="#e84118" />
    <polygon points="14,48 20,53 16,46" fill="#e84118" />
    <polygon points="10,18 6,26 12,20" fill="#e84118" />
    {/* Highlight Glow */}
    <circle cx="22" cy="18" r="6" fill="#ffffff" opacity="0.4" />
  </svg>
);

// 3D Casino Live Dealer / Chips & Dice for 'Casino'
const Casino3DIcon = () => (
  <svg viewBox="0 0 60 60" className="w-10 h-10 drop-shadow-md" fill="none">
    {/* Dealer / Woman Silhouette with Red Bow */}
    <ellipse cx="30" cy="46" rx="16" ry="10" fill="#c0392b" />
    <circle cx="30" cy="24" r="10" fill="#f8c291" />
    {/* Hair */}
    <path d="M20 23 C20 12 40 12 40 23 C40 28 38 32 38 32 C38 26 36 22 30 22 C24 22 22 26 22 32 Z" fill="#2d3436" />
    {/* Dice 1 (Red with white pips) */}
    <rect x="8" y="32" width="14" height="14" rx="3" fill="#e74c3c" stroke="#c0392b" strokeWidth="1" transform="rotate(15 15 39)" />
    <circle cx="15" cy="39" r="1.5" fill="#ffffff" />
    {/* Casino Chip (Gold/Black) */}
    <circle cx="46" cy="38" r="10" fill="#f1c40f" stroke="#d4ac0d" strokeWidth="2" strokeDasharray="4 2" />
    <circle cx="46" cy="38" r="5" fill="#2c3e50" />
    <circle cx="46" cy="38" r="3" fill="#ffffff" />
  </svg>
);

// 3D Royal Cards & Poker Pedestal for 'Rummy'
const Rummy3DIcon = () => (
  <svg viewBox="0 0 60 60" className="w-10 h-10 drop-shadow-md" fill="none">
    {/* Round Golden Pedestal Base */}
    <ellipse cx="30" cy="48" rx="18" ry="7" fill="#ffd700" stroke="#d4af37" strokeWidth="1.5" />
    <ellipse cx="30" cy="46" rx="14" ry="4.5" fill="#fff3a8" />
    {/* Card 1 - Back/Ace of Hearts */}
    <rect x="14" y="14" width="20" height="28" rx="3" fill="#ffffff" stroke="#dcdde1" strokeWidth="1" transform="rotate(-15 24 28)" />
    <text x="18" y="24" fontSize="7" fontWeight="bold" fill="#e74c3c" transform="rotate(-15 24 28)">A♥</text>
    {/* Card 2 - Front/Ace of Spades */}
    <rect x="25" y="12" width="20" height="28" rx="3" fill="#ffffff" stroke="#dcdde1" strokeWidth="1" transform="rotate(12 35 26)" />
    <text x="29" y="22" fontSize="7" fontWeight="bold" fill="#2c3e50" transform="rotate(12 35 26)">A♠</text>
    {/* Floating Dice */}
    <rect x="36" y="38" width="10" height="10" rx="2" fill="#ffffff" stroke="#b2bec3" strokeWidth="0.8" />
    <circle cx="41" cy="43" r="1" fill="#e74c3c" />
  </svg>
);

// 3D Cute Cartoon Shark for 'Fishing'
const Fishing3DIcon = () => (
  <svg viewBox="0 0 80 60" className="w-14 h-11 drop-shadow-md" fill="none">
    {/* Bubbles */}
    <circle cx="12" cy="18" r="3" fill="#81ecec" opacity="0.6" />
    <circle cx="18" cy="10" r="2" fill="#81ecec" opacity="0.5" />
    {/* Shark Body */}
    <path
      d="M16 32 C20 18 45 16 68 28 C74 22 78 18 78 18 L76 34 L78 46 C74 44 70 38 66 36 C45 48 22 46 16 32 Z"
      fill="url(#sharkBlue)"
      stroke="#0984e3"
      strokeWidth="1"
    />
    {/* White Belly */}
    <path d="M22 34 C30 42 50 42 64 36 C52 45 30 44 22 34 Z" fill="#ffffff" />
    {/* Shark Dorsal Fin */}
    <path d="M38 18 C38 18 44 8 48 16 Z" fill="#0984e3" />
    {/* Pectoral Fin */}
    <path d="M32 34 L28 44 L38 38 Z" fill="#0984e3" />
    {/* Big Cute Eye */}
    <circle cx="25" cy="26" r="4.5" fill="#ffffff" />
    <circle cx="24" cy="26" r="2.5" fill="#2d3436" />
    <circle cx="23" cy="25" r="1" fill="#ffffff" />
    {/* Bowtie on Shark */}
    <polygon points="32,32 38,36 38,28" fill="#2d3436" />
    <polygon points="44,32 38,28 38,36" fill="#2d3436" />
    <circle cx="38" cy="32" r="1.5" fill="#e74c3c" />
    <defs>
      <linearGradient id="sharkBlue" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#74b9ff" />
        <stop offset="100%" stopColor="#0984e3" />
      </linearGradient>
    </defs>
  </svg>
);

// 3D Red Aviator Biplane & Golden Gift Box for 'Original'
const Original3DIcon = () => (
  <svg viewBox="0 0 80 60" className="w-14 h-11 drop-shadow-md" fill="none">
    {/* Golden Gift Box with Red Ribbon */}
    <rect x="48" y="32" width="22" height="20" rx="3" fill="#f1c40f" stroke="#d4ac0d" strokeWidth="1" />
    <rect x="46" y="28" width="26" height="6" rx="2" fill="#ffd32a" stroke="#d4ac0d" strokeWidth="1" />
    <line x1="59" y1="28" x2="59" y2="52" stroke="#e74c3c" strokeWidth="3" />
    <path d="M59 28 C55 22 51 22 55 26 C59 26 59 28 59 28 Z" fill="#e74c3c" />
    <path d="M59 28 C63 22 67 22 63 26 C59 26 59 28 59 28 Z" fill="#e74c3c" />
    {/* Red Retro Aviator Aircraft Flying */}
    <g transform="rotate(-15 30 25)">
      {/* Fuselage */}
      <ellipse cx="28" cy="22" rx="20" ry="7" fill="url(#planeRed)" stroke="#b71540" strokeWidth="1" />
      {/* Upper Wing */}
      <rect x="18" y="9" width="26" height="5" rx="2.5" fill="#eb4d4b" stroke="#b71540" strokeWidth="0.8" />
      {/* Struts */}
      <line x1="22" y1="14" x2="22" y2="20" stroke="#747d8c" strokeWidth="1.5" />
      <line x1="38" y1="14" x2="38" y2="20" stroke="#747d8c" strokeWidth="1.5" />
      {/* Cockpit / Windshield */}
      <path d="M26 17 C28 13 32 13 34 17 Z" fill="#81ecec" stroke="#ffffff" strokeWidth="0.8" />
      {/* Tail Fin */}
      <polygon points="10,16 14,22 8,22" fill="#eb4d4b" stroke="#b71540" strokeWidth="0.8" />
      {/* Front Propeller Spinner */}
      <circle cx="48" cy="22" r="3.5" fill="#f5cd79" />
      <ellipse cx="48" cy="22" rx="1.5" ry="11" fill="#ffffff" opacity="0.8" />
    </g>
    <defs>
      <linearGradient id="planeRed" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ff7675" />
        <stop offset="100%" stopColor="#d63031" />
      </linearGradient>
    </defs>
  </svg>
);

export const CategoryCardView: React.FC<CategoryCardViewProps> = ({
  selectedCategory,
  onSelectCategory
}) => {
  return (
    <div className="w-full space-y-2 select-none" id="bgnice-game-categories">
      {/* Top Row: 3 Tall Vertical Cards (Popular, Lottery, Slots) */}
      <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
        {/* Card 1: Popular */}
        <button
          onClick={() => onSelectCategory('popular')}
          className={`relative rounded-2xl p-2 sm:p-2.5 flex flex-col items-center justify-between h-[115px] sm:h-[130px] transition-all cursor-pointer shadow-md bg-gradient-to-b from-[#3a8ef6] via-[#2f80ed] to-[#00f2fe] overflow-hidden ${
            selectedCategory === 'popular'
              ? 'ring-3 ring-amber-300 scale-[1.03] shadow-blue-500/40'
              : 'hover:brightness-105 active:scale-98 opacity-95'
          }`}
          id="cat-card-popular"
        >
          {/* Subtle top gloss */}
          <div className="absolute top-0 inset-x-0 h-1/3 bg-white/20 rounded-t-2xl pointer-events-none" />
          <div className="flex-1 flex items-center justify-center pt-1">
            <Trophy3DIcon />
          </div>
          <span className="text-white font-black text-xs sm:text-sm tracking-wide drop-shadow-md pb-0.5">
            Popular
          </span>
          {selectedCategory === 'popular' && (
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-amber-300 ring-2 ring-white animate-pulse" />
          )}
        </button>

        {/* Card 2: Lottery */}
        <button
          onClick={() => onSelectCategory('lottery')}
          className={`relative rounded-2xl p-2 sm:p-2.5 flex flex-col items-center justify-between h-[115px] sm:h-[130px] transition-all cursor-pointer shadow-md bg-gradient-to-b from-[#b276f8] via-[#a18cd1] to-[#fbc2eb] overflow-hidden ${
            selectedCategory === 'lottery'
              ? 'ring-3 ring-amber-300 scale-[1.03] shadow-purple-500/40'
              : 'hover:brightness-105 active:scale-98 opacity-95'
          }`}
          id="cat-card-lottery"
        >
          <div className="absolute top-0 inset-x-0 h-1/3 bg-white/20 rounded-t-2xl pointer-events-none" />
          <div className="flex-1 flex items-center justify-center pt-1">
            <Lottery3DIcon />
          </div>
          <span className="text-white font-black text-xs sm:text-sm tracking-wide drop-shadow-md pb-0.5">
            Lottery
          </span>
          {selectedCategory === 'lottery' && (
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-amber-300 ring-2 ring-white animate-pulse" />
          )}
        </button>

        {/* Card 3: Slots */}
        <button
          onClick={() => onSelectCategory('slots')}
          className={`relative rounded-2xl p-2 sm:p-2.5 flex flex-col items-center justify-between h-[115px] sm:h-[130px] transition-all cursor-pointer shadow-md bg-gradient-to-b from-[#2193b0] via-[#38ef7d]/60 to-[#6dd5ed] overflow-hidden ${
            selectedCategory === 'slots'
              ? 'ring-3 ring-amber-300 scale-[1.03] shadow-cyan-500/40'
              : 'hover:brightness-105 active:scale-98 opacity-95'
          }`}
          id="cat-card-slots"
        >
          <div className="absolute top-0 inset-x-0 h-1/3 bg-white/20 rounded-t-2xl pointer-events-none" />
          <div className="flex-1 flex items-center justify-center pt-1">
            <Slots3DIcon />
          </div>
          <span className="text-white font-black text-xs sm:text-sm tracking-wide drop-shadow-md pb-0.5">
            Slots
          </span>
          {selectedCategory === 'slots' && (
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-amber-300 ring-2 ring-white animate-pulse" />
          )}
        </button>
      </div>

      {/* Middle Row: Rounded Coral/Peach Bar with 3 Sections (Sports, Casino, Rummy) */}
      <div className="rounded-2xl p-1.5 sm:p-2 bg-gradient-to-r from-[#ff6b6b] via-[#ff758c] to-[#ff8e53] shadow-md grid grid-cols-3 divide-x divide-white/25">
        {/* Section 1: Sports */}
        <button
          onClick={() => onSelectCategory('sports')}
          className={`flex flex-col items-center justify-center py-1.5 sm:py-2 px-1 rounded-xl transition-all cursor-pointer ${
            selectedCategory === 'sports'
              ? 'bg-white/25 ring-2 ring-amber-300 shadow-inner scale-[1.02]'
              : 'hover:bg-white/10 active:scale-95'
          }`}
          id="cat-sec-sports"
        >
          <Sports3DIcon />
          <span className="text-white font-black text-xs mt-0.5 drop-shadow-sm">
            Sports
          </span>
        </button>

        {/* Section 2: Casino */}
        <button
          onClick={() => onSelectCategory('casino')}
          className={`flex flex-col items-center justify-center py-1.5 sm:py-2 px-1 rounded-xl transition-all cursor-pointer ${
            selectedCategory === 'casino'
              ? 'bg-white/25 ring-2 ring-amber-300 shadow-inner scale-[1.02]'
              : 'hover:bg-white/10 active:scale-95'
          }`}
          id="cat-sec-casino"
        >
          <Casino3DIcon />
          <span className="text-white font-black text-xs mt-0.5 drop-shadow-sm">
            Casino
          </span>
        </button>

        {/* Section 3: Rummy */}
        <button
          onClick={() => onSelectCategory('rummy')}
          className={`flex flex-col items-center justify-center py-1.5 sm:py-2 px-1 rounded-xl transition-all cursor-pointer ${
            selectedCategory === 'rummy'
              ? 'bg-white/25 ring-2 ring-amber-300 shadow-inner scale-[1.02]'
              : 'hover:bg-white/10 active:scale-95'
          }`}
          id="cat-sec-rummy"
        >
          <Rummy3DIcon />
          <span className="text-white font-black text-xs mt-0.5 drop-shadow-sm">
            Rummy
          </span>
        </button>
      </div>

      {/* Bottom Row: 2 Wide Horizontal Cards (Fishing, Original) */}
      <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
        {/* Card 1: Fishing */}
        <button
          onClick={() => onSelectCategory('fishing')}
          className={`relative rounded-2xl p-2.5 sm:p-3 flex items-center justify-between h-[65px] sm:h-[72px] transition-all cursor-pointer shadow-md bg-gradient-to-r from-[#f6d365] to-[#fda085] overflow-hidden ${
            selectedCategory === 'fishing'
              ? 'ring-3 ring-amber-400 scale-[1.02] shadow-orange-500/40'
              : 'hover:brightness-105 active:scale-98 opacity-95'
          }`}
          id="cat-card-fishing"
        >
          <div className="flex items-center justify-center -ml-1">
            <Fishing3DIcon />
          </div>
          <span className="text-white font-black text-sm sm:text-base tracking-wide drop-shadow-md pr-2">
            Fishing
          </span>
          {selectedCategory === 'fishing' && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-300 ring-2 ring-white animate-pulse" />
          )}
        </button>

        {/* Card 2: Original */}
        <button
          onClick={() => onSelectCategory('original')}
          className={`relative rounded-2xl p-2.5 sm:p-3 flex items-center justify-between h-[65px] sm:h-[72px] transition-all cursor-pointer shadow-md bg-gradient-to-r from-[#ff5858] via-[#f09819] to-[#fa709a] overflow-hidden ${
            selectedCategory === 'original'
              ? 'ring-3 ring-amber-300 scale-[1.02] shadow-pink-500/40'
              : 'hover:brightness-105 active:scale-98 opacity-95'
          }`}
          id="cat-card-original"
        >
          <div className="flex items-center justify-center -ml-1">
            <Original3DIcon />
          </div>
          <span className="text-white font-black text-sm sm:text-base tracking-wide drop-shadow-md pr-2">
            Original
          </span>
          {selectedCategory === 'original' && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-300 ring-2 ring-white animate-pulse" />
          )}
        </button>
      </div>
    </div>
  );
};
