import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Copy,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ShieldCheck,
  QrCode,
  Info,
  Check,
  X,
  Maximize2
} from 'lucide-react';
import { DepositChannel } from '../types';
import { EWALLET_DEFAULT_IMAGE } from '../utils/defaultChannels';
import { PAYMENT_LOGOS } from '../utils/paymentLogos';
import { PaymentGuideGraphic } from './PaymentGuideGraphics';

interface DepositRequestPageProps {
  channel: DepositChannel;
  amount: number;
  onBack: () => void;
  onSubmitTxn: (channel: DepositChannel, amount: number, txnId: string) => Promise<boolean>;
  showToast: (msg: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
}

export const DepositRequestPage: React.FC<DepositRequestPageProps> = ({
  channel,
  amount,
  onBack,
  onSubmitTxn,
  showToast
}) => {
  const [txnId, setTxnId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [lang, setLang] = useState<'bn' | 'en'>('bn');
  const [zoomImage, setZoomImage] = useState<string | null>(null);
  const [isZoomOpen, setIsZoomOpen] = useState(false);

  // Custom countdown minutes or 15 mins default
  const defaultSeconds = (channel.countdownMinutes ? channel.countdownMinutes : 15) * 60;
  const [timeLeft, setTimeLeft] = useState(defaultSeconds);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatCountdown = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleCopy = (text: string, field: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    showToast(lang === 'bn' ? `${field} কপি হয়েছে!` : `Copied ${field} to clipboard!`, 'success');
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (channel.transactionRequired && !txnId.trim()) {
      showToast(
        lang === 'bn' ? 'অনুগ্রহ করে Transaction ID প্রদান করুন' : 'Please enter Transaction ID',
        'error'
      );
      return;
    }
    setIsSubmitting(true);
    await onSubmitTxn(channel, amount, txnId.trim());
    setIsSubmitting(false);
  };

  const isUsdt = channel.paymentType === 'USDT' || channel.currency === 'USDT';
  const currencySymbol = isUsdt ? '$' : '৳';
  const template = channel.requestPage || 'A';
  const paymentTarget = channel.walletAddress || channel.paymentNumber;

  // Determine Send Money vs Cash Out
  const isSendMoney =
    channel.transferType === 'Send Money' ||
    channel.accountType.toLowerCase().includes('send money') ||
    channel.accountType.toLowerCase().includes('personal');

  // Channel Logo Fallback
  const channelLogo =
    channel.logo ||
    (channel.paymentType === 'bKash'
      ? PAYMENT_LOGOS.bkash
      : channel.paymentType === 'Nagad'
      ? PAYMENT_LOGOS.nagad
      : channel.paymentType === 'Rocket'
      ? PAYMENT_LOGOS.rocket
      : channel.paymentType === 'USDT'
      ? PAYMENT_LOGOS.usdt
      : EWALLET_DEFAULT_IMAGE);

  // 4 Consistent Visual Themes Matching Bangladeshi Cashier Gateways
  const getTheme = () => {
    switch (template) {
      case 'A':
        return {
          themeName: 'Nagad / GoPay Orange',
          headerBg: 'bg-gradient-to-r from-[#ff6000] via-[#ff4500] to-[#e63900]',
          accentColor: '#ff6000',
          accentText: 'text-[#ff5000]',
          badgeBg: 'bg-orange-100 text-orange-800 border-orange-200',
          containerBg: 'bg-[#fff9f5]',
          cardBorder: 'border-orange-200',
          copyBtn: 'bg-gradient-to-r from-[#ff6000] to-[#ff4500]',
          submitBtn:
            'bg-gradient-to-r from-[#ff6000] to-[#ff4500] hover:from-[#e65500] hover:to-[#d63b00] shadow-orange-500/30'
        };
      case 'B':
        return {
          themeName: 'bKash Pink/Red',
          headerBg: 'bg-gradient-to-r from-[#e2136e] via-[#c70f5e] to-[#a00949]',
          accentColor: '#e2136e',
          accentText: 'text-[#e2136e]',
          badgeBg: 'bg-pink-100 text-pink-800 border-pink-200',
          containerBg: 'bg-[#fff5f8]',
          cardBorder: 'border-pink-200',
          copyBtn: 'bg-gradient-to-r from-[#e2136e] to-[#c70f5e]',
          submitBtn:
            'bg-gradient-to-r from-[#e2136e] to-[#b30851] hover:from-[#c70f5e] hover:to-[#9c0746] shadow-pink-500/30'
        };
      case 'C':
        return {
          themeName: 'Green Premium Payment',
          headerBg: 'bg-gradient-to-r from-[#059669] via-[#10b981] to-[#047857]',
          accentColor: '#059669',
          accentText: 'text-[#059669]',
          badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          containerBg: 'bg-[#f4fdf8]',
          cardBorder: 'border-emerald-200',
          copyBtn: 'bg-gradient-to-r from-[#059669] to-[#10b981]',
          submitBtn:
            'bg-gradient-to-r from-[#059669] to-[#047857] hover:from-[#047857] hover:to-[#065f46] shadow-emerald-500/30'
        };
      case 'D':
      default:
        return {
          themeName: 'USDT Crypto Dark',
          headerBg: 'bg-gradient-to-r from-[#0f172a] via-[#1e293b] to-[#0369a1]',
          accentColor: '#0284c7',
          accentText: 'text-cyan-600',
          badgeBg: 'bg-slate-100 text-slate-800 border-slate-200',
          containerBg: 'bg-[#f8fafc]',
          cardBorder: 'border-slate-200',
          copyBtn: 'bg-gradient-to-r from-[#0284c7] to-[#0369a1]',
          submitBtn:
            'bg-gradient-to-r from-[#0284c7] to-[#0f172a] hover:from-[#0369a1] hover:to-[#0284c7] shadow-cyan-500/30'
        };
    }
  };

  const theme = getTheme();

  const handleOpenZoom = (imgUrl?: string) => {
    if (imgUrl) {
      setZoomImage(imgUrl);
      setIsZoomOpen(true);
    }
  };

  return (
    <div className={`min-h-screen ${theme.containerBg} pb-20 text-slate-800 select-none`}>
      {/* Top Header Bar with Language and Countdown Timer */}
      <div
        className={`${theme.headerBg} text-white px-4 py-3 sticky top-0 z-30 shadow-md flex items-center justify-between`}
      >
        <button
          onClick={onBack}
          className="p-1.5 -ml-1 text-white hover:bg-white/15 rounded-full active:scale-95 transition-all"
          id="request-page-back-btn"
          aria-label="Back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-2">
          {/* Language Switcher Pill */}
          <button
            type="button"
            onClick={() => setLang(lang === 'bn' ? 'en' : 'bn')}
            className="bg-black/20 hover:bg-black/30 border border-white/25 text-white px-2.5 py-1 rounded-full text-xs font-bold transition-all flex items-center space-x-1"
          >
            <span>{lang === 'bn' ? 'বাংলা' : 'English'}</span>
            <span className="text-[10px] opacity-75">▾</span>
          </button>

          {/* Countdown Badge */}
          <div className="flex items-center space-x-1.5 bg-black/25 backdrop-blur-xs px-2.5 py-1 rounded-full text-xs font-mono font-bold border border-white/20">
            <Clock className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
            <span className="text-amber-200">⏱ {formatCountdown(timeLeft)}</span>
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* Payable Order Amount Card (Matching User Screenshot 3 & 4) */}
        <div className={`bg-white rounded-3xl p-4 shadow-sm border ${theme.cardBorder} flex items-center justify-between`}>
          <div>
            <span className="text-xs font-bold text-slate-500 block">
              {lang === 'bn' ? 'পরিশোধের পরিমাণ' : 'Payable Amount'}
            </span>
            <div className="flex items-baseline space-x-1 mt-0.5">
              <span className="text-xs font-bold text-slate-600">
                {isUsdt ? 'USDT' : 'BDT'}
              </span>
              <span className={`text-2xl font-black ${theme.accentText} tracking-tight font-mono`}>
                {amount.toFixed(2)}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => handleCopy(amount.toString(), lang === 'bn' ? 'পরিমাণ' : 'Amount')}
            className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xs active:scale-90 transition-all ${theme.copyBtn}`}
            title="Copy Amount"
          >
            {copiedField === (lang === 'bn' ? 'পরিমাণ' : 'Amount') ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : (
              <Copy className="w-5 h-5" />
            )}
          </button>
        </div>

        {/* Recipient Account Number Card */}
        <div className={`bg-white rounded-3xl p-4 shadow-sm border ${theme.cardBorder} flex items-center justify-between`}>
          <div className="flex items-center space-x-3 min-w-0 pr-2">
            <div className="w-12 h-12 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center p-1.5 overflow-hidden shadow-2xs shrink-0">
              <img
                src={channelLogo}
                alt={channel.paymentType}
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="min-w-0">
              <div className="text-[11px] text-slate-500 font-bold truncate">
                {lang === 'bn' ? 'যাকে পেমেন্ট করবেন' : 'Recipient'} • {channel.paymentType}
              </div>
              <div className="font-mono font-black text-slate-900 text-sm sm:text-base break-all select-all">
                {paymentTarget}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => handleCopy(paymentTarget, lang === 'bn' ? 'নম্বর' : 'Number')}
            className={`px-3 py-2 rounded-xl text-white text-xs font-bold flex items-center space-x-1.5 shadow-xs active:scale-95 transition-all shrink-0 ${theme.copyBtn}`}
          >
            {copiedField === (lang === 'bn' ? 'নম্বর' : 'Number') ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'কপি হয়েছে' : 'Copied'}</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'কপি করুন' : 'Copy'}</span>
              </>
            )}
          </button>
        </div>

        {/* USDT Template D - QR Code & Network Badge */}
        {isUsdt && template === 'D' && (
          <div className="bg-gradient-to-b from-slate-900 to-slate-800 rounded-3xl p-5 text-white shadow-md border border-slate-700 space-y-3.5 text-center">
            <div className="flex items-center justify-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
              <QrCode className="w-4 h-4" />
              <span>Scan QR to Deposit USDT ({channel.network || 'TRC20'})</span>
            </div>
            <div className="w-40 h-40 mx-auto bg-white rounded-2xl p-2 flex items-center justify-center shadow-lg border-2 border-cyan-400/40">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(paymentTarget)}`}
                alt="USDT Wallet QR Code"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="inline-block bg-cyan-950/80 border border-cyan-500/40 rounded-full px-3 py-1 text-[11px] text-cyan-300 font-bold">
              Only send USDT via {channel.network || 'TRC20'} network!
            </div>
          </div>
        )}

        {/* Transfer Instructions & 2 Screenshot Tutorials (Send Money vs Cash Out Rules) */}
        <div className={`bg-white rounded-3xl p-4 sm:p-5 shadow-sm border ${theme.cardBorder} space-y-3.5`}>
          {/* Main Instruction Header */}
          <div className="text-center space-y-1">
            <h2 className="text-sm sm:text-base font-black text-slate-900 leading-snug">
              {channel.title ||
                (isSendMoney
                  ? `${channel.paymentType}-এ শুধুমাত্র Send Money দিয়ে ট্রান্সফার করুন`
                  : `${channel.paymentType}-এ শুধুমাত্র Cash Out দিয়ে ট্রান্সফার করুন`)}
            </h2>
            <p className="text-[11px] text-slate-500 font-medium">
              {isSendMoney
                ? 'নিচের আসল অ্যাপ স্ক্রিন দেখে একইভাবে ট্রান্সফার সম্পন্ন করুন।'
                : 'নিচের আসল এজেন্ট নাম্বারে ক্যাশআউট সম্পন্ন করুন।'}
            </p>
          </div>

          {/* Badge Indicator */}
          <div className="flex justify-center">
            <span
              className={`px-3 py-1 rounded-full text-xs font-extrabold border ${
                isSendMoney
                  ? 'bg-blue-50 text-blue-800 border-blue-200'
                  : 'bg-emerald-50 text-emerald-800 border-emerald-200'
              }`}
            >
              ✓ {isSendMoney ? 'শুধুমাত্র Send Money / সেন্ড মানি' : 'শুধুমাত্র Cash Out / ক্যাশ আউট'}
            </span>
          </div>

          {/* 2 Screenshot Guide Grid (Side-by-side on mobile) */}
          <div className="grid grid-cols-2 gap-2.5 pt-1">
            {/* Screenshot Card 1 */}
            <div className="space-y-1.5">
              <PaymentGuideGraphic
                type="step1"
                paymentType={channel.paymentType}
                isSendMoney={isSendMoney}
                paymentTarget={paymentTarget}
                amount={amount}
                imageUrl={channel.step1Image}
                onOpenZoom={handleOpenZoom}
              />
              <div className="text-center">
                <span className="inline-block bg-slate-100 text-slate-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-slate-200 truncate max-w-full">
                  ❶ {channel.step1Title || (isSendMoney ? 'Send Money নির্বাচন করুন' : 'Cash Out নির্বাচন করুন')}
                </span>
              </div>
            </div>

            {/* Screenshot Card 2 */}
            <div className="space-y-1.5">
              <PaymentGuideGraphic
                type="step2"
                paymentType={channel.paymentType}
                isSendMoney={isSendMoney}
                paymentTarget={paymentTarget}
                amount={amount}
                imageUrl={channel.step2Image}
                onOpenZoom={handleOpenZoom}
              />
              <div className="text-center">
                <span className="inline-block bg-slate-100 text-slate-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-slate-200 truncate max-w-full">
                  ❷ {channel.step2Title || 'Transaction ID কোথায় পাবেন দেখুন'}
                </span>
              </div>
            </div>
          </div>

          {/* Rule Note Callout */}
          <div className="bg-red-50 border border-red-200 rounded-2xl p-2.5 flex items-start space-x-2 text-[11px] text-red-900 font-semibold leading-relaxed">
            <span className="text-red-600 font-black text-sm leading-none mt-0.5">!</span>
            <span>
              {isSendMoney
                ? 'অর্থ স্থানান্তর করতে অনুগ্রহ করে শুধুমাত্র Send Money / সেন্ড মানি ব্যবহার করুন।'
                : 'এই এজেন্ট অ্যাকাউন্টে অর্থ প্রদান করতে শুধুমাত্র ক্যাশ আউট (Cash Out) ব্যবহার করুন।'}
            </span>
          </div>

          {/* Custom Step Instructions if set by Admin */}
          {channel.instructions && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 text-xs text-slate-700 leading-relaxed font-medium">
              <div className="font-bold text-slate-900 mb-1 flex items-center space-x-1.5">
                <Info className="w-3.5 h-3.5 text-blue-600" />
                <span>পেমেন্ট নির্দেশিকা:</span>
              </div>
              <p className="whitespace-pre-line text-[11px]">{channel.instructions}</p>
            </div>
          )}
        </div>

        {/* Transaction ID Submission Form (Matching Screenshot 3 & 4) */}
        <form
          onSubmit={handleSubmit}
          className={`bg-white rounded-3xl p-5 shadow-sm border ${theme.cardBorder} space-y-4`}
        >
          <div>
            <label className="text-xs font-black text-slate-900 block mb-1.5">
              {lang === 'bn' ? 'ট্রানজ্যাকশন আইডি' : 'Transaction ID'}
              {channel.transactionRequired && <span className="text-red-500 ml-1">*</span>}
            </label>
            <input
              type="text"
              value={txnId}
              onChange={(e) => setTxnId(e.target.value.trim())}
              placeholder={
                lang === 'bn'
                  ? 'ট্রানজ্যাকশন আইডি লিখুন'
                  : isUsdt
                  ? 'Paste TxHash e.g. 0x8f4c...'
                  : 'Enter 8-10 digit Transaction ID'
              }
              className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-red-500 focus:bg-white transition-all shadow-inner"
              required={channel.transactionRequired}
              id="deposit-txid-input"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className={`w-full py-3.5 rounded-2xl text-white font-extrabold text-sm shadow-md active:scale-98 transition-all flex items-center justify-center space-x-2 disabled:opacity-50 ${theme.submitBtn}`}
            id="deposit-submit-btn"
          >
            {isSubmitting ? (
              <span>যাচাই ও জমা হচ্ছে...</span>
            ) : (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>{channel.buttonText || (lang === 'bn' ? 'জমা দিন' : 'Submit Deposit')}</span>
              </>
            )}
          </button>

          <div className="flex items-center justify-center space-x-1 text-[11px] text-emerald-700 font-extrabold pt-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>✓ ১০০% নিরাপদ পেমেন্ট</span>
          </div>
        </form>

        {/* Important Warning Notice Box (Matching User Screenshots) */}
        <div className="bg-amber-50 border border-amber-200 rounded-3xl p-4 space-y-2 text-xs">
          <div className="flex items-center space-x-1.5 font-black text-amber-900">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>⚠️ গুরুত্বপূর্ণ সতর্কতা</span>
          </div>
          <p className="text-amber-950/90 text-[11px] leading-relaxed font-medium">
            <strong>Transaction ID (TrxID / Transaction ID) ভুল দেবেন না:</strong> {channel.paymentType}-এ ট্রান্সফার
            সম্পন্ন হলে একটি লেনদেন নম্বর তৈরি হবে। সেটি হুবহু কপি করে প্ল্যাটফর্মে লিখুন, নইলে সিস্টেম স্বয়ংক্রিয়ভাবে আপনার
            পেমেন্ট মিলিয়ে ব্যালেন্স যোগ করতে পারবে না।
          </p>
          {channel.warningText && (
            <div className="pt-2 border-t border-amber-200/80 text-[11px] text-amber-900 font-semibold">
              * {channel.warningText}
            </div>
          )}
        </div>
      </div>

      {/* Lightbox / Zoom Modal for Guide Screenshot */}
      {isZoomOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setIsZoomOpen(false)}
        >
          <div
            className="bg-white rounded-3xl max-w-sm w-full p-4 space-y-3 relative shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <span className="text-xs font-bold text-slate-800">স্ক্রিনশট গাইড</span>
              <button
                type="button"
                onClick={() => setIsZoomOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 font-bold text-sm"
              >
                ✕
              </button>
            </div>
            <div className="rounded-2xl overflow-hidden bg-slate-950 flex items-center justify-center p-1 max-h-[70vh]">
              {zoomImage ? (
                <img
                  src={zoomImage}
                  alt="Zoomed Screenshot"
                  className="w-full h-auto max-h-[65vh] object-contain"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="p-4 text-xs text-slate-400 text-center">কোনো ছবি পাওয়া যায়নি</div>
              )}
            </div>
            <button
              type="button"
              onClick={() => setIsZoomOpen(false)}
              className="w-full py-2 bg-slate-900 text-white rounded-xl text-xs font-bold"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
