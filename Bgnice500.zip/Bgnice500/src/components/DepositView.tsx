import React, { useState, useEffect } from 'react';
import {
  Copy,
  RefreshCw,
  ChevronRight,
  CheckCircle2,
  AlertCircle,
  ArrowLeft,
  Clock,
  ExternalLink,
  ShieldCheck,
  X,
  Sparkles
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PAYMENT_LOGOS } from '../utils/paymentLogos';
import { DepositChannel, DepositItem } from '../types';
import { DEFAULT_DEPOSIT_CHANNELS } from '../utils/defaultChannels';
import { DepositRequestPage } from './DepositRequestPage';

interface DepositViewProps {
  onBack: () => void;
}

export const DepositView: React.FC<DepositViewProps> = ({ onBack }) => {
  const {
    user,
    deposits = [],
    depositChannels,
    submitDepositChannelRequest,
    submitDeposit,
    showToast,
    refreshBalance,
    isRefreshingBalance
  } = useApp() as any;

  const [paymentType, setPaymentType] = useState<'Nagad' | 'bKash' | 'Rocket' | 'USDT'>('Nagad');
  const [selectedChannel, setSelectedChannel] = useState<DepositChannel | null>(null);
  const [amount, setAmount] = useState<number>(500);
  const [customAmount, setCustomAmount] = useState<string>('500');
  const [showHistory, setShowHistory] = useState(false);
  const [historyFilter, setHistoryFilter] = useState<'all' | 'completed' | 'pending' | 'rejected'>('all');

  // Strictly filter deposits to only belong to the current authenticated user
  const userDeposits = React.useMemo(() => {
    if (!user) return [];
    return (deposits || []).filter((dep: DepositItem) => {
      if (!dep) return false;
      return Boolean(
        (dep.uid && dep.uid === user.uid) ||
        ((dep as any).userId && (dep as any).userId === user.uid) ||
        (user.phone && dep.phone && String(dep.phone).trim() === String(user.phone).trim()) ||
        (user.username && dep.username && String(dep.username).trim() === String(user.username).trim())
      );
    });
  }, [deposits, user]);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard?.writeText(text);
    showToast(`${label} copied to clipboard!`, 'success');
  };

  const formatOrderId = (dep: DepositItem) => {
    if (dep.orderId) return dep.orderId;
    const dateStr = new Date(dep.createdAt || Date.now()).toISOString().slice(0, 10).replace(/-/g, '');
    const numPart = (dep.id || '').replace(/[^0-9]/g, '').slice(-6).padStart(6, '9');
    return `D${dateStr}${numPart}`;
  };

  // Active Checkout Request Page state
  const [activeRequestChannel, setActiveRequestChannel] = useState<DepositChannel | null>(null);

  // 3D Premium Success Card state
  const [successModalData, setSuccessModalData] = useState<{
    amount: number;
    paymentType: string;
    channel: string;
    txnId: string;
  } | null>(null);

  // Guaranteed safe channel list
  const safeChannels: DepositChannel[] = (Array.isArray(depositChannels) && depositChannels.length > 0)
    ? depositChannels
    : DEFAULT_DEPOSIT_CHANNELS;

  // Filter channels by selected payment type and enabled state
  const availableChannels = safeChannels.filter(
    (ch) => ch && ch.paymentType && ch.paymentType.toLowerCase() === paymentType.toLowerCase() && ch.enabled !== false
  );

  // Auto-select first channel when payment type changes
  useEffect(() => {
    if (availableChannels.length > 0) {
      if (!selectedChannel || selectedChannel.paymentType.toLowerCase() !== paymentType.toLowerCase()) {
        setSelectedChannel(availableChannels[0]);
        // Set default amount respecting min/max
        const defaultAmt = Math.max(availableChannels[0].minimumDeposit, 500);
        setAmount(defaultAmt);
        setCustomAmount(defaultAmt.toString());
      }
    } else {
      setSelectedChannel(null);
    }
  }, [paymentType, depositChannels]);

  // Amount Presets according to currency
  const isUsdt = paymentType === 'USDT';
  const currencySymbol = isUsdt ? '$' : '৳';
  const bdtPresets = [100, 300, 500, 1000, 2000, 5000, 10000, 25000];
  const usdtPresets = [10, 25, 50, 100, 250, 500, 1000, 2500];
  const presets = isUsdt ? usdtPresets : bdtPresets;

  // Validate Min/Max and open Channel-Specific Request Page
  const handleDepositGo = () => {
    if (!user) {
      showToast('Please sign in or register first', 'error');
      return;
    }

    if (!selectedChannel) {
      showToast('Please select a deposit channel', 'error');
      return;
    }

    const num = parseFloat(customAmount);
    if (isNaN(num)) {
      showToast('Please enter a valid deposit amount', 'error');
      return;
    }

    // Min validation
    if (num < selectedChannel.minimumDeposit) {
      showToast(
        `Minimum deposit is ${currencySymbol}${selectedChannel.minimumDeposit.toLocaleString()}`,
        'error'
      );
      return;
    }

    // Max validation
    if (num > selectedChannel.maximumDeposit) {
      showToast(
        `Maximum deposit is ${currencySymbol}${selectedChannel.maximumDeposit.toLocaleString()}`,
        'error'
      );
      return;
    }

    setAmount(num);
    setActiveRequestChannel(selectedChannel);
  };

  // Submit TxID from Request Page
  const handleTxnSubmit = async (
    channel: DepositChannel,
    depositAmount: number,
    txnId: string
  ): Promise<boolean> => {
    let success = false;
    if (typeof submitDepositChannelRequest === 'function') {
      const depItem = await submitDepositChannelRequest(channel, depositAmount, txnId);
      success = !!depItem;
    } else if (typeof submitDeposit === 'function') {
      const methodKey = (channel.paymentType.toLowerCase() === 'bkash' ? 'bkash' : channel.paymentType.toLowerCase() === 'usdt' ? 'usdt' : 'nagad') as 'nagad' | 'bkash' | 'usdt';
      success = await submitDeposit(channel.channelName, methodKey, depositAmount, txnId);
    } else {
      showToast('Deposit request recorded successfully!', 'success');
      success = true;
    }

    if (success) {
      // Close Request Page
      setActiveRequestChannel(null);
      // Immediately show 3D Premium Success Card
      setSuccessModalData({
        amount: depositAmount,
        paymentType: channel.paymentType,
        channel: channel.channelName,
        txnId: txnId
      });

      // Auto close after 3.8 seconds and switch to Deposit History
      setTimeout(() => {
        setSuccessModalData(null);
        setShowHistory(true);
      }, 3800);

      return true;
    }
    return false;
  };

  // If user is currently on the Request Page, render it full screen
  if (activeRequestChannel) {
    return (
      <DepositRequestPage
        channel={activeRequestChannel}
        amount={amount}
        onBack={() => setActiveRequestChannel(null)}
        onSubmitTxn={handleTxnSubmit}
        showToast={showToast}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#f7f8fc] pb-24 text-slate-800 select-none">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-slate-100 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={onBack}
          className="p-1 -ml-1 text-slate-700 hover:text-slate-900 rounded-full active:scale-95 transition-all"
          id="deposit-back-btn"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-base font-extrabold text-slate-900 tracking-tight">Deposit Center</h1>
        <button
          onClick={() => setShowHistory(!showHistory)}
          className="text-xs font-bold text-[#2196f3] hover:underline"
          id="deposit-history-toggle-btn"
        >
          {showHistory ? 'Deposit Form' : 'Deposit History'}
        </button>
      </div>

      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* Balance Card */}
        <div className="bg-[#29303d] border border-slate-700/80 rounded-3xl p-5 text-white shadow-xl relative overflow-hidden">
          <div className="flex items-center space-x-1.5 text-xs text-slate-300">
            <ShieldCheck className="w-4 h-4 text-[#2196f3]" />
            <span className="font-semibold">Current Account Balance</span>
          </div>
          <div className="flex items-center space-x-2 mt-2">
            <span className="text-3xl font-black tracking-tight text-white">
              ৳{user?.balance.toFixed(2) || '0.00'}
            </span>
            <button
              onClick={refreshBalance}
              disabled={isRefreshingBalance}
              className="text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10 active:scale-90 transition-all"
              title="Refresh Balance"
              id="refresh-deposit-balance-btn"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshingBalance ? 'animate-spin' : ''}`} />
            </button>
          </div>
          <div className="absolute right-4 bottom-4 text-xs tracking-widest text-[#2196f3] font-mono font-bold">
            BGNICE VIP
          </div>
        </div>

        {showHistory ? (
          /* Real-time Deposit History List */
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-sm font-extrabold text-slate-800">
                <Clock className="w-4 h-4 text-[#2196f3]" />
                <span>Deposit History (ডিপোজিট হিস্টোরি)</span>
              </div>
              <span className="text-[11px] text-slate-400 font-medium">Auto-Synced</span>
            </div>

            {/* Quick Status Filter Tabs */}
            <div className="grid grid-cols-4 gap-1.5 bg-slate-100 p-1 rounded-2xl text-[11px] font-bold text-slate-600">
              <button
                onClick={() => setHistoryFilter('all')}
                className={`py-1.5 rounded-xl transition-all ${
                  historyFilter === 'all' ? 'bg-white text-[#2196f3] shadow-xs' : 'hover:text-slate-900'
                }`}
              >
                All ({userDeposits.length})
              </button>
              <button
                onClick={() => setHistoryFilter('completed')}
                className={`py-1.5 rounded-xl transition-all ${
                  historyFilter === 'completed' ? 'bg-white text-emerald-600 shadow-xs' : 'hover:text-slate-900'
                }`}
              >
                Success
              </button>
              <button
                onClick={() => setHistoryFilter('pending')}
                className={`py-1.5 rounded-xl transition-all ${
                  historyFilter === 'pending' ? 'bg-white text-amber-600 shadow-xs' : 'hover:text-slate-900'
                }`}
              >
                Processing
              </button>
              <button
                onClick={() => setHistoryFilter('rejected')}
                className={`py-1.5 rounded-xl transition-all ${
                  historyFilter === 'rejected' ? 'bg-white text-rose-600 shadow-xs' : 'hover:text-slate-900'
                }`}
              >
                Failed
              </button>
            </div>

            {(() => {
              const filteredList = userDeposits.filter((dep) => {
                if (historyFilter === 'completed') return dep.status === 'completed' || dep.status === 'success';
                if (historyFilter === 'pending') return dep.status === 'pending';
                if (historyFilter === 'rejected') return dep.status === 'rejected';
                return true;
              });

              if (filteredList.length === 0) {
                return (
                  <div className="bg-white rounded-3xl p-8 text-center text-xs text-slate-400 border border-slate-100 shadow-xs">
                    কোনো ডিপোজিট রেকর্ড পাওয়া যায়নি (No records found)
                  </div>
                );
              }

              return filteredList.map((dep, dIdx) => {
                const orderIdStr = formatOrderId(dep);
                const isSuccess = dep.status === 'completed' || dep.status === 'success';
                const isPending = dep.status === 'pending';
                const isFailed = dep.status === 'rejected';
                const methodLower = (dep.method || '').toLowerCase();

                const methodBadgeColor =
                  methodLower === 'bkash'
                    ? 'bg-[#e2136e] text-white'
                    : methodLower === 'rocket'
                    ? 'bg-[#8e24aa] text-white'
                    : methodLower === 'usdt'
                    ? 'bg-[#009393] text-white'
                    : 'bg-[#ff5138] text-white';

                return (
                  <div
                    key={`dep-rec-${dep.id || dIdx}-${dIdx}`}
                    className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 space-y-3 text-xs"
                  >
                    {/* Header: Green Deposit Badge + Channel + Status */}
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                      <div className="flex items-center space-x-2">
                        <span className="px-2.5 py-0.5 rounded-md bg-emerald-600 text-white font-black text-[11px] tracking-wide shadow-xs">
                          Deposit
                        </span>
                        <span className="text-xs font-bold text-slate-800">
                          {dep.channel || (dep.method || '').toUpperCase()}
                        </span>
                      </div>

                      <div
                        className={`font-black text-xs px-2.5 py-0.5 rounded-full border flex items-center space-x-1 ${
                          isSuccess
                            ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
                            : isPending
                            ? 'bg-amber-50 text-amber-600 border-amber-200'
                            : 'bg-rose-50 text-rose-600 border-rose-200'
                        }`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          isSuccess ? 'bg-emerald-500' : isPending ? 'bg-amber-500 animate-pulse' : 'bg-rose-500'
                        }`} />
                        <span>
                          {isSuccess ? 'Success' : isPending ? 'Processing' : 'Rejected'}
                        </span>
                      </div>
                    </div>

                    {/* Order Amount Row */}
                    <div className="flex justify-between items-center bg-slate-50/70 p-2.5 rounded-xl border border-slate-100">
                      <div>
                        <span className="text-slate-400 font-medium block text-[11px]">Recharge Amount</span>
                        <span className="text-slate-500 text-[10px]">অর্ডার পরিমাণ</span>
                      </div>
                      <span className="font-black text-[#2196f3] text-lg font-mono">
                        +{dep.method === 'usdt' ? '$' : '৳'}{dep.amount.toFixed(2)}
                      </span>
                    </div>

                    {/* Detailed Metadata Grid */}
                    <div className="space-y-2 pt-0.5 text-slate-600">
                      {/* Order ID */}
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 font-medium">Order ID</span>
                        <div className="flex items-center space-x-1.5">
                          <span className="font-mono text-slate-900 font-black text-xs tracking-tight">
                            {orderIdStr}
                          </span>
                          <button
                            type="button"
                            onClick={() => copyToClipboard(orderIdStr, 'Order ID')}
                            className="p-1 text-slate-400 hover:text-slate-800 active:scale-95 transition-all"
                            title="Copy Order ID"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Transaction ID */}
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 font-medium">Transaction ID (TxnID)</span>
                        <div className="flex items-center space-x-1.5">
                          <span className="font-mono text-slate-900 font-bold select-all">
                            {dep.txnId}
                          </span>
                          <button
                            type="button"
                            onClick={() => copyToClipboard(dep.txnId, 'Transaction ID')}
                            className="p-1 text-slate-400 hover:text-slate-800 active:scale-95 transition-all"
                            title="Copy TxnID"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Created At */}
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 font-medium">Date & Time</span>
                        <span className="text-slate-500 font-mono text-[11px]">
                          {new Date(dep.createdAt).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              });
            })()}
          </div>
        ) : (
          <>
            {/* Step 1: Payment Type Selector */}
            <div className="space-y-1.5">
              <span className="text-xs font-extrabold text-slate-600 uppercase tracking-wider">
                1. Select Payment Method
              </span>
              <div className="grid grid-cols-4 gap-2">
                {(['Nagad', 'bKash', 'Rocket', 'USDT'] as const).map((type) => {
                  const isSel = paymentType === type;
                  return (
                    <button
                      key={type}
                      onClick={() => setPaymentType(type)}
                      className={`py-3 px-1.5 rounded-2xl flex flex-col items-center justify-center border transition-all active:scale-95 ${
                        isSel
                          ? type === 'Nagad'
                            ? 'bg-[#ff5138] text-white border-transparent shadow-md'
                            : type === 'bKash'
                            ? 'bg-[#e2136e] text-white border-transparent shadow-md'
                            : type === 'Rocket'
                            ? 'bg-[#8e24aa] text-white border-transparent shadow-md'
                            : 'bg-[#009393] text-white border-transparent shadow-md'
                          : 'bg-white text-slate-700 border-slate-100 hover:bg-slate-50'
                      }`}
                      id={`deposit-method-${type.toLowerCase()}`}
                    >
                      {type === 'USDT' && (
                        <span className="absolute -top-1.5 -right-1 bg-amber-400 text-slate-900 font-extrabold text-[8px] px-1 py-0.2 rounded-full shadow-xs">
                          +2%
                        </span>
                      )}
                      <div className="w-8 h-8 rounded-lg bg-white p-0.5 mb-1 flex items-center justify-center shadow-xs">
                        {type === 'Nagad' && (
                          <img
                            src={PAYMENT_LOGOS.nagad}
                            alt="Nagad"
                            className="w-full h-full object-contain rounded"
                          />
                        )}
                        {type === 'bKash' && (
                          <img
                            src={PAYMENT_LOGOS.bkash}
                            alt="bKash"
                            className="w-full h-full object-contain rounded"
                          />
                        )}
                        {type === 'Rocket' && (
                          <img
                            src={PAYMENT_LOGOS.rocket}
                            alt="Rocket"
                            className="w-full h-full object-contain rounded"
                          />
                        )}
                        {type === 'USDT' && (
                          <div className="w-full h-full rounded bg-emerald-600 text-white font-black text-xs flex items-center justify-center">
                            ₮
                          </div>
                        )}
                      </div>
                      <span className="font-extrabold text-[11px]">{type}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Select Channel (Payment number is NOT shown here) */}
            <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-slate-700 uppercase tracking-wider">
                  2. Select Channel ({availableChannels.length})
                </span>
                <span className="text-[10px] text-slate-400">Official Channels</span>
              </div>

              {availableChannels.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-400 bg-slate-50 rounded-2xl">
                  No active channels available for {paymentType}. Please choose another method.
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2.5">
                  {availableChannels.map((ch, chIdx) => {
                    const isSel = selectedChannel?.channelId === ch.channelId;
                    return (
                      <button
                        key={`ch-${ch.channelId || chIdx}-${chIdx}`}
                        onClick={() => setSelectedChannel(ch)}
                        className={`p-3 text-left rounded-2xl border transition-all active:scale-98 ${
                          isSel
                            ? 'bg-gradient-to-r from-[#1976d2] to-[#2196f3] text-white border-transparent shadow-md'
                            : 'bg-slate-50 text-slate-800 border-slate-200/80 hover:bg-slate-100'
                        }`}
                        id={`channel-${ch.channelId}`}
                      >
                        <div className="font-extrabold text-xs truncate">{ch.channelName}</div>
                        <div
                          className={`text-[10px] font-bold mt-1 ${
                            isSel ? 'text-white/90' : 'text-slate-500'
                          }`}
                        >
                          Limit: {ch.currency === 'USDT' ? '$' : '৳'}
                          {ch.minimumDeposit} - {ch.maximumDeposit.toLocaleString()}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Step 3: Deposit Amount Presets */}
            <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-slate-700 uppercase tracking-wider">
                  3. Enter Deposit Amount
                </span>
                {selectedChannel && (
                  <span className="text-[10px] font-bold text-slate-500">
                    Min: {currencySymbol}{selectedChannel.minimumDeposit} | Max: {currencySymbol}
                    {selectedChannel.maximumDeposit.toLocaleString()}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-4 gap-2">
                {presets.map((p) => {
                  const isSel = amount === p && customAmount === p.toString();
                  return (
                    <button
                      key={p}
                      onClick={() => {
                        setAmount(p);
                        setCustomAmount(p.toString());
                      }}
                      className={`py-2 rounded-xl text-xs font-extrabold transition-all active:scale-95 ${
                        isSel
                          ? 'bg-[#2196f3] text-white shadow-sm'
                          : 'bg-slate-50 text-slate-700 border border-slate-200/70 hover:bg-blue-50/50'
                      }`}
                      id={`amount-preset-${p}`}
                    >
                      {currencySymbol}{p >= 1000 ? `${p / 1000}K` : p}
                    </button>
                  );
                })}
              </div>

              {/* Custom Input */}
              <div className="relative mt-2">
                <span className="absolute left-3.5 top-3 text-[#2196f3] font-black text-sm">
                  {currencySymbol}
                </span>
                <input
                  type="number"
                  value={customAmount}
                  onChange={(e) => {
                    setCustomAmount(e.target.value);
                    const val = parseFloat(e.target.value);
                    if (!isNaN(val)) setAmount(val);
                  }}
                  placeholder={
                    selectedChannel
                      ? `${currencySymbol}${selectedChannel.minimumDeposit} - ${currencySymbol}${selectedChannel.maximumDeposit.toLocaleString()}`
                      : 'Enter amount'
                  }
                  className="w-full pl-8 pr-4 py-2.5 rounded-2xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-900 focus:outline-none focus:border-[#2196f3]"
                  id="deposit-custom-input"
                />
              </div>
            </div>

            {/* Step 4: Deposit GO Trigger Button */}
            <div className="pt-2">
              <button
                onClick={handleDepositGo}
                disabled={!selectedChannel}
                className="w-full py-4 rounded-2xl font-black text-white bg-gradient-to-r from-[#1976d2] to-[#2196f3] hover:brightness-105 active:scale-98 shadow-lg shadow-blue-500/25 text-sm uppercase tracking-wide flex items-center justify-center space-x-2 disabled:opacity-50"
                id="deposit-go-btn"
              >
                <span>DEPOSIT GO ({currencySymbol}{amount.toLocaleString()})</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Recharge Instructions */}
            <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-2">
              <div className="flex items-center space-x-1.5 text-xs font-bold text-slate-800">
                <span>📖</span>
                <span>Deposit Rules & Instructions</span>
              </div>
              <ul className="text-xs text-slate-500 space-y-2 leading-relaxed list-disc list-inside">
                <li>Payment details are revealed on the secure channel payment page.</li>
                <li>Transfer the exact amount and submit the genuine Transaction ID.</li>
                <li>Do not reuse old numbers or save numbers for future transactions.</li>
                <li>Credits are processed automatically by the finance system within minutes.</li>
              </ul>
            </div>
          </>
        )}
      </div>

      {/* 3D Premium Success Card (Requirement 19) */}
      {successModalData && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className="bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-emerald-500/50 rounded-3xl p-6 text-white max-w-sm w-full shadow-2xl text-center space-y-4 animate-in zoom-in-95 relative"
            style={{
              boxShadow: '0 25px 50px -12px rgba(16, 185, 129, 0.35), inset 0 1px 0 rgba(255,255,255,0.15)'
            }}
            id="deposit-3d-success-card"
          >
            <button
              onClick={() => {
                setSuccessModalData(null);
                setShowHistory(true);
              }}
              className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10"
              id="close-success-card-btn"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Floating 3D Check Icon */}
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-emerald-500 to-teal-400 mx-auto flex items-center justify-center shadow-lg shadow-emerald-500/50 transform -rotate-3 hover:rotate-0 transition-transform">
              <CheckCircle2 className="w-10 h-10 text-white" />
            </div>

            <div>
              <div className="flex items-center justify-center space-x-1 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Request Registered</span>
              </div>
              <h2 className="text-xl font-black tracking-tight text-white mt-1">
                Deposit Request Successful
              </h2>
            </div>

            {/* Info Grid */}
            <div className="bg-white/5 rounded-2xl p-3.5 border border-white/10 space-y-2 text-xs text-left">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Amount:</span>
                <span className="text-emerald-400 font-extrabold text-sm">
                  {isUsdt ? '$' : '৳'}{successModalData.amount.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Payment Type:</span>
                <span className="text-white font-bold">{successModalData.paymentType}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Channel:</span>
                <span className="text-white font-bold">{successModalData.channel}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Transaction ID:</span>
                <span className="text-white font-mono font-bold select-all">
                  {successModalData.txnId}
                </span>
              </div>
              <div className="flex justify-between items-center pt-1 border-t border-white/10">
                <span className="text-slate-400">Status:</span>
                <span className="bg-amber-500/20 text-amber-300 font-bold px-2 py-0.5 rounded-full text-[10px] border border-amber-500/30">
                  Processing
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-tight">
              Our automated system will verify and credit your balance shortly.
            </p>

            <button
              onClick={() => {
                setSuccessModalData(null);
                setShowHistory(true);
              }}
              className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-black text-xs rounded-xl shadow-md shadow-emerald-500/20 active:scale-98 transition-all"
              id="success-card-close-btn"
            >
              CLOSE & VIEW HISTORY
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
