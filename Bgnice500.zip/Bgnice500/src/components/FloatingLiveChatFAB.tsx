import React, { useState, useEffect, useRef } from 'react';
import {
  MessageCircle,
  X,
  Headphones,
  Sparkles,
  Send,
  Bot,
  User,
  ArrowRight,
  ShieldCheck,
  CheckCheck,
  Image as ImageIcon,
  Loader2,
  ZoomIn,
  Trash2
} from 'lucide-react';
import { useApp, stripUndefined } from '../context/AppContext';
import { useLanguage } from '../context/LanguageContext';
import { ref, push, set, onValue, update, remove } from 'firebase/database';
import { rtdb } from '../lib/firebase';
import { SupportChat, SupportMessage, SupportAgentProfile } from '../types';
import { DEFAULT_SUPPORT_AGENTS } from '../utils/defaultChannels';
import { uploadToImgBB } from '../utils/imgbb';

export const FloatingLiveChatFAB: React.FC = () => {
  const { user, showToast, isGameActive, settings } = useApp();
  const { t } = useLanguage();

  const [isOpen, setIsOpen] = useState(false);
  const [position, setPosition] = useState<{ x: number; y: number }>(() => {
    try {
      const saved = localStorage.getItem('trade_bd_live_chat_fab_pos');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.x === 'number' && typeof parsed.y === 'number') {
          return parsed;
        }
      }
    } catch {}
    // Default: bottom right
    const defaultX = typeof window !== 'undefined' ? Math.max(16, window.innerWidth - 75) : 320;
    const defaultY = typeof window !== 'undefined' ? Math.max(100, window.innerHeight - 150) : 600;
    return { x: defaultX, y: defaultY };
  });

  const [isDragging, setIsDragging] = useState(false);
  const dragStartPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const elementStartPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const hasMovedSignificantly = useRef(false);

  // Chat conversation state
  const [activeChat, setActiveChat] = useState<SupportChat | null>(null);
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [assignedAgent, setAssignedAgent] = useState<SupportAgentProfile>(DEFAULT_SUPPORT_AGENTS[0]);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Image Upload State
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [selectedImagePreview, setSelectedImagePreview] = useState<string | null>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // If user is inside any game, completely remove the floating chat button
  if (isGameActive) {
    return null;
  }

  // Adjust position on window resize so it stays within viewport
  useEffect(() => {
    const handleResize = () => {
      setPosition((prev) => {
        const maxX = window.innerWidth - 65;
        const maxY = window.innerHeight - 75;
        const newX = Math.min(Math.max(12, prev.x), Math.max(12, maxX));
        const newY = Math.min(Math.max(60, prev.y), Math.max(60, maxY));
        return { x: newX, y: newY };
      });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Save position when stopped dragging
  const handleDragEnd = () => {
    setIsDragging(false);
    try {
      localStorage.setItem('trade_bd_live_chat_fab_pos', JSON.stringify(position));
    } catch {}
  };

  // Pointer drag handlers (works for mouse and touch seamlessly)
  const handlePointerDown = (e: React.PointerEvent) => {
    // Only drag with primary pointer button
    if (e.button !== 0) return;
    dragStartPos.current = { x: e.clientX, y: e.clientY };
    elementStartPos.current = { ...position };
    hasMovedSignificantly.current = false;
    setIsDragging(true);
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const deltaX = e.clientX - dragStartPos.current.x;
    const deltaY = e.clientY - dragStartPos.current.y;

    if (Math.abs(deltaX) > 4 || Math.abs(deltaY) > 4) {
      hasMovedSignificantly.current = true;
    }

    const maxX = window.innerWidth - 65;
    const maxY = window.innerHeight - 75;

    const nextX = Math.min(Math.max(10, elementStartPos.current.x + deltaX), Math.max(10, maxX));
    const nextY = Math.min(Math.max(50, elementStartPos.current.y + deltaY), Math.max(50, maxY));

    setPosition({ x: nextX, y: nextY });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDragging) return;
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}
    handleDragEnd();

    // If user tapped without dragging, toggle modal
    if (!hasMovedSignificantly.current) {
      setIsOpen((prev) => !prev);
    }
  };

  // Auto scroll messages
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  // Firebase support chat integration
  useEffect(() => {
    if (!isOpen) return;

    // Listen to support agents
    const agentsRef = ref(rtdb, 'supportAgents');
    const unsubAgents = onValue(agentsRef, (snapshot) => {
      if (snapshot.exists()) {
        const list = Object.values(snapshot.val()) as SupportAgentProfile[];
        if (list.length > 0) setAssignedAgent(list[0]);
      }
    });

    if (!user) return () => unsubAgents();

    const userChatsRef = ref(rtdb, `supportChats/${user.uid}`);
    const unsubChats = onValue(userChatsRef, (snapshot) => {
      if (snapshot.exists()) {
        const raw = snapshot.val();
        const list: SupportChat[] = [];
        Object.entries(raw).forEach(([k, v]: [string, any]) => {
          if (v && typeof v === 'object' && k !== 'undefined') {
            list.push({ ...v, chatId: v.chatId || k });
          }
        });
        list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        const active = list.find((c) => c.status === 'active') || list[0];
        if (active) setActiveChat(active);
      }
    });

    return () => {
      unsubAgents();
      unsubChats();
    };
  }, [isOpen, user]);

  // Listen to messages for active chat
  useEffect(() => {
    if (!isOpen || !activeChat?.chatId) return;

    const msgsRef = ref(rtdb, `messages/${activeChat.chatId}`);
    const unsub = onValue(msgsRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = Object.values(snapshot.val()) as SupportMessage[];
        data.sort((a, b) => a.timestamp - b.timestamp);
        setMessages(data);
      } else {
        setMessages([]);
      }
    });

    return () => unsub();
  }, [isOpen, activeChat?.chatId]);

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file (JPG, PNG, WebP)', 'error');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      showToast('Image file size must be under 10MB', 'error');
      return;
    }

    setSelectedImageFile(file);
    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const removeSelectedImage = () => {
    setSelectedImageFile(null);
    setSelectedImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!inputText.trim() && !selectedImageFile) || isSending || isUploadingImage) return;

    if (!user) {
      showToast('Please login to chat with customer support', 'info');
      return;
    }

    const text = inputText.trim();
    setInputText('');
    setIsSending(true);

    try {
      let uploadedImageUrl: string | undefined = undefined;

      // Upload image to ImgBB if attached
      if (selectedImageFile) {
        setIsUploadingImage(true);
        showToast('Uploading image to ImgBB...', 'info');
        const uploadRes = await uploadToImgBB(selectedImageFile, settings.imgbbApiKey);
        if (!uploadRes.success || !uploadRes.url) {
          throw new Error(uploadRes.error || 'ImgBB upload failed');
        }
        uploadedImageUrl = uploadRes.url;
        removeSelectedImage();
      }

      let chatId = activeChat?.chatId;

      if (!chatId || activeChat?.status === 'closed') {
        const newChatRef = push(ref(rtdb, `supportChats/${user.uid}`));
        chatId = newChatRef.key || `chat_${Date.now()}`;

        const newChat: SupportChat = {
          chatId,
          userId: user.uid,
          userUid: user.numericUid || user.uid,
          username: user.username || user.phone || 'User',
          userPhone: user.phone || '',
          userEmail: user.email || '',
          status: 'active',
          createdAt: Date.now(),
          updatedAt: Date.now(),
          agentId: assignedAgent.agentId || 'AGENT_DEFAULT',
          agentName: assignedAgent.agentName || 'BGNICE Support',
          agentPhoto: assignedAgent.profilePhoto || '',
          lastMessage: text || (uploadedImageUrl ? '📷 Image Attachment' : '')
        };

        await set(newChatRef, stripUndefined(newChat));
        await set(ref(rtdb, `supportChatsIndex/${chatId}`), stripUndefined({
          ...newChat,
          userPath: user.uid
        }));

        setActiveChat(newChat);

        // System greeting
        const welcomeMsgRef = push(ref(rtdb, `messages/${chatId}`));
        await set(welcomeMsgRef, stripUndefined({
          id: welcomeMsgRef.key || `msg_w_${Date.now()}`,
          chatId,
          senderId: assignedAgent.agentId || 'AGENT_DEFAULT',
          senderType: 'admin',
          message: assignedAgent.welcomeMessage || 'Hello! Welcome to BGNICE 24/7 Live Customer Service. How can we help you today?',
          timestamp: Date.now(),
          read: true
        }));
      }

      // User Message
      const msgRef = push(ref(rtdb, `messages/${chatId}`));
      const newMsg: SupportMessage = {
        id: msgRef.key || `msg_${Date.now()}`,
        chatId,
        senderId: user.uid,
        senderType: 'user',
        message: text || (uploadedImageUrl ? '📷 Image' : ''),
        ...(uploadedImageUrl ? { imageUrl: uploadedImageUrl } : {}),
        timestamp: Date.now(),
        read: false
      };

      await set(msgRef, stripUndefined(newMsg));

      const displayLastMessage = text || (uploadedImageUrl ? '📷 Image' : 'Message');
      await update(ref(rtdb, `supportChats/${user.uid}/${chatId}`), {
        lastMessage: displayLastMessage,
        updatedAt: Date.now(),
        status: 'active'
      });

      await update(ref(rtdb, `supportChatsIndex/${chatId}`), {
        lastMessage: displayLastMessage,
        updatedAt: Date.now(),
        status: 'active'
      });
    } catch (err: any) {
      console.error('Failed to send live chat message', err);
      showToast(err?.message || 'Could not send message. Please check connection.', 'error');
    } finally {
      setIsSending(false);
      setIsUploadingImage(false);
    }
  };

  return (
    <>
      {/* Draggable Floating Action Button (FAB) */}
      <div
        id="global-floating-live-chat-fab"
        style={{
          position: 'fixed',
          left: `${position.x}px`,
          top: `${position.y}px`,
          zIndex: 9999,
          touchAction: 'none'
        }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className={`select-none cursor-grab active:cursor-grabbing transition-transform ${
          isDragging ? 'scale-110 shadow-2xl opacity-90' : 'hover:scale-105 shadow-xl'
        }`}
      >
        <div className="relative group flex items-center justify-center">
          {/* Pulsing glow halo */}
          <div className="absolute -inset-1.5 bg-gradient-to-r from-[#2196f3] via-[#42a5f5] to-[#1976d2] rounded-full blur-xs opacity-75 animate-pulse group-hover:opacity-100 transition duration-300"></div>

          {/* Core Button */}
          <div className="relative w-14 h-14 rounded-full bg-[#29303d] text-white flex flex-col items-center justify-center border-2 border-[#2196f3] shadow-2xl">
            <Headphones className="w-6 h-6 text-[#2196f3] drop-shadow-md animate-bounce" />
            <span className="text-[8px] font-black uppercase tracking-tighter leading-none mt-0.5 text-white">
              24/7 Live
            </span>

            {/* Online Green Pulsing Beacon */}
            <span className="absolute -top-0.5 -right-0.5 flex h-3.5 w-3.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-[#29303d]"></span>
            </span>
          </div>
        </div>
      </div>

      {/* Floating Live Chat Popup Window / Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-[10000] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full sm:max-w-md h-[90vh] sm:h-[620px] bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200/80 animate-in slide-in-from-bottom duration-200">
            {/* Header */}
            <div className="bg-[#29303d] border-b border-slate-700/80 text-white p-4 flex items-center justify-between shadow-md shrink-0">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-[#1e2530] border-2 border-[#2196f3] flex flex-col items-center justify-center shadow-sm overflow-hidden">
                    <span className="text-[11px] font-black text-white font-mono tracking-tighter leading-none">BG</span>
                    <span className="text-[7px] font-black text-[#2196f3] tracking-widest uppercase mt-0.5 leading-none">NICE</span>
                  </div>
                  <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#29303d]"></span>
                </div>
                <div>
                  <div className="flex items-center space-x-1.5">
                    <span className="font-extrabold text-sm text-white">BGNICE OFFICIAL SUPPORT</span>
                    <span className="text-[9px] bg-[#2196f3]/30 text-blue-200 border border-[#2196f3]/40 font-bold px-1.5 py-0.2 rounded-full">
                      Official
                    </span>
                  </div>
                  <div className="text-[11px] text-emerald-400 flex items-center space-x-1 font-semibold">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>24/7 VIP Online Support</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white active:scale-95 transition-all"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chat Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#f8fafc]">
              {/* Trust Badge */}
              <div className="bg-white rounded-2xl p-3 border border-slate-100 shadow-xs flex items-center space-x-2.5 text-xs text-slate-600">
                <ShieldCheck className="w-5 h-5 text-[#2196f3] shrink-0" />
                <span>
                  Welcome to BGNICE official live help desk. All deposits, withdrawals, and game issues are resolved in real-time.
                </span>
              </div>

              {!user && (
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 text-center space-y-2">
                  <p className="text-xs font-bold text-amber-900">
                    You are currently in guest mode. Please sign in to connect to live support records.
                  </p>
                </div>
              )}

              {/* Messages list */}
              {messages.length === 0 ? (
                <div className="text-center py-8 space-y-2">
                  <div className="w-12 h-12 rounded-full bg-blue-50 text-[#2196f3] flex items-center justify-center mx-auto">
                    <Headphones className="w-6 h-6" />
                  </div>
                  <p className="text-xs font-bold text-slate-700">How can we help you today?</p>
                  <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                    Ask any question regarding deposit methods, withdrawal status, gift codes, or game rules. You can also send screenshots!
                  </p>
                </div>
              ) : (
                messages.map((m, idx) => {
                  const isMe = m.senderType === 'user';
                  return (
                    <div
                      key={m.id || idx}
                      className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-[85%] rounded-2xl p-2.5 text-xs leading-relaxed shadow-xs ${
                          isMe
                            ? 'bg-[#2196f3] text-white rounded-tr-xs'
                            : 'bg-white text-slate-800 border border-slate-200/70 rounded-tl-xs'
                        }`}
                      >
                        {Boolean(m.imageUrl && m.imageUrl.trim()) && (
                          <div className="mb-1.5 rounded-xl overflow-hidden bg-black/5 relative group cursor-pointer" onClick={() => setLightboxImage(m.imageUrl || null)}>
                            <img
                              src={m.imageUrl}
                              alt="Attachment"
                              className="max-h-48 max-w-full rounded-xl object-contain hover:scale-102 transition-transform duration-200"
                              loading="lazy"
                            />
                            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-xl">
                              <span className="text-[10px] bg-black/60 text-white px-2 py-0.5 rounded-full flex items-center gap-1 font-sans">
                                <ZoomIn className="w-3 h-3" /> View
                              </span>
                            </div>
                          </div>
                        )}
                        {m.message && (
                          <p className="whitespace-pre-wrap break-words px-1 font-sans">{m.message}</p>
                        )}
                      </div>
                      <div className="flex items-center space-x-1 text-[9px] text-slate-400 mt-0.5 px-1 font-mono">
                        <span>{new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        {isMe && <CheckCheck className="w-3 h-3 text-emerald-500" />}
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Selected Image Preview before sending */}
            {Boolean(selectedImagePreview && selectedImagePreview.trim()) && (
              <div className="px-3 py-2 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <img
                    src={selectedImagePreview}
                    alt="Preview"
                    className="w-12 h-12 object-cover rounded-lg border border-slate-300 shadow-xs"
                  />
                  <div className="text-left">
                    <p className="text-[11px] font-bold text-slate-700">Image attached</p>
                    <p className="text-[9px] text-slate-400">Ready to upload to ImgBB</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={removeSelectedImage}
                  className="p-1.5 text-red-500 hover:bg-red-50 rounded-full transition-colors"
                  title="Remove image"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Input Bar */}
            <form
              onSubmit={handleSendMessage}
              className="p-3 bg-white border-t border-slate-100 flex items-center space-x-2 shrink-0"
            >
              {/* Hidden File Input for Image Upload */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageFileChange}
                className="hidden"
                id="live-chat-file-input"
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploadingImage || isSending}
                className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors shrink-0 disabled:opacity-50"
                title="Send screenshot / image via ImgBB"
              >
                <ImageIcon className="w-4 h-4" />
              </button>

              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={selectedImagePreview ? "Add caption (optional)..." : "Type your message..."}
                disabled={isSending || isUploadingImage}
                className="flex-1 px-4 py-2.5 bg-slate-100 rounded-full text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#2196f3] border border-transparent"
              />

              <button
                type="submit"
                disabled={(!inputText.trim() && !selectedImageFile) || isSending || isUploadingImage}
                className="w-10 h-10 rounded-full bg-[#2196f3] hover:bg-[#1e88e5] text-white flex items-center justify-center shadow-md disabled:opacity-40 active:scale-95 transition-all shrink-0"
              >
                {isSending || isUploadingImage ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4 ml-0.5" />
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Lightbox Modal for viewing images in full size */}
      {Boolean(lightboxImage && lightboxImage.trim()) && (
        <div
          className="fixed inset-0 z-[100000] bg-black/85 flex items-center justify-center p-4 backdrop-blur-xs"
          onClick={() => setLightboxImage(null)}
        >
          <div className="relative max-w-lg max-h-[85vh] flex flex-col items-center">
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute -top-10 right-0 p-2 text-white/80 hover:text-white bg-white/10 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={lightboxImage}
              alt="Full size view"
              className="max-h-[80vh] max-w-full rounded-2xl shadow-2xl object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        </div>
      )}
    </>
  );
};
export default FloatingLiveChatFAB;
