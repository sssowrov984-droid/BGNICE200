import React, { useState, useEffect } from 'react';
import { ChevronLeft, History, Trophy, TrendingDown, Clock, Search, Filter } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { BetItem } from '../types';

interface GameHistoryViewProps {
  onBack: () => void;
}

export const GameHistoryView: React.FC<GameHistoryViewProps> = ({ onBack }) => {
  const { userBets = [] } = useApp();
  const [filterType, setFilterType] = useState<'all' | 'won' | 'lost' | 'pending'>('all');
  const [selectedGameFilter, setSelectedGameFilter] = useState<string>('all');
  const [selectedDuration, setSelectedDuration] = useState<string>('all');

  // Scroll to top when entering Game History
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
  }, []);

  const safeBets: BetItem[] = Array.isArray(userBets) ? userBets : Object.values(userBets || {});

  const filteredBets = safeBets.filter((bet) => {
    if (filterType !== 'all' && bet.status !== filterType) return false;
    const gName = (bet.gameName || bet.gameType || '').toLowerCase();

    // Duration filter (30s, 1m, 2m, 3m, 5m)
    if (selectedDuration !== 'all') {
      const target = selectedDuration.toLowerCase();
      const hasDuration =
        bet.gameType?.toLowerCase() === target ||
        gName.includes(` ${target}`) ||
        gName.includes(`(${target})`) ||
        gName.includes(`-${target}`) ||
        gName.includes(target);
      if (!hasDuration) return false;
    }

    if (selectedGameFilter !== 'all') {
      if (selectedGameFilter === 'crash') {
        if (!gName.includes('aviator') && !gName.includes('crash')) return false;
      } else if (selectedGameFilter === 'wingo') {
        if (!gName.includes('wingo') && !gName.includes('win go') && !['30s', '1m', '2m', '3m', '5m'].includes(bet.gameType)) return false;
      } else if (selectedGameFilter === 'lottery') {
        if (!gName.includes('k3') && !gName.includes('5d') && !gName.includes('trx')) return false;
      }
    }
    return true;
  });

  const totalWon = safeBets
    .filter((b) => b.status === 'won')
    .reduce((acc, b) => acc + (b.winAmount || 0), 0);

  const totalBet = safeBets.reduce((acc, b) => acc + (b.totalAmount || 0), 0);

  const getGameLabel = (bet: BetItem) => {
    if (bet.gameName) return bet.gameName;
    if (bet.gameType === 'aviator') return 'Aviator';
    if (bet.gameType === 'aviatorX') return 'Aviator X';
    if (bet.gameType === 'crash') return 'Crash Rocket';
    if (bet.gameType === 'k3') return 'K3 Lottery';
    if (bet.gameType === 'fiveD') return '5D Lottery';
    if (bet.gameType === 'trx') return 'TRX Win Go';
    return `Win Go (${bet.gameType || '30s'})`;
  };

  return (
    <div className="min-h-screen bg-[#29303d] pb-24 text-slate-100 select-none">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-[#2196f3] text-white px-4 py-3.5 flex items-center justify-between shadow-md">
        <button
          onClick={onBack}
          className="p-1.5 -ml-1 text-white hover:bg-white/10 rounded-full active:scale-95 transition-all"
          id="game-history-back-btn"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-base font-bold tracking-wide">Game History</h1>
        <div className="w-8"></div>
      </div>

      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* User Summary Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-[#1f2633] rounded-2xl p-3.5 shadow-sm border border-slate-700/60 flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase block">Total Won</span>
              <span className="text-sm font-black text-emerald-400">৳{totalWon.toFixed(2)}</span>
            </div>
          </div>
          <div className="bg-[#1f2633] rounded-2xl p-3.5 shadow-sm border border-slate-700/60 flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-[#2196f3]/10 text-[#2196f3] flex items-center justify-center">
              <History className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase block">Total Bets</span>
              <span className="text-sm font-black text-white">৳{totalBet.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="space-y-2">
          {/* Status Filter */}
          <div className="flex items-center space-x-1.5 p-1 bg-[#1f2633] rounded-2xl border border-slate-700/60">
            {(['all', 'won', 'lost', 'pending'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setFilterType(t)}
                className={`flex-1 py-1.5 text-xs font-bold rounded-xl capitalize transition-all ${
                  filterType === t
                    ? 'bg-[#2196f3] text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {t === 'all' ? 'All' : t === 'won' ? 'Success' : t === 'lost' ? 'Failed' : 'Pending'}
              </button>
            ))}
          </div>

          {/* Duration Filter (30s, 1m, 2m, 3m, 5m) */}
          <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar py-0.5">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Duration:</span>
            {[
              { id: 'all', label: 'All' },
              { id: '30s', label: '30s' },
              { id: '1m', label: '1 Min' },
              { id: '2m', label: '2 Min' },
              { id: '3m', label: '3 Min' },
              { id: '5m', label: '5 Min' }
            ].map((d) => (
              <button
                key={d.id}
                onClick={() => setSelectedDuration(d.id)}
                className={`px-3 py-1 text-[11px] font-bold rounded-full whitespace-nowrap transition-all ${
                  selectedDuration === d.id
                    ? 'bg-[#2196f3] text-white shadow-xs'
                    : 'bg-[#1f2633] text-slate-300 border border-slate-700 hover:bg-slate-800'
                }`}
              >
                {d.label}
              </button>
            ))}
          </div>

          {/* Game Category Filter */}
          <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar py-0.5">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Game:</span>
            {[
              { id: 'all', label: 'All Games' },
              { id: 'wingo', label: 'Win Go' },
              { id: 'lottery', label: 'Lottery (K3/5D/TRX)' },
              { id: 'crash', label: 'Aviator & Crash' }
            ].map((g) => (
              <button
                key={g.id}
                onClick={() => setSelectedGameFilter(g.id)}
                className={`px-3 py-1 text-[11px] font-bold rounded-full whitespace-nowrap transition-all ${
                  selectedGameFilter === g.id
                    ? 'bg-[#2196f3] text-white shadow-xs'
                    : 'bg-[#1f2633] text-slate-300 border border-slate-700 hover:bg-slate-800'
                }`}
              >
                {g.label}
              </button>
            ))}
          </div>
        </div>

        {/* History List */}
        {filteredBets.length > 0 ? (
          <div className="space-y-3">
            {filteredBets.map((bet, betIdx) => {
              const dateObj = new Date(bet.createdAt);
              const dateStr = dateObj.toLocaleDateString('en-US', {
                day: '2-digit',
                month: 'short',
                year: 'numeric'
              });
              const timeStr = dateObj.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit'
              });
              const isWon = bet.status === 'won';
              const isLost = bet.status === 'lost';
              const isCancelled = bet.status === 'cancelled';
              const gameTitle = getGameLabel(bet);

              return (
                <div
                  key={`gh-bet-${bet.id || betIdx}-${betIdx}`}
                  className="bg-[#1f2633] rounded-2xl p-4 shadow-sm border border-slate-700/60 space-y-2.5"
                >
                  <div className="flex items-center justify-between border-b border-slate-700 pb-2">
                    <div className="flex items-center space-x-2">
                      <span className="font-extrabold text-xs text-white">
                        {gameTitle}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {bet.periodId ? `Round: ${bet.periodId}` : `ID: ${bet.id.slice(-6)}`}
                      </span>
                    </div>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                        isWon
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : isLost
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : isCancelled
                          ? 'bg-slate-500/20 text-slate-300 border border-slate-600'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {isWon ? 'Success' : isLost ? 'Failed' : isCancelled ? 'Cancelled' : 'Pending'}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-medium">Bet / Entry</span>
                      <span className="font-bold text-white">৳{bet.totalAmount.toFixed(2)}</span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block font-medium">
                        {isWon ? 'Win Amount' : isLost ? 'Loss Amount' : isCancelled ? 'Refund' : 'Potential'}
                      </span>
                      <span
                        className={`font-black ${
                          isWon
                            ? 'text-emerald-400'
                            : isLost
                            ? 'text-rose-400'
                            : isCancelled
                            ? 'text-slate-400'
                            : 'text-slate-200'
                        }`}
                      >
                        {isWon
                          ? `+৳${(bet.winAmount || 0).toFixed(2)}`
                          : isLost
                          ? `-৳${bet.totalAmount.toFixed(2)}`
                          : isCancelled
                          ? `+৳${bet.totalAmount.toFixed(2)}`
                          : '---'}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block font-medium">Choice</span>
                      <span className="font-bold text-slate-200 capitalize">
                        {isWon && bet.winAmount && bet.totalAmount
                          ? `${(bet.winAmount / bet.totalAmount).toFixed(2)}x`
                          : bet.selectValue
                          ? `${bet.selectType ? `${bet.selectType}: ` : ''}${bet.selectValue}`
                          : isLost
                          ? 'Failed'
                          : isCancelled
                          ? 'Returned'
                          : 'In Play'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-700/60 text-[10px] text-slate-400 font-mono">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>
                        {dateStr} • {timeStr}
                      </span>
                    </div>
                    <span>Ref: {bet.id.slice(0, 8)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-[#1f2633] rounded-3xl p-10 text-center space-y-2 border border-slate-700/60">
            <History className="w-10 h-10 text-slate-500 mx-auto" />
            <h3 className="text-sm font-bold text-white">No game activity found</h3>
            <p className="text-xs text-slate-400">
              {filterType === 'all'
                ? 'You have not placed any bets yet.'
                : `No bets matching status "${filterType}".`}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
