import React, { useEffect, useState } from 'react';
import { X, Check } from 'lucide-react';
import { GameResultModalData } from '../types';

interface GameResultModalProps {
  data: GameResultModalData | null;
  onClose: () => void;
}

export const GameResultModal: React.FC<GameResultModalProps> = ({ data, onClose }) => {
  const [autoClose, setAutoClose] = useState<boolean>(true);

  useEffect(() => {
    if (!data) return;
    if (!autoClose) return;

    // Auto-close after 3 seconds matching "3 seconds auto close" in image
    const timer = setTimeout(() => {
      onClose();
    }, 3200);

    return () => clearTimeout(timer);
  }, [data, autoClose, onClose]);

  if (!data) return null;

  const isWin = data.win;
  const durationLabel = data.duration || '30sec';
  const num = data.resultNumber !== undefined ? data.resultNumber : (isWin ? 9 : 3);
  const bigSmall = data.resultBigSmall || (num >= 5 ? 'Big' : 'Small');

  // Determine colors if not passed
  let primaryColor: 'Green' | 'Red' | 'Violet' = 'Green';
  if (data.resultColors && data.resultColors.length > 0) {
    if (data.resultColors.includes('green')) primaryColor = 'Green';
    else if (data.resultColors.includes('red')) primaryColor = 'Red';
    else if (data.resultColors.includes('violet')) primaryColor = 'Violet';
  } else {
    if (num === 0) primaryColor = 'Red';
    else if (num === 5) primaryColor = 'Green';
    else if ([1, 3, 7, 9].includes(num)) primaryColor = 'Green';
    else primaryColor = 'Red';
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex flex-col items-center justify-center p-4 select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-[310px] flex flex-col items-center">
        {/* Top Floating Winged Medallion Emblem matching image */}
        <div className="relative -mb-10 z-20 flex items-center justify-center">
          {/* Symmetrical Left Wing */}
          <div className="w-12 h-14 flex items-center justify-end -mr-2 drop-shadow-md">
            <svg viewBox="0 0 50 60" className="w-full h-full" fill="none">
              <path
                d="M48 35 C38 25, 20 18, 5 2 C18 16, 28 28, 42 42 Z"
                fill={isWin ? '#FFF4E0' : '#E3F2FD'}
                opacity="0.95"
              />
              <path
                d="M46 38 C34 30, 15 26, 2 12 C14 24, 25 36, 40 48 Z"
                fill={isWin ? '#FFE0B2' : '#BBDEFB'}
                opacity="0.9"
              />
              <path
                d="M44 42 C30 38, 12 36, 6 25 C14 34, 26 44, 38 54 Z"
                fill={isWin ? '#FFCC80' : '#90CAF9'}
                opacity="0.85"
              />
            </svg>
          </div>

          {/* Golden Center Medallion Badge with Rocket / Trophy */}
          <div className="relative">
            {/* Ribbon wings under medal */}
            <div className="absolute -bottom-3 -left-6 -right-6 flex justify-between pointer-events-none">
              <div
                className="w-8 h-4 rounded-b-md transform -rotate-12 shadow-sm"
                style={{
                  background: isWin
                    ? 'linear-gradient(135deg, #e67e22, #d35400)'
                    : 'linear-gradient(135deg, #64b5f6, #1976d2)'
                }}
              />
              <div
                className="w-8 h-4 rounded-b-md transform rotate-12 shadow-sm"
                style={{
                  background: isWin
                    ? 'linear-gradient(225deg, #e67e22, #d35400)'
                    : 'linear-gradient(225deg, #64b5f6, #1976d2)'
                }}
              />
            </div>

            {/* Circular Medallion */}
            <div
              className={`w-20 h-20 rounded-full p-1 shadow-2xl flex items-center justify-center border-2 ${
                isWin
                  ? 'border-[#FFE082] bg-gradient-to-tr from-[#F57C00] via-[#FFB74D] to-[#FFE082]'
                  : 'border-[#BBDEFB] bg-gradient-to-tr from-[#1976D2] via-[#64B5F6] to-[#E3F2FD]'
              }`}
              style={{
                boxShadow: isWin
                  ? '0 10px 25px -3px rgba(245, 124, 0, 0.6), inset 0 2px 4px rgba(255,255,255,0.7)'
                  : '0 10px 25px -3px rgba(25, 118, 210, 0.4), inset 0 2px 4px rgba(255,255,255,0.7)'
              }}
            >
              <div
                className={`w-16 h-16 rounded-full flex items-center justify-center border shadow-inner ${
                  isWin
                    ? 'border-white/60 bg-gradient-to-b from-[#FFA726] to-[#FB8C00]'
                    : 'border-white/60 bg-gradient-to-b from-[#42A5F5] to-[#1E88E5]'
                }`}
              >
                {/* Center Rocket icon with lightning bolt matching image */}
                <div className="relative flex items-center justify-center">
                  <svg className="w-9 h-9 text-white drop-shadow-sm" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2.5C12 2.5 7 5.5 7 12C7 15 8.5 17.5 10 18.5V21.5L12 20.5L14 21.5V18.5C15.5 17.5 17 15 17 12C17 5.5 12 2.5 12 2.5ZM12 11C10.9 11 10 10.1 10 9C10 7.9 10.9 7 12 7C13.1 7 14 7.9 14 9C14 10.1 13.1 11 12 11Z" />
                  </svg>
                  {/* Lightning flash on rocket */}
                  <div className="absolute inset-0 flex items-center justify-center pt-1">
                    <svg className="w-3.5 h-3.5 text-amber-300 fill-current" viewBox="0 0 24 24">
                      <path d="M13 2L3 14H12L11 22L21 10H12L13 2Z" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Symmetrical Right Wing */}
          <div className="w-12 h-14 flex items-center justify-start -ml-2 drop-shadow-md">
            <svg viewBox="0 0 50 60" className="w-full h-full transform scale-x-[-1]" fill="none">
              <path
                d="M48 35 C38 25, 20 18, 5 2 C18 16, 28 28, 42 42 Z"
                fill={isWin ? '#FFF4E0' : '#E3F2FD'}
                opacity="0.95"
              />
              <path
                d="M46 38 C34 30, 15 26, 2 12 C14 24, 25 36, 40 48 Z"
                fill={isWin ? '#FFE0B2' : '#BBDEFB'}
                opacity="0.9"
              />
              <path
                d="M44 42 C30 38, 12 36, 6 25 C14 34, 26 44, 38 54 Z"
                fill={isWin ? '#FFCC80' : '#90CAF9'}
                opacity="0.85"
              />
            </svg>
          </div>
        </div>

        {/* Main Card */}
        <div
          className={`w-full pt-14 pb-5 px-4 rounded-3xl shadow-2xl text-center border relative overflow-hidden transition-all ${
            isWin
              ? 'bg-gradient-to-b from-[#ff6b4a] via-[#ff543e] to-[#ff4141] border-[#ff7a5c]/80 text-white'
              : 'bg-[#BBDEFB] border-[#90CAF9] text-slate-800'
          }`}
          style={{
            boxShadow: isWin
              ? '0 25px 60px -10px rgba(255, 65, 65, 0.55), inset 0 2px 4px rgba(255, 255, 255, 0.3)'
              : '0 25px 60px -10px rgba(144, 202, 249, 0.6), inset 0 2px 4px rgba(255, 255, 255, 0.6)'
          }}
          id="game-result-modal-card"
        >
          {/* Header Title */}
          <h2
            className={`text-2xl font-extrabold tracking-wide drop-shadow-sm ${
              isWin ? 'text-white' : 'text-[#1565C0]'
            }`}
          >
            {isWin ? 'Congratulations' : 'Sorry'}
          </h2>

          {/* Game Results Row */}
          <div className="flex items-center justify-center space-x-1.5 mt-3 text-xs">
            {data.multiplierRate !== undefined || data.gameName?.toLowerCase().includes('aviator') ? (
              <>
                <span
                  className={`font-semibold ${
                    isWin ? 'text-white/90' : 'text-[#1976D2]'
                  }`}
                >
                  {isWin ? 'Cashed Out at' : 'Crashed at'}
                </span>
                <span className="px-2.5 py-0.5 rounded-md font-black text-xs bg-amber-400 text-slate-950 font-mono shadow-xs">
                  {(data.multiplierRate || (data.resultNumber ? data.resultNumber / 100 : 1.0)).toFixed(2)}x
                </span>
              </>
            ) : (
              <>
                <span
                  className={`font-semibold ${
                    isWin ? 'text-white/90' : 'text-[#1976D2]'
                  }`}
                >
                  Lottery results
                </span>

                {/* Color Badge */}
                <span
                  className={`px-2.5 py-0.5 rounded-md font-bold text-[11px] text-white shadow-xs ${
                    primaryColor === 'Green'
                      ? 'bg-[#10b981]'
                      : primaryColor === 'Red'
                      ? 'bg-[#ef4444]'
                      : 'bg-[#a855f7]'
                  }`}
                >
                  {primaryColor}
                </span>

                {/* Number Ball Badge */}
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center font-black text-xs text-white shadow-xs ${
                    num === 0
                      ? 'bg-gradient-to-tr from-[#9c27b0] to-[#f44336]'
                      : num === 5
                      ? 'bg-gradient-to-tr from-[#9c27b0] to-[#4caf50]'
                      : [1, 3, 7, 9].includes(num)
                      ? 'bg-[#10b981]'
                      : 'bg-[#ef4444]'
                  }`}
                >
                  {num}
                </span>

                {/* Big / Small Badge */}
                <span
                  className={`px-2.5 py-0.5 rounded-md font-bold text-[11px] text-white shadow-xs ${
                    bigSmall === 'Big' ? 'bg-[#10b981]' : 'bg-[#3b82f6]'
                  }`}
                >
                  {bigSmall}
                </span>
              </>
            )}
          </div>

          {/* Printer Slot Slit */}
          <div className="mt-4 mx-2 relative">
            <div
              className={`h-3 rounded-full mx-auto w-[92%] shadow-inner ${
                isWin ? 'bg-[#b92c18]/80' : 'bg-[#90caf9]/80'
              }`}
            />

            {/* Receipt Ticket Rolling Downwards from Slot */}
            <div
              className="bg-white rounded-b-2xl mx-auto w-[88%] -mt-1.5 px-4 pt-3 pb-3.5 shadow-xl border border-t-0 border-slate-100 flex flex-col items-center justify-center text-center relative z-10"
              style={{
                boxShadow: '0 12px 25px -4px rgba(0, 0, 0, 0.15)'
              }}
            >
              <div
                className={`text-xs font-bold uppercase tracking-wider ${
                  isWin ? 'text-[#ff5252]' : 'text-[#1976D2]'
                }`}
              >
                {isWin ? 'Bonus' : 'Result'}
              </div>

              {/* Amount Display */}
              <div
                className={`text-3xl font-black tracking-tight mt-0.5 ${
                  isWin ? 'text-[#ff3838]' : 'text-slate-700'
                }`}
              >
                {isWin ? `৳${data.amount.toFixed(2)}` : '৳0.00'}
              </div>

              {/* Game Period Label */}
              <div className="text-[11px] font-semibold text-slate-500 mt-1">
                {data.gameName ? data.gameName : `Period: WinGo ${durationLabel}`}
              </div>

              {/* Period Number */}
              <div className="text-[10px] font-mono text-slate-400 mt-0.5 truncate max-w-full">
                {data.period}
              </div>
            </div>
          </div>

          {/* Auto-Close Checkbox */}
          <div
            onClick={() => setAutoClose(!autoClose)}
            className="flex items-center justify-center space-x-2 mt-4 cursor-pointer text-xs select-none"
          >
            <div
              className={`w-4 h-4 rounded-full flex items-center justify-center transition-colors border ${
                autoClose
                  ? isWin
                    ? 'bg-white border-white text-[#ff4141]'
                    : 'bg-[#1976D2] border-[#1976D2] text-white'
                  : isWin
                  ? 'border-white/60 bg-transparent'
                  : 'border-slate-400 bg-transparent'
              }`}
            >
              {autoClose && <Check className="w-3 h-3 stroke-[3]" />}
            </div>
            <span
              className={`font-medium text-[11px] ${
                isWin ? 'text-white/90' : 'text-slate-700'
              }`}
            >
              3 seconds auto close
            </span>
          </div>
        </div>

        {/* Circular Close Button below card matching screenshot */}
        <button
          onClick={onClose}
          className="mt-5 w-11 h-11 rounded-full border-2 border-white/80 bg-black/40 hover:bg-black/60 text-white flex items-center justify-center transition-transform active:scale-90 shadow-xl backdrop-blur-xs"
          id="close-game-result-modal-btn"
          aria-label="Close"
        >
          <X className="w-5 h-5 stroke-[2.5]" />
        </button>
      </div>
    </div>
  );
};
