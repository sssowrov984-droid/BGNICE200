import React from 'react';
import { Bell, Download, Globe } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useLanguage } from '../context/LanguageContext';
import { BrandLogo } from './BrandLogo';

interface HeaderProps {
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
  rightAction?: React.ReactNode;
  onOpenNotification?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  title, 
  showBack, 
  onBack, 
  rightAction, 
  onOpenNotification 
}) => {
  const { downloadApp, settings, user } = useApp();
  const { language, setLanguage } = useLanguage();

  return (
    <header className="sticky top-0 z-40 w-full max-w-full bg-[#29303d] border-b border-slate-700/60 text-white px-3 sm:px-4 py-2.5 shadow-md flex items-center justify-between overflow-hidden shrink-0 select-none">
      <div className="flex items-center space-x-2 shrink-0">
        {showBack ? (
          <button
            onClick={onBack}
            className="p-1.5 -ml-1 text-white hover:bg-white/10 rounded-full active:scale-95 transition-all"
            id="header-back-btn"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
        ) : null}

        {!title ? (
          <div className="select-none">
            <BrandLogo variant="header" showBadge={false} />
          </div>
        ) : (
          <h1 className="text-base font-bold tracking-wide truncate max-w-[170px]">{title}</h1>
        )}
      </div>

      <div className="flex items-center space-x-1.5 shrink-0">
        {/* Quick Language Toggle: বাংলা / EN */}
        <button
          onClick={() => setLanguage(language === 'bn' ? 'en' : 'bn')}
          className="flex items-center space-x-1 px-2 py-1 rounded-full text-[11px] font-bold bg-white/20 hover:bg-white/30 text-white transition-all shadow-xs border border-white/30 active:scale-95 shrink-0"
          title="Switch Language / ভাষা পরিবর্তন করুন"
          id="header-lang-toggle-btn"
        >
          <Globe className="w-3 h-3 text-yellow-300" />
          <span>{language === 'bn' ? 'EN' : 'বাংলা'}</span>
        </button>

        {rightAction ? (
          rightAction
        ) : (
          <>
            {/* App Direct Download APK Icon */}
            <button
              onClick={downloadApp}
              className="p-1.5 text-white hover:bg-white/15 rounded-full active:scale-95 transition-transform shrink-0"
              title={`Download ${settings.appVersion || 'BGNICE'} App`}
              id="header-download-btn"
            >
              <Download className="w-4 h-4" />
            </button>

            {/* Notification Bell Button */}
            <button
              onClick={onOpenNotification}
              className="relative p-1.5 text-white hover:bg-white/15 active:scale-95 transition-transform rounded-full shrink-0 cursor-pointer"
              title="Notifications"
              id="header-notification-btn"
            >
              <Bell className="w-4 h-4" />
              {user && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-yellow-300 rounded-full animate-pulse shadow-xs"></span>
              )}
            </button>
          </>
        )}
      </div>
    </header>
  );
};

