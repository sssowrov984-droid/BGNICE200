import React, { useState, useEffect } from 'react';
import { X, ArrowUpRight, ArrowDownLeft, Gamepad2, Gift, Clock, FileText, ChevronRight, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DepositItem, WithdrawalItem, BetItem, GiftClaimRecord, AccountTransaction } from '../types';

export type HistoryType = 'game' | 'deposit' | 'withdraw' | 'account' | 'gift';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: HistoryType;
  initialTab?: HistoryType | 'transactions';
  deposits?: DepositItem[];
  withdrawals?: WithdrawalItem[];
  bets?: BetItem[];
  giftClaims?: GiftClaimRecord[];
  transactions?: AccountTransaction[];
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  initialType = 'game',
  initialTab,
  deposits: propDeposits,
  withdrawals: propWithdrawals,
  bets: propBets,
  giftClaims: propGiftClaims,
  transactions: propTransactions
}) => {
  const {
    user,
    deposits: ctxDeposits = [],
    withdrawals: ctxWithdrawals = [],
    userBets: ctxBets = [],
    userGiftClaims: ctxGiftClaims = [],
    userTransactions: ctxTransactions = []
  } = useApp();

  const resolveTab = (tabValue?: string): HistoryType => {
    if (tabValue === 'transactions') return 'account';
    if (['game', 'deposit', 'withdraw', 'account', 'gift'].includes(tabValue || '')) {
      return tabValue as HistoryType;
    }
    return 'game';
  };

  const [tab, setTab] = useState<HistoryType>(() => resolveTab(initialTab || initialType));
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'yesterday' | '7days'>('all');
  const [accountSubFilter, setAccountSubFilter] = useState<'all' | 'moves' | 'deposit_in' | 'withdraw_out' | 'commission' | 'gift' | 'gaming'>('all');

  useEffect(() => {
    if (isOpen) {
      setTab(resolveTab(initialTab || initialType));
    }
  }, [isOpen, initialTab, initialType]);

  if (!isOpen) return null;

  const toArray = <T,>(val: any): T[] => {
    if (!val) return [];
    if (Array.isArray(val)) return val;
    if (typeof val === 'object') return Object.values(val);
    return [];
  };

  // Resolve data safely from props or context
  const bets: BetItem[] = toArray<BetItem>(propBets || ctxBets);
  const deposits: DepositItem[] = toArray<DepositItem>(propDeposits || ctxDeposits).filter(
    (d) => d && (!user || d.uid === user.uid)
  );
  const withdrawals: WithdrawalItem[] = toArray<WithdrawalItem>(propWithdrawals || ctxWithdrawals).filter(
    (w) => w && (!user || w.uid === user.uid)
  );
  const giftClaims: GiftClaimRecord[] = toArray<GiftClaimRecord>(propGiftClaims || ctxGiftClaims);
  const transactions: AccountTransaction[] = toArray<AccountTransaction>(propTransactions || ctxTransactions);

  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startOfYesterday = startOfToday - 24 * 60 * 60 * 1000;
  const sevenDaysAgo = startOfToday - 6 * 24 * 60 * 60 * 1000;

  const filterByDate = (timestamp: number) => {
    if (dateFilter === 'today') return timestamp >= startOfToday;
    if (dateFilter === 'yesterday') return timestamp >= startOfYesterday && timestamp < startOfToday;
    if (dateFilter === '7days') return timestamp >= sevenDaysAgo;
    return true;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl space-y-4 border border-slate-100 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <h3 className="text-base font-black text-slate-900 flex items-center space-x-2">
            <FileText className="w-5 h-5 text-[#ff4747]" />
            <span>Transaction & Records</span>
          </h3>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600"
            id="close-history-modal-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* History Category Tabs */}
        <div className="grid grid-cols-5 gap-1 bg-slate-100 p-1 rounded-2xl text-[11px] font-bold text-slate-600">
          <button
            onClick={() => setTab('game')}
            className={`py-2 rounded-xl transition-all ${
              tab === 'game' ? 'bg-white text-[#ff4747] shadow-xs' : 'hover:text-slate-900'
            }`}
          >
            Game
          </button>
          <button
            onClick={() => setTab('deposit')}
            className={`py-2 rounded-xl transition-all ${
              tab === 'deposit' ? 'bg-white text-[#ff4747] shadow-xs' : 'hover:text-slate-900'
            }`}
          >
            Deposit
          </button>
          <button
            onClick={() => setTab('withdraw')}
            className={`py-2 rounded-xl transition-all ${
              tab === 'withdraw' ? 'bg-white text-[#ff4747] shadow-xs' : 'hover:text-slate-900'
            }`}
          >
            Withdraw
          </button>
          <button
            onClick={() => setTab('account')}
            className={`py-2 rounded-xl transition-all ${
              tab === 'account' ? 'bg-white text-[#ff4747] shadow-xs' : 'hover:text-slate-900'
            }`}
          >
            Account
          </button>
          <button
            onClick={() => setTab('gift')}
            className={`py-2 rounded-xl transition-all ${
              tab === 'gift' ? 'bg-white text-[#ff4747] shadow-xs' : 'hover:text-slate-900'
            }`}
          >
            Gifts
          </button>
        </div>

        {/* Date Filter Pills */}
        <div className="flex items-center space-x-2 text-[11px] font-semibold">
          {(['all', 'today', 'yesterday', '7days'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setDateFilter(filter)}
              className={`px-3 py-1 rounded-full capitalize transition-all ${
                dateFilter === filter
                  ? 'bg-[#2196f3] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {filter === '7days' ? 'Last 7 Days' : filter}
            </button>
          ))}
        </div>

        {/* Content List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 text-xs">
          {/* 1. Game History */}
          {tab === 'game' && (
            <>
              {bets.filter((b) => filterByDate(b.createdAt)).length === 0 ? (
                <div className="text-center py-12 text-slate-400">No game records found.</div>
              ) : (
                bets
                  .filter((b) => filterByDate(b.createdAt))
                  .map((bet, bIdx) => {
                    const isWin = bet.status === 'won';
                    const isPending = bet.status === 'pending';
                    const isBig = bet.selectValue === 'Big';
                    const isSmall = bet.selectValue === 'Small';

                    return (
                      <div
                        key={`h-bet-${bet.id || bIdx}-${bIdx}`}
                        className="bg-slate-50 rounded-2xl p-3 border border-slate-100 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <span
                              className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold uppercase ${
                                isBig
                                  ? 'bg-amber-400 text-slate-950'
                                  : isSmall
                                  ? 'bg-sky-500 text-white'
                                  : 'bg-slate-800 text-white'
                              }`}
                            >
                              {bet.selectValue}
                            </span>
                            <span className="font-mono text-xs font-bold text-slate-700">
                              {bet.periodId}
                            </span>
                          </div>

                          <span
                            className={`font-black text-xs px-2 py-0.5 rounded-md border ${
                              isPending
                                ? 'bg-amber-50 text-amber-600 border-amber-200'
                                : isWin
                                ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
                                : 'bg-red-50 text-slate-500 border-slate-200'
                            }`}
                          >
                            {isPending ? 'Pending' : isWin ? `+৳${(bet.winAmount || 0).toFixed(2)}` : `-৳${bet.totalAmount.toFixed(2)}`}
                          </span>
                        </div>

                        <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                          <span>Amount: ৳{bet.totalAmount.toFixed(2)} ({bet.gameType})</span>
                          <span>{new Date(bet.createdAt).toLocaleString()}</span>
                        </div>
                      </div>
                    );
                  })
              )}
            </>
          )}

          {/* 2. Deposit History */}
          {tab === 'deposit' && (
            <>
              {deposits.filter((d) => filterByDate(d.createdAt)).length === 0 ? (
                <div className="text-center py-12 text-slate-400">No deposit records found.</div>
              ) : (
                deposits
                  .filter((d) => filterByDate(d.createdAt))
                  .map((dep, dIdx) => (
                    <div
                      key={`h-dep-${dep.id || dIdx}-${dIdx}`}
                      className="bg-slate-50 rounded-2xl p-3 border border-slate-100 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-1.5">
                          <span className="px-2 py-0.5 rounded-md bg-emerald-500 text-white font-bold text-[10px]">
                            Deposit
                          </span>
                          <span className="font-semibold text-slate-800 text-xs">{dep.channel}</span>
                        </div>
                        <span className="font-black text-emerald-600 text-sm">
                          +৳{dep.amount.toFixed(2)}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-500">
                        <span>TxnID: <strong className="font-mono text-slate-800">{dep.txnId}</strong></span>
                        <span
                          className={`font-bold capitalize ${
                            dep.status === 'completed' || dep.status === 'success'
                              ? 'text-emerald-600'
                              : dep.status === 'pending'
                              ? 'text-amber-500'
                              : 'text-red-500'
                          }`}
                        >
                          {dep.status === 'completed' || dep.status === 'success'
                            ? 'Success'
                            : dep.status === 'pending'
                            ? 'Processing'
                            : 'Rejected'}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {new Date(dep.createdAt).toLocaleString()}
                      </div>
                    </div>
                  ))
              )}
            </>
          )}

          {/* 3. Withdraw History */}
          {tab === 'withdraw' && (
            <>
              {withdrawals.filter((w) => filterByDate(w.createdAt)).length === 0 ? (
                <div className="text-center py-12 text-slate-400">No withdrawal records found.</div>
              ) : (
                withdrawals
                  .filter((w) => filterByDate(w.createdAt))
                  .map((withItem, wIdx) => (
                    <div
                      key={`h-with-${withItem.id || wIdx}-${wIdx}`}
                      className="bg-slate-50 rounded-2xl p-3 border border-slate-100 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-1.5">
                          <span className="px-2 py-0.5 rounded-md bg-orange-500 text-white font-bold text-[10px]">
                            Withdraw
                          </span>
                          <span className="font-semibold text-slate-800 text-xs">
                            {withItem.walletMethod}
                          </span>
                        </div>
                        <span className="font-black text-[#ff4747] text-sm">
                          -৳{withItem.amount.toFixed(2)}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-500">
                        <span>Account: <strong className="font-mono text-slate-800">{withItem.accountNumber}</strong></span>
                        <span
                          className={`font-bold capitalize ${
                            withItem.status === 'completed'
                              ? 'text-emerald-600'
                              : withItem.status === 'pending'
                              ? 'text-amber-500'
                              : 'text-red-500'
                          }`}
                        >
                          {withItem.status === 'completed'
                            ? 'Success'
                            : withItem.status === 'pending'
                            ? 'Processing'
                            : 'Rejected'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                        <span>Order: {withItem.orderId || withItem.id}</span>
                        <span>{new Date(withItem.createdAt).toLocaleString()}</span>
                      </div>

                      {(withItem.rejectionReason || withItem.remark) && (
                        <div className="bg-rose-50 border border-rose-200 rounded-xl p-2 text-[11px] text-rose-800 space-y-0.5">
                          <span className="font-bold text-rose-700">Rejection Reason: </span>
                          <span>{withItem.rejectionReason || withItem.remark}</span>
                        </div>
                      )}
                    </div>
                  ))
              )}
            </>
          )}

          {/* 4. Account Balance History */}
          {tab === 'account' && (
            <div className="space-y-3">
              {/* Sub-filters for Account History */}
              <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 no-scrollbar text-[11px] font-bold">
                {[
                  { id: 'all', label: 'All' },
                  { id: 'moves', label: 'Move In/Out' },
                  { id: 'deposit_in', label: 'Deposit In' },
                  { id: 'withdraw_out', label: 'Transfer Out' },
                  { id: 'commission', label: 'Commission' },
                  { id: 'gift', label: 'Gift Bonus' },
                  { id: 'gaming', label: 'Bet / Win' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setAccountSubFilter(item.id as any)}
                    className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-all ${
                      accountSubFilter === item.id
                        ? 'bg-slate-900 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              {(() => {
                const filteredTx = transactions.filter((t) => {
                  if (!filterByDate(t.createdAt)) return false;
                  if (accountSubFilter === 'moves') return t.type === 'move_in' || t.type === 'move_out';
                  if (accountSubFilter === 'deposit_in') return t.type === 'deposit_in' || t.type === 'deposit';
                  if (accountSubFilter === 'withdraw_out') return t.type === 'withdraw_out' || t.type === 'withdrawal';
                  if (accountSubFilter === 'commission') return t.type === 'referral_commission';
                  if (accountSubFilter === 'gift') return t.type === 'gift_code';
                  if (accountSubFilter === 'gaming') return t.type === 'bet' || t.type === 'win';
                  return true;
                });

                if (filteredTx.length === 0) {
                  return (
                    <div className="text-center py-12 text-slate-400">
                      No matching account history records found.
                    </div>
                  );
                }

                const getBadgeStyle = (type: AccountTransaction['type']) => {
                  switch (type) {
                    case 'move_in':
                      return { label: 'Move In 📥', cls: 'bg-indigo-100 text-indigo-800 border-indigo-200' };
                    case 'move_out':
                      return { label: 'Move Out 📤', cls: 'bg-purple-100 text-purple-800 border-purple-200' };
                    case 'deposit_in':
                    case 'deposit':
                      return { label: 'Transfer In 💰', cls: 'bg-emerald-100 text-emerald-800 border-emerald-200' };
                    case 'withdraw_out':
                    case 'withdrawal':
                      return { label: 'Transfer Out 💸', cls: 'bg-rose-100 text-rose-800 border-rose-200' };
                    case 'referral_commission':
                      return { label: 'Referral Comm. 👥', cls: 'bg-amber-100 text-amber-900 border-amber-200' };
                    case 'gift_code':
                      return { label: 'Gift Bonus 🎁', cls: 'bg-pink-100 text-pink-800 border-pink-200' };
                    case 'win':
                      return { label: 'Game Win 🏆', cls: 'bg-emerald-100 text-emerald-800 border-emerald-200' };
                    case 'bet':
                      return { label: 'Game Bet 🎲', cls: 'bg-slate-200 text-slate-800 border-slate-300' };
                    case 'vip_bonus':
                      return { label: 'VIP Bonus 👑', cls: 'bg-yellow-100 text-yellow-900 border-yellow-200' };
                    case 'attendance':
                      return { label: 'Daily Attendance 📅', cls: 'bg-sky-100 text-sky-800 border-sky-200' };
                    default:
                      return { label: type.replace('_', ' ').toUpperCase(), cls: 'bg-slate-100 text-slate-700 border-slate-200' };
                  }
                };

                return (
                  <div className="space-y-2">
                    {filteredTx.map((t, tIdx) => {
                      const badge = getBadgeStyle(t.type);
                      const isMove = t.type === 'move_in' || t.type === 'move_out';
                      return (
                        <div
                          key={`h-tx-${t.id || tIdx}-${tIdx}`}
                          className="bg-slate-50 rounded-2xl p-3 border border-slate-100 space-y-1.5 hover:border-slate-300 transition-colors"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-1.5">
                              <span className={`px-2 py-0.5 rounded-md font-extrabold text-[10px] border ${badge.cls}`}>
                                {badge.label}
                              </span>
                              <span className="font-semibold text-slate-700 text-xs truncate max-w-[140px]">
                                {t.type.replace('_', ' ')}
                              </span>
                            </div>

                            {isMove ? (
                              <span className="font-bold text-xs text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                                ৳{t.newBalance.toFixed(2)}
                              </span>
                            ) : (
                              <span
                                className={`font-black text-sm ${
                                  t.amount >= 0 ? 'text-emerald-600' : 'text-[#ff4747]'
                                }`}
                              >
                                {t.amount >= 0 ? `+৳${t.amount.toFixed(2)}` : `-৳${Math.abs(t.amount).toFixed(2)}`}
                              </span>
                            )}
                          </div>

                          <p className="text-[11px] text-slate-600 font-medium leading-relaxed">
                            {t.description}
                          </p>

                          <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono pt-1.5 border-t border-slate-200/60">
                            <span>
                              Bal: ৳{t.previousBalance !== undefined ? t.previousBalance.toFixed(2) : '0.00'} → <strong className="text-slate-700">৳{t.newBalance.toFixed(2)}</strong>
                            </span>
                            <span>{new Date(t.createdAt).toLocaleString()}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>
          )}

          {/* 5. Gift Codes History */}
          {tab === 'gift' && (
            <>
              {giftClaims.filter((g) => filterByDate(g.claimedAt)).length === 0 ? (
                <div className="text-center py-12 text-slate-400">No gift codes redeemed yet.</div>
              ) : (
                giftClaims
                  .filter((g) => filterByDate(g.claimedAt))
                  .map((gc, gcIdx) => (
                    <div
                      key={`h-gc-${gc.id || gcIdx}-${gcIdx}`}
                      className="bg-slate-50 rounded-2xl p-3 border border-slate-100 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-slate-800 text-xs">{gc.code}</span>
                        <span className="font-black text-emerald-600 text-sm">+৳{gc.amount.toFixed(2)}</span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                        <span>Redeemed</span>
                        <span>{new Date(gc.claimedAt).toLocaleString()}</span>
                      </div>
                    </div>
                  ))
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
