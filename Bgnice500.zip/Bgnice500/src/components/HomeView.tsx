import React, { useState, useMemo, useEffect } from 'react';
import {
  Volume2,
  Flame,
  TrendingUp,
  Sparkles,
  Play,
  MonitorDown,
  Download,
  Smartphone,
  Search,
  X,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Gamepad2,
  ShieldCheck,
  Award
} from 'lucide-react';
import { useApp, defaultBannersSeed } from '../context/AppContext';
import { TabType } from './BottomNav';
import { GameItem, BannerItem } from '../types';
import { POPULAR_JILI_GAMES } from '../data/popularGamesData';
import { DEFAULT_FEATURED_GAMES, FeaturedGameCard } from '../data/featuredGames';
import { CategoryCardView } from './CategoryCardView';
import { TopEarningsLeaderboard } from './TopEarningsLeaderboard';
import { getAvatarById } from '../utils/avatars';

interface HomeViewProps {
  onNavigate: (tab: TabType | 'settings' | 'gameHistory') => void;
  onOpenAnnouncement: () => void;
  onOpenAuth: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onNavigate,
  onOpenAnnouncement,
  onOpenAuth
}) => {
  const { settings, games, banners, user, showToast, downloadApp, allBets, allUsers, recordGameMove, refreshBalance, setIsGameActive } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('popular');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeGameModal, setActiveGameModal] = useState<GameItem | null>(null);
  const [activeBannerIndex, setActiveBannerIndex] = useState(0);

  useEffect(() => {
    setIsGameActive(!!activeGameModal);
    return () => {
      setIsGameActive(false);
    };
  }, [activeGameModal, setIsGameActive]);

  const closeCurrentGameModal = () => {
    if (activeGameModal) {
      recordGameMove('move_out', activeGameModal.name);
      setActiveGameModal(null);
    }
  };

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (!event.data) return;
      if (event.data.type === 'CLOSE_GAME') {
        closeCurrentGameModal();
      } else if (event.data.type === 'BALANCE_UPDATE' || event.data.type === 'REFRESH_BALANCE') {
        refreshBalance();
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [activeGameModal]);

  const categories = [
    { id: 'popular', label: 'Popular', icon: '🏆', badge: 'HOT' },
    { id: 'lottery', label: 'Wingo Lottery', icon: '🎱', badge: 'WIN' },
    { id: 'original', label: 'Original', icon: '✈️', badge: 'TOP' },
    { id: 'slots', label: 'Slots', icon: '🎰', badge: '777' },
    { id: 'sports', label: 'Sports', icon: '⚽', badge: 'LIVE' },
    { id: 'casino', label: 'Casino', icon: '🎲', badge: 'VIP' },
    { id: 'rummy', label: 'Rummy', icon: '🃏', badge: 'FAST' },
    { id: 'fishing', label: 'Fishing', icon: '🦈', badge: 'NEW' }
  ];

  // Active sorted banners from Firebase, guaranteed 5 slots fallback
  const activeBanners = useMemo(() => {
    let bannerList: BannerItem[] = [];
    if (banners) {
      bannerList = Array.isArray(banners) ? banners : Object.values(banners);
    }
    const filtered = bannerList.filter((b) => b && b.active !== false);
    if (filtered.length > 0) {
      return filtered.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
    }
    // Fallback: 5 high-converting default banners
    return Object.values(defaultBannersSeed).sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  }, [banners]);

  // Automated Banner Carousel Interval
  useEffect(() => {
    if (activeBanners.length <= 1) return;
    const timer = setInterval(() => {
      setActiveBannerIndex((prev) => (prev + 1) % activeBanners.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [activeBanners.length]);

  const handleNextBanner = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setActiveBannerIndex((prev) => (prev + 1) % activeBanners.length);
  };

  const handlePrevBanner = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setActiveBannerIndex((prev) => (prev - 1 + activeBanners.length) % activeBanners.length);
  };

  // Touch swipe support for mobile gesture sliding
  const touchStartX = React.useRef<number | null>(null);
  const touchEndX = React.useRef<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (touchStartX.current !== null && touchEndX.current !== null) {
      const diff = touchStartX.current - touchEndX.current;
      if (diff > 45) {
        // Swiped left -> next banner
        setActiveBannerIndex((prev) => (prev + 1) % activeBanners.length);
      } else if (diff < -45) {
        // Swiped right -> previous banner
        setActiveBannerIndex((prev) => (prev - 1 + activeBanners.length) % activeBanners.length);
      }
    }
    touchStartX.current = null;
    touchEndX.current = null;
  };

  // Filter featured cards according to category requested by user
  const activeFeaturedCards = useMemo(() => {
    if (selectedCategory === 'popular') {
      return DEFAULT_FEATURED_GAMES; // 6 cards: Wingo Lottery, K3 Lottery, 5D Lottery, TRX Wingo, Aviator, Aviator X
    }
    if (selectedCategory === 'lottery') {
      return DEFAULT_FEATURED_GAMES.filter((g) => g.category === 'Lottery'); // Wingo, 5D, TRX, K3
    }
    if (selectedCategory === 'original') {
      return DEFAULT_FEATURED_GAMES.filter((g) => g.category === 'Original'); // Aviator, Aviator X
    }
    return [];
  }, [selectedCategory]);

  const getGameKey = (card: FeaturedGameCard): 'wingo' | 'k3' | 'fiveD' | 'trx' | 'aviator' | 'aviatorX' | null => {
    if (card.actionType === 'wingo') return 'wingo';
    if (card.actionType === 'k3') return 'k3';
    if (card.actionType === 'fiveD') return 'fiveD';
    if (card.actionType === 'trx') return 'trx';
    if (card.id === 'aviatorX') return 'aviatorX';
    if (card.id === 'aviator' || card.actionType === 'aviator') return 'aviator';
    return null;
  };

  const isGameOffline = (card: FeaturedGameCard) => {
    const key = getGameKey(card);
    if (!key) return false;
    return settings?.enabledGames?.[key] === false;
  };

  const handleLaunchFeaturedCard = (card: FeaturedGameCard) => {
    if (!user) {
      onOpenAuth();
      return;
    }

    if (isGameOffline(card)) {
      showToast(`⚠️ ${card.name} is currently offline for maintenance by admin. (গেমটি সাময়িক বন্ধ আছে)`, 'warning');
      return;
    }

    if (card.actionType === 'wingo') {
      onNavigate('wingo');
      return;
    }
    if (card.actionType === 'k3') {
      onNavigate('k3');
      return;
    }
    if (card.actionType === 'fiveD') {
      onNavigate('fiveD');
      return;
    }
    if (card.actionType === 'trx') {
      onNavigate('trx');
      return;
    }
    if (card.id === 'aviatorX') {
      onNavigate('aviatorX');
      return;
    }
    if (card.id === 'aviator' || card.actionType === 'aviator') {
      onNavigate('aviator');
      return;
    }
  };

  // Dynamic rotating winners feed with real and authentic players matching Screenshot_20260911-213716.png
  const baseWinners = useMemo(() => {
    const defaultList = [
      { name: 'Mem***RGF', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100', game: 'Win Go 30s', amount: 84.28 },
      { name: 'Mem***MWZ', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100', game: 'Win Go 1m', amount: 98.00 },
      { name: 'Mem***FSL', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=100', game: 'Win Go 30s', amount: 98.00 },
      { name: 'Mem***HDB', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100', game: 'Win Go 5m', amount: 196.00 },
      { name: 'Mem***382', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100', game: 'Win Go 30s', amount: 392.00 },
      { name: 'Mem***711', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100', game: 'Win Go 2m', amount: 147.00 },
      { name: 'Mem***904', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100', game: 'Win Go 1m', amount: 490.00 }
    ];

    // Inject real bets from system if any won
    const realWinners: typeof defaultList = [];
    if (Array.isArray(allBets)) {
      allBets.slice(0, 10).forEach((b) => {
        if (b && (b.status === 'win' || (b.payout && b.payout > 0))) {
          const uProfile = allUsers && b.userId ? allUsers[b.userId] : null;
          const uName = uProfile?.username || uProfile?.phone || 'Mem';
          const masked = uName.length > 4 ? `${uName.slice(0, 3)}***${uName.slice(-3)}` : `Mem***${b.userId.slice(-3)}`;
          let userAvatarUrl = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100';
          if (uProfile?.avatar) {
            userAvatarUrl = uProfile.avatar.startsWith('http')
              ? uProfile.avatar
              : (getAvatarById(uProfile.avatar)?.photoUrl || userAvatarUrl);
          }
          realWinners.push({
            name: masked,
            avatar: userAvatarUrl,
            game: b.type === 'wingo' ? 'Win Go 30s' : 'Win Go',
            amount: Number(b.payout || b.amount * 1.96)
          });
        }
      });
    }

    return [...realWinners, ...defaultList];
  }, [allBets, allUsers]);

  const [feedOffset, setFeedOffset] = useState(0);

  useEffect(() => {
    const feedTimer = setInterval(() => {
      setFeedOffset((prev) => (prev + 1) % baseWinners.length);
    }, 3200);
    return () => clearInterval(feedTimer);
  }, [baseWinners.length]);

  const currentWinnersFeed = useMemo(() => {
    const list = [];
    for (let i = 0; i < 5; i++) {
      list.push(baseWinners[(feedOffset + i) % baseWinners.length]);
    }
    return list;
  }, [feedOffset, baseWinners]);

  // Filter games based on search query, category, and active status
  const filteredGames = useMemo(() => {
    const gamesList: GameItem[] = games
      ? Array.isArray(games)
        ? games
        : Object.values(games)
      : [];
    const activeGames = gamesList.filter((g) => g && g.status !== false);

    if (searchQuery.trim().length > 0) {
      const q = searchQuery.toLowerCase().trim();
      return activeGames.filter(
        (g) =>
          g.name.toLowerCase().includes(q) ||
          g.category.toLowerCase().includes(q)
      );
    }

    if (selectedCategory === 'popular') {
      return activeGames;
    }

    return activeGames.filter(
      (g) => g.category.toLowerCase() === selectedCategory.toLowerCase()
    );
  }, [games, selectedCategory, searchQuery]);

  // Safe game launch supporting both local HTML5 games and External API Provider games
  const handleLaunchGame = (game: GameItem) => {
    if (!user) {
      onOpenAuth();
      return;
    }

    const pathOrEndpoint = (game.gamePath || game.apiEndpoint || '').trim();
    if (!pathOrEndpoint) {
      showToast('Game launcher path is currently being updated.', 'info');
      return;
    }

    recordGameMove('move_in', game.name);
    setActiveGameModal(game);
  };

  const getGameLaunchUrl = (game: GameItem): string => {
    const raw = (game.gamePath || game.apiEndpoint || '').trim();
    if (!raw) return '';

    // If it is an external URL (API provider launch URL)
    if (raw.startsWith('http://') || raw.startsWith('https://')) {
      if (game.apiAutoSession !== false && user) {
        const separator = raw.includes('?') ? '&' : '?';
        const params = new URLSearchParams({
          uid: user.numericUid || user.uid,
          token: user.uid,
          currency: 'BDT',
          lang: 'en'
        });
        if (game.apiGameCode) {
          params.append('gameCode', game.apiGameCode);
        }
        return `${raw}${separator}${params.toString()}`;
      }
      return raw;
    }

    // Local Public HTML5 Game path (e.g. games/cointoss/index.html or public/games/crash/index.html)
    let cleanPath = raw;
    if (cleanPath.startsWith('public/')) {
      cleanPath = cleanPath.slice(7);
    } else if (cleanPath.startsWith('/public/')) {
      cleanPath = cleanPath.slice(8);
    }
    const base = cleanPath.startsWith('/') ? cleanPath : `/${cleanPath}`;
    if (user) {
      const sep = base.includes('?') ? '&' : '?';
      return `${base}${sep}uid=${encodeURIComponent(user.uid)}&balance=${user.balance || 0}`;
    }
    return base;
  };

  const handleBannerAction = (action?: string) => {
    if (!action) {
      onNavigate('wingo');
      return;
    }
    if (action === 'download') {
      downloadApp();
      return;
    }
    if (!user && (action === 'deposit' || action === 'withdraw' || action === 'safe' || action === 'wingo')) {
      onOpenAuth();
      return;
    }
    onNavigate(action as TabType);
  };

  return (
    <div className="w-full pb-24 text-slate-800 select-none">
      <div className="w-full p-3 space-y-3.5">
        {/* Dynamic Firebase Banners Carousel */}
        {activeBanners.length > 0 ? (
          <div
            className="relative overflow-hidden rounded-2xl shadow-md group touch-pan-y bg-slate-950 w-full aspect-[2.35/1] sm:aspect-[2.5/1] min-h-[140px] max-h-[220px]"
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            {activeBanners.map((banner, index) => {
              const isActive = index === activeBannerIndex;
              return (
                <div
                  key={`home-banner-${banner.id || index}-${index}`}
                  className={`transition-opacity duration-500 ${
                    isActive ? 'block relative' : 'hidden'
                  } w-full h-full cursor-pointer`}
                  onClick={() => handleBannerAction(banner.action)}
                >
                  {banner.image ? (
                    /* Clean, crystal-clear banner image preserving natural aspect ratio without distortion */
                    <img
                      src={banner.image || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80'}
                      alt={banner.title || 'Promotional Banner'}
                      className="w-full h-full object-cover object-center rounded-2xl select-none"
                      style={{ imageRendering: '-webkit-optimize-contrast' }}
                      loading="eager"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src =
                          'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80';
                      }}
                    />
                  ) : (
                    /* Fallback styled gradient when banner is text-only */
                    <div className="w-full h-full bg-gradient-to-r from-[#d32f2f] via-[#f44336] to-[#ff5722] p-4 text-white rounded-2xl flex flex-col justify-center">
                      <div className="relative z-10 max-w-[78%] space-y-1">
                        <div className="inline-flex items-center space-x-1 bg-amber-400 text-slate-950 font-black text-[9px] px-2 py-0.5 rounded-full uppercase shadow-xs">
                          <Sparkles className="w-2.5 h-2.5" />
                          <span>Official Platform</span>
                        </div>
                        <h2 className="text-sm sm:text-base font-black leading-tight tracking-tight drop-shadow-sm truncate">
                          {banner.title}
                        </h2>
                        <p className="text-[10px] text-white/95 font-medium leading-tight line-clamp-1">
                          {banner.subtitle}
                        </p>
                        <div className="pt-1">
                          <span className="inline-flex items-center space-x-1 px-3.5 py-1 rounded-full bg-white text-[#ff4747] font-black text-[11px] shadow-sm">
                            <Play className="w-2.5 h-2.5 fill-current" />
                            <span>{banner.buttonText || 'Play Now'}</span>
                          </span>
                        </div>
                      </div>
                      <div className="absolute -right-3 -bottom-3 w-28 h-28 opacity-85 pointer-events-none flex items-center justify-center">
                        <div className="w-20 h-20 rounded-full bg-amber-400/30 blur-lg absolute"></div>
                        <span className="text-5xl drop-shadow-md">🏆</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {/* Carousel Dots, Slide Counter & Arrow Controls */}
            {activeBanners.length > 1 && (
              <>
                {/* Arrow Navigation */}
                <button
                  type="button"
                  onClick={handlePrevBanner}
                  className="absolute left-1.5 top-1/2 -translate-y-1/2 z-20 w-6 h-6 rounded-full bg-black/40 text-white flex items-center justify-center backdrop-blur-xs hover:bg-black/60 active:scale-95 transition-all opacity-80 group-hover:opacity-100"
                  aria-label="Previous Banner"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={handleNextBanner}
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 z-20 w-6 h-6 rounded-full bg-black/40 text-white flex items-center justify-center backdrop-blur-xs hover:bg-black/60 active:scale-95 transition-all opacity-80 group-hover:opacity-100"
                  aria-label="Next Banner"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>

                {/* Counter and Dots */}
                <div className="absolute bottom-2 right-2.5 z-20 flex items-center space-x-1.5 bg-black/40 backdrop-blur-xs px-2 py-0.5 rounded-full">
                  <span className="text-[9px] font-mono text-amber-300 font-bold">
                    {activeBannerIndex + 1}/{activeBanners.length}
                  </span>
                  <div className="flex items-center space-x-1">
                    {activeBanners.map((_, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveBannerIndex(i);
                        }}
                        className={`h-1 rounded-full transition-all ${
                          i === activeBannerIndex ? 'bg-amber-400 w-3' : 'bg-white/50 w-1'
                        }`}
                        aria-label={`Slide ${i + 1}`}
                      />
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        ) : (
          /* Fallback Default Banner */
          <div
            onClick={() => onNavigate('wingo')}
            className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#d32f2f] via-[#f44336] to-[#ff5722] p-4 text-white shadow-sm h-[145px] sm:h-[165px] flex flex-col justify-center cursor-pointer"
          >
            <div className="relative z-10 max-w-[75%] space-y-1.5">
              <div className="inline-flex items-center space-x-1 bg-amber-400 text-slate-950 font-black text-[9px] px-2 py-0.5 rounded-full uppercase shadow-xs">
                <Sparkles className="w-2.5 h-2.5" />
                <span>Official Platform</span>
              </div>
              <h2 className="text-sm sm:text-base font-black leading-tight tracking-tight drop-shadow-sm truncate">
                Largest Online Entertainment Hub
              </h2>
              <p className="text-[10px] text-white/90 font-medium leading-tight truncate">
                Reputation guarantee • Instant Nagad & bKash payouts
              </p>
              <div className="pt-1">
                <span className="inline-flex items-center space-x-1 px-3.5 py-1 rounded-full bg-white text-[#ff4747] font-black text-[11px] shadow-sm">
                  <Play className="w-2.5 h-2.5 fill-current" />
                  <span>Play Win Go</span>
                </span>
              </div>
            </div>

            <div className="absolute -right-3 -bottom-3 w-28 h-28 opacity-85 pointer-events-none flex items-center justify-center">
              <div className="w-20 h-20 rounded-full bg-amber-400/30 blur-lg absolute"></div>
              <span className="text-5xl drop-shadow-md">🏆</span>
            </div>
          </div>
        )}

        {/* Marquee Ticker Bar */}
        <div className="bg-white rounded-2xl p-2.5 shadow-sm border border-slate-100 flex items-center space-x-2">
          <div className="w-7 h-7 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center shrink-0">
            <Volume2 className="w-4 h-4" />
          </div>
          <div className="flex-1 overflow-hidden whitespace-nowrap text-xs text-slate-600">
            <div className="animate-marquee inline-block font-medium">
              {settings.platformAnnouncement ||
                'Attention! Official Nagad, bKash & Rocket 24/7 automated deposits & withdrawals are active!'}
            </div>
          </div>
          <button
            onClick={onOpenAnnouncement}
            className="shrink-0 px-2.5 py-1 rounded-full bg-gradient-to-r from-red-500 to-orange-500 text-white font-bold text-[10px] flex items-center space-x-0.5 shadow-xs active:scale-95"
            id="home-detail-announcement-btn"
          >
            <Flame className="w-3 h-3 fill-current" />
            <span>Detail</span>
          </button>
        </div>

        {/* Game Search Box */}
        <div className="relative">
          <div className="relative flex items-center bg-white rounded-2xl border border-slate-200/80 shadow-xs focus-within:border-[#ff4747] focus-within:ring-2 focus-within:ring-[#ff4747]/10 transition-all">
            <Search className="w-4 h-4 text-slate-400 ml-3.5 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search games: Win Go, Aviator, 777, Crash, Ludo..."
              className="w-full py-2.5 pl-2.5 pr-8 text-xs text-slate-800 placeholder-slate-400 outline-none rounded-2xl bg-transparent"
              id="game-search-input"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 p-1 rounded-full hover:bg-slate-100 text-slate-400"
                aria-label="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Game Category Section matching Screenshot 2 */}
        <div className="space-y-2">
          {searchQuery && (
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Game Search
              </span>
              <span className="text-[11px] text-[#2196f3] font-semibold">
                Found {filteredGames.length} game{filteredGames.length !== 1 ? 's' : ''}
              </span>
            </div>
          )}

          {/* 3-Tier BGNICE Category Card View */}
          <CategoryCardView
            selectedCategory={selectedCategory}
            onSelectCategory={(catId) => {
              setSelectedCategory(catId);
              setSearchQuery('');
            }}
          />
        </div>

        {/* Featured Game Cards (Popular: 6, Wingo Lottery: 4, Original: 2) */}
        {activeFeaturedCards.length > 0 && !searchQuery ? (
          <div className="space-y-3.5">
            <div className="flex items-center justify-between pt-1 px-0.5">
              <div className="flex items-center space-x-2">
                <div className="w-1.5 h-4.5 bg-[#2196f3] rounded-full"></div>
                <h3 className="font-black text-sm sm:text-base text-slate-900 capitalize">
                  {selectedCategory === 'popular'
                    ? 'Popular'
                    : selectedCategory === 'lottery'
                    ? 'Lottery'
                    : selectedCategory === 'original'
                    ? 'Original'
                    : `${selectedCategory}`}
                </h3>
              </div>
              {/* Add to Desktop / Install App button matching Screenshot 2 */}
              <button
                onClick={downloadApp}
                className="flex items-center space-x-1.5 px-3 py-1 rounded-full bg-white border border-slate-200 shadow-xs hover:bg-slate-50 text-slate-700 text-xs font-bold active:scale-95 transition-all cursor-pointer"
                id="home-add-desktop-btn"
              >
                <div className="w-4 h-4 rounded-full bg-gradient-to-tr from-[#1976d2] to-[#2196f3] flex items-center justify-center text-white text-[9px] font-black">
                  ★
                </div>
                <span>Add to Desktop</span>
                <Download className="w-3 h-3 text-slate-500" />
              </button>
            </div>

            {/* Exact 6 Featured Cards (Wingo Lottery, K3 Lottery, 5D Lottery, TRX Wingo, Aviator, Aviator X) */}
            <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
              {activeFeaturedCards.map((card) => {
                const cardImg = settings?.gameCardImages?.[card.id] || card.defaultImage;
                const isOffline = isGameOffline(card);
                return (
                  <div
                    key={`feat-card-${card.id}`}
                    onClick={() => handleLaunchFeaturedCard(card)}
                    className={`group flex flex-col cursor-pointer active:scale-95 transition-transform ${
                      isOffline ? 'opacity-75' : ''
                    }`}
                    id={`featured-card-${card.id}`}
                  >
                    <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-slate-900 border-2 border-[#ff4747] shadow-sm">
                      <img
                        src={cardImg || card.defaultImage || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80'}
                        alt={card.name}
                        referrerPolicy="no-referrer"
                        className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 ${
                          isOffline ? 'grayscale' : ''
                        }`}
                        onError={(e) => {
                          (e.target as HTMLImageElement).src =
                            card.defaultImage ||
                            'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80';
                        }}
                      />
                      {/* Provider / Badge Tag */}
                      <span className="absolute top-1 right-1 z-10 text-[9px] font-black text-amber-300 bg-black/70 backdrop-blur-xs px-1.5 py-0.5 rounded shadow-xs tracking-wider">
                        {isOffline ? 'PAUSED' : card.badge}
                      </span>
                      {/* Name Overlay */}
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/95 via-black/60 to-transparent pt-3.5 pb-1 px-1 text-center">
                        <span className="text-[10px] sm:text-[11px] font-black text-white uppercase tracking-wider block truncate drop-shadow-md">
                          {card.name}
                        </span>
                      </div>

                      {/* Maintenance Overlay if game is toggled OFF */}
                      {isOffline && (
                        <div className="absolute inset-0 bg-black/75 backdrop-blur-[1px] z-20 flex flex-col items-center justify-center p-1 text-center">
                          <span className="text-base">🔒</span>
                          <span className="text-[9px] font-black text-red-400 uppercase tracking-wider">
                            OFFLINE
                          </span>
                          <span className="text-[8px] text-slate-300 font-medium">
                            Maintenance
                          </span>
                        </div>
                      )}
                    </div>
                    {/* Red / Coral RTP Pill */}
                    <div
                      className={`mt-1 text-white text-[9px] sm:text-[10px] font-extrabold py-0.5 px-1 rounded-full text-center shadow-xs tracking-wide truncate ${
                        isOffline
                          ? 'bg-slate-700 text-slate-300'
                          : 'bg-gradient-to-r from-red-500 to-rose-500'
                      }`}
                    >
                      {isOffline ? 'Maintenance (বন্ধ)' : (card.payout || 'Up to 9X')}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* More Platform Games if admin has created extra games */}
            {selectedCategory === 'popular' && filteredGames.length > 0 && (
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between px-0.5">
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-3.5 bg-orange-500 rounded-full"></div>
                    <h4 className="font-extrabold text-xs text-slate-700">
                      More Casino Games ({filteredGames.length})
                    </h4>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
                  {filteredGames.map((game, gIdx) => (
                    <div
                      key={`admin-game-${game.id || gIdx}`}
                      onClick={() => handleLaunchGame(game)}
                      className="group flex flex-col cursor-pointer active:scale-95 transition-transform"
                      id={`pop-game-${game.id}`}
                    >
                      <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-slate-900 border border-slate-200 shadow-xs">
                        <img
                          src={game.image || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80'}
                          alt={game.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src =
                              'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80';
                          }}
                        />
                        <span className="absolute top-1 right-1 z-10 text-[8px] font-black text-amber-300 bg-black/60 px-1 py-0.5 rounded">
                          {game.provider || 'HOT'}
                        </span>
                        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent pt-3 pb-1 px-1 text-center">
                          <span className="text-[10px] font-black text-white uppercase block truncate">
                            {game.name}
                          </span>
                        </div>
                      </div>
                      <div className="mt-1 bg-slate-100 text-slate-700 text-[9px] font-bold py-0.5 px-1 rounded-full text-center truncate">
                        RTP {game.rtp ? `${game.rtp}%` : `97.${((gIdx * 3) % 25) + 70}%`}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Category Filtered / Search 3-Column Grid */
          <div className="space-y-3">
            <div className="flex items-center justify-between pt-1 px-0.5">
              <div className="flex items-center space-x-2">
                <div className="w-1.5 h-4.5 bg-[#2196f3] rounded-full"></div>
                <h3 className="font-black text-sm sm:text-base text-slate-900 capitalize">
                  {searchQuery ? `Search Results` : `${selectedCategory}`}
                </h3>
              </div>
              <button
                onClick={downloadApp}
                className="flex items-center space-x-1.5 px-3 py-1 rounded-full bg-white border border-slate-200 shadow-xs hover:bg-slate-50 text-slate-700 text-xs font-bold active:scale-95 transition-all cursor-pointer"
                id="home-search-add-desktop-btn"
              >
                <div className="w-4 h-4 rounded-full bg-gradient-to-tr from-[#1976d2] to-[#2196f3] flex items-center justify-center text-white text-[9px] font-black">
                  ★
                </div>
                <span>Add to Desktop</span>
                <Download className="w-3 h-3 text-slate-500" />
              </button>
            </div>

            {filteredGames.length > 0 ? (
              <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
                {filteredGames.map((game, gIdx) => (
                  <div
                    key={`home-game-${game.id || gIdx}-${gIdx}`}
                    onClick={() => handleLaunchGame(game)}
                    className="group flex flex-col cursor-pointer active:scale-95 transition-transform"
                    id={`game-card-${game.id}`}
                  >
                    <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-slate-900 border-2 border-[#2196f3] shadow-sm">
                      <img
                        src={game.image || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80'}
                        alt={game.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src =
                            'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80';
                        }}
                      />
                      {/* Provider Badge */}
                      <span className="absolute top-1 right-1 z-10 text-[9px] font-black text-amber-300 bg-black/60 backdrop-blur-xs px-1.5 py-0.5 rounded font-serif shadow-xs tracking-wider">
                        {game.badge || 'JILI'}
                      </span>
                      {/* Name Overlay */}
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/95 via-black/60 to-transparent pt-3.5 pb-1 px-1 text-center">
                        <span className="text-[10px] sm:text-[11px] font-black text-white uppercase tracking-wider block truncate drop-shadow-md">
                          {game.name}
                        </span>
                      </div>
                    </div>
                    {/* Blue RTP Pill */}
                    <div className="mt-1 bg-gradient-to-r from-[#1976d2] to-[#2196f3] text-white text-[9px] sm:text-[10px] font-extrabold py-0.5 px-2 rounded-full text-center shadow-xs tracking-wide">
                      RTP 96.{((gIdx * 7) % 80) + 15}%
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-2xl p-8 text-center space-y-2 border border-slate-100">
                <Gamepad2 className="w-8 h-8 text-slate-300 mx-auto" />
                <p className="text-xs font-bold text-slate-600">No games found</p>
                <p className="text-[11px] text-slate-400">
                  Try searching with another keyword or pick another category.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Top 10 Player Live Betting Champions Leaderboard */}
        <TopEarningsLeaderboard />

        {/* Realtime Winning Information Feed */}
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
            <div className="flex items-center space-x-2">
              <div className="w-1.5 h-4 bg-[#2196f3] rounded-full"></div>
              <h3 className="font-extrabold text-sm text-slate-900">Winning information</h3>
            </div>
            <span className="text-[10px] text-slate-400 font-medium bg-slate-100 px-2 py-0.5 rounded-full">
              Recent Activity
            </span>
          </div>

          <div className="space-y-2 transition-all">
            {currentWinnersFeed.map((w, i) => (
              <div
                key={`${w.name}-${i}-${feedOffset}`}
                className="flex items-center justify-between text-xs py-2 hover:bg-slate-50 rounded-2xl px-1.5 transition-all duration-300"
              >
                {/* Left: Avatar & Masked Name */}
                <div className="flex items-center space-x-2.5 min-w-[105px]">
                  <img
                    src={w.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                    alt={w.name}
                    className="w-9 h-9 rounded-full object-cover border border-slate-200 bg-slate-100"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100';
                    }}
                  />
                  <div className="font-extrabold text-slate-800 text-xs truncate max-w-[80px]">
                    {w.name}
                  </div>
                </div>

                {/* Center: Red/Coral Rounded Ticket with 3 Lottery Balls (9 red, 4 green, 9 purple) */}
                <div className="w-16 h-9 rounded-xl bg-gradient-to-r from-[#ff5252] to-[#ff7b7b] flex items-center justify-center space-x-1 px-1 shadow-xs shrink-0">
                  <span className="w-4 h-4 rounded-full bg-red-600 text-white font-black text-[9px] flex items-center justify-center shadow-xs border border-white/40">
                    9
                  </span>
                  <span className="w-4 h-4 rounded-full bg-emerald-500 text-white font-black text-[9px] flex items-center justify-center shadow-xs border border-white/40">
                    4
                  </span>
                  <span className="w-4 h-4 rounded-full bg-purple-600 text-white font-black text-[9px] flex items-center justify-center shadow-xs border border-white/40">
                    9
                  </span>
                </div>

                {/* Right: Receive amount & Winning amount label */}
                <div className="text-right min-w-[95px]">
                  <div className="text-xs font-black text-slate-900 leading-tight">
                    Receive ৳{w.amount.toFixed(2)}
                  </div>
                  <div className="text-[10px] text-slate-400 font-medium mt-0.5">
                    Winning amount
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* In-App Game Launcher Modal */}
      {activeGameModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex flex-col items-center justify-center">
          <div className="w-full h-full max-w-md bg-slate-900 flex flex-col shadow-2xl relative">
            {/* Game Navigation Header */}
            <div className="bg-slate-950 text-white px-3 py-2.5 flex items-center justify-between border-b border-slate-800 z-10 shrink-0">
              <button
                onClick={closeCurrentGameModal}
                className="flex items-center space-x-1 text-xs font-bold text-slate-300 hover:text-white px-2 py-1 rounded-lg bg-slate-800 active:scale-95"
                id="game-modal-back-btn"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Lobby</span>
              </button>

              <div className="flex items-center space-x-1.5 text-center">
                <span className="text-xs font-black text-white">{activeGameModal.name}</span>
                <span className="text-[9px] bg-[#2196f3] text-white px-1.5 py-0.2 rounded-full font-bold">
                  LIVE
                </span>
              </div>

              <div className="flex items-center space-x-1">
                <button
                  onClick={() => {
                    const url = getGameLaunchUrl(activeGameModal);
                    if (url) window.open(url, '_blank');
                  }}
                  title="Open full page"
                  className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white active:scale-95"
                  aria-label="Open full page"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={closeCurrentGameModal}
                  className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white active:scale-95"
                  aria-label="Close game"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Game Iframe Canvas */}
            <div className="flex-1 w-full h-full relative bg-slate-950">
              {getGameLaunchUrl(activeGameModal) ? (
                <iframe
                  src={getGameLaunchUrl(activeGameModal)}
                  title={activeGameModal.name}
                  className="w-full h-full border-0"
                  allow="autoplay; fullscreen; clipboard-read; clipboard-write"
                />
              ) : (
                <div className="flex items-center justify-center w-full h-full text-slate-400 text-xs font-semibold">
                  Game content unavailable
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
