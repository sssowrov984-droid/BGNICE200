import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  ArrowLeft,
  RefreshCw,
  Clock,
  Volume2,
  VolumeX,
  ChevronLeft,
  ChevronRight,
  Check,
  Headphones,
  Info
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ref, get, set, update, push } from 'firebase/database';
import { rtdb } from '../lib/firebase';
import { BrandLogo } from './BrandLogo';
import { GameResultModal } from './GameResultModal';
import confetti from 'canvas-confetti';

interface K3GameProps {
  onDepositClick: () => void;
  onWithdrawClick: () => void;
  onBack: () => void;
}

type K3TimerType = '1m' | '3m' | '5m' | '10m';
type K3BetTab = 'total' | '2same' | '3same' | 'different';

interface K3HistoryItem {
  periodId: string;
  dice: [number, number, number];
  sum: number;
  size: 'Big' | 'Small';
  parity: 'Odd' | 'Even';
  pattern: string;
  timestamp: number;
}

interface K3BetItem {
  id: string;
  uid: string;
  periodId: string;
  timerType: K3TimerType;
  tab: K3BetTab;
  selectType: string;
  selectValue: string;
  multiplierRate: number;
  baseAmount: number;
  multiplier: number;
  totalAmount: number;
  status: 'pending' | 'won' | 'lost';
  winAmount?: number;
  dice?: [number, number, number];
  sum?: number;
  createdAt: number;
}

// 3D Red Dice Component with white and yellow/gold dots
export const DiceFace: React.FC<{ value: number; size?: number; spinning?: boolean }> = ({
  value,
  size = 48,
  spinning = false
}) => {
  const dotClass = (row: number, col: number) => {
    // 3x3 grid dots
    const dotsMap: Record<number, [number, number][]> = {
      1: [[2, 2]],
      2: [[1, 1], [3, 3]],
      3: [[1, 1], [2, 2], [3, 3]],
      4: [[1, 1], [1, 3], [3, 1], [3, 3]],
      5: [[1, 1], [1, 3], [2, 2], [3, 1], [3, 3]],
      6: [[1, 1], [2, 1], [3, 1], [1, 3], [2, 3], [3, 3]]
    };
    const activeDots = dotsMap[value] || [[2, 2]];
    return activeDots.some(([r, c]) => r === row && c === col);
  };

  return (
    <div
      className={`relative rounded-xl shadow-lg border border-red-400 flex items-center justify-center select-none ${
        spinning ? 'animate-bounce' : ''
      }`}
      style={{
        width: `${size}px`,
        height: `${size}px`,
        background: 'linear-gradient(135deg, #ff3b30 0%, #d32f2f 60%, #b71c1c 100%)',
        boxShadow: 'inset 0 2px 4px rgba(255,255,255,0.4), 0 4px 10px rgba(0,0,0,0.35)'
      }}
    >
      {/* 3x3 Grid for dots */}
      <div className="grid grid-cols-3 grid-rows-3 gap-1 w-3/4 h-3/4 items-center justify-items-center">
        {[1, 2, 3].map((r) =>
          [1, 2, 3].map((c) => {
            const isVisible = dotClass(r, c);
            const isCenterDot = (value === 1 || value === 3 || value === 5) && r === 2 && c === 2;
            return (
              <div
                key={`${r}-${c}`}
                className={`rounded-full ${
                  isVisible
                    ? isCenterDot
                      ? 'bg-amber-300 ring-1 ring-amber-400'
                      : 'bg-white ring-1 ring-slate-100'
                    : 'opacity-0'
                }`}
                style={{
                  width: `${size * 0.18}px`,
                  height: `${size * 0.18}px`,
                  boxShadow: isVisible ? 'inset 0 1px 1px rgba(0,0,0,0.2)' : 'none'
                }}
              />
            );
          })
        )}
      </div>
    </div>
  );
};

export const K3Game: React.FC<K3GameProps> = ({ onDepositClick, onWithdrawClick, onBack }) => {
  const { user, refreshBalance, isRefreshingBalance, settings, lastWinModal, setLastWinModal, closeWinModal } = useApp();

  const [timerType, setTimerType] = useState<K3TimerType>('1m');
  const [activeTab, setActiveTab] = useState<K3BetTab>('total');
  const [activeSubTab, setActiveSubTab] = useState<'history' | 'chart' | 'myBets'>('history');

  // Pagination states
  const [historyPage, setHistoryPage] = useState(1);
  const [chartPage, setChartPage] = useState(1);
  const [myBetsPage, setMyBetsPage] = useState(1);
  const pageSize = 10;

  // Sound
  const [soundEnabled, setSoundEnabled] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const playBeep = (freq = 600, duration = 0.1) => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        const AudioClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioClass) audioCtxRef.current = new AudioClass();
      }
      const ctx = audioCtxRef.current;
      if (ctx) {
        if (ctx.state === 'suspended') ctx.resume().catch(() => {});
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + duration);
      }
    } catch {}
  };

  // Timer loop & Period calculation
  const cycleSeconds = timerType === '1m' ? 60 : timerType === '3m' ? 180 : timerType === '5m' ? 300 : 600;
  const [timeLeft, setTimeLeft] = useState(60);
  const [periodId, setPeriodId] = useState('');
  const [isRolling, setIsRolling] = useState(false);

  // Recent History
  const [history, setHistory] = useState<K3HistoryItem[]>([]);
  const [myBets, setMyBets] = useState<K3BetItem[]>([]);

  // Bet Modal State
  const [isBetSheetOpen, setIsBetSheetOpen] = useState(false);
  const [selectedBet, setSelectedBet] = useState<{
    tab: K3BetTab;
    label: string;
    value: string;
    rate: number;
  }>({
    tab: 'total',
    label: 'Big',
    value: 'big',
    rate: 2.0
  });

  const [baseBalance, setBaseBalance] = useState<number>(1);
  const [quantityInput, setQuantityInput] = useState<string>('1');
  const [multiplier, setMultiplier] = useState<number>(1);
  const [agreeRules, setAgreeRules] = useState<boolean>(true);
  const [isPlacing, setIsPlacing] = useState(false);

  const parsedQuantity = Math.max(1, parseInt(quantityInput, 10) || 1);
  const totalBetAmount = baseBalance * parsedQuantity * multiplier;

  // Generate Period ID synchronized with current time
  const generateK3Period = (type: K3TimerType) => {
    const d = new Date();
    const YYYY = d.getFullYear();
    const MM = String(d.getMonth() + 1).padStart(2, '0');
    const DD = String(d.getDate()).padStart(2, '0');
    const totalSecs = d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds();
    const cycle = type === '1m' ? 60 : type === '3m' ? 180 : type === '5m' ? 300 : 600;
    const periodSeq = String(Math.floor(totalSecs / cycle) + 1).padStart(4, '0');
    const prefix = type === '1m' ? '10' : type === '3m' ? '30' : type === '5m' ? '50' : '100';
    return `${YYYY}${MM}${DD}${prefix}${periodSeq}`;
  };

  // Fetch initial history or mock deterministic historical items
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
    const currentP = generateK3Period(timerType);
    setPeriodId(currentP);

    // Fetch from Firebase RTDB
    const histRef = ref(rtdb, `k3_history/${timerType}`);
    get(histRef).then((snap) => {
      if (snap.exists()) {
        const data = snap.val();
        const list: K3HistoryItem[] = Object.values(data);
        list.sort((a, b) => b.timestamp - a.timestamp);
        setHistory(list.slice(0, 30));
      } else {
        // Generate initial fallback history if empty
        const initialList: K3HistoryItem[] = [];
        const baseTime = Date.now();
        for (let i = 0; i < 20; i++) {
          const d1 = (Math.floor(Math.random() * 6) + 1) as number;
          const d2 = (Math.floor(Math.random() * 6) + 1) as number;
          const d3 = (Math.floor(Math.random() * 6) + 1) as number;
          const sum = d1 + d2 + d3;
          const pId = `${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}${String(new Date().getDate()).padStart(2, '0')}10${String(1000 - i).padStart(4, '0')}`;
          initialList.push({
            periodId: pId,
            dice: [d1, d2, d3],
            sum,
            size: sum >= 11 ? 'Big' : 'Small',
            parity: sum % 2 === 0 ? 'Even' : 'Odd',
            pattern: d1 === d2 && d2 === d3 ? '3 same' : (d1 === d2 || d2 === d3 || d1 === d3) ? '2 same' : '3 different',
            timestamp: baseTime - i * cycleSeconds * 1000
          });
        }
        setHistory(initialList);
      }
    }).catch(() => {});
  }, [timerType, cycleSeconds]);

  // Fetch user's bets
  useEffect(() => {
    if (!user) return;
    const betsRef = ref(rtdb, 'k3_bets');
    get(betsRef).then((snap) => {
      if (snap.exists()) {
        const allBets = snap.val();
        const list: K3BetItem[] = Object.entries(allBets)
          .map(([id, b]: [string, any]) => ({ ...b, id }))
          .filter((b) => b.uid === user.uid)
          .sort((a, b) => b.createdAt - a.createdAt);
        setMyBets(list.slice(0, 30));
      }
    }).catch(() => {});
  }, [user]);

  // Resolve K3 round
  const resolveK3Round = async (expPeriod: string, expType: K3TimerType) => {
    try {
      setIsRolling(true);

      // Check admin forced results
      let d1 = Math.floor(Math.random() * 6) + 1;
      let d2 = Math.floor(Math.random() * 6) + 1;
      let d3 = Math.floor(Math.random() * 6) + 1;

      const forcedDice = settings?.gameControls?.k3Dice;
      if (Array.isArray(forcedDice) && forcedDice.length === 3) {
        d1 = forcedDice[0];
        d2 = forcedDice[1];
        d3 = forcedDice[2];
      }

      const sum = d1 + d2 + d3;
      const size = sum >= 11 ? 'Big' : 'Small';
      const parity = sum % 2 === 0 ? 'Even' : 'Odd';
      const pattern = d1 === d2 && d2 === d3 ? '3 same' : (d1 === d2 || d2 === d3 || d1 === d3) ? '2 same' : '3 different';

      const historyEntry: K3HistoryItem = {
        periodId: expPeriod,
        dice: [d1, d2, d3],
        sum,
        size,
        parity,
        pattern,
        timestamp: Date.now()
      };

      // Save to Firebase RTDB
      await set(ref(rtdb, `k3_history/${expType}/${expPeriod}`), historyEntry).catch(() => {});

      setHistory((prev) => [historyEntry, ...prev.slice(0, 29)]);

      setTimeout(() => {
        setIsRolling(false);
      }, 1500);

      // Resolve pending bets
      const betsSnap = await get(ref(rtdb, 'k3_bets'));
      if (betsSnap.exists()) {
        const allBets = betsSnap.val();
        let totalWin = 0;
        let totalUserBet = 0;
        let userHadWon = false;
        let userHadBet = false;

        for (const [k, b] of Object.entries<K3BetItem>(allBets)) {
          if (b.periodId === expPeriod && b.timerType === expType && b.status === 'pending') {
            if (user && b.uid === user.uid) {
              userHadBet = true;
              totalUserBet += b.totalAmount;
            }

            let isWin = false;

            if (b.tab === 'total') {
              if (b.selectValue === 'big' && size === 'Big') isWin = true;
              else if (b.selectValue === 'small' && size === 'Small') isWin = true;
              else if (b.selectValue === 'even' && parity === 'Even') isWin = true;
              else if (b.selectValue === 'odd' && parity === 'Odd') isWin = true;
              else if (b.selectValue === String(sum)) isWin = true;
            } else if (b.tab === '2same') {
              if (b.selectValue === 'any' && (d1 === d2 || d2 === d3 || d1 === d3)) isWin = true;
              else {
                const pairNum = parseInt(b.selectValue, 10);
                const count = [d1, d2, d3].filter((x) => x === pairNum).length;
                if (count >= 2) isWin = true;
              }
            } else if (b.tab === '3same') {
              if (b.selectValue === 'any' && d1 === d2 && d2 === d3) isWin = true;
              else if (b.selectValue === `${d1}${d1}${d1}` && d1 === d2 && d2 === d3) isWin = true;
            } else if (b.tab === 'different') {
              if (b.selectValue === 'continuous') {
                const sorted = [d1, d2, d3].sort((a, b) => a - b);
                if (sorted[0] + 1 === sorted[1] && sorted[1] + 1 === sorted[2]) isWin = true;
              } else if (b.selectValue === '3diff' && d1 !== d2 && d2 !== d3 && d1 !== d3) {
                isWin = true;
              }
            }

            const winAmt = isWin ? Number((b.totalAmount * b.multiplierRate).toFixed(2)) : 0;
            const newStatus = isWin ? 'won' : 'lost';

            await update(ref(rtdb, `k3_bets/${k}`), {
              status: newStatus,
              winAmount: winAmt,
              dice: [d1, d2, d3],
              sum
            });

            if (isWin && winAmt > 0) {
              const uSnap = await get(ref(rtdb, `users/${b.uid}`));
              if (uSnap.exists()) {
                const uData = uSnap.val();
                const curB = Number(uData.balance || 0);
                const newB = Number((curB + winAmt).toFixed(2));
                const totWon = Number((Number(uData.totalWon || 0) + winAmt).toFixed(2));
                await update(ref(rtdb, `users/${b.uid}`), { balance: newB, totalWon: totWon });
              }
              if (user && b.uid === user.uid) {
                totalWin += winAmt;
                userHadWon = true;
              }
            }
          }
        }

        const durLabel = expType === '1m' ? '1Min' : expType === '3m' ? '3Min' : expType === '5m' ? '5Min' : '10Min';

        if (userHadWon && totalWin > 0) {
          try {
            confetti({ particleCount: 90, spread: 75, origin: { y: 0.6 } });
          } catch {}
          const curBal = Number(user?.balance || 0);
          setLastWinModal({
            win: true,
            amount: totalWin,
            period: expPeriod,
            gameName: 'K3 Lottery',
            duration: durLabel,
            resultNumber: sum,
            resultBigSmall: size as 'Big' | 'Small',
            previousBalance: Number(Math.max(0, curBal - totalWin).toFixed(2)),
            newBalance: curBal
          });
          refreshBalance();
        } else if (userHadBet && totalUserBet > 0) {
          const curBal = Number(user?.balance || 0);
          setLastWinModal({
            win: false,
            amount: totalUserBet,
            period: expPeriod,
            gameName: 'K3 Lottery',
            duration: durLabel,
            resultNumber: sum,
            resultBigSmall: size as 'Big' | 'Small',
            previousBalance: Number((curBal + totalUserBet).toFixed(2)),
            newBalance: curBal
          });
        }

        // Refresh user's bet history list
        if (user) {
          const freshSnap = await get(ref(rtdb, 'k3_bets'));
          if (freshSnap.exists()) {
            const list: K3BetItem[] = Object.entries(freshSnap.val())
              .map(([id, b]: [string, any]) => ({ ...b, id }))
              .filter((b) => b.uid === user.uid)
              .sort((a, b) => b.createdAt - a.createdAt);
            setMyBets(list.slice(0, 30));
          }
        }
      }
    } catch (err) {
      console.error('K3 round resolution error:', err);
    }
  };

  // Timer interval
  useEffect(() => {
    const timer = setInterval(() => {
      const now = Math.floor(Date.now() / 1000);
      const rem = cycleSeconds - (now % cycleSeconds);
      setTimeLeft(rem);

      const expPeriod = generateK3Period(timerType);
      setPeriodId(expPeriod);

      if (rem <= 5 && rem > 0) {
        playBeep(rem === 1 ? 880 : 520, 0.12);
      }

      if (rem === 1) {
        resolveK3Round(expPeriod, timerType);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [timerType, cycleSeconds]);

  // Current latest dice
  const latestResult = useMemo(() => {
    return history[0] || {
      dice: [3, 4, 4] as [number, number, number],
      sum: 11,
      size: 'Big',
      parity: 'Odd'
    };
  }, [history]);

  // Handle open bet sheet
  const handleOpenBet = (tab: K3BetTab, label: string, value: string, rate: number) => {
    setSelectedBet({ tab, label, value, rate });
    setBaseBalance(1);
    setQuantityInput('1');
    setMultiplier(1);
    setIsBetSheetOpen(true);
  };

  // Confirm and place real bet in RTDB
  const handleConfirmBet = async () => {
    if (!user) return;
    if (!agreeRules) {
      alert('Please agree to the pre-sale rules');
      return;
    }
    if (user.balance < totalBetAmount) {
      alert('Insufficient wallet balance. Please deposit funds to continue.');
      return;
    }

    try {
      setIsPlacing(true);
      const currentBal = Number(user.balance || 0);
      const updatedBal = Number((currentBal - totalBetAmount).toFixed(2));
      const curLoss = Number(user.totalLoss || 0);

      // Deduct balance in Firebase RTDB
      await update(ref(rtdb, `users/${user.uid}`), {
        balance: updatedBal,
        totalLoss: curLoss + totalBetAmount
      });

      // Record Bet
      const betData: Omit<K3BetItem, 'id'> = {
        uid: user.uid,
        periodId,
        timerType,
        tab: selectedBet.tab,
        selectType: selectedBet.label,
        selectValue: selectedBet.value,
        multiplierRate: selectedBet.rate,
        baseAmount: baseBalance * parsedQuantity,
        multiplier,
        totalAmount: totalBetAmount,
        status: 'pending',
        createdAt: Date.now()
      };

      const newRef = push(ref(rtdb, 'k3_bets'));
      await set(newRef, betData);

      setIsBetSheetOpen(false);
      refreshBalance();

      setMyBets((prev) => [{ ...betData, id: newRef.key || String(Date.now()) }, ...prev]);
    } catch (err) {
      console.error('K3 Bet placement error:', err);
    } finally {
      setIsPlacing(false);
    }
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const minStr = String(minutes).padStart(2, '0');
  const secStr = String(seconds).padStart(2, '0');

  return (
    <div className="min-h-screen bg-[#f7f8fc] pb-20 text-slate-800 select-none">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-[#29303d] border-b border-slate-700/40 text-white px-3.5 py-2.5 flex items-center justify-between shadow-md">
        <div className="flex items-center space-x-2">
          <button
            onClick={onBack}
            className="p-1 hover:bg-white/10 rounded-full active:scale-95 transition-transform"
            id="k3-back-btn"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
          </button>
          <BrandLogo variant="white" size="sm" />
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-1 hover:bg-white/10 rounded-full"
            id="k3-sound-toggle-btn"
          >
            {soundEnabled ? <Volume2 className="w-5 h-5 text-amber-200" /> : <VolumeX className="w-5 h-5 text-white/70" />}
          </button>
          <button
            onClick={() => window.location.hash = 'support'}
            className="p-1 hover:bg-white/10 rounded-full"
            id="k3-support-btn"
          >
            <Headphones className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="p-3 space-y-3">
        {/* Red Gradient Balance Card matching Screenshot_20260914-160509.png */}
        <div className="bg-gradient-to-r from-[#ff5447] via-[#ff4343] to-[#ff2f2f] rounded-2xl p-4 text-white shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-black tracking-tight">
                  ৳{Number(user?.balance || 0).toFixed(2)}
                </span>
                <button
                  onClick={refreshBalance}
                  className={`p-1 hover:bg-white/20 rounded-full active:rotate-180 transition-all ${
                    isRefreshingBalance ? 'animate-spin' : ''
                  }`}
                  id="k3-refresh-balance-btn"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
              <span className="text-xs text-white/80 font-medium mt-0.5 block">Wallet balance</span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={onWithdrawClick}
                className="px-3.5 py-1.5 rounded-full border border-white/80 text-xs font-bold hover:bg-white/10 active:scale-95 transition-all shadow-xs"
                id="k3-withdraw-btn"
              >
                Withdraw
              </button>
              <button
                onClick={onDepositClick}
                className="px-4 py-1.5 rounded-full bg-white text-[#ff3a3a] text-xs font-black hover:bg-amber-50 active:scale-95 transition-all shadow-md"
                id="k3-deposit-btn"
              >
                Deposit
              </button>
            </div>
          </div>

          {/* Announcement Banner inside card */}
          <div className="mt-3.5 pt-2.5 border-t border-white/20 flex items-center justify-between text-xs text-white/90">
            <div className="flex items-center space-x-2 truncate">
              <Volume2 className="w-4 h-4 text-amber-300 shrink-0 animate-pulse" />
              <span className="truncate text-[11px] font-medium">
                {settings.platformAnnouncement || 'Official 24/7 instant deposit and withdrawal services'}
              </span>
            </div>
            <button
              onClick={() => alert(settings.platformAnnouncement || 'Welcome to K3 Lottery!')}
              className="ml-2 px-2 py-0.5 rounded-full bg-white/25 text-[10px] font-bold text-white shrink-0 hover:bg-white/35"
              id="k3-detail-btn"
            >
              Detail
            </button>
          </div>
        </div>

        {/* Timer Duration Tabs: K3 1 Min, K3 3 Min, K3 5 Min, K3 10 Min */}
        <div className="grid grid-cols-4 gap-1.5 bg-white p-1.5 rounded-2xl shadow-xs border border-slate-100">
          {(['1m', '3m', '5m', '10m'] as K3TimerType[]).map((t) => {
            const isSel = timerType === t;
            const label = t === '1m' ? 'K3 1 Min' : t === '3m' ? 'K3 3 Min' : t === '5m' ? 'K3 5 Min' : 'K3 10 Min';
            return (
              <button
                key={t}
                onClick={() => setTimerType(t)}
                className={`py-2 px-1 rounded-xl flex flex-col items-center justify-center transition-all ${
                  isSel
                    ? 'bg-[#2196f3] text-white shadow-md font-bold'
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100 font-semibold'
                }`}
                id={`k3-timer-tab-${t}`}
              >
                <Clock className={`w-4 h-4 mb-0.5 ${isSel ? 'text-white' : 'text-slate-400'}`} />
                <span className="text-[11px] whitespace-nowrap">{label}</span>
              </button>
            );
          })}
        </div>

        {/* Period & Time Remaining Box */}
        <div className="bg-white rounded-2xl p-3.5 shadow-xs border border-slate-100 flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="text-xs text-slate-500 font-bold">Period</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-red-50 text-[#ff4949] font-bold border border-red-200">
                How to play
              </span>
            </div>
            <div className="text-sm font-black text-slate-800 font-mono mt-0.5 tracking-tight">
              {periodId || '20260914101010606'}
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-500 font-bold block mb-1">Time remaining</span>
            <div className="flex items-center space-x-1 font-mono text-base font-black">
              <span className="w-6 h-7 rounded-md bg-[#fff0f0] border border-red-200 text-[#ff4040] flex items-center justify-center shadow-inner">
                {minStr[0]}
              </span>
              <span className="w-6 h-7 rounded-md bg-[#fff0f0] border border-red-200 text-[#ff4040] flex items-center justify-center shadow-inner">
                {minStr[1]}
              </span>
              <span className="text-[#ff4040] font-bold">:</span>
              <span className="w-6 h-7 rounded-md bg-[#fff0f0] border border-red-200 text-[#ff4040] flex items-center justify-center shadow-inner">
                {secStr[0]}
              </span>
              <span className="w-6 h-7 rounded-md bg-[#fff0f0] border border-red-200 text-[#ff4040] flex items-center justify-center shadow-inner">
                {secStr[1]}
              </span>
            </div>
          </div>
        </div>

        {/* 3D Dice Slot Box matching Screenshot_20260914-160509.png */}
        <div
          className="rounded-3xl p-4 flex flex-col items-center justify-center shadow-inner border-4 border-[#1b5e20] relative overflow-hidden"
          style={{
            background: 'radial-gradient(circle at center, #2e7d32 0%, #1b5e20 80%, #0d3810 100%)'
          }}
        >
          {/* Top slot reel arch */}
          <div className="flex items-center justify-center space-x-4 py-2">
            <div className="bg-black/30 p-2.5 rounded-2xl border border-white/20 shadow-2xl backdrop-blur-xs flex items-center space-x-3">
              <DiceFace value={latestResult.dice[0]} size={48} spinning={isRolling} />
              <DiceFace value={latestResult.dice[1]} size={48} spinning={isRolling} />
              <DiceFace value={latestResult.dice[2]} size={48} spinning={isRolling} />
            </div>
          </div>

          {/* Sum & Attributes Tag */}
          <div className="mt-2 flex items-center space-x-2 text-xs font-black text-white">
            <span className="bg-black/40 px-3 py-1 rounded-full border border-white/20">
              Total: {latestResult.sum}
            </span>
            <span
              className={`px-2.5 py-1 rounded-full ${
                latestResult.size === 'Big' ? 'bg-amber-500' : 'bg-blue-500'
              }`}
            >
              {latestResult.size}
            </span>
            <span
              className={`px-2.5 py-1 rounded-full ${
                latestResult.parity === 'Odd' ? 'bg-rose-500' : 'bg-emerald-500'
              }`}
            >
              {latestResult.parity}
            </span>
          </div>
        </div>

        {/* Betting Type Tabs: Total, 2 same, 3 same, Different */}
        <div className="flex items-center bg-white rounded-2xl p-1 shadow-xs border border-slate-100">
          {(
            [
              { id: 'total', label: 'Total' },
              { id: '2same', label: '2 same' },
              { id: '3same', label: '3 same' },
              { id: 'different', label: 'Different' }
            ] as { id: K3BetTab; label: string }[]
          ).map((tab) => {
            const isSel = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 py-2 rounded-xl text-xs font-black transition-all ${
                  isSel
                    ? 'bg-[#ff4949] text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                id={`k3-bet-tab-${tab.id}`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* TAB 1: Total */}
        {activeTab === 'total' && (
          <div className="bg-white rounded-2xl p-3 shadow-xs border border-slate-100 space-y-3">
            {/* Balls 3 to 18 */}
            <div className="grid grid-cols-4 gap-2">
              {[
                { num: 3, rate: 207.36, color: 'red' },
                { num: 4, rate: 69.12, color: 'green' },
                { num: 5, rate: 34.56, color: 'red' },
                { num: 6, rate: 20.74, color: 'green' },
                { num: 7, rate: 13.83, color: 'red' },
                { num: 8, rate: 9.88, color: 'green' },
                { num: 9, rate: 8.3, color: 'red' },
                { num: 10, rate: 7.68, color: 'green' },
                { num: 11, rate: 7.68, color: 'red' },
                { num: 12, rate: 8.3, color: 'green' },
                { num: 13, rate: 9.88, color: 'red' },
                { num: 14, rate: 13.83, color: 'green' },
                { num: 15, rate: 20.74, color: 'red' },
                { num: 16, rate: 34.56, color: 'green' },
                { num: 17, rate: 69.12, color: 'red' },
                { num: 18, rate: 207.36, color: 'green' }
              ].map((item) => (
                <button
                  key={item.num}
                  onClick={() => handleOpenBet('total', `Total ${item.num}`, String(item.num), item.rate)}
                  className="flex flex-col items-center justify-center p-2 rounded-xl bg-slate-50 hover:bg-red-50 border border-slate-100 hover:border-red-200 active:scale-95 transition-all"
                  id={`k3-ball-${item.num}`}
                >
                  <div
                    className={`w-9 h-9 rounded-full text-white font-black text-sm flex items-center justify-center shadow-sm ${
                      item.color === 'red' ? 'bg-[#ff4949]' : 'bg-[#10b981]'
                    }`}
                  >
                    {item.num}
                  </div>
                  <span className="text-[10px] text-slate-500 font-bold mt-1">{item.rate}X</span>
                </button>
              ))}
            </div>

            {/* 4 Big Buttons: Small, Big, Even, Odd */}
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => handleOpenBet('total', 'Small', 'small', 2.0)}
                className="py-3 rounded-xl bg-[#3b82f6] hover:bg-[#2563eb] text-white font-black text-sm flex flex-col items-center justify-center shadow-md active:scale-98"
                id="k3-bet-small-btn"
              >
                <span>Small</span>
                <span className="text-[11px] opacity-90 font-medium">2X (3-10)</span>
              </button>
              <button
                onClick={() => handleOpenBet('total', 'Big', 'big', 2.0)}
                className="py-3 rounded-xl bg-[#f59e0b] hover:bg-[#d97706] text-white font-black text-sm flex flex-col items-center justify-center shadow-md active:scale-98"
                id="k3-bet-big-btn"
              >
                <span>Big</span>
                <span className="text-[11px] opacity-90 font-medium">2X (11-18)</span>
              </button>
              <button
                onClick={() => handleOpenBet('total', 'Even', 'even', 2.0)}
                className="py-3 rounded-xl bg-[#10b981] hover:bg-[#059669] text-white font-black text-sm flex flex-col items-center justify-center shadow-md active:scale-98"
                id="k3-bet-even-btn"
              >
                <span>Even</span>
                <span className="text-[11px] opacity-90 font-medium">2X</span>
              </button>
              <button
                onClick={() => handleOpenBet('total', 'Odd', 'odd', 2.0)}
                className="py-3 rounded-xl bg-[#ef4444] hover:bg-[#dc2626] text-white font-black text-sm flex flex-col items-center justify-center shadow-md active:scale-98"
                id="k3-bet-odd-btn"
              >
                <span>Odd</span>
                <span className="text-[11px] opacity-90 font-medium">2X</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: 2 same */}
        {activeTab === '2same' && (
          <div className="bg-white rounded-2xl p-3 shadow-xs border border-slate-100 space-y-3">
            <span className="text-xs font-bold text-slate-600 block">2 matching numbers (13.83X)</span>
            <div className="grid grid-cols-3 gap-2">
              {[1, 2, 3, 4, 5, 6].map((n) => (
                <button
                  key={`2same-${n}`}
                  onClick={() => handleOpenBet('2same', `Pair ${n}${n}`, String(n), 13.83)}
                  className="p-2.5 rounded-xl bg-slate-50 hover:bg-red-50 border border-slate-100 hover:border-red-200 flex items-center justify-center space-x-1.5 active:scale-95"
                >
                  <DiceFace value={n} size={28} />
                  <DiceFace value={n} size={28} />
                </button>
              ))}
            </div>
            <button
              onClick={() => handleOpenBet('2same', 'Any 2 Same', 'any', 6.91)}
              className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-black text-xs rounded-xl shadow-xs"
            >
              Any 2 Same (6.91X)
            </button>
          </div>
        )}

        {/* TAB 3: 3 same */}
        {activeTab === '3same' && (
          <div className="bg-white rounded-2xl p-3 shadow-xs border border-slate-100 space-y-3">
            <span className="text-xs font-bold text-slate-600 block">3 matching numbers (207.36X)</span>
            <div className="grid grid-cols-3 gap-2">
              {[1, 2, 3, 4, 5, 6].map((n) => (
                <button
                  key={`3same-${n}`}
                  onClick={() => handleOpenBet('3same', `Triple ${n}${n}${n}`, `${n}${n}${n}`, 207.36)}
                  className="p-2.5 rounded-xl bg-slate-50 hover:bg-red-50 border border-slate-100 hover:border-red-200 flex items-center justify-center space-x-1 active:scale-95"
                >
                  <DiceFace value={n} size={24} />
                  <DiceFace value={n} size={24} />
                  <DiceFace value={n} size={24} />
                </button>
              ))}
            </div>
            <button
              onClick={() => handleOpenBet('3same', 'Any 3 Same', 'any', 34.56)}
              className="w-full py-2.5 bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-black text-xs rounded-xl shadow-xs"
            >
              Any 3 Same (34.56X)
            </button>
          </div>
        )}

        {/* TAB 4: Different */}
        {activeTab === 'different' && (
          <div className="bg-white rounded-2xl p-3 shadow-xs border border-slate-100 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleOpenBet('different', '3 Continuous Numbers', 'continuous', 8.64)}
                className="py-3 px-2 rounded-xl bg-slate-50 border border-slate-200 hover:bg-red-50 text-center active:scale-95"
              >
                <span className="text-xs font-black text-slate-800 block">3 Continuous</span>
                <span className="text-[10px] text-red-500 font-bold">8.64X (e.g. 1-2-3)</span>
              </button>
              <button
                onClick={() => handleOpenBet('different', '3 Different Numbers', '3diff', 34.56)}
                className="py-3 px-2 rounded-xl bg-slate-50 border border-slate-200 hover:bg-red-50 text-center active:scale-95"
              >
                <span className="text-xs font-black text-slate-800 block">3 Different</span>
                <span className="text-[10px] text-red-500 font-bold">34.56X</span>
              </button>
            </div>
          </div>
        )}

        {/* Sub Tabs: Game History, Chart, My History */}
        <div className="bg-white rounded-2xl shadow-xs border border-slate-100 overflow-hidden">
          <div className="flex border-b border-slate-100">
            {[
              { id: 'history', label: 'Game history' },
              { id: 'chart', label: 'Chart' },
              { id: 'myBets', label: 'My history' }
            ].map((st) => (
              <button
                key={st.id}
                onClick={() => setActiveSubTab(st.id as any)}
                className={`flex-1 py-2.5 text-xs font-bold transition-all border-b-2 ${
                  activeSubTab === st.id
                    ? 'border-[#2196f3] text-[#2196f3]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>

          {/* History List */}
          {activeSubTab === 'history' && (
            <div>
              <div className="divide-y divide-slate-100 text-xs">
                <div className="grid grid-cols-3 px-3 py-2 bg-slate-50 font-bold text-slate-500 text-[11px]">
                  <span>Period</span>
                  <span className="text-center">Sum</span>
                  <span className="text-right">Results</span>
                </div>
                {history.slice((historyPage - 1) * pageSize, historyPage * pageSize).map((h, i) => (
                  <div key={i} className="grid grid-cols-3 px-3 py-2.5 items-center font-medium">
                    <span className="font-mono text-slate-700 truncate">{h.periodId}</span>
                    <div className="flex items-center justify-center space-x-1 font-bold">
                      <span className="text-slate-900">{h.sum}</span>
                      <span
                        className={`text-[9px] px-1 rounded text-white ${
                          h.size === 'Big' ? 'bg-amber-500' : 'bg-blue-500'
                        }`}
                      >
                        {h.size[0]}
                      </span>
                      <span
                        className={`text-[9px] px-1 rounded text-white ${
                          h.parity === 'Odd' ? 'bg-rose-500' : 'bg-emerald-500'
                        }`}
                      >
                        {h.parity[0]}
                      </span>
                    </div>
                    <div className="flex items-center justify-end space-x-1">
                      <DiceFace value={h.dice[0]} size={20} />
                      <DiceFace value={h.dice[1]} size={20} />
                      <DiceFace value={h.dice[2]} size={20} />
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between px-3 py-2 bg-white rounded-b-2xl border-t border-slate-100">
                <button
                  onClick={() => setHistoryPage((p) => Math.max(1, p - 1))}
                  disabled={historyPage <= 1}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center space-x-1"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  <span>Previous</span>
                </button>
                <span className="text-xs font-bold text-slate-600">
                  {historyPage} / {Math.max(1, Math.ceil(history.length / pageSize))}
                </span>
                <button
                  onClick={() => setHistoryPage((p) => Math.min(Math.max(1, Math.ceil(history.length / pageSize)), p + 1))}
                  disabled={historyPage >= Math.max(1, Math.ceil(history.length / pageSize))}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center space-x-1"
                >
                  <span>Next</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* Chart View */}
          {activeSubTab === 'chart' && (
            <div className="p-3 space-y-2 text-xs">
              <span className="text-[11px] font-bold text-slate-500">Pattern Statistics (Recent rounds)</span>
              <div className="space-y-1.5">
                {history.slice((chartPage - 1) * pageSize, chartPage * pageSize).map((h, idx) => (
                  <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-slate-50">
                    <span className="font-mono text-slate-600">{h.periodId.slice(-6)}</span>
                    <div className="flex space-x-1">
                      <DiceFace value={h.dice[0]} size={18} />
                      <DiceFace value={h.dice[1]} size={18} />
                      <DiceFace value={h.dice[2]} size={18} />
                    </div>
                    <span className="font-bold text-slate-800">Sum: {h.sum}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 text-slate-700 font-bold">
                      {h.pattern}
                    </span>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <button
                  onClick={() => setChartPage((p) => Math.max(1, p - 1))}
                  disabled={chartPage <= 1}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center space-x-1"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  <span>Previous</span>
                </button>
                <span className="text-xs font-bold text-slate-600">
                  {chartPage} / {Math.max(1, Math.ceil(history.length / pageSize))}
                </span>
                <button
                  onClick={() => setChartPage((p) => Math.min(Math.max(1, Math.ceil(history.length / pageSize)), p + 1))}
                  disabled={chartPage >= Math.max(1, Math.ceil(history.length / pageSize))}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center space-x-1"
                >
                  <span>Next</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* My Bets List */}
          {activeSubTab === 'myBets' && (
            <div>
              <div className="divide-y divide-slate-100 text-xs">
                {myBets.length === 0 ? (
                  <div className="py-8 text-center text-slate-400 font-medium">No betting records yet</div>
                ) : (
                  myBets.slice((myBetsPage - 1) * pageSize, myBetsPage * pageSize).map((b) => (
                    <div key={b.id} className="p-3 flex items-center justify-between">
                      <div>
                        <div className="flex items-center space-x-1.5">
                          <span className="font-bold text-slate-800">{b.selectType}</span>
                          <span className="text-[10px] px-1.5 rounded bg-slate-100 text-slate-600 font-mono">
                            {b.multiplierRate}X
                          </span>
                        </div>
                        <span className="text-[10px] font-mono text-slate-400 block mt-0.5">
                          {b.periodId}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-slate-800 block">৳{b.totalAmount.toFixed(2)}</span>
                        <span
                          className={`text-[11px] font-bold ${
                            b.status === 'won'
                              ? 'text-emerald-600'
                              : b.status === 'lost'
                              ? 'text-red-500'
                              : 'text-amber-500'
                          }`}
                        >
                          {b.status === 'won'
                            ? `+৳${(b.winAmount || 0).toFixed(2)}`
                            : b.status === 'lost'
                            ? 'Lost'
                            : 'Pending'}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
              {myBets.length > 0 && (
                <div className="flex items-center justify-between px-3 py-2 bg-white rounded-b-2xl border-t border-slate-100">
                  <button
                    onClick={() => setMyBetsPage((p) => Math.max(1, p - 1))}
                    disabled={myBetsPage <= 1}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center space-x-1"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                    <span>Previous</span>
                  </button>
                  <span className="text-xs font-bold text-slate-600">
                    {myBetsPage} / {Math.max(1, Math.ceil(myBets.length / pageSize))}
                  </span>
                  <button
                    onClick={() => setMyBetsPage((p) => Math.min(Math.max(1, Math.ceil(myBets.length / pageSize)), p + 1))}
                    disabled={myBetsPage >= Math.max(1, Math.ceil(myBets.length / pageSize))}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center space-x-1"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Betting Sheet Modal with Custom Free Typing Quantity */}
      {isBetSheetOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end justify-center animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-t-3xl p-4 space-y-3.5 shadow-2xl animate-in slide-in-from-bottom duration-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div>
                <h3 className="font-black text-sm text-slate-800">
                  Total: <span className="text-[#ff4949]">{selectedBet.label}</span>
                </h3>
                <span className="text-[11px] text-slate-400">Odds: {selectedBet.rate}X</span>
              </div>
              <button
                onClick={() => setIsBetSheetOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
                id="k3-close-sheet-btn"
              >
                ✕
              </button>
            </div>

            {/* Balance Chips: 1, 10, 100, 1K */}
            <div>
              <span className="text-xs font-bold text-slate-600 block mb-1.5">Balance</span>
              <div className="grid grid-cols-4 gap-2">
                {[1, 10, 100, 1000].map((b) => (
                  <button
                    key={b}
                    onClick={() => setBaseBalance(b)}
                    className={`py-1.5 rounded-xl font-bold text-xs transition-all ${
                      baseBalance === b
                        ? 'bg-[#ff4949] text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {b >= 1000 ? `${b / 1000}K` : b}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity Stepper with Free Typing */}
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600">Quantity</span>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    const cur = parseInt(quantityInput, 10) || 1;
                    setQuantityInput(String(Math.max(1, cur - 1)));
                  }}
                  className="w-8 h-8 rounded-lg bg-slate-100 font-bold text-slate-700 flex items-center justify-center active:scale-95"
                >
                  -
                </button>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={quantityInput}
                  placeholder="1"
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val === '' || /^\d+$/.test(val)) {
                      setQuantityInput(val);
                    }
                  }}
                  onBlur={() => {
                    if (!quantityInput || parseInt(quantityInput, 10) < 1) {
                      setQuantityInput('1');
                    }
                  }}
                  className="w-20 text-center font-bold text-slate-800 text-sm py-1 bg-white rounded-lg border border-slate-200 focus:outline-none"
                />
                <button
                  onClick={() => {
                    const cur = parseInt(quantityInput, 10) || 1;
                    setQuantityInput(String(cur + 1));
                  }}
                  className="w-8 h-8 rounded-lg bg-[#ff4949] text-white font-bold flex items-center justify-center active:scale-95"
                >
                  +
                </button>
              </div>
            </div>

            {/* Multipliers: X1, X5, X10, X20, X50, X100 */}
            <div className="flex items-center justify-between space-x-1.5 pt-1">
              {[1, 5, 10, 20, 50, 100].map((m) => (
                <button
                  key={m}
                  onClick={() => setMultiplier(m)}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    multiplier === m
                      ? 'bg-[#2196f3] text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  X{m}
                </button>
              ))}
            </div>

            {/* Agreement */}
            <div
              onClick={() => setAgreeRules(!agreeRules)}
              className="flex items-center space-x-2 text-xs text-slate-500 cursor-pointer pt-1"
            >
              <div
                className={`w-4 h-4 rounded-full flex items-center justify-center border ${
                  agreeRules ? 'bg-[#2196f3] border-[#2196f3] text-white' : 'border-slate-300'
                }`}
              >
                {agreeRules && <Check className="w-3 h-3 stroke-[3]" />}
              </div>
              <span>I agree 《Pre-sale rules》</span>
            </div>

            {/* Actions */}
            <div className="flex items-center space-x-2 pt-2">
              <button
                onClick={() => setIsBetSheetOpen(false)}
                className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl active:scale-98"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmBet}
                disabled={isPlacing}
                className="flex-2 py-3 bg-[#2196f3] hover:bg-blue-600 text-white font-black rounded-xl shadow-md active:scale-98 disabled:opacity-50"
                id="k3-confirm-bet-btn"
              >
                Total amount ৳{totalBetAmount.toFixed(2)}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Global Win/Loss Receipt Modal */}
      {lastWinModal && (
        <GameResultModal data={lastWinModal} onClose={closeWinModal} />
      )}
    </div>
  );
};
