import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Send,
  X,
  Plus,
  Clock,
  ShieldCheck,
  CheckCheck,
  History,
  AlertCircle,
  HelpCircle,
  MessageCircle,
  Sparkles,
  Image as ImageIcon,
  ZoomIn,
  Trash2,
  Loader2
} from 'lucide-react';
import { ref, push, set, onValue, update, get, remove } from 'firebase/database';
import { rtdb } from '../lib/firebase';
import { useApp, stripUndefined } from '../context/AppContext';
import { useLanguage } from '../context/LanguageContext';
import { SupportChat, SupportMessage, SupportAgentProfile } from '../types';
import { DEFAULT_SUPPORT_AGENTS } from '../utils/defaultChannels';
import { uploadToImgBB } from '../utils/imgbb';

interface LiveChatViewProps {
  onBack: () => void;
}

export const LiveChatView: React.FC<LiveChatViewProps> = ({ onBack }) => {
  const { user, showToast } = useApp();
  const { language, t } = useLanguage();

  const [activeChat, setActiveChat] = useState<SupportChat | null>(null);
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [chatHistoryList, setChatHistoryList] = useState<SupportChat[]>([]);
  const [showCloseConfirm, setShowCloseConfirm] = useState(false);
  const [assignedAgent, setAssignedAgent] = useState<SupportAgentProfile>(DEFAULT_SUPPORT_AGENTS[0]);

  // Image Upload State
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [selectedImagePreview, setSelectedImagePreview] = useState<string | null>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast(language === 'bn' ? 'সঠিক ছবি সিলেক্ট করুন' : 'Please select a valid image', 'error');
      return;
    }

    setSelectedImageFile(file);
    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const removeSelectedImage = () => {
    setSelectedImageFile(null);
    setSelectedImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // 1. Fetch available support agents from RTDB or fallback
  useEffect(() => {
    const agentsRef = ref(rtdb, 'supportAgents');
    const unsub = onValue(agentsRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = Object.values(snapshot.val()) as SupportAgentProfile[];
        if (data.length > 0) {
          // Select a random or first online agent
          setAssignedAgent(data[0]);
        }
      } else {
        // Seed default agents in RTDB
        const seedMap: Record<string, SupportAgentProfile> = {};
        DEFAULT_SUPPORT_AGENTS.forEach((a) => {
          seedMap[a.agentId] = a;
        });
        set(agentsRef, seedMap);
      }
    });
    return () => unsub();
  }, []);

  // 2. Listen to user's support chats & history
  useEffect(() => {
    if (!user) return;

    // Clean up corrupted 'undefined' paths if any exist in RTDB
    remove(ref(rtdb, 'messages/undefined')).catch(() => {});
    remove(ref(rtdb, `supportChats/${user.uid}/undefined`)).catch(() => {});
    remove(ref(rtdb, 'supportChatsIndex/undefined')).catch(() => {});

    const userChatsRef = ref(rtdb, `supportChats/${user.uid}`);
    const unsub = onValue(userChatsRef, (snapshot) => {
      if (snapshot.exists()) {
        const raw = snapshot.val();
        const data: SupportChat[] = [];
        if (raw && typeof raw === 'object') {
          Object.entries(raw).forEach(([key, val]: [string, any]) => {
            if (key === 'undefined' || key === 'null' || !key) {
              remove(ref(rtdb, `supportChats/${user.uid}/${key}`)).catch(() => {});
              return;
            }
            if (val && typeof val === 'object') {
              const safeChatId = (val.chatId && val.chatId !== 'undefined') ? String(val.chatId) : key;
              data.push({
                ...val,
                chatId: safeChatId
              });
            }
          });
        }
        data.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setChatHistoryList(data);

        // Find active unclosed chat with valid chatId
        const currentActive = data.find((c) => c.status === 'active' && c.chatId && c.chatId !== 'undefined');
        if (currentActive) {
          // Check 2-hour expiration rule
          const twoHoursMs = 2 * 60 * 60 * 1000;
          if (Date.now() - (currentActive.createdAt || 0) >= twoHoursMs) {
            // Auto close expired chat
            update(ref(rtdb, `supportChats/${user.uid}/${currentActive.chatId}`), {
              status: 'closed',
              closedAt: Date.now()
            }).catch(() => {});
            setActiveChat({ ...currentActive, status: 'closed', closedAt: Date.now() });
          } else {
            setActiveChat(currentActive);
          }
        } else {
          // If latest is closed, set activeChat to that closed chat so user sees "Previous chat closed" + "+ Start New Chat"
          setActiveChat(data[0] || null);
        }
      } else {
        setActiveChat(null);
        setChatHistoryList([]);
      }
    });

    return () => unsub();
  }, [user]);

  // 3. Listen to messages for current active chat
  useEffect(() => {
    if (!activeChat?.chatId || activeChat.chatId === 'undefined') {
      setMessages([]);
      return;
    }

    const messagesRef = ref(rtdb, `messages/${activeChat.chatId}`);
    const unsub = onValue(messagesRef, (snapshot) => {
      if (snapshot.exists()) {
        const raw = snapshot.val();
        const data: SupportMessage[] = [];
        if (raw && typeof raw === 'object') {
          Object.entries(raw).forEach(([key, val]: [string, any]) => {
            if (val && typeof val === 'object') {
              data.push({
                ...val,
                id: val.id || key,
                chatId: (val.chatId && val.chatId !== 'undefined') ? val.chatId : activeChat.chatId
              });
            }
          });
        }
        data.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
        setMessages(data);
        setTimeout(scrollToBottom, 100);
      } else {
        setMessages([]);
      }
    });

    return () => unsub();
  }, [activeChat?.chatId]);

  // Start a brand new support chat
  const handleStartNewChat = async (initialUserMessage?: string | any, imageUrl?: string) => {
    if (!user) {
      showToast('Please sign in to access live customer support', 'error');
      return null;
    }

    const messageText = typeof initialUserMessage === 'string' ? initialUserMessage.trim() : '';
    const newChatId = `CHAT_${Date.now()}`;
    const agent = assignedAgent || DEFAULT_SUPPORT_AGENTS[0];

    const newChat: SupportChat = {
      chatId: newChatId,
      userId: user.numericUid || user.uid || 'guest',
      userUid: user.uid,
      username: user.nickname || user.username || 'Valued Member',
      userPhone: user.phone || '',
      userEmail: user.email || '',
      status: 'active',
      createdAt: Date.now(),
      agentId: agent.agentId || 'AGENT_DEFAULT',
      agentName: agent.agentName || 'BGNICE OFFICIAL SUPPORT',
      agentPhoto: agent.profilePhoto || '',
      lastMessage: messageText || (imageUrl ? '📷 Image' : agent.welcomeMessage || 'Welcome to BGNICE Support!'),
      updatedAt: Date.now()
    };

    // Save in user's chats
    await set(ref(rtdb, `supportChats/${user.uid}/${newChatId}`), stripUndefined(newChat));
    // Also save in root supportChatsIndex for Admin view
    await set(ref(rtdb, `supportChatsIndex/${newChatId}`), stripUndefined({
      ...newChat,
      userUid: user.uid
    }));

    // Auto-create initial professional welcome greeting from Support Representative
    const greetingMsgRef = push(ref(rtdb, `messages/${newChatId}`));
    const greetingMsg: SupportMessage = {
      id: greetingMsgRef.key || `msg_${Date.now()}`,
      chatId: newChatId,
      senderId: agent.agentId || 'AGENT_DEFAULT',
      senderType: 'admin',
      message: `Hi ${user.nickname || user.username || 'Member'}! 👋 Welcome to BGNICE Official Support. How can our 24/7 team assist you with your deposits, withdrawals, or gameplay today?`,
      timestamp: Date.now(),
      read: true
    };
    await set(greetingMsgRef, stripUndefined(greetingMsg));

    // If initial user message was provided, send it too
    if (messageText || imageUrl) {
      const userMsgRef = push(ref(rtdb, `messages/${newChatId}`));
      const userMsg: SupportMessage = {
        id: userMsgRef.key || `msg_${Date.now() + 1}`,
        chatId: newChatId,
        senderId: user.uid,
        senderType: 'user',
        message: messageText || (imageUrl ? '📷 Image' : ''),
        ...(imageUrl ? { imageUrl } : {}),
        timestamp: Date.now() + 1,
        read: false
      };
      await set(userMsgRef, stripUndefined(userMsg));
    }

    setActiveChat(newChat);
    showToast('Connected to BGNICE Official Support', 'success');
    return newChat;
  };

  // Send a message
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!inputText.trim() && !selectedImageFile) || !user) return;

    const textToSend = inputText.trim();
    setInputText('');
    setIsSending(true);

    try {
      let uploadedImageUrl: string | undefined = undefined;
      if (selectedImageFile) {
        setIsUploadingImage(true);
        showToast(language === 'bn' ? 'ছবি আপলোড হচ্ছে...' : 'Uploading image to ImgBB...', 'info');
        const uploadRes = await uploadToImgBB(selectedImageFile);
        if (!uploadRes.success || !uploadRes.url) {
          throw new Error(uploadRes.error || 'ImgBB upload failed');
        }
        uploadedImageUrl = uploadRes.url;
        removeSelectedImage();
      }

      let effectiveChat = activeChat;
      let effectiveChatId = effectiveChat?.chatId;

      // If no valid active chat or conversation is closed, start a new chat with this message
      if (!effectiveChat || !effectiveChatId || effectiveChatId === 'undefined' || effectiveChat.status === 'closed') {
        const created = await handleStartNewChat(textToSend || (uploadedImageUrl ? '📷 Image' : 'Hello'), uploadedImageUrl);
        if (created) {
          setTimeout(scrollToBottom, 100);
        }
        setIsSending(false);
        setIsUploadingImage(false);
        return;
      }

      const msgRef = push(ref(rtdb, `messages/${effectiveChatId}`));
      const userMsg: SupportMessage = {
        id: msgRef.key || `msg_${Date.now()}`,
        chatId: effectiveChatId,
        senderId: user.uid,
        senderType: 'user',
        message: textToSend || (uploadedImageUrl ? '📷 Image' : ''),
        ...(uploadedImageUrl ? { imageUrl: uploadedImageUrl } : {}),
        timestamp: Date.now(),
        read: false
      };

      await set(msgRef, stripUndefined(userMsg));

      // Update chat last message & time
      const displayLastMessage = textToSend || (uploadedImageUrl ? '📷 Image' : 'Message');
      const chatUpdates = {
        lastMessage: displayLastMessage,
        updatedAt: Date.now()
      };
      await update(ref(rtdb, `supportChats/${user.uid}/${effectiveChatId}`), chatUpdates).catch(() => {});
      await update(ref(rtdb, `supportChatsIndex/${effectiveChatId}`), chatUpdates).catch(() => {});

      setTimeout(scrollToBottom, 50);
    } catch (err: any) {
      console.error('Send message error:', err);
      showToast('Failed to send message: ' + (err?.message || 'Try again'), 'error');
    } finally {
      setIsSending(false);
      setIsUploadingImage(false);
    }
  };

  // Close active chat
  const handleCloseChat = async () => {
    if (!activeChat || !user || !activeChat.chatId || activeChat.chatId === 'undefined') return;
    const now = Date.now();
    const cId = activeChat.chatId;

    await update(ref(rtdb, `supportChats/${user.uid}/${cId}`), {
      status: 'closed',
      closedAt: now
    }).catch(() => {});
    await update(ref(rtdb, `supportChatsIndex/${cId}`), {
      status: 'closed',
      closedAt: now
    }).catch(() => {});

    // Add a system notice message
    const sysRef = push(ref(rtdb, `messages/${cId}`));
    await set(sysRef, stripUndefined({
      id: sysRef.key || `msg_${now}`,
      chatId: cId,
      senderId: 'system',
      senderType: 'system',
      message: 'Support conversation has been closed by the member. Thank you for contacting BGNICE.',
      timestamp: now,
      read: true
    })).catch(() => {});

    setActiveChat((prev) => (prev ? { ...prev, status: 'closed', closedAt: now } : null));
    setShowCloseConfirm(false);
    showToast('Chat closed successfully', 'info');
  };

  const isClosed = !activeChat || activeChat.status === 'closed';

  return (
    <div className="fixed inset-0 z-50 bg-[#f8fafc] flex flex-col max-w-lg mx-auto shadow-2xl overflow-hidden select-none animate-in fade-in duration-200">
      {/* 1. Header with Official BGNICE Support Branding */}
      <div className="bg-[#29303d] border-b border-slate-700/80 text-white px-4 py-3 shadow-md flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-3">
          <button
            onClick={onBack}
            className="p-1.5 -ml-1 text-white/90 hover:text-white hover:bg-white/10 rounded-full active:scale-95 transition-all"
            id="chat-back-btn"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="relative">
            <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-[#2196f3] bg-[#1e2530] shadow-sm flex flex-col items-center justify-center">
              <span className="text-[11px] font-black text-white font-mono tracking-tighter leading-none">BG</span>
              <span className="text-[7px] font-black text-[#2196f3] tracking-widest uppercase mt-0.5 leading-none">NICE</span>
            </div>
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-[#29303d] rounded-full"></span>
          </div>

          <div>
            <div className="flex items-center space-x-1.5">
              <h1 className="text-xs font-black tracking-wide text-white">
                BGNICE OFFICIAL SUPPORT
              </h1>
              <span className="bg-[#2196f3]/30 text-blue-200 text-[9px] font-bold px-1.5 py-0.2 rounded border border-[#2196f3]/40">
                Official
              </span>
            </div>
            <div className="flex items-center space-x-1 text-[11px] text-emerald-400 font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>BGNICE Official Support ● Online</span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-1">
          {/* History Button */}
          <button
            onClick={() => setIsHistoryOpen(true)}
            className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl transition-all"
            title="Chat History"
            id="chat-history-btn"
          >
            <History className="w-4 h-4" />
          </button>

          {/* Close Chat button if active */}
          {!isClosed && (
            <button
              onClick={() => setShowCloseConfirm(true)}
              className="px-2.5 py-1 text-xs font-bold text-rose-300 hover:text-rose-100 hover:bg-rose-500/20 border border-rose-500/30 rounded-xl transition-all active:scale-95"
              id="chat-close-btn"
            >
              End Chat
            </button>
          )}
        </div>
      </div>

      {/* User Session Bar */}
      <div className="bg-slate-100/90 border-b border-slate-200 px-4 py-1.5 text-[10px] text-slate-500 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2">
          <span>UID: <strong className="text-slate-800 font-mono">{user?.numericUid || user?.uid?.slice(0, 6) || 'Guest'}</strong></span>
          <span>•</span>
          <span className="truncate max-w-[120px] font-semibold text-slate-700">{user?.nickname || user?.username}</span>
        </div>
        {activeChat?.chatId && (
          <span className="font-mono text-slate-400">ID: {activeChat.chatId.slice(-8)}</span>
        )}
      </div>

      {/* 2. Chat Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#f8fafc]">
        {/* Welcome Security Card */}
        <div className="bg-white rounded-2xl p-3.5 border border-slate-200/80 shadow-2xs text-center space-y-1 max-w-sm mx-auto">
          <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 mx-auto flex items-center justify-center">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <p className="text-xs font-black text-slate-800">24/7 Verified Customer Support</p>
          <p className="text-[11px] text-slate-500 leading-relaxed">
            Welcome to BGNICE. Our support representatives are available around the clock to assist you with deposits, withdrawals, turnover rules, and gameplay.
          </p>
        </div>

        {/* Render Messages */}
        {messages.map((msg, mIdx) => {
          if (msg.senderType === 'system') {
            return (
              <div key={`sys-${msg.id || mIdx}-${mIdx}`} className="text-center my-2">
                <span className="bg-slate-200/80 text-slate-600 text-[10px] font-semibold px-3 py-1 rounded-full border border-slate-300">
                  {msg.message}
                </span>
              </div>
            );
          }

          const isUser = msg.senderType === 'user';

          return (
            <div
              key={`msg-${msg.id || mIdx}-${mIdx}`}
              className={`flex items-end space-x-2 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-7 h-7 rounded-full overflow-hidden bg-slate-200 shrink-0 mb-0.5 border border-slate-300">
                  <img
                    src={activeChat?.agentPhoto || assignedAgent.profilePhoto || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80'}
                    alt="Agent"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80';
                    }}
                  />
                </div>
              )}

              <div
                className={`max-w-[80%] rounded-2xl p-2.5 text-xs shadow-2xs leading-relaxed ${
                  isUser
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-br-xs'
                    : 'bg-white text-slate-800 border border-slate-200/90 rounded-bl-xs'
                }`}
              >
                {Boolean(msg.imageUrl && msg.imageUrl.trim()) && (
                  <div
                    className="mb-1.5 rounded-xl overflow-hidden bg-black/5 relative group cursor-pointer"
                    onClick={() => setLightboxImage(msg.imageUrl || null)}
                  >
                    <img
                      src={msg.imageUrl}
                      alt="Attachment"
                      className="max-h-48 max-w-full rounded-xl object-contain hover:scale-102 transition-transform duration-200"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-xl">
                      <span className="text-[10px] bg-black/70 text-white px-2 py-0.5 rounded-full flex items-center gap-1 font-sans">
                        <ZoomIn className="w-3 h-3" /> {language === 'bn' ? 'বড় করে দেখুন' : 'Zoom'}
                      </span>
                    </div>
                  </div>
                )}
                {msg.message && (
                  <p className="font-medium whitespace-pre-wrap break-words">{msg.message}</p>
                )}
                <div
                  className={`flex items-center justify-end space-x-1 mt-1 text-[9px] ${
                    isUser ? 'text-blue-200' : 'text-slate-400'
                  }`}
                >
                  <span>
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  {isUser && <CheckCheck className="w-3 h-3 text-blue-200" />}
                </div>
              </div>
            </div>
          );
        })}

        {/* State Notice if Chat is Closed or Not Started */}
        {isClosed && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-center space-y-3 my-4">
            <div className="w-9 h-9 rounded-full bg-amber-100 text-amber-600 mx-auto flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-black text-amber-900">
                {activeChat?.status === 'closed' ? 'Support Session Ended' : 'BGNICE Live Support'}
              </h3>
              <p className="text-[11px] text-amber-700 mt-0.5">
                {activeChat?.status === 'closed'
                  ? 'This support conversation is closed. Start a fresh session or send a message below to connect with an agent.'
                  : 'Start a conversation with our verified support team for instant 24/7 assistance with deposits, withdrawals, or bonuses.'}
              </p>
            </div>
            <button
              onClick={() => handleStartNewChat()}
              className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-blue-500/20 active:scale-98 transition-all flex items-center justify-center space-x-1.5"
              id="chat-start-new-btn"
            >
              <Plus className="w-4 h-4" />
              <span>{activeChat?.status === 'closed' ? 'START NEW CHAT' : 'START LIVE CHAT'}</span>
            </button>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Inquiries */}
      <div className="bg-white/80 border-t border-slate-200/60 px-3 py-2 flex items-center space-x-1.5 overflow-x-auto no-scrollbar shrink-0">
        {(language === 'bn'
          ? ['ডিপোজিট সহায়তা', 'উইথড্র স্ট্যাটাস', 'ভিআইপি বোনাস', 'টার্নওভার সম্পর্কিত']
          : ['Deposit Confirmation', 'Withdrawal Status', 'VIP Bonus Inquiry', 'Turnover Questions']
        ).map((q) => (
          <button
            key={q}
            onClick={() => {
              setInputText(q);
            }}
            className="px-2.5 py-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-semibold shrink-0 transition-all border border-slate-200/80 active:scale-95"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Selected Image Preview */}
      {Boolean(selectedImagePreview && selectedImagePreview.trim()) && (
        <div className="px-4 py-2 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <img
              src={selectedImagePreview}
              alt="Preview"
              className="w-11 h-11 object-cover rounded-xl border border-slate-200 shadow-2xs"
            />
            <div>
              <p className="text-xs font-bold text-slate-800">{language === 'bn' ? 'ছবি সংযুক্ত করা হয়েছে' : 'Image attached'}</p>
              <p className="text-[10px] text-slate-400">ImgBB Cloud Hosting</p>
            </div>
          </div>
          <button
            type="button"
            onClick={removeSelectedImage}
            className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-full transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 3. Message Input Footer */}
      <div className="bg-white border-t border-slate-200 p-3 shrink-0">
        <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
          {/* Hidden Image Input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageFileChange}
            className="hidden"
            id="live-chat-full-file-input"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploadingImage || isSending}
            className="w-10 h-10 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors shrink-0 disabled:opacity-50"
            title="Attach image"
          >
            <ImageIcon className="w-4 h-4" />
          </button>

          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              selectedImagePreview
                ? (language === 'bn' ? 'ছবির সাথে বিবরণ লিখুন (ঐচ্ছিক)...' : 'Add image description...')
                : isClosed
                ? (language === 'bn' ? 'মেসেজ লিখে লাইভ চ্যাট শুরু করুন...' : 'Type a message to start support...')
                : (language === 'bn' ? 'আপনার প্রশ্ন এখানে লিখুন...' : 'Type your question here...')
            }
            className="flex-1 bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-xs font-semibold text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white transition-all shadow-inner"
            id="chat-input-field"
          />
          <button
            type="submit"
            disabled={isSending || isUploadingImage || (!inputText.trim() && !selectedImageFile)}
            className="w-10 h-10 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20 active:scale-95 transition-all disabled:opacity-40 shrink-0"
            id="chat-send-btn"
          >
            {isSending || isUploadingImage ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </button>
        </form>
      </div>

      {/* Close Confirmation Modal */}
      {showCloseConfirm && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 max-w-xs w-full text-center space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900">Close Live Chat?</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Are you sure you want to end this conversation? Your session will be saved in your chat history.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => setShowCloseConfirm(false)}
                className="py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all"
                id="cancel-close-chat-btn"
              >
                Cancel
              </button>
              <button
                onClick={handleCloseChat}
                className="py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all active:scale-95 shadow-sm"
                id="confirm-close-chat-btn"
              >
                Close Chat
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Chat History Drawer / Modal */}
      {isHistoryOpen && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex flex-col justify-end">
          <div className="bg-white rounded-t-3xl p-5 max-h-[80vh] flex flex-col shadow-2xl animate-in slide-in-from-bottom duration-200 max-w-lg mx-auto w-full">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
              <div className="flex items-center space-x-2">
                <History className="w-4 h-4 text-blue-600" />
                <h3 className="text-sm font-black text-slate-900">Support Chat History</h3>
              </div>
              <button
                onClick={() => setIsHistoryOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full"
                id="close-chat-history-btn"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-3 space-y-2">
              {chatHistoryList.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  No previous conversations found.
                </div>
              ) : (
                chatHistoryList.map((c, cIdx) => (
                  <div
                    key={`hist-${c.chatId || cIdx}-${cIdx}`}
                    onClick={() => {
                      setActiveChat(c);
                      setIsHistoryOpen(false);
                    }}
                    className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                      activeChat?.chatId === c.chatId
                        ? 'bg-blue-50 border-blue-200'
                        : 'bg-slate-50 border-slate-100 hover:bg-slate-100'
                    }`}
                  >
                    <div className="min-w-0 pr-2">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-bold text-slate-900">{c.agentName || 'Support Agent'}</span>
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full ${
                            c.status === 'active'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-200 text-slate-600'
                          }`}
                        >
                          {c.status}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 truncate mt-0.5">
                        {c.lastMessage || 'No messages yet'}
                      </p>
                      <span className="text-[9px] text-slate-400">
                        {new Date(c.createdAt).toLocaleDateString()} {new Date(c.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <button
              onClick={() => {
                setIsHistoryOpen(false);
                handleStartNewChat();
              }}
              className="w-full mt-2 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-extrabold text-xs rounded-2xl shadow-md active:scale-98 transition-all shrink-0"
              id="history-start-new-chat-btn"
            >
              + START NEW CONVERSATION
            </button>
          </div>
        </div>
      )}

      {/* Full Size Image Lightbox */}
      {Boolean(lightboxImage && lightboxImage.trim()) && (
        <div
          className="fixed inset-0 z-[100000] bg-black/90 flex items-center justify-center p-4 backdrop-blur-xs"
          onClick={() => setLightboxImage(null)}
        >
          <div className="relative max-w-lg max-h-[85vh] flex flex-col items-center">
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute -top-10 right-0 p-2 text-white/80 hover:text-white bg-white/10 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={lightboxImage}
              alt="Attachment"
              className="max-h-[80vh] max-w-full rounded-2xl shadow-2xl object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        </div>
      )}
    </div>
  );
};
