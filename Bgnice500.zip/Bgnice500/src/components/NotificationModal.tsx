import React, { useState, useMemo } from 'react';
import { 
  Bell, 
  X, 
  CheckCheck, 
  LogIn, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Clock, 
  CheckCircle2, 
  XCircle,
  ShieldCheck,
  Calendar
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { 
  AppNotification, 
  formatNotificationDateTime, 
  getStoredLoginNotifications, 
  getReadNotificationIds, 
  markNotificationsAsRead 
} from '../utils/notifications';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate?: (tab: string) => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  onNavigate
}) => {
  const { user, deposits, withdrawals, setShowAuthModal } = useApp();
  const [filter, setFilter] = useState<'all' | 'login' | 'deposit' | 'withdrawal'>('all');
  const [readVersion, setReadVersion] = useState(0);

  // Compute all notifications dynamically from user state, real-time deposits & withdrawals
  const allNotifications = useMemo(() => {
    if (!user?.uid) return [];

    const notifs: AppNotification[] = [];

    // 1. Login History
    const logins = getStoredLoginNotifications(user.uid);
    notifs.push(...logins);

    // 2. User Deposits
    (deposits || [])
      .filter((d) => d.uid === user.uid || (d as any).userId === user.uid)
      .forEach((d) => {
        const isSuccess = d.status === 'completed' || d.status === 'approved' || d.status === 'success';
        const isPending = d.status === 'pending' || d.status === 'processing';
        const isFailed = d.status === 'rejected';

        const method = (d.channel || d.method || 'Online').toUpperCase();
        const amountStr = `৳${(d.amount || 0).toFixed(2)}`;

        if (isSuccess) {
          notifs.push({
            id: `dep_${d.id}`,
            type: 'deposit',
            title: 'Deposit Approved',
            message: `Your deposit request of ${amountStr} via ${method} has been approved by admin and added to your balance.`,
            timestamp: d.createdAt || Date.now(),
            status: 'success',
            amount: d.amount
          });
        } else if (isPending) {
          notifs.push({
            id: `dep_${d.id}`,
            type: 'deposit',
            title: 'Deposit Processing',
            message: `Your deposit request of ${amountStr} via ${method} is currently being verified by admin.`,
            timestamp: d.createdAt || Date.now(),
            status: 'processing',
            amount: d.amount
          });
        } else if (isFailed) {
          notifs.push({
            id: `dep_${d.id}`,
            type: 'deposit',
            title: 'Deposit Rejected',
            message: `Your deposit order of ${amountStr} via ${method} could not be verified by admin.`,
            timestamp: d.createdAt || Date.now(),
            status: 'rejected',
            amount: d.amount
          });
        }
      });

    // 3. User Withdrawals
    (withdrawals || [])
      .filter((w) => w.uid === user.uid || (w as any).userId === user.uid)
      .forEach((w) => {
        const isSuccess = w.status === 'completed' || w.status === 'approved' || w.status === 'success';
        const isPending = w.status === 'pending' || w.status === 'processing';
        const isFailed = w.status === 'rejected';

        const amountStr = `৳${(w.amount || 0).toFixed(2)}`;
        const accountInfo = `${w.walletMethod || 'Account'} (${w.accountNumber || ''})`;

        if (isSuccess) {
          notifs.push({
            id: `with_${w.id}`,
            type: 'withdrawal',
            title: 'Withdrawal Approved',
            message: `Your withdrawal request of ${amountStr} to ${accountInfo} has been approved by admin and paid out.`,
            timestamp: w.createdAt || Date.now(),
            status: 'success',
            amount: w.amount
          });
        } else if (isPending) {
          notifs.push({
            id: `with_${w.id}`,
            type: 'withdrawal',
            title: 'Withdrawal Processing',
            message: `Your withdrawal request of ${amountStr} to ${accountInfo} has been received and is waiting for admin approval.`,
            timestamp: w.createdAt || Date.now(),
            status: 'processing',
            amount: w.amount
          });
        } else if (isFailed) {
          notifs.push({
            id: `with_${w.id}`,
            type: 'withdrawal',
            title: 'Withdrawal Rejected',
            message: `Your withdrawal request of ${amountStr} to ${accountInfo} was rejected by admin.`,
            timestamp: w.createdAt || Date.now(),
            status: 'rejected',
            amount: w.amount
          });
        }
      });

    // Sort newest first
    return notifs.sort((a, b) => b.timestamp - a.timestamp);
  }, [user?.uid, deposits, withdrawals]);

  // Read status set
  const readIds = useMemo(() => {
    if (!user?.uid) return new Set<string>();
    return getReadNotificationIds(user.uid);
  }, [user?.uid, readVersion]);

  const handleMarkAllRead = () => {
    if (!user?.uid) return;
    const allIds = allNotifications.map((n) => n.id);
    markNotificationsAsRead(user.uid, allIds);
    setReadVersion((v) => v + 1);
  };

  const filteredNotifications = useMemo(() => {
    if (filter === 'all') return allNotifications;
    return allNotifications.filter((n) => n.type === filter);
  }, [allNotifications, filter]);

  const unreadCount = useMemo(() => {
    return allNotifications.filter((n) => !readIds.has(n.id)).length;
  }, [allNotifications, readIds]);

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-xs select-none animate-in fade-in duration-200"
      id="notification-modal-overlay"
    >
      <div 
        className="bg-white rounded-3xl w-full max-w-md max-h-[85vh] flex flex-col shadow-2xl overflow-hidden border border-slate-100"
        id="notification-modal-container"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-[#ea4335] via-[#e53935] to-[#d32f2f] text-white p-4 flex items-center justify-between shrink-0 shadow-md">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-xs shadow-inner">
              <Bell className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="font-black text-sm tracking-wide flex items-center space-x-2">
                <span>Notifications</span>
                {unreadCount > 0 && (
                  <span className="bg-amber-400 text-slate-900 font-extrabold text-[10px] px-2 py-0.2 rounded-full shadow-xs">
                    {unreadCount} New
                  </span>
                )}
              </h2>
              <p className="text-[11px] text-white/80 font-medium">Real-time alerts for login, deposits & payouts</p>
            </div>
          </div>

          <div className="flex items-center space-x-1.5">
            {unreadCount > 0 && (
              <button
                onClick={handleMarkAllRead}
                className="px-2.5 py-1 bg-white/20 hover:bg-white/30 active:scale-95 text-white rounded-lg text-[10px] font-bold transition-all flex items-center space-x-1 shadow-xs"
                title="Mark all as read"
                id="notif-mark-all-read-btn"
              >
                <CheckCheck className="w-3 h-3" />
                <span>Mark Read</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 active:scale-95 flex items-center justify-center transition-all text-white"
              id="notif-close-btn"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center space-x-1.5 px-3.5 py-2.5 bg-slate-50 border-b border-slate-100 overflow-x-auto shrink-0 scrollbar-none text-xs">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-full font-bold text-xs transition-all whitespace-nowrap ${
              filter === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-200/70 border border-slate-200'
            }`}
            id="notif-filter-all"
          >
            All ({allNotifications.length})
          </button>
          <button
            onClick={() => setFilter('login')}
            className={`px-3 py-1.5 rounded-full font-bold text-xs transition-all whitespace-nowrap flex items-center space-x-1 ${
              filter === 'login'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-200/70 border border-slate-200'
            }`}
            id="notif-filter-login"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Login</span>
          </button>
          <button
            onClick={() => setFilter('deposit')}
            className={`px-3 py-1.5 rounded-full font-bold text-xs transition-all whitespace-nowrap flex items-center space-x-1 ${
              filter === 'deposit'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-200/70 border border-slate-200'
            }`}
            id="notif-filter-deposit"
          >
            <ArrowDownLeft className="w-3.5 h-3.5" />
            <span>Deposits</span>
          </button>
          <button
            onClick={() => setFilter('withdrawal')}
            className={`px-3 py-1.5 rounded-full font-bold text-xs transition-all whitespace-nowrap flex items-center space-x-1 ${
              filter === 'withdrawal'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-200/70 border border-slate-200'
            }`}
            id="notif-filter-withdraw"
          >
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>Withdrawals</span>
          </button>
        </div>

        {/* Content List */}
        <div className="flex-1 overflow-y-auto p-3.5 space-y-2.5">
          {!user ? (
            <div className="py-12 px-4 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 mx-auto flex items-center justify-center text-slate-400">
                <LogIn className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800">Please Log In</h3>
                <p className="text-xs text-slate-500 max-w-xs mx-auto mt-1">
                  Log in to your account to view your login history, deposit approvals, and payout records.
                </p>
              </div>
              <button
                onClick={() => {
                  onClose();
                  setShowAuthModal(true);
                }}
                className="py-2.5 px-6 bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold rounded-xl text-xs shadow-md transition-all"
                id="notif-auth-prompt-btn"
              >
                Log In / Register
              </button>
            </div>
          ) : filteredNotifications.length === 0 ? (
            <div className="py-12 text-center text-slate-400 space-y-2">
              <Bell className="w-8 h-8 mx-auto text-slate-300 stroke-[1.5]" />
              <p className="text-xs font-semibold">No notifications found in this category.</p>
              <p className="text-[11px] text-slate-400">
                New login, deposit approval, and withdrawal alerts will appear here automatically.
              </p>
            </div>
          ) : (
            filteredNotifications.map((notif) => {
              const isRead = readIds.has(notif.id);

              return (
                <div
                  key={notif.id}
                  onClick={() => {
                    if (user?.uid && !isRead) {
                      markNotificationsAsRead(user.uid, [notif.id]);
                      setReadVersion((v) => v + 1);
                    }
                    if (notif.type === 'deposit' && onNavigate) {
                      onClose();
                      onNavigate('deposit');
                    } else if (notif.type === 'withdrawal' && onNavigate) {
                      onClose();
                      onNavigate('withdraw');
                    }
                  }}
                  className={`rounded-2xl p-3 border transition-all cursor-pointer ${
                    !isRead
                      ? 'bg-amber-50/50 border-amber-200/70 shadow-xs'
                      : 'bg-white border-slate-100 hover:border-slate-200'
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    {/* Icon based on Type */}
                    <div className="shrink-0 mt-0.5">
                      {notif.type === 'login' ? (
                        <div className="w-8 h-8 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center shadow-2xs">
                          <ShieldCheck className="w-4 h-4" />
                        </div>
                      ) : notif.type === 'deposit' ? (
                        <div className="w-8 h-8 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-600 flex items-center justify-center shadow-2xs">
                          <ArrowDownLeft className="w-4 h-4" />
                        </div>
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-blue-50 border border-blue-100 text-blue-600 flex items-center justify-center shadow-2xs">
                          <ArrowUpRight className="w-4 h-4" />
                        </div>
                      )}
                    </div>

                    {/* Content Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1.5 mb-1">
                        <h4 className="text-xs font-bold text-slate-800 truncate">
                          {notif.title}
                        </h4>

                        {/* Status Badge */}
                        {notif.status && (
                          <span
                            className={`shrink-0 px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border flex items-center space-x-1 ${
                              notif.status === 'success'
                                ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
                                : notif.status === 'processing'
                                ? 'bg-amber-50 text-amber-600 border-amber-200'
                                : 'bg-rose-50 text-rose-600 border-rose-200'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                notif.status === 'success'
                                  ? 'bg-emerald-500'
                                  : notif.status === 'processing'
                                  ? 'bg-amber-500 animate-pulse'
                                  : 'bg-rose-500'
                              }`}
                            />
                            <span>{notif.status === 'success' ? 'Success' : notif.status === 'processing' ? 'Processing' : 'Rejected'}</span>
                          </span>
                        )}
                      </div>

                      <p className="text-[11px] text-slate-600 leading-relaxed break-words">
                        {notif.message}
                      </p>

                      {/* Time and Date Display */}
                      <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-slate-100 text-[10px] text-slate-400">
                        <span className="flex items-center space-x-1 font-medium">
                          <Calendar className="w-3 h-3 text-slate-400" />
                          <span>{formatNotificationDateTime(notif.timestamp)}</span>
                        </span>
                        {!isRead && (
                          <span className="text-[9px] font-bold text-amber-600 uppercase bg-amber-100/70 px-1.5 py-0.2 rounded-xs">
                            New
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 shrink-0">
          <span>BGNICE Real-Time Notifications</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl text-xs active:scale-95 transition-all"
            id="notif-footer-close-btn"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
