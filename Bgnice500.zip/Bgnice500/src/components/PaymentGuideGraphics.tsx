import React from 'react';
import { Check, Send, Download, Smartphone, CreditCard, ArrowDownRight, CornerDownRight } from 'lucide-react';

interface GuideGraphicProps {
  type: 'step1' | 'step2';
  paymentType: 'Nagad' | 'bKash' | 'Rocket' | 'USDT' | string;
  isSendMoney: boolean;
  paymentTarget: string;
  amount: number;
  imageUrl?: string;
  onOpenZoom?: (imgUrl?: string) => void;
}

export const PaymentGuideGraphic: React.FC<GuideGraphicProps> = ({
  type,
  paymentType,
  isSendMoney,
  paymentTarget,
  amount,
  imageUrl,
  onOpenZoom
}) => {
  // If admin uploaded an image (via ImgBB or direct link), render the image
  if (imageUrl && imageUrl.trim().length > 5) {
    return (
      <div
        onClick={() => onOpenZoom && onOpenZoom(imageUrl)}
        className="w-full h-44 sm:h-52 rounded-2xl overflow-hidden bg-slate-900 border border-slate-200 shadow-inner flex items-center justify-center cursor-pointer group relative"
      >
        <img
          src={imageUrl}
          alt={type === 'step1' ? 'Step 1 Guide' : 'Step 2 Guide'}
          className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
          <span className="opacity-0 group-hover:opacity-100 bg-black/70 text-white text-[10px] font-bold px-2 py-1 rounded-full shadow-sm transition-opacity">
            ক্লিক করে বড় দেখুন 🔍
          </span>
        </div>
      </div>
    );
  }

  const isBkash = paymentType.toLowerCase().includes('bkash');
  const isNagad = paymentType.toLowerCase().includes('nagad');
  const isRocket = paymentType.toLowerCase().includes('rocket');

  const brandColor = isBkash ? '#e2136e' : isNagad ? '#ff6000' : isRocket ? '#8b2487' : '#0284c7';
  const brandName = isBkash ? 'bKash' : isNagad ? 'নগদ' : isRocket ? 'রকেট' : 'Crypto';

  // Vector realistic UI representation
  if (type === 'step1') {
    return (
      <div
        onClick={() => onOpenZoom && onOpenZoom()}
        className="w-full h-44 sm:h-52 rounded-2xl bg-white border border-slate-200 shadow-xs overflow-hidden flex flex-col cursor-pointer select-none relative group"
      >
        {/* App Top Bar */}
        <div
          style={{ backgroundColor: brandColor }}
          className="px-2.5 py-1.5 flex items-center justify-between text-white text-[10px] font-bold shrink-0 shadow-xs"
        >
          <div className="flex items-center space-x-1">
            <div className="w-2.5 h-2.5 rounded-full bg-white/30 flex items-center justify-center text-[7px] font-black">
              ●
            </div>
            <span>{brandName} অ্যাপ</span>
          </div>
          <span className="text-[9px] bg-black/20 px-1.5 py-0.5 rounded-full font-mono">
            ব্যালেন্স: ৳***
          </span>
        </div>

        {/* 4 App Service Icons */}
        <div className="p-2 flex-1 bg-slate-50/70 flex flex-col justify-center">
          <div className="grid grid-cols-2 gap-1.5">
            {/* Send Money Tile */}
            <div
              className={`p-2 rounded-xl border flex flex-col items-center justify-center text-center relative transition-all ${
                isSendMoney
                  ? 'bg-red-50/90 border-red-500 shadow-sm ring-2 ring-red-500/40 animate-pulse'
                  : 'bg-white border-slate-200 opacity-60'
              }`}
            >
              <div
                style={{ backgroundColor: isSendMoney ? brandColor : '#94a3b8' }}
                className="w-7 h-7 rounded-full flex items-center justify-center text-white mb-1 shadow-2xs"
              >
                <Send className="w-3.5 h-3.5" />
              </div>
              <span className={`text-[10px] font-black ${isSendMoney ? 'text-red-700' : 'text-slate-600'}`}>
                সেন্ড মানি
              </span>
              {isSendMoney && (
                <div className="absolute -top-2 right-1 bg-red-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded-full shadow-xs uppercase tracking-tighter animate-bounce">
                  ট্যাপ করুন 👆
                </div>
              )}
            </div>

            {/* Cash Out Tile */}
            <div
              className={`p-2 rounded-xl border flex flex-col items-center justify-center text-center relative transition-all ${
                !isSendMoney
                  ? 'bg-red-50/90 border-red-500 shadow-sm ring-2 ring-red-500/40 animate-pulse'
                  : 'bg-white border-slate-200 opacity-60'
              }`}
            >
              <div
                style={{ backgroundColor: !isSendMoney ? brandColor : '#94a3b8' }}
                className="w-7 h-7 rounded-full flex items-center justify-center text-white mb-1 shadow-2xs"
              >
                <Download className="w-3.5 h-3.5" />
              </div>
              <span className={`text-[10px] font-black ${!isSendMoney ? 'text-red-700' : 'text-slate-600'}`}>
                ক্যাশ আউট
              </span>
              {!isSendMoney && (
                <div className="absolute -top-2 right-1 bg-red-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded-full shadow-xs uppercase tracking-tighter animate-bounce">
                  ট্যাপ করুন 👆
                </div>
              )}
            </div>

            {/* Mobile Recharge Tile (Background dummy) */}
            <div className="p-1.5 rounded-xl border bg-white border-slate-200 opacity-40 flex flex-col items-center justify-center text-center">
              <div className="w-5 h-5 rounded-full bg-slate-400 text-white flex items-center justify-center mb-0.5">
                <Smartphone className="w-3 h-3" />
              </div>
              <span className="text-[8px] font-bold text-slate-500">রিচার্জ</span>
            </div>

            {/* Payment Tile (Background dummy) */}
            <div className="p-1.5 rounded-xl border bg-white border-slate-200 opacity-40 flex flex-col items-center justify-center text-center">
              <div className="w-5 h-5 rounded-full bg-slate-400 text-white flex items-center justify-center mb-0.5">
                <CreditCard className="w-3 h-3" />
              </div>
              <span className="text-[8px] font-bold text-slate-500">পেমেন্ট</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-100 py-1 px-2 text-[9px] text-center text-slate-600 font-bold border-t border-slate-200 truncate">
          ধাপ ১: {isSendMoney ? 'Send Money নির্বাচন করুন' : 'Cash Out নির্বাচন করুন'}
        </div>
      </div>
    );
  }

  // Step 2: Transaction Receipt Screen Graphic
  return (
    <div
      onClick={() => onOpenZoom && onOpenZoom()}
      className="w-full h-44 sm:h-52 rounded-2xl bg-white border border-slate-200 shadow-xs overflow-hidden flex flex-col cursor-pointer select-none relative group"
    >
      {/* App Top Bar */}
      <div
        style={{ backgroundColor: brandColor }}
        className="px-2.5 py-1.5 flex items-center justify-between text-white text-[10px] font-bold shrink-0 shadow-xs"
      >
        <span className="text-[10px]">{brandName} লেনদেন রশিদ</span>
        <div className="w-3.5 h-3.5 rounded-full bg-emerald-400 text-emerald-950 flex items-center justify-center text-[9px] font-black">
          ✓
        </div>
      </div>

      {/* Receipt Card Body */}
      <div className="p-2 flex-1 bg-slate-50/70 flex flex-col justify-center space-y-1 text-slate-800">
        <div className="flex items-center space-x-1.5 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-lg text-emerald-800 text-[10px] font-bold">
          <Check className="w-3 h-3 text-emerald-600 shrink-0" />
          <span className="truncate">{isSendMoney ? 'সেন্ড মানি সফল হয়েছে' : 'ক্যাশ আউট সফল হয়েছে'}</span>
        </div>

        <div className="bg-white p-1.5 rounded-xl border border-slate-200 text-[9px] space-y-0.5 font-medium shadow-2xs">
          <div className="flex justify-between text-slate-500 text-[8px]">
            <span>প্রাপক:</span>
            <span className="font-mono text-slate-800 font-bold truncate max-w-[110px]">{paymentTarget}</span>
          </div>
          <div className="flex justify-between text-slate-500 text-[8px]">
            <span>পরিমাণ:</span>
            <span className="font-bold text-slate-900 font-mono">৳{amount.toLocaleString()}</span>
          </div>

          {/* Highlighted TrxID Row */}
          <div className="mt-1 p-1 bg-red-50 rounded-lg border-2 border-red-500 flex items-center justify-between text-red-900 font-bold relative">
            <span className="text-[9px] font-black text-red-700">TrxID:</span>
            <span className="font-mono font-black text-[10px] text-red-600 tracking-wider">
              72N9X4P1
            </span>
            <div className="absolute -bottom-3 right-0 bg-red-600 text-white text-[7px] font-black px-1.5 py-0.5 rounded-full shadow-xs animate-bounce">
              কপি করুন 👈
            </div>
          </div>
        </div>
      </div>

      <div className="bg-slate-100 py-1 px-2 text-[9px] text-center text-slate-600 font-bold border-t border-slate-200 truncate">
        ধাপ ২: TrxID কপি করে নিচে লিখুন
      </div>
    </div>
  );
};
