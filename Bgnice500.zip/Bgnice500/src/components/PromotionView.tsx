import React, { useState } from 'react';
import { Copy, Check, Users, Gift, Share2, HelpCircle, ChevronRight, Award, DollarSign } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { UserProfile } from '../types';
import { BrandLogo } from './BrandLogo';
import { SubordinateDataModal } from './SubordinateDataModal';

export const PromotionView: React.FC = () => {
  const { user, allUsers, deposits } = useApp();
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isSubordinateModalOpen, setIsSubordinateModalOpen] = useState(false);

  const inviteCode = user?.referCode || user?.inviteCode || user?.numericUid || '11376236313';
  const inviteLink = `${window.location.origin}?invite=${inviteCode}`;

  const usersList: UserProfile[] = React.useMemo(() => {
    if (!allUsers) return [];
    return Array.isArray(allUsers) ? allUsers : Object.values(allUsers);
  }, [allUsers]);

  const safeDeposits: any[] = React.useMemo(() => {
    if (!deposits) return [];
    return Array.isArray(deposits) ? deposits : Object.values(deposits);
  }, [deposits]);

  // Recursive multi-level subordinate tree calculation
  const { directSubordinates, allTeamSubordinates, directDeposits, teamDeposits } = React.useMemo(() => {
    if (!user) {
      return {
        directSubordinates: [],
        allTeamSubordinates: [],
        directDeposits: 0,
        teamDeposits: 0
      };
    }

    const matchesParent = (child: UserProfile, parent: UserProfile) => {
      const ref = (child.referredBy || child.invitedBy || '').trim();
      if (!ref) return false;
      return (
        ref === (parent.referCode || '').trim() ||
        ref === (parent.numericUid || '').trim() ||
        ref === (parent.inviteCode || '').trim() ||
        ref === parent.uid
      );
    };

    const visitedUids = new Set<string>([user.uid]);
    const breakdown: Record<number, UserProfile[]> = {};
    let currentLevelUsers: UserProfile[] = [user];
    let level = 1;

    while (currentLevelUsers.length > 0 && level <= 10) {
      const nextLevelUsers: UserProfile[] = [];
      for (const parent of currentLevelUsers) {
        for (const candidate of usersList) {
          if (!visitedUids.has(candidate.uid) && matchesParent(candidate, parent)) {
            visitedUids.add(candidate.uid);
            nextLevelUsers.push(candidate);
          }
        }
      }
      if (nextLevelUsers.length > 0) {
        breakdown[level] = nextLevelUsers;
        currentLevelUsers = nextLevelUsers;
        level++;
      } else {
        break;
      }
    }

    const directs = breakdown[1] || [];
    const allTeam = Object.values(breakdown).flat();

    const directUids = new Set(directs.map((u) => u.uid));
    const teamUids = new Set(allTeam.map((u) => u.uid));

    const directDep = safeDeposits
      .filter((d) => directUids.has(d.uid) && d.status === 'completed')
      .reduce((sum, d) => sum + (Number(d.amount) || 0), 0);

    const teamDep = safeDeposits
      .filter((d) => teamUids.has(d.uid) && d.status === 'completed')
      .reduce((sum, d) => sum + (Number(d.amount) || 0), 0);

    return {
      directSubordinates: directs,
      allTeamSubordinates: allTeam,
      directDeposits: directDep,
      teamDeposits: teamDep
    };
  }, [user, usersList, safeDeposits]);

  const totalCommission = Number(user?.referralBalance || 0);

  const handleCopy = (type: 'code' | 'link') => {
    if (type === 'code') {
      navigator.clipboard.writeText(inviteCode);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } else {
      navigator.clipboard.writeText(inviteLink);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-[#29303d] pb-24 text-slate-100 select-none">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-[#2196f3] text-white px-4 py-3 flex items-center justify-between shadow-md">
        <BrandLogo variant="compact" showBadge={false} />
        <h1 className="text-base font-bold">Agency Promotion</h1>
        <button
          onClick={() => setIsSubordinateModalOpen(true)}
          className="text-white/90 hover:text-white p-1"
          title="Team Statistics"
        >
          <HelpCircle className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* Commission Card */}
        <div className="bg-gradient-to-r from-[#2196f3] to-[#1976d2] rounded-3xl p-5 text-white shadow-lg space-y-4">
          <div>
            <div className="text-xs text-white/80 font-medium">Total referral commission earned</div>
            <div className="text-3xl font-black mt-1">৳{totalCommission.toFixed(2)}</div>
            <div className="text-[10px] bg-white/20 inline-block px-2.5 py-0.5 rounded-full mt-1.5 font-medium">
              Multi-Level Team Commissions Active
            </div>
          </div>

          {/* Subordinates Matrix */}
          <div className="grid grid-cols-2 gap-3 pt-2 border-t border-white/20">
            {/* Direct */}
            <div
              onClick={() => setIsSubordinateModalOpen(true)}
              className="bg-white/10 rounded-xl p-2.5 space-y-1 text-xs cursor-pointer hover:bg-white/15 transition-colors"
            >
              <div className="flex items-center space-x-1 font-bold">
                <Users className="w-3.5 h-3.5" />
                <span>Direct (Level 1)</span>
              </div>
              <div className="text-base font-extrabold">{directSubordinates.length}</div>
              <div className="text-[10px] text-white/80">Deposit: ৳{directDeposits.toFixed(2)}</div>
            </div>

            {/* Team */}
            <div
              onClick={() => setIsSubordinateModalOpen(true)}
              className="bg-white/10 rounded-xl p-2.5 space-y-1 text-xs cursor-pointer hover:bg-white/15 transition-colors"
            >
              <div className="flex items-center space-x-1 font-bold">
                <Users className="w-3.5 h-3.5" />
                <span>Total Team</span>
              </div>
              <div className="text-base font-extrabold">{allTeamSubordinates.length}</div>
              <div className="text-[10px] text-white/80">Deposit: ৳{teamDeposits.toFixed(2)}</div>
            </div>
          </div>
        </div>

        {/* Invitation Link & Code */}
        <div className="bg-[#1f2633] rounded-2xl p-4 shadow-sm border border-slate-700/60 space-y-3">
          <button
            onClick={() => handleCopy('link')}
            className="w-full py-3 bg-[#2196f3] hover:bg-[#1e88e5] active:scale-98 text-white font-extrabold rounded-xl shadow-md text-sm flex items-center justify-center space-x-2"
            id="copy-invite-link-btn"
          >
            <Share2 className="w-4 h-4" />
            <span>{copiedLink ? 'Link Copied to Clipboard!' : 'INVITATION LINK'}</span>
          </button>

          <div className="flex items-center justify-between p-3 bg-[#29303d] rounded-xl border border-slate-700 text-xs">
            <div>
              <span className="text-slate-400 block text-[10px]">Copy invitation code</span>
              <span className="font-mono font-bold text-white text-sm">{inviteCode}</span>
            </div>
            <button
              onClick={() => handleCopy('code')}
              className="p-2 text-[#2196f3] hover:bg-white/5 rounded-lg active:scale-90"
              id="copy-invite-code-btn"
            >
              {copiedCode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Multi-Tier Commission Rates */}
        <div className="bg-[#1f2633] rounded-2xl p-4 shadow-sm border border-slate-700/60 space-y-2.5 text-xs">
          <div className="font-bold text-slate-200">Commission Tiers</div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="bg-[#29303d] p-2.5 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 block">Level 1</span>
              <span className="font-black text-sm text-[#2196f3]">5.0%</span>
            </div>
            <div className="bg-[#29303d] p-2.5 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 block">Level 2</span>
              <span className="font-black text-sm text-emerald-400">2.0%</span>
            </div>
            <div className="bg-[#29303d] p-2.5 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 block">Level 3+</span>
              <span className="font-black text-sm text-amber-400">1.0%</span>
            </div>
          </div>
        </div>

        {/* Agency Menu List */}
        <div className="bg-[#1f2633] rounded-2xl shadow-sm border border-slate-700/60 divide-y divide-slate-700/60 text-xs text-slate-200">
          <button
            onClick={() => setIsSubordinateModalOpen(true)}
            className="w-full p-3.5 flex items-center justify-between hover:bg-white/5 transition-colors text-left"
            id="agency-subordinate-data-btn"
          >
            <span className="font-medium">Subordinate team members</span>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
          <button
            onClick={() => setIsSubordinateModalOpen(true)}
            className="w-full p-3.5 flex items-center justify-between hover:bg-white/5 transition-colors text-left"
            id="agency-commission-details-btn"
          >
            <span className="font-medium">Multi-level referral breakdown</span>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        </div>
      </div>

      {/* Subordinate Data Modal */}
      <SubordinateDataModal
        isOpen={isSubordinateModalOpen}
        onClose={() => setIsSubordinateModalOpen(false)}
      />
    </div>
  );
};
