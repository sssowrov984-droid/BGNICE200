import React, { useState } from 'react';
import { ArrowLeft, ShieldCheck, History, ArrowDownToLine, ArrowUpFromLine } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface SafeViewProps {
  onBack: () => void;
}

export const SafeView: React.FC<SafeViewProps> = ({ onBack }) => {
  const { user, transferSafe, showToast } = useApp();
  const [modalType, setModalType] = useState<'Transfer In' | 'Transfer Out' | null>(null);
  const [amount, setAmount] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!modalType) return;
    const num = parseFloat(amount);
    if (isNaN(num) || num <= 0) {
      showToast('Please enter a valid amount', 'error');
      return;
    }
    setIsProcessing(true);
    const ok = await transferSafe(num, modalType);
    setIsProcessing(false);

    if (ok) {
      showToast(`Successfully processed ${modalType} of ৳${num}!`, 'success');
      setModalType(null);
      setAmount('');
    }
  };

  return (
    <div className="min-h-screen bg-[#f7f8fc] pb-24 text-slate-800 select-none">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-slate-100 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={onBack}
          className="p-1 -ml-1 text-slate-700 hover:text-slate-900 rounded-full"
          id="safe-back-btn"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-base font-bold text-slate-900">Safe Vault</h1>
        <button className="text-slate-500 hover:text-slate-800 p-1">
          <History className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* Banner Card (Screenshot 22) */}
        <div className="bg-[#29303d] border border-slate-700/80 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-[#2196f3]" />
            <span className="text-xs font-bold uppercase tracking-wider text-[#2196f3]">
              Financial Security
            </span>
          </div>

          <div className="mt-4 space-y-1">
            <div className="text-xs text-slate-300 font-medium">Interest rate 0.006% Daily</div>
            <div className="text-3xl font-black tracking-tight text-white">
              ৳{user?.safeBalance.toFixed(2) || '0.00'}
            </div>
            <div className="text-[11px] text-slate-400">
              Wallet balance: ৳{user?.balance.toFixed(2) || '0.00'}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3 mt-6">
            <button
              onClick={() => {
                setModalType('Transfer Out');
                setAmount('');
              }}
              className="py-2.5 rounded-xl text-xs font-bold text-white bg-white/10 hover:bg-white/20 border border-slate-600 shadow-xs flex items-center justify-center space-x-1 active:scale-95 transition-all"
              id="safe-transfer-out-btn"
            >
              <ArrowUpFromLine className="w-4 h-4" />
              <span>Transfer Out</span>
            </button>
            <button
              onClick={() => {
                setModalType('Transfer In');
                setAmount('');
              }}
              className="py-2.5 rounded-xl text-xs font-bold text-white bg-[#2196f3] hover:bg-[#1e88e5] shadow-md flex items-center justify-center space-x-1 active:scale-95 transition-all"
              id="safe-transfer-in-btn"
            >
              <ArrowDownToLine className="w-4 h-4" />
              <span>Transfer In</span>
            </button>
          </div>
        </div>

        {/* Notice Card */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 text-xs text-slate-500 space-y-1.5">
          <div className="font-bold text-slate-800">Rules & Interest Calculation</div>
          <p>• Interest is calculated daily and credited directly to your Safe balance.</p>
          <p>• Single purchase limit: ৳100 - ৳50,000.</p>
          <p>• Transfer in or transfer out at any time without fees.</p>
        </div>

        {/* Historical Records */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 space-y-3">
          <div className="text-xs font-bold text-slate-800">Historical records</div>
          <div className="text-center py-6 text-xs text-slate-400">
            No transfer records currently available.
          </div>
        </div>
      </div>

      {/* Transfer In / Out Modal */}
      {modalType && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm">{modalType} Safe</h3>
              <button onClick={() => setModalType(null)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleTransfer} className="space-y-4">
              <div>
                <label className="text-xs text-slate-500 font-medium block mb-1">
                  Amount to {modalType}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-[#2196f3] font-bold">৳</span>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="w-full pl-8 pr-16 py-2 rounded-xl border border-slate-200 text-sm font-bold focus:outline-none focus:border-[#2196f3]"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const max = modalType === 'Transfer In' ? user?.balance || 0 : user?.safeBalance || 0;
                      setAmount(max.toString());
                    }}
                    className="absolute right-3 top-2.5 text-xs font-bold text-[#2196f3]"
                  >
                    Max
                  </button>
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  Available:{' '}
                  {modalType === 'Transfer In'
                    ? `৳${user?.balance.toFixed(2)} (Wallet)`
                    : `৳${user?.safeBalance.toFixed(2)} (Safe)`}
                </div>
              </div>

              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-2.5 bg-[#2196f3] hover:bg-[#1e88e5] text-white font-bold rounded-xl text-xs shadow-md active:scale-95 disabled:opacity-50"
              >
                {isProcessing ? 'Processing...' : 'Confirm'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
