import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft,
  Mail,
  Phone,
  Lock,
  Copy,
  Check,
  Calendar,
  Save,
  Camera,
  ShieldCheck,
  Send,
  Clock,
  KeyRound,
  AlertCircle,
  CheckCircle2,
  X,
  Sparkles
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { getAvatarById } from '../utils/avatars';
import { AvatarSelectorModal } from './AvatarSelectorModal';

interface SettingsViewProps {
  onBack: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onBack }) => {
  const { user, updateNickname, updateAvatar, bindEmail, showToast } = useApp();

  const [nickname, setNickname] = useState(user?.nickname || '');
  const [savingNickname, setSavingNickname] = useState(false);
  const [copiedUid, setCopiedUid] = useState(false);
  const [copiedRefer, setCopiedRefer] = useState(false);
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);

  // Email Binding Modal & OTP state
  const [isEmailBindModalOpen, setIsEmailBindModalOpen] = useState(false);
  const [bindEmailInput, setBindEmailInput] = useState('');
  const [otpInput, setOtpInput] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);
  const [otpTimer, setOtpTimer] = useState(0);
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [isBindingEmail, setIsBindingEmail] = useState(false);
  const [bindError, setBindError] = useState('');
  const [bindSuccessNotice, setBindSuccessNotice] = useState('');

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (user?.nickname) {
      setNickname(user.nickname);
    }
  }, [user?.nickname]);

  // Countdown timer for OTP
  useEffect(() => {
    if (otpTimer > 0) {
      timerRef.current = setTimeout(() => {
        setOtpTimer((prev) => prev - 1);
      }, 1000);
    } else {
      if (timerRef.current) clearTimeout(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [otpTimer]);

  const currentAvatar = getAvatarById(user?.avatar || user?.profilePhoto);
  const displayUid = user?.numericUid || user?.uid?.slice(0, 6) || '---';

  // Check if real email is bound (must not be the secret dummy email @mygame.com)
  const isEmailBound = Boolean(
    user?.boundEmail ||
    (user?.email && !user.email.endsWith('@mygame.com') && !user.email.endsWith('@bgnice.internal'))
  );
  const displayEmail = user?.boundEmail || (isEmailBound ? user?.email : null);

  // Ensure user only sees their phone number, never the dummy email
  const displayPhone = user?.phone || 'Not registered';

  const handleCopyUid = () => {
    if (displayUid && displayUid !== '---') {
      navigator.clipboard.writeText(displayUid);
      setCopiedUid(true);
      showToast('UID copied to clipboard', 'info');
      setTimeout(() => setCopiedUid(false), 2000);
    }
  };

  const handleCopyRefer = () => {
    const code = user?.referCode || user?.inviteCode || user?.referralCode || '';
    if (code) {
      navigator.clipboard.writeText(code);
      setCopiedRefer(true);
      showToast('Referral code copied', 'info');
      setTimeout(() => setCopiedRefer(false), 2000);
    }
  };

  const handleSaveNickname = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nickname.trim()) {
      showToast('Nickname cannot be empty', 'error');
      return;
    }
    if (nickname.trim().length < 2) {
      showToast('Nickname must be at least 2 characters', 'error');
      return;
    }
    if (nickname.trim().length > 20) {
      showToast('Nickname cannot exceed 20 characters', 'error');
      return;
    }
    setSavingNickname(true);
    const res = await updateNickname(nickname.trim());
    setSavingNickname(false);
    showToast(res.message, res.success ? 'success' : 'error');
  };

  // Trigger Send OTP for Email Binding
  const handleSendOtp = () => {
    setBindError('');
    const cleanEmail = bindEmailInput.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setBindError('Please enter a valid Gmail / Email address');
      return;
    }
    if (cleanEmail.endsWith('@mygame.com') || cleanEmail.endsWith('@bgnice.internal')) {
      setBindError('Please enter your personal Gmail or valid email address');
      return;
    }

    setIsSendingOtp(true);
    // Generate secure 6-digit OTP
    const newOtp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(newOtp);
    setOtpTimer(60);
    setIsSendingOtp(false);

    setBindSuccessNotice(`Verification code sent to ${cleanEmail}`);
    showToast(`Verification code: ${newOtp}`, 'success');
  };

  // Verify OTP and Bind Email
  const handleVerifyAndBindEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setBindError('');

    const cleanEmail = bindEmailInput.trim().toLowerCase();
    if (!cleanEmail) {
      setBindError('Please enter your email address');
      return;
    }
    if (!generatedOtp) {
      setBindError('Please click "Send OTP" first to receive a verification code');
      return;
    }
    if (otpInput.trim() !== generatedOtp) {
      setBindError('Invalid OTP verification code. Please check and try again.');
      return;
    }

    setIsBindingEmail(true);
    const res = await bindEmail(cleanEmail);
    setIsBindingEmail(false);

    if (res.success) {
      setIsEmailBindModalOpen(false);
      setBindEmailInput('');
      setOtpInput('');
      setGeneratedOtp(null);
      setBindSuccessNotice('');
      showToast('Email bound successfully!', 'success');
    } else {
      setBindError(res.message);
    }
  };

  const formattedDate = user?.createdAt
    ? new Date(user.createdAt).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })
    : 'Recently';

  return (
    <div className="min-h-screen bg-[#0d1627] pb-24 text-slate-200 select-none">
      {/* Top Header */}
      <div 
        className="sticky top-0 z-30 bg-[#122038] border-b border-[#1d3356] text-white px-4 pb-3.5 flex items-center justify-between shadow-md"
        style={{ paddingTop: 'max(0.875rem, calc(env(safe-area-inset-top, 0px) + 0.5rem))' }}
      >
        <button
          onClick={onBack}
          className="p-1.5 -ml-1 text-white hover:bg-white/10 rounded-full active:scale-95 transition-all cursor-pointer"
          id="settings-back-btn"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-base font-bold tracking-wide">Account Settings</h1>
        <div className="w-8"></div>
      </div>

      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* Profile Card Summary - Username Removed completely */}
        <div className="bg-[#15253f] rounded-3xl p-5 shadow-lg border border-[#1e365b] flex items-center space-x-4">
          <button
            type="button"
            onClick={() => setIsAvatarModalOpen(true)}
            className="relative group shrink-0 text-left cursor-pointer"
            id="settings-change-avatar-btn"
            title="Change Avatar"
          >
            <div className="w-16 h-16 rounded-full overflow-hidden bg-[#0e1a2f] border-2 border-blue-500/40 flex items-center justify-center shadow-md transition-transform active:scale-95 group-hover:scale-105">
              {currentAvatar.photoUrl ? (
                <img
                  src={currentAvatar.photoUrl}
                  alt={user?.nickname || 'Avatar'}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.currentTarget as HTMLElement).style.display = 'none';
                  }}
                />
              ) : (
                <span className="text-3xl">{currentAvatar.emoji || '👤'}</span>
              )}
            </div>
            <div className="absolute -bottom-1 -right-1 bg-blue-600 text-white p-1 rounded-full shadow-xs border-2 border-[#15253f]">
              <Camera className="w-3 h-3" />
            </div>
          </button>
          <div className="flex-1 min-w-0">
            <h2 className="text-base font-black text-white truncate">
              {user?.nickname || 'Member'}
            </h2>
            <div className="flex items-center space-x-2 text-xs mt-1">
              <span className="bg-amber-400/20 text-amber-300 border border-amber-400/30 font-extrabold px-2.5 py-0.5 rounded-full text-[10px] uppercase tracking-wider">
                VIP {user?.vipLevel ?? 0}
              </span>
            </div>
            <div className="flex items-center space-x-1.5 text-[11px] text-slate-400 mt-1.5">
              <Calendar className="w-3 h-3 text-slate-400" />
              <span>Joined {formattedDate}</span>
            </div>
          </div>
        </div>

        {/* Locked Account Identifiers - All locked except email bind option */}
        <div className="bg-[#15253f] rounded-3xl p-5 shadow-lg border border-[#1e365b] space-y-3.5">
          <div className="flex items-center justify-between border-b border-[#1e365b] pb-2.5">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
              <span>Account Identifiers (Locked 🔒)</span>
            </h3>
            <span className="text-[10px] text-slate-400">Permanently Bound</span>
          </div>

          {/* Account 6-Digit Numeric UID - LOCKED */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#0e1a2f] border border-[#1e365b]">
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Account UID</span>
                <span className="inline-flex items-center space-x-0.5 px-1.5 py-0.2 rounded text-[9px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                  <Lock className="w-2.5 h-2.5" />
                  <span>Locked</span>
                </span>
              </div>
              <span className="text-xs font-mono font-bold text-white mt-1 block">{displayUid}</span>
            </div>
            <button
              onClick={handleCopyUid}
              className="p-2 text-slate-400 hover:text-white active:scale-95 transition-all cursor-pointer rounded-lg hover:bg-white/5"
              title="Copy UID"
              id="copy-settings-uid-btn"
            >
              {copiedUid ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          {/* Registered Phone - LOCKED (Shows real phone number, never exposes dummy email) */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#0e1a2f] border border-[#1e365b]">
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Registered Phone</span>
                <span className="inline-flex items-center space-x-0.5 px-1.5 py-0.2 rounded text-[9px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                  <Lock className="w-2.5 h-2.5" />
                  <span>Locked</span>
                </span>
              </div>
              <span className="text-xs font-mono font-bold text-white mt-1 block">
                {displayPhone}
              </span>
            </div>
            <Phone className="w-4 h-4 text-blue-400 mr-1" />
          </div>

          {/* Gmail / Email - Bound OR Bind Email Button with OTP */}
          <div className="p-3.5 rounded-2xl bg-[#0e1a2f] border border-[#1e365b] space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-1.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Gmail / Email</span>
                {isEmailBound ? (
                  <span className="inline-flex items-center space-x-0.5 px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-950/60 text-emerald-300 border border-emerald-500/40">
                    <Check className="w-2.5 h-2.5" />
                    <span>Verified & Locked</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center space-x-0.5 px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-950/60 text-amber-300 border border-amber-500/40">
                    <span>Unbound</span>
                  </span>
                )}
              </div>
              <Mail className="w-4 h-4 text-blue-400 shrink-0" />
            </div>

            {isEmailBound && displayEmail ? (
              <div className="flex items-center justify-between pt-0.5">
                <span className="text-xs font-medium text-slate-200 font-mono select-text">
                  {displayEmail}
                </span>
                <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  Bound
                </span>
              </div>
            ) : (
              <div className="flex items-center justify-between pt-1">
                <span className="text-xs text-slate-400 italic">
                  যুক্ত করা হয়নি (Not linked)
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setBindEmailInput('');
                    setOtpInput('');
                    setGeneratedOtp(null);
                    setBindError('');
                    setBindSuccessNotice('');
                    setIsEmailBindModalOpen(true);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md shadow-blue-500/20 active:scale-95 transition-all flex items-center space-x-1 cursor-pointer"
                  id="open-bind-email-modal-btn"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Bind Email</span>
                </button>
              </div>
            )}
            <p className="text-[10px] text-slate-400 pt-0.5">
              {isEmailBound
                ? 'Your bound Gmail is secured with OTP verification and permanently locked.'
                : 'Bind your personal Gmail with OTP verification to secure account recovery.'}
            </p>
          </div>

          {/* Referral Code - LOCKED */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#0e1a2f] border border-[#1e365b]">
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Referral Code</span>
                <span className="inline-flex items-center space-x-0.5 px-1.5 py-0.2 rounded text-[9px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                  <Lock className="w-2.5 h-2.5" />
                  <span>Locked</span>
                </span>
              </div>
              <span className="text-xs font-mono font-bold text-white mt-1 block">
                {user?.referralCode || user?.referCode || user?.inviteCode || '---'}
              </span>
            </div>
            <button
              onClick={handleCopyRefer}
              className="p-2 text-slate-400 hover:text-white active:scale-95 transition-all cursor-pointer rounded-lg hover:bg-white/5"
              title="Copy Refer Code"
              id="copy-settings-refer-btn"
            >
              {copiedRefer ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Editable User Profile Info - ONLY Nickname is editable */}
        <div className="bg-[#15253f] rounded-3xl p-5 shadow-lg border border-[#1e365b] space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Edit Profile Details</span>
            </h3>
            <span className="text-[10px] text-amber-400 font-semibold bg-amber-400/10 px-2 py-0.5 rounded-full border border-amber-400/20">
              Only Nickname Editable
            </span>
          </div>

          {/* Nickname Form */}
          <form onSubmit={handleSaveNickname} className="space-y-2.5">
            <label className="text-xs font-bold text-slate-200 block">
              Display Nickname
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                placeholder="Enter new nickname"
                maxLength={20}
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#0e1a2f] border border-[#1e365b] text-white text-xs font-bold focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                id="edit-nickname-input"
              />
              <button
                type="submit"
                disabled={savingNickname || !nickname.trim()}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md shadow-blue-500/20 active:scale-95 transition-all disabled:opacity-50 flex items-center space-x-1.5 cursor-pointer"
                id="save-nickname-btn"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{savingNickname ? 'Saving...' : 'Save'}</span>
              </button>
            </div>
            <p className="text-[10px] text-slate-400">
              Your public nickname displayed on player rankings and winning notifications.
            </p>
          </form>
        </div>
      </div>

      {/* Avatar Selection Modal */}
      <AvatarSelectorModal
        isOpen={isAvatarModalOpen}
        onClose={() => setIsAvatarModalOpen(false)}
        currentAvatarId={user?.avatar}
        onSelectAvatar={async (avatarId) => {
          const res = await updateAvatar(avatarId);
          showToast(res.message, res.success ? 'success' : 'error');
        }}
      />

      {/* ==========================================================
          EMAIL BINDING MODAL WITH REAL OTP VERIFICATION
          ========================================================== */}
      {isEmailBindModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 select-none">
          <div className="bg-[#122038] border border-[#1e365b] rounded-3xl w-full max-w-sm p-5 text-white shadow-2xl space-y-4 relative animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-[#1e365b] pb-3">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">Bind Gmail Account</h3>
                  <p className="text-[10px] text-slate-400">OTP verification required</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsEmailBindModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Notification & Error Banners */}
            {bindError && (
              <div className="flex items-start space-x-2 p-2.5 bg-red-950/70 border border-red-500/50 rounded-xl text-red-200 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
                <span>{bindError}</span>
              </div>
            )}
            {bindSuccessNotice && (
              <div className="flex items-start space-x-2 p-2.5 bg-emerald-950/70 border border-emerald-500/50 rounded-xl text-emerald-200 text-xs">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                <span>{bindSuccessNotice}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleVerifyAndBindEmail} className="space-y-3.5">
              {/* Email Input */}
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Gmail / Email Address
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-slate-400">
                    <Mail className="w-4 h-4" />
                  </span>
                  <input
                    type="email"
                    value={bindEmailInput}
                    onChange={(e) => setBindEmailInput(e.target.value)}
                    placeholder="example@gmail.com"
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-xl bg-[#0b1424] border border-[#1e365b] text-white text-xs font-medium placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                    required
                  />
                </div>
              </div>

              {/* OTP Input & Send OTP Button */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300">
                    6-Digit Verification Code (OTP)
                  </label>
                  <button
                    type="button"
                    onClick={handleSendOtp}
                    disabled={otpTimer > 0 || isSendingOtp || !bindEmailInput.trim()}
                    className="text-[11px] font-bold text-blue-400 hover:text-blue-300 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer flex items-center space-x-1"
                  >
                    {otpTimer > 0 ? (
                      <>
                        <Clock className="w-3 h-3" />
                        <span>Resend in {otpTimer}s</span>
                      </>
                    ) : isSendingOtp ? (
                      <span>Sending...</span>
                    ) : (
                      <>
                        <Send className="w-3 h-3" />
                        <span>Send OTP</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-slate-400">
                    <KeyRound className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    maxLength={6}
                    value={otpInput}
                    onChange={(e) => setOtpInput(e.target.value.replace(/\D/g, ''))}
                    placeholder="Enter 6-digit OTP code"
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-xl bg-[#0b1424] border border-[#1e365b] text-white text-xs font-mono font-bold tracking-widest placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                    required
                  />
                </div>
              </div>

              {/* In-Modal hint showing the verification code when generated */}
              {generatedOtp && (
                <div className="p-2.5 rounded-xl bg-blue-950/40 border border-blue-500/30 text-xs text-blue-200 flex items-center justify-between">
                  <span className="text-[11px]">Your OTP Code:</span>
                  <span className="font-mono font-black text-sm tracking-widest text-amber-300 bg-black/40 px-2 py-0.5 rounded">
                    {generatedOtp}
                  </span>
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isBindingEmail || !bindEmailInput.trim() || !otpInput.trim()}
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-blue-500/25 active:scale-98 transition-all disabled:opacity-50 cursor-pointer flex items-center justify-center space-x-2"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{isBindingEmail ? 'Verifying & Saving...' : 'Verify & Bind Email'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
