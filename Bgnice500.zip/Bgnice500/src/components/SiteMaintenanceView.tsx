import React, { useState } from 'react';
import { Wrench, Shield, RefreshCw, AlertTriangle, Sparkles, Clock, CheckCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { BrandLogo } from './BrandLogo';

interface SiteMaintenanceViewProps {
  onAdminLoginSuccess?: () => void;
}

export const SiteMaintenanceView: React.FC<SiteMaintenanceViewProps> = () => {
  const { settings, showToast } = useApp();
  const [isChecking, setIsChecking] = useState(false);

  const handleRefresh = () => {
    setIsChecking(true);
    showToast('Checking system server status...', 'info');
    setTimeout(() => {
      setIsChecking(false);
      window.location.reload();
    }, 1200);
  };

  const message = settings?.maintenanceMessage ||
    'BGNICE প্ল্যাটফর্মের সিস্টেম পারফরম্যান্স, সিকিউরিটি এবং সার্ভার আপগ্রেডেশনের জন্য সাময়িক রক্ষণাবেক্ষণ কাজ চলছে। খুব দ্রুত সার্ভিস পুনরায় স্বাভাবিক অবস্থায় ফিরিয়ে আনা হবে। সাময়িক অসুবিধার জন্য আমরা আন্তরিকভাবে দুঃখিত।';

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white flex flex-col items-center justify-between p-4 sm:p-6 select-none relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-600/15 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-amber-500/10 rounded-full blur-2xl pointer-events-none"></div>

      {/* Top Header */}
      <header className="w-full max-w-md mx-auto pt-6 flex items-center justify-between z-10">
        <BrandLogo className="h-8" />
        <div className="inline-flex items-center space-x-1.5 bg-red-500/10 border border-red-500/30 px-3 py-1 rounded-full text-red-400 text-xs font-bold">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
          <span>MAINTENANCE MODE</span>
        </div>
      </header>

      {/* Main Content Box */}
      <main className="w-full max-w-md mx-auto my-auto py-8 z-10 text-center space-y-6">
        {/* Animated Maintenance Icon Card */}
        <div className="relative mx-auto w-24 h-24 flex items-center justify-center">
          <div className="absolute inset-0 rounded-3xl bg-gradient-to-tr from-red-600 to-amber-500 opacity-20 animate-pulse blur-sm"></div>
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-red-600 to-amber-500 p-0.5 shadow-2xl shadow-red-600/30">
            <div className="w-full h-full bg-slate-900 rounded-[22px] flex items-center justify-center">
              <Wrench className="w-12 h-12 text-amber-400 animate-spin" style={{ animationDuration: '8s' }} />
            </div>
          </div>
          <div className="absolute -bottom-2 -right-2 p-1.5 rounded-xl bg-red-500 text-white shadow-md">
            <AlertTriangle className="w-4 h-4" />
          </div>
        </div>

        {/* Headlines */}
        <div className="space-y-2">
          <div className="inline-flex items-center space-x-1 text-amber-400 text-xs font-black uppercase tracking-widest">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Under Scheduled Maintenance</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-snug">
            সিস্টেম রক্ষণাবেক্ষণ চলছে
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 font-medium leading-relaxed px-2">
            {message}
          </p>
        </div>

        {/* Status Indicators */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 text-left space-y-3 shadow-xl">
          <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
            <span className="text-slate-400 flex items-center space-x-1.5 font-semibold">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Current Status</span>
            </span>
            <span className="text-amber-400 font-bold bg-amber-500/10 px-2.5 py-0.5 rounded-full border border-amber-500/20">
              Upgrading Core Engine
            </span>
          </div>

          <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
            <span className="text-slate-400 flex items-center space-x-1.5 font-semibold">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>User Balance & Data</span>
            </span>
            <span className="text-emerald-400 font-bold flex items-center space-x-1">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>100% Safe & Guaranteed</span>
            </span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-semibold">Estimated Reopening</span>
            <span className="text-white font-mono font-bold">Shortly / দ্রুততম সময়ে</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 pt-2">
          <button
            onClick={handleRefresh}
            disabled={isChecking}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-black text-sm shadow-lg shadow-red-600/30 flex items-center justify-center space-x-2 active:scale-98 transition-all cursor-pointer"
            id="maintenance-refresh-btn"
          >
            <RefreshCw className={`w-4 h-4 ${isChecking ? 'animate-spin' : ''}`} />
            <span>{isChecking ? 'সার্ভার চেক করা হচ্ছে...' : 'পুনরায় চেষ্টা করুন (Check Status)'}</span>
          </button>
        </div>
      </main>

      {/* Footer */}
      <footer className="w-full max-w-md mx-auto pb-6 text-center text-[11px] text-slate-500 z-10">
        <p>© 2026 BGNICE Platform. All Rights Reserved.</p>
        <p className="mt-0.5">Automated High-Speed Gaming & Entertainment Network</p>
      </footer>
    </div>
  );
};
