import React, { useEffect, useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import splashImg from '../assets/images/splash_tradebd_1789125006613.jpg';

interface SplashScreenProps {
  onComplete: () => void;
  duration?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete, duration = 2000 }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [progress, setProgress] = useState(0);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;
  const completedRef = useRef(false);

  const finishSplash = useCallback(() => {
    if (completedRef.current) return;
    completedRef.current = true;
    setIsVisible(false);
    setTimeout(() => {
      onCompleteRef.current();
    }, 200);
  }, []);

  useEffect(() => {
    // 1. Progress animation ticker
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(pct);
      if (pct >= 100) {
        clearInterval(interval);
      }
    }, 40);

    // 2. Primary auto-advance timer
    const primaryTimer = setTimeout(() => {
      finishSplash();
    }, duration);

    // 3. Absolute safety fallback timer to guarantee splash screen NEVER hangs or gets stuck
    const safetyTimer = setTimeout(() => {
      finishSplash();
    }, duration + 600);

    return () => {
      clearInterval(interval);
      clearTimeout(primaryTimer);
      clearTimeout(safetyTimer);
    };
  }, [duration, finishSplash]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 1 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25, ease: 'easeInOut' }}
          onClick={finishSplash}
          onTouchStart={finishSplash}
          className="fixed inset-0 z-[99999] w-screen h-screen min-h-screen flex items-center justify-center bg-[#fca2a7] cursor-pointer select-none overflow-hidden"
          id="tradebd-splash-screen"
          title="Click or tap to enter immediately"
        >
          {/* Top Skip Button - Guarantees the user is NEVER stuck */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              finishSplash();
            }}
            onTouchStart={(e) => {
              e.stopPropagation();
              finishSplash();
            }}
            className="absolute top-4 right-4 sm:top-6 sm:right-6 z-50 px-3.5 py-1.5 rounded-full bg-black/40 hover:bg-black/60 text-white text-xs font-black backdrop-blur-md border border-white/30 flex items-center space-x-1.5 shadow-xl active:scale-95 transition-all"
            id="splash-skip-btn"
          >
            <span>Skip</span>
            <span className="text-amber-300">✕</span>
          </button>

          {/* 
            Full 100% fit splash graphic without any empty letterbox bars
          */}
          <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
            <img
              src={(splashImg && splashImg.trim()) || '/splash.jpg'}
              alt="BGNICE - Pro Gaming Platform"
              className="w-full h-full object-cover select-none pointer-events-none"
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/splash.jpg';
              }}
            />

            {/* Bottom Progress Bar - visual indicator that loading is active & advancing */}
            <div className="absolute bottom-3 left-0 right-0 max-w-xs mx-auto px-6 flex flex-col items-center space-y-1.5 pointer-events-none">
              <div className="w-full bg-white/30 rounded-full h-1.5 overflow-hidden backdrop-blur-xs">
                <div
                  className="bg-white h-full rounded-full transition-all duration-75 ease-out shadow-sm"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <span className="text-[10px] text-white/90 font-bold tracking-wider uppercase font-mono">
                Loading... {progress}%
              </span>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};


