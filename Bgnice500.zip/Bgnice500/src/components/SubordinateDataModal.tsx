import React from 'react';
import { X, Users, Calendar, ShieldCheck, DollarSign } from 'lucide-react';
import { UserProfile, DepositItem } from '../types';
import { useApp } from '../context/AppContext';

interface SubordinateDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  referCode?: string;
  numericUid?: string;
  allUsers?: UserProfile[] | Record<string, UserProfile>;
  deposits?: DepositItem[];
}

export const SubordinateDataModal: React.FC<SubordinateDataModalProps> = ({
  isOpen,
  onClose,
  referCode: propReferCode,
  numericUid: propNumericUid,
  allUsers: propAllUsers,
  deposits: propDeposits
}) => {
  const context = useApp();

  const activeUser = context.user;
  const referCode = propReferCode || activeUser?.referCode || activeUser?.inviteCode;
  const numericUid = propNumericUid || activeUser?.numericUid;

  const rawUsers = propAllUsers || context?.allUsers || {};
  const usersList: UserProfile[] = Array.isArray(rawUsers)
    ? rawUsers
    : Object.values(rawUsers || {});

  const rawDeposits = propDeposits || context?.deposits || [];
  const depositsList: DepositItem[] = Array.isArray(rawDeposits)
    ? rawDeposits
    : Object.values(rawDeposits || {});

  // Calculate recursive multi-level subordinates
  const { allSubordinatesWithLevel, levelCounts } = React.useMemo(() => {
    if (!isOpen || !activeUser) return { allSubordinatesWithLevel: [], levelCounts: {} };

    const matchesParent = (child: UserProfile, parent: UserProfile) => {
      const ref = (child.referredBy || child.invitedBy || '').trim();
      if (!ref) return false;
      return (
        ref === (parent.referCode || '').trim() ||
        ref === (parent.numericUid || '').trim() ||
        ref === (parent.inviteCode || '').trim() ||
        ref === parent.uid
      );
    };

    const visitedUids = new Set<string>([activeUser.uid]);
    const result: Array<{ user: UserProfile; level: number }> = [];
    const counts: Record<number, number> = {};
    let currentParents: UserProfile[] = [activeUser];
    let level = 1;

    while (currentParents.length > 0 && level <= 10) {
      const nextLevelUsers: UserProfile[] = [];
      for (const parent of currentParents) {
        for (const candidate of usersList) {
          if (!visitedUids.has(candidate.uid) && matchesParent(candidate, parent)) {
            visitedUids.add(candidate.uid);
            nextLevelUsers.push(candidate);
            result.push({ user: candidate, level });
            counts[level] = (counts[level] || 0) + 1;
          }
        }
      }
      if (nextLevelUsers.length > 0) {
        currentParents = nextLevelUsers;
        level++;
      } else {
        break;
      }
    }

    return { allSubordinatesWithLevel: result, levelCounts: counts };
  }, [isOpen, activeUser, usersList]);

  const [activeLevelTab, setActiveLevelTab] = React.useState<number | 'all'>('all');

  const filteredSubordinates = React.useMemo(() => {
    if (activeLevelTab === 'all') return allSubordinatesWithLevel;
    return allSubordinatesWithLevel.filter((item) => item.level === activeLevelTab);
  }, [allSubordinatesWithLevel, activeLevelTab]);

  // Calculate 30-day deposit per subordinate
  const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl space-y-4 border border-slate-100 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-base font-black text-slate-900 flex items-center space-x-2">
              <Users className="w-4 h-4 text-[#2196f3]" />
              <span>Multi-Level Team Subordinates</span>
            </h3>
            <p className="text-[11px] text-slate-400">Recursive multi-level team network and commissions</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600"
            id="close-subordinate-modal-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Summary Header */}
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50/40 rounded-2xl p-3.5 border border-blue-100/60 flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-500 block text-[10px]">Total Team Members</span>
            <span className="text-xl font-extrabold text-[#2196f3]">{allSubordinatesWithLevel.length}</span>
          </div>
          <div className="text-right">
            <span className="text-slate-500 block text-[10px]">Multi-Tier Rates</span>
            <span className="text-xs font-black text-emerald-600">L1: 5% • L2: 2% • L3: 1% • L4+: 0.5%</span>
          </div>
        </div>

        {/* Level Filter Tabs */}
        <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar py-1">
          <button
            onClick={() => setActiveLevelTab('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeLevelTab === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All ({allSubordinatesWithLevel.length})
          </button>
          {[1, 2, 3].map((lvl) => (
            <button
              key={lvl}
              onClick={() => setActiveLevelTab(lvl)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                activeLevelTab === lvl
                  ? 'bg-[#2196f3] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Level {lvl} ({levelCounts[lvl] || 0})
            </button>
          ))}
        </div>

        {/* List of Subordinates */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
          {filteredSubordinates.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs space-y-2">
              <Users className="w-8 h-8 mx-auto opacity-40 text-slate-300" />
              <p>No subordinate members found in this tier.</p>
              <p className="text-[10px] text-slate-400">
                Share your invitation link to expand your recursive referral team!
              </p>
            </div>
          ) : (
            filteredSubordinates.map(({ user: sub, level: memberLevel }, subIdx: number) => {
              const subDeposits = depositsList.filter(
                (d) => d.uid === sub.uid && d.status === 'completed' && d.createdAt >= thirtyDaysAgo
              );
              const total30d = subDeposits.reduce((sum, d) => sum + d.amount, 0);

              const joinDate = sub.createdAt
                ? new Date(sub.createdAt).toLocaleDateString('en-GB', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric'
                  })
                : 'Recently';

              return (
                <div
                  key={`sub-${sub.uid || 's'}-${subIdx}`}
                  className="bg-slate-50 hover:bg-slate-100/80 rounded-2xl p-3 border border-slate-100 text-xs space-y-2 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono font-bold text-slate-900 text-sm">
                        UID: {sub.numericUid || sub.uid.slice(0, 6)}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-100 text-[#2196f3] border border-blue-200">
                        Level {memberLevel}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-slate-950">
                        VIP{sub.vipLevel ?? 0}
                      </span>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        sub.status === 'banned'
                          ? 'bg-red-100 text-red-600'
                          : 'bg-emerald-100 text-emerald-700'
                      }`}
                    >
                      {sub.status === 'banned' ? 'Suspended' : 'Active'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-500 pt-1 border-t border-slate-200/60">
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>Joined: {joinDate}</span>
                    </div>
                    <div className="flex items-center justify-end space-x-1 font-semibold text-slate-800">
                      <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
                      <span>30d Deposit: ৳{total30d.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
