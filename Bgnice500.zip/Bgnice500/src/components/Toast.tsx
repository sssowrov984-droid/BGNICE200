import React from 'react';

export interface ToastData {
  message: string;
  type: 'success' | 'error' | 'warning' | 'info' | 'refresh';
}

interface ToastProps {
  toast: ToastData | null;
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ toast }) => {
  if (!toast) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center pointer-events-none p-4 select-none animate-in fade-in zoom-in-95 duration-200">
      <div
        className="bg-[#2c3238]/95 text-white rounded-2xl px-6 py-3.5 flex items-center justify-center shadow-2xl border border-white/10 backdrop-blur-xs min-w-[160px] max-w-sm text-center"
        style={{
          boxShadow: '0 20px 40px -10px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.1)'
        }}
        id="app-center-toast"
      >
        <span className="text-sm font-semibold text-white tracking-wide leading-snug break-words">
          {toast.message}
        </span>
      </div>
    </div>
  );
};

