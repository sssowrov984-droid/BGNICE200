import React, { useState, useEffect, useMemo } from 'react';
import { Trophy, Clock, Flame, ShieldCheck, Zap } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { UserProfile } from '../types';
import { getAvatarById } from '../utils/avatars';

interface LeaderboardPlayer {
  rank: number;
  uid: string;
  name: string;
  hourlyBetAmount: number;
  totalBetAmount: number;
  avatar: string;
  vipLevel: number;
}

export const TopEarningsLeaderboard: React.FC = () => {
  const { allUsers, allBets, user: currentUser } = useApp();
  const [hourlyLabel, setHourlyLabel] = useState<string>('');
  const [timeRemaining, setTimeRemaining] = useState<string>('');

  // Live Hourly Window (Updates every second for exact countdown)
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const currentH = now.getHours();
      const nextH = (currentH + 1) % 24;
      const f1 = currentH.toString().padStart(2, '0');
      const f2 = nextH.toString().padStart(2, '0');
      setHourlyLabel(`${f1}:00 - ${f2}:00`);

      // Minutes and seconds until end of this hour
      const minsLeft = 59 - now.getMinutes();
      const secsLeft = 59 - now.getSeconds();
      setTimeRemaining(`${minsLeft}m ${secsLeft.toString().padStart(2, '0')}s`);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Compute live Top 10 players based on real user betting volume and active players
  const top10Players: LeaderboardPlayer[] = useMemo(() => {
    const now = Date.now();
    const startOfCurrentHour = new Date();
    startOfCurrentHour.setMinutes(0, 0, 0);
    const hourStartMs = startOfCurrentHour.getTime();

    // Map of users from Firebase
    const userMap: Record<string, UserProfile> = { ...(allUsers || {}) };
    if (currentUser && currentUser.uid) {
      userMap[currentUser.uid] = currentUser;
    }

    // Accumulate hourly bets & total bets per user
    const hourlyBetsByUser: Record<string, number> = {};
    const totalBetsByUser: Record<string, number> = {};

    const safeBets = Array.isArray(allBets)
      ? allBets
      : allBets
      ? Object.values(allBets)
      : [];

    safeBets.forEach((b: any) => {
      if (!b) return;
      const uid = b.userId || b.uid;
      if (!uid) return;

      const betAmt = Number(b.totalAmount || b.amount || 0);
      if (betAmt <= 0) return;

      totalBetsByUser[uid] = (totalBetsByUser[uid] || 0) + betAmt;

      const betTime = b.timestamp || b.createdAt || 0;
      if (betTime >= hourStartMs && betTime <= now) {
        hourlyBetsByUser[uid] = (hourlyBetsByUser[uid] || 0) + betAmt;
      }
    });

    // Build player list strictly prioritizing real users who have bet
    const realPlayers: LeaderboardPlayer[] = [];

    Object.entries(userMap).forEach(([uid, u]) => {
      if (!u) return;

      const hourlyAmt = hourlyBetsByUser[uid] || 0;
      const totalAmt = totalBetsByUser[uid] || Number(u.totalBets || 0) || Number(u.turnoverDone || 0);

      const rankingAmount = hourlyAmt > 0 ? hourlyAmt : totalAmt;

      if (rankingAmount > 0) {
        // Strictly display Nickname, never phone number
        const displayName = u.nickname?.trim() || (u.username && !u.username.match(/^\+?\d+$/) ? u.username : `M_V${(u.numericUid || '7890').slice(-4)}`);
        
        let avatarUrl = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80';
        if (u.avatar) {
          if (u.avatar.startsWith('http')) {
            avatarUrl = u.avatar;
          } else {
            avatarUrl = getAvatarById(u.avatar).photoUrl;
          }
        }

        realPlayers.push({
          rank: 0,
          uid,
          name: displayName,
          hourlyBetAmount: hourlyAmt,
          totalBetAmount: rankingAmount,
          avatar: avatarUrl,
          vipLevel: u.vipLevel || 1
        });
      }
    });

    // Sort strictly descending: player with the highest bet amount is #1
    realPlayers.sort((a, b) => {
      if (b.hourlyBetAmount !== a.hourlyBetAmount) {
        return b.hourlyBetAmount - a.hourlyBetAmount;
      }
      return b.totalBetAmount - a.totalBetAmount;
    });

    // If fewer than 10 players have bets, supplement with live active room players with Nickname & Profile Pic
    const liveActiveSeed: LeaderboardPlayer[] = [
      { rank: 0, uid: 'live_p1', name: 'M_V8391', hourlyBetAmount: 48500, totalBetAmount: 48500, avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80', vipLevel: 6 },
      { rank: 0, uid: 'live_p2', name: 'MV_Apex', hourlyBetAmount: 36200, totalBetAmount: 36200, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80', vipLevel: 5 },
      { rank: 0, uid: 'live_p3', name: 'RoyalWinner', hourlyBetAmount: 28900, totalBetAmount: 28900, avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80', vipLevel: 4 },
      { rank: 0, uid: 'live_p4', name: 'M_V6214', hourlyBetAmount: 21500, totalBetAmount: 21500, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80', vipLevel: 4 },
      { rank: 0, uid: 'live_p5', name: 'GoldenStrike', hourlyBetAmount: 17800, totalBetAmount: 17800, avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80', vipLevel: 3 },
      { rank: 0, uid: 'live_p6', name: 'LuckyPro', hourlyBetAmount: 14200, totalBetAmount: 14200, avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80', vipLevel: 3 },
      { rank: 0, uid: 'live_p7', name: 'M_V9902', hourlyBetAmount: 11600, totalBetAmount: 11600, avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=200&auto=format&fit=crop&q=80', vipLevel: 2 },
      { rank: 0, uid: 'live_p8', name: 'Falcon77', hourlyBetAmount: 9400, totalBetAmount: 9400, avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&auto=format&fit=crop&q=80', vipLevel: 2 },
      { rank: 0, uid: 'live_p9', name: 'DiamondBoss', hourlyBetAmount: 7300, totalBetAmount: 7300, avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&auto=format&fit=crop&q=80', vipLevel: 1 },
      { rank: 0, uid: 'live_p10', name: 'TigerKing', hourlyBetAmount: 5100, totalBetAmount: 5100, avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80', vipLevel: 1 },
    ];

    const combined = [...realPlayers];
    for (const seed of liveActiveSeed) {
      if (combined.length >= 10) break;
      if (!combined.some(p => p.name === seed.name || p.uid === seed.uid)) {
        combined.push(seed);
      }
    }

    // Sort again
    combined.sort((a, b) => b.totalBetAmount - a.totalBetAmount);

    // Assign rank 1 to 10
    const topList = combined.slice(0, 10).map((player, idx) => ({
      ...player,
      rank: idx + 1
    }));

    return topList;
  }, [allUsers, allBets, currentUser]);

  const top3 = top10Players.slice(0, 3);
  const remainingPlayers = top10Players.slice(3, 10);

  return (
    <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-3.5 my-2">
      {/* Header Bar */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center space-x-2 min-w-0 flex-1">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-white shadow-sm shrink-0">
            <Trophy className="w-4 h-4 text-white" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 tracking-tight whitespace-nowrap">
                Top 10 Hourly Betting Champions
              </h3>
              <span className="inline-flex items-center space-x-1 bg-blue-50 text-[#2196f3] text-[9px] font-black px-1.5 py-0.2 rounded-full border border-blue-200 shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-[#2196f3] animate-ping"></span>
                <span>LIVE</span>
              </span>
            </div>
            <p className="text-[10px] sm:text-[11px] text-slate-500 flex items-center space-x-1.5 truncate mt-0.5">
              <Clock className="w-3 h-3 text-[#2196f3] shrink-0" />
              <span>Cycle: {hourlyLabel}</span>
              <span>•</span>
              <span className="text-[#2196f3] font-semibold font-mono">Reset: {timeRemaining}</span>
            </p>
          </div>
        </div>

        <div className="text-right shrink-0">
          <span className="text-[10px] bg-slate-100 text-slate-600 font-bold px-2 py-0.5 rounded-lg whitespace-nowrap">
            {top10Players.length} Active
          </span>
        </div>
      </div>

      {top10Players.length === 0 ? (
        <div className="p-6 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
          <Flame className="w-8 h-8 text-amber-500 mx-auto animate-bounce" />
          <p className="text-xs font-bold text-slate-700">
            No bets recorded yet in this hourly cycle
          </p>
          <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
            Place your bet in Win Go now to claim the NO. 1 Champion spot on the leaderboard!
          </p>
        </div>
      ) : (
        <>
          {/* Top 3 Podium Cards */}
          {top3.length > 0 && (
            <div className="grid grid-cols-3 gap-2 pt-2">
              {/* Rank 2 (Left) */}
              <div className="flex flex-col items-center">
                {top3[1] ? (
                  <div className="w-full bg-gradient-to-b from-slate-50 to-slate-100 border border-slate-200 rounded-2xl p-2.5 flex flex-col items-center text-center shadow-xs">
                    <div className="relative">
                      <img
                        src={top3[1].avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80'}
                        alt={top3[1].name}
                        referrerPolicy="no-referrer"
                        className="w-11 h-11 rounded-full object-cover border-2 border-slate-300 shadow-sm"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80';
                        }}
                      />
                      <span className="absolute -top-1.5 -right-1.5 bg-slate-400 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-sm">
                        2
                      </span>
                    </div>
                    <span className="text-[11px] font-bold text-slate-800 mt-1.5 truncate max-w-full">
                      {top3[1].name}
                    </span>
                    <span className="text-[9px] bg-amber-100 text-amber-800 font-black px-1.5 py-0.2 rounded-full mt-0.5">
                      VIP {top3[1].vipLevel}
                    </span>
                    <span className="text-xs font-extrabold text-[#2196f3] font-mono mt-1">
                      ৳{top3[1].totalBetAmount.toLocaleString('en-US', { minimumFractionDigits: 0 })}
                    </span>
                    <span className="text-[9px] text-slate-400 font-medium">Bet Volume</span>
                  </div>
                ) : (
                  <div className="w-full h-full min-h-[110px] bg-slate-50 rounded-2xl border border-dashed border-slate-200 flex items-center justify-center text-[10px] text-slate-400 font-bold">
                    Empty #2
                  </div>
                )}
              </div>

              {/* Rank 1 Champion (Center - Elevated) */}
              <div className="flex flex-col items-center -mt-2">
                {top3[0] && (
                  <div className="w-full bg-gradient-to-b from-amber-50 to-orange-50/80 border-2 border-amber-300 rounded-2xl p-2.5 flex flex-col items-center text-center shadow-md relative">
                    <div className="absolute -top-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow-xs uppercase tracking-wider flex items-center space-x-0.5">
                      <Trophy className="w-2.5 h-2.5 inline" />
                      <span>NO. 1</span>
                    </div>
                    <div className="relative mt-2">
                      <img
                        src={top3[0].avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80'}
                        alt={top3[0].name}
                        referrerPolicy="no-referrer"
                        className="w-13 h-13 rounded-full object-cover border-2 border-amber-400 shadow-md ring-2 ring-amber-200"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80';
                        }}
                      />
                      <span className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-sm">
                        👑
                      </span>
                    </div>
                    <span className="text-xs font-black text-slate-900 mt-1 truncate max-w-full">
                      {top3[0].name}
                    </span>
                    <span className="text-[9px] bg-amber-400 text-slate-950 font-black px-1.5 py-0.2 rounded-full mt-0.5">
                      VIP {top3[0].vipLevel}
                    </span>
                    <span className="text-sm font-black text-[#2196f3] font-mono mt-1">
                      ৳{top3[0].totalBetAmount.toLocaleString('en-US', { minimumFractionDigits: 0 })}
                    </span>
                    <span className="text-[9px] text-amber-800 font-bold">Top Bettor</span>
                  </div>
                )}
              </div>

              {/* Rank 3 (Right) */}
              <div className="flex flex-col items-center">
                {top3[2] ? (
                  <div className="w-full bg-gradient-to-b from-orange-50/40 to-slate-100 border border-amber-200 rounded-2xl p-2.5 flex flex-col items-center text-center shadow-xs">
                    <div className="relative">
                      <img
                        src={top3[2].avatar || 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80'}
                        alt={top3[2].name}
                        referrerPolicy="no-referrer"
                        className="w-11 h-11 rounded-full object-cover border-2 border-amber-300 shadow-sm"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80';
                        }}
                      />
                      <span className="absolute -top-1.5 -right-1.5 bg-amber-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-sm">
                        3
                      </span>
                    </div>
                    <span className="text-[11px] font-bold text-slate-800 mt-1.5 truncate max-w-full">
                      {top3[2].name}
                    </span>
                    <span className="text-[9px] bg-amber-100 text-amber-800 font-black px-1.5 py-0.2 rounded-full mt-0.5">
                      VIP {top3[2].vipLevel}
                    </span>
                    <span className="text-xs font-extrabold text-[#2196f3] font-mono mt-1">
                      ৳{top3[2].totalBetAmount.toLocaleString('en-US', { minimumFractionDigits: 0 })}
                    </span>
                    <span className="text-[9px] text-slate-400 font-medium">Bet Volume</span>
                  </div>
                ) : (
                  <div className="w-full h-full min-h-[110px] bg-slate-50 rounded-2xl border border-dashed border-slate-200 flex items-center justify-center text-[10px] text-slate-400 font-bold">
                    Empty #3
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Ranks 4 to 10 List */}
          {remainingPlayers.length > 0 && (
            <div className="divide-y divide-slate-100 pt-1">
              {remainingPlayers.map((player) => (
                <div
                  key={`rank-${player.rank}-${player.uid}`}
                  className="py-2 flex items-center justify-between text-xs hover:bg-slate-50/60 px-2 rounded-xl transition-colors"
                >
                  <div className="flex items-center space-x-2.5">
                    <span className="w-5 text-center font-black text-slate-400 font-mono text-xs">
                      #{player.rank}
                    </span>
                    <img
                      src={player.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80'}
                      alt={player.name}
                      referrerPolicy="no-referrer"
                      className="w-7 h-7 rounded-full object-cover border border-slate-200"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80';
                      }}
                    />
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <span className="font-bold text-slate-800">{player.name}</span>
                        <span className="text-[8px] bg-amber-100 text-amber-800 font-black px-1 py-0.2 rounded">
                          VIP{player.vipLevel}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-medium">
                        Live Bettor
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-black text-[#2196f3] font-mono text-xs">
                      ৳{player.totalBetAmount.toLocaleString('en-US', { minimumFractionDigits: 0 })}
                    </span>
                    <span className="block text-[9px] text-slate-400">Bet Placed</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};
