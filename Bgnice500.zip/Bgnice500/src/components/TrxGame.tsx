import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  ArrowLeft,
  RefreshCw,
  Clock,
  Volume2,
  VolumeX,
  Headphones,
  Check,
  ExternalLink,
  ShieldCheck,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ref, get, set, update, push } from 'firebase/database';
import { rtdb } from '../lib/firebase';
import { BrandLogo } from './BrandLogo';
import { GameResultModal } from './GameResultModal';
import confetti from 'canvas-confetti';

interface TrxGameProps {
  onDepositClick: () => void;
  onWithdrawClick: () => void;
  onBack: () => void;
}

type TrxTimerType = '1m' | '3m' | '5m' | '10m';

interface TrxHistoryItem {
  periodId: string;
  blockHeight: number;
  blockTime: string;
  hash: string;
  lastChars: string[];
  winningNumber: number;
  color: 'green' | 'red' | 'violet' | 'green-violet' | 'red-violet';
  size: 'Big' | 'Small';
  timestamp: number;
}

interface TrxBetItem {
  id: string;
  uid: string;
  periodId: string;
  timerType: TrxTimerType;
  selectType: 'color' | 'number' | 'size';
  selectValue: string;
  multiplierRate: number;
  baseAmount: number;
  multiplier: number;
  totalAmount: number;
  status: 'pending' | 'won' | 'lost';
  winAmount?: number;
  winningNumber?: number;
  createdAt: number;
}

export const TrxGame: React.FC<TrxGameProps> = ({ onDepositClick, onWithdrawClick, onBack }) => {
  const { user, refreshBalance, isRefreshingBalance, settings, lastWinModal, setLastWinModal, closeWinModal } = useApp();

  const [timerType, setTimerType] = useState<TrxTimerType>('1m');
  const [activeSubTab, setActiveSubTab] = useState<'history' | 'chart' | 'myBets'>('history');

  // Pagination states
  const [historyPage, setHistoryPage] = useState(1);
  const [chartPage, setChartPage] = useState(1);
  const [myBetsPage, setMyBetsPage] = useState(1);
  const pageSize = 10;

  // Sound
  const [soundEnabled, setSoundEnabled] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const playBeep = (freq = 600, duration = 0.1) => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        const AudioClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioClass) audioCtxRef.current = new AudioClass();
      }
      const ctx = audioCtxRef.current;
      if (ctx) {
        if (ctx.state === 'suspended') ctx.resume().catch(() => {});
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + duration);
      }
    } catch {}
  };

  const cycleSeconds = timerType === '1m' ? 60 : timerType === '3m' ? 180 : timerType === '5m' ? 300 : 600;
  const [timeLeft, setTimeLeft] = useState(60);
  const [periodId, setPeriodId] = useState('');

  const [history, setHistory] = useState<TrxHistoryItem[]>([]);
  const [myBets, setMyBets] = useState<TrxBetItem[]>([]);

  // Bet Modal
  const [isBetSheetOpen, setIsBetSheetOpen] = useState(false);
  const [selectedBet, setSelectedBet] = useState<{
    type: 'color' | 'number' | 'size';
    label: string;
    value: string;
    rate: number;
    bg: string;
  }>({
    type: 'size',
    label: 'Big',
    value: 'big',
    rate: 2.0,
    bg: '#f59e0b'
  });

  const [baseBalance, setBaseBalance] = useState<number>(1);
  const [quantityInput, setQuantityInput] = useState<string>('1');
  const [multiplier, setMultiplier] = useState<number>(1);
  const [agreeRules, setAgreeRules] = useState<boolean>(true);
  const [isPlacing, setIsPlacing] = useState(false);

  const parsedQuantity = Math.max(1, parseInt(quantityInput, 10) || 1);
  const totalBetAmount = baseBalance * parsedQuantity * multiplier;

  const generateTrxPeriod = (type: TrxTimerType) => {
    const d = new Date();
    const YYYY = d.getFullYear();
    const MM = String(d.getMonth() + 1).padStart(2, '0');
    const DD = String(d.getDate()).padStart(2, '0');
    const totalSecs = d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds();
    const cycle = type === '1m' ? 60 : type === '3m' ? 180 : type === '5m' ? 300 : 600;
    const periodSeq = String(Math.floor(totalSecs / cycle) + 1).padStart(4, '0');
    const prefix = type === '1m' ? '30' : type === '3m' ? '60' : type === '5m' ? '90' : '300';
    return `${YYYY}${MM}${DD}${prefix}${periodSeq}`;
  };

  const getNumberColor = (num: number) => {
    if (num === 0) return 'red-violet';
    if (num === 5) return 'green-violet';
    if ([1, 3, 7, 9].includes(num)) return 'green';
    return 'red';
  };

  // Initial fetch
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
    const currentP = generateTrxPeriod(timerType);
    setPeriodId(currentP);

    const histRef = ref(rtdb, `trx_history/${timerType}`);
    get(histRef).then((snap) => {
      if (snap.exists()) {
        const data = snap.val();
        const list: TrxHistoryItem[] = Object.values(data);
        list.sort((a, b) => b.timestamp - a.timestamp);
        setHistory(list.slice(0, 30));
      } else {
        const initialList: TrxHistoryItem[] = [];
        const baseTime = Date.now();
        let baseHeight = 65421890;
        for (let i = 0; i < 20; i++) {
          const num = Math.floor(Math.random() * 10);
          const pId = `${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}${String(new Date().getDate()).padStart(2, '0')}30${String(1000 - i).padStart(4, '0')}`;
          const hexRandom = Math.random().toString(16).substring(2, 6).toUpperCase();
          const last5 = [...hexRandom.split(''), String(num)];
          initialList.push({
            periodId: pId,
            blockHeight: baseHeight - i * 20,
            blockTime: new Date(baseTime - i * cycleSeconds * 1000).toTimeString().substring(0, 8),
            hash: `0000000003b8e${hexRandom}${num}`,
            lastChars: last5,
            winningNumber: num,
            color: getNumberColor(num),
            size: num >= 5 ? 'Big' : 'Small',
            timestamp: baseTime - i * cycleSeconds * 1000
          });
        }
        setHistory(initialList);
      }
    }).catch(() => {});
  }, [timerType, cycleSeconds]);

  // Fetch my bets
  useEffect(() => {
    if (!user) return;
    const betsRef = ref(rtdb, 'trx_bets');
    get(betsRef).then((snap) => {
      if (snap.exists()) {
        const allBets = snap.val();
        const list: TrxBetItem[] = Object.entries(allBets)
          .map(([id, b]: [string, any]) => ({ ...b, id }))
          .filter((b) => b.uid === user.uid)
          .sort((a, b) => b.createdAt - a.createdAt);
        setMyBets(list.slice(0, 30));
      }
    }).catch(() => {});
  }, [user]);

  // Resolve TRX round
  const resolveTrxRound = async (expPeriod: string, expType: TrxTimerType) => {
    try {
      let winNum = Math.floor(Math.random() * 10);
      const forced = settings?.gameControls?.trxWinningNumber;
      if (typeof forced === 'number' && forced >= 0 && forced <= 9) {
        winNum = forced;
      }

      const hexPart = Math.random().toString(16).substring(2, 6).toUpperCase();
      const lastChars = [...hexPart.split(''), String(winNum)];
      const blockHeight = 65421890 + Math.floor(Date.now() / 10000);
      const blockTime = new Date().toTimeString().substring(0, 8);
      const color = getNumberColor(winNum);
      const size = winNum >= 5 ? 'Big' : 'Small';

      const historyEntry: TrxHistoryItem = {
        periodId: expPeriod,
        blockHeight,
        blockTime,
        hash: `0000000003b8e${hexPart}${winNum}`,
        lastChars,
        winningNumber: winNum,
        color,
        size,
        timestamp: Date.now()
      };

      await set(ref(rtdb, `trx_history/${expType}/${expPeriod}`), historyEntry).catch(() => {});
      setHistory((prev) => [historyEntry, ...prev.slice(0, 29)]);

      // Evaluate bets
      const betsSnap = await get(ref(rtdb, 'trx_bets'));
      if (betsSnap.exists()) {
        const allBets = betsSnap.val();
        let totalWin = 0;
        let totalUserBet = 0;
        let userHadWon = false;
        let userHadBet = false;

        for (const [k, bet] of Object.entries<TrxBetItem>(allBets)) {
          if (bet.periodId === expPeriod && bet.timerType === expType && bet.status === 'pending') {
            if (user && bet.uid === user.uid) {
              userHadBet = true;
              totalUserBet += bet.totalAmount;
            }

            let isWin = false;

            if (bet.selectType === 'size') {
              if (bet.selectValue === 'big' && winNum >= 5) isWin = true;
              else if (bet.selectValue === 'small' && winNum <= 4) isWin = true;
            } else if (bet.selectType === 'color') {
              if (bet.selectValue === 'green' && (color === 'green' || color === 'green-violet')) isWin = true;
              else if (bet.selectValue === 'red' && (color === 'red' || color === 'red-violet')) isWin = true;
              else if (bet.selectValue === 'violet' && (color === 'green-violet' || color === 'red-violet')) isWin = true;
            } else if (bet.selectType === 'number') {
              if (bet.selectValue === String(winNum)) isWin = true;
            }

            const winAmt = isWin ? Number((bet.totalAmount * bet.multiplierRate).toFixed(2)) : 0;
            const newStatus = isWin ? 'won' : 'lost';

            await update(ref(rtdb, `trx_bets/${k}`), {
              status: newStatus,
              winAmount: winAmt,
              winningNumber: winNum
            });

            if (isWin && winAmt > 0) {
              const uSnap = await get(ref(rtdb, `users/${bet.uid}`));
              if (uSnap.exists()) {
                const uData = uSnap.val();
                const curB = Number(uData.balance || 0);
                const newB = Number((curB + winAmt).toFixed(2));
                const totWon = Number((Number(uData.totalWon || 0) + winAmt).toFixed(2));
                await update(ref(rtdb, `users/${bet.uid}`), { balance: newB, totalWon: totWon });
              }
              if (user && bet.uid === user.uid) {
                totalWin += winAmt;
                userHadWon = true;
              }
            }
          }
        }

        const durLabel = expType === '1m' ? '1Min' : expType === '3m' ? '3Min' : expType === '5m' ? '5Min' : '10Min';

        if (userHadWon && totalWin > 0) {
          try {
            confetti({ particleCount: 90, spread: 75, origin: { y: 0.6 } });
          } catch {}
          const curBal = Number(user?.balance || 0);
          setLastWinModal({
            win: true,
            amount: totalWin,
            period: expPeriod,
            gameName: 'TRX Win',
            duration: durLabel,
            resultNumber: winNum,
            resultBigSmall: size as 'Big' | 'Small',
            resultColor: color as any,
            previousBalance: Number(Math.max(0, curBal - totalWin).toFixed(2)),
            newBalance: curBal
          });
          refreshBalance();
        } else if (userHadBet && totalUserBet > 0) {
          const curBal = Number(user?.balance || 0);
          setLastWinModal({
            win: false,
            amount: totalUserBet,
            period: expPeriod,
            gameName: 'TRX Win',
            duration: durLabel,
            resultNumber: winNum,
            resultBigSmall: size as 'Big' | 'Small',
            resultColor: color as any,
            previousBalance: Number((curBal + totalUserBet).toFixed(2)),
            newBalance: curBal
          });
        }

        if (user) {
          const freshSnap = await get(ref(rtdb, 'trx_bets'));
          if (freshSnap.exists()) {
            const list: TrxBetItem[] = Object.entries(freshSnap.val())
              .map(([id, b]: [string, any]) => ({ ...b, id }))
              .filter((b) => b.uid === user.uid)
              .sort((a, b) => b.createdAt - a.createdAt);
            setMyBets(list.slice(0, 30));
          }
        }
      }
    } catch (err) {
      console.error('TRX round resolution error:', err);
    }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      const now = Math.floor(Date.now() / 1000);
      const rem = cycleSeconds - (now % cycleSeconds);
      setTimeLeft(rem);

      const expPeriod = generateTrxPeriod(timerType);
      setPeriodId(expPeriod);

      if (rem <= 5 && rem > 0) {
        playBeep(rem === 1 ? 880 : 520, 0.12);
      }

      if (rem === 1) {
        resolveTrxRound(expPeriod, timerType);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [timerType, cycleSeconds]);

  const latestResult = useMemo(() => {
    return history[0] || {
      periodId: '20260914103010612',
      blockHeight: 65421890,
      blockTime: '10:30:10',
      hash: '0000000003b8e2676',
      lastChars: ['E', '2', '6', '7', '6'],
      winningNumber: 6,
      color: 'red',
      size: 'Big'
    };
  }, [history]);

  const handleOpenBet = (
    type: 'color' | 'number' | 'size',
    label: string,
    value: string,
    rate: number,
    bg: string
  ) => {
    setSelectedBet({ type, label, value, rate, bg });
    setBaseBalance(1);
    setQuantityInput('1');
    setMultiplier(1);
    setIsBetSheetOpen(true);
  };

  const handleConfirmBet = async () => {
    if (!user) return;
    if (!agreeRules) {
      alert('Please agree to the pre-sale rules');
      return;
    }
    if (user.balance < totalBetAmount) {
      alert('Insufficient wallet balance. Please deposit funds to continue.');
      return;
    }

    try {
      setIsPlacing(true);
      const currentBal = Number(user.balance || 0);
      const updatedBal = Number((currentBal - totalBetAmount).toFixed(2));
      const curLoss = Number(user.totalLoss || 0);

      await update(ref(rtdb, `users/${user.uid}`), {
        balance: updatedBal,
        totalLoss: curLoss + totalBetAmount
      });

      const betData: Omit<TrxBetItem, 'id'> = {
        uid: user.uid,
        periodId,
        timerType,
        selectType: selectedBet.type,
        selectValue: selectedBet.value,
        multiplierRate: selectedBet.rate,
        baseAmount: baseBalance * parsedQuantity,
        multiplier,
        totalAmount: totalBetAmount,
        status: 'pending',
        createdAt: Date.now()
      };

      const newRef = push(ref(rtdb, 'trx_bets'));
      await set(newRef, betData);

      setIsBetSheetOpen(false);
      refreshBalance();

      setMyBets((prev) => [{ ...betData, id: newRef.key || String(Date.now()) }, ...prev]);
    } catch (err) {
      console.error('TRX Bet placement error:', err);
    } finally {
      setIsPlacing(false);
    }
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const minStr = String(minutes).padStart(2, '0');
  const secStr = String(seconds).padStart(2, '0');

  return (
    <div className="min-h-screen bg-[#f7f8fc] pb-20 text-slate-800 select-none">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-[#29303d] border-b border-slate-700/40 text-white px-3.5 py-2.5 flex items-center justify-between shadow-md">
        <div className="flex items-center space-x-2">
          <button
            onClick={onBack}
            className="p-1 hover:bg-white/10 rounded-full active:scale-95 transition-transform"
            id="trx-back-btn"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
          </button>
          <BrandLogo variant="white" size="sm" />
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-1 hover:bg-white/10 rounded-full"
            id="trx-sound-toggle-btn"
          >
            {soundEnabled ? <Volume2 className="w-5 h-5 text-amber-200" /> : <VolumeX className="w-5 h-5 text-white/70" />}
          </button>
          <button
            onClick={() => window.location.hash = 'support'}
            className="p-1 hover:bg-white/10 rounded-full"
            id="trx-support-btn"
          >
            <Headphones className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="p-3 space-y-3">
        {/* Balance Card */}
        <div className="bg-gradient-to-r from-[#ff5447] via-[#ff4343] to-[#ff2f2f] rounded-2xl p-4 text-white shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-black tracking-tight">
                  ৳{Number(user?.balance || 0).toFixed(2)}
                </span>
                <button
                  onClick={refreshBalance}
                  className={`p-1 hover:bg-white/20 rounded-full active:rotate-180 transition-all ${
                    isRefreshingBalance ? 'animate-spin' : ''
                  }`}
                  id="trx-refresh-balance-btn"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
              <span className="text-xs text-white/80 font-medium mt-0.5 block">Wallet balance</span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={onWithdrawClick}
                className="px-3.5 py-1.5 rounded-full border border-white/80 text-xs font-bold hover:bg-white/10 active:scale-95 transition-all shadow-xs"
                id="trx-withdraw-btn"
              >
                Withdraw
              </button>
              <button
                onClick={onDepositClick}
                className="px-4 py-1.5 rounded-full bg-white text-[#ff3a3a] text-xs font-black hover:bg-amber-50 active:scale-95 transition-all shadow-md"
                id="trx-deposit-btn"
              >
                Deposit
              </button>
            </div>
          </div>

          <div className="mt-3.5 pt-2.5 border-t border-white/20 flex items-center justify-between text-xs text-white/90">
            <div className="flex items-center space-x-2 truncate">
              <Volume2 className="w-4 h-4 text-amber-300 shrink-0 animate-pulse" />
              <span className="truncate text-[11px] font-medium">
                {settings.platformAnnouncement || 'Official 24/7 instant deposit and withdrawal services'}
              </span>
            </div>
            <button
              onClick={() => alert('TRX WinGo uses Tron Public Blockchain hash to determine 100% fair and verifiable lottery numbers.')}
              className="ml-2 px-2 py-0.5 rounded-full bg-white/25 text-[10px] font-bold text-white shrink-0 hover:bg-white/35"
              id="trx-detail-btn"
            >
              Detail
            </button>
          </div>
        </div>

        {/* TrxWinGo Timer Tabs */}
        <div className="grid grid-cols-4 gap-1.5 bg-white p-1.5 rounded-2xl shadow-xs border border-slate-100">
          {(['1m', '3m', '5m', '10m'] as TrxTimerType[]).map((t) => {
            const isSel = timerType === t;
            const label = t === '1m' ? 'Trx 1 Min' : t === '3m' ? 'Trx 3 Min' : t === '5m' ? 'Trx 5 Min' : 'Trx 10 Min';
            return (
              <button
                key={t}
                onClick={() => setTimerType(t)}
                className={`py-2 px-1 rounded-xl flex flex-col items-center justify-center transition-all ${
                  isSel
                    ? 'bg-[#2196f3] text-white shadow-md font-bold'
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100 font-semibold'
                }`}
                id={`trx-timer-tab-${t}`}
              >
                <Clock className={`w-4 h-4 mb-0.5 ${isSel ? 'text-white' : 'text-slate-400'}`} />
                <span className="text-[11px] whitespace-nowrap">{label}</span>
              </button>
            );
          })}
        </div>

        {/* Period & Draw time */}
        <div className="bg-white rounded-2xl p-3.5 shadow-xs border border-slate-100 flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="text-xs text-slate-500 font-bold">Period</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-blue-50 text-[#2196f3] font-bold border border-blue-200">
                Public Chain Query
              </span>
            </div>
            <div className="text-sm font-black text-slate-800 font-mono mt-0.5 tracking-tight">
              {periodId || '20260914103010612'}
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-500 font-bold block mb-1">Draw time</span>
            <div className="flex items-center space-x-1 font-mono text-base font-black">
              <span className="w-6 h-7 rounded-md bg-[#fff0f0] border border-red-200 text-[#ff4040] flex items-center justify-center shadow-inner">
                {minStr[0]}
              </span>
              <span className="w-6 h-7 rounded-md bg-[#fff0f0] border border-red-200 text-[#ff4040] flex items-center justify-center shadow-inner">
                {minStr[1]}
              </span>
              <span className="text-[#ff4040] font-bold">:</span>
              <span className="w-6 h-7 rounded-md bg-[#fff0f0] border border-red-200 text-[#ff4040] flex items-center justify-center shadow-inner">
                {secStr[0]}
              </span>
              <span className="w-6 h-7 rounded-md bg-[#fff0f0] border border-red-200 text-[#ff4040] flex items-center justify-center shadow-inner">
                {secStr[1]}
              </span>
            </div>
          </div>
        </div>

        {/* Tron Wavy Ticket Banner matching Screenshot_20260914-160858.png */}
        <div
          className="rounded-3xl p-4 flex flex-col items-center justify-center shadow-md relative overflow-hidden text-white"
          style={{
            background: 'linear-gradient(135deg, #ff6b6b 0%, #ff4757 50%, #ee5253 100%)'
          }}
        >
          <div className="flex items-center space-x-1.5 text-xs font-black uppercase tracking-wider mb-2">
            <ShieldCheck className="w-4 h-4 text-amber-200" />
            <span>Tron Blockchain Cryptographic Hash</span>
          </div>

          {/* 5 Hash Character Balls */}
          <div className="flex items-center space-x-2.5 my-1">
            {latestResult.lastChars.map((ch, idx) => {
              const isLastWinning = idx === latestResult.lastChars.length - 1;
              return (
                <div
                  key={idx}
                  className={`w-11 h-11 rounded-full flex items-center justify-center font-black text-lg shadow-lg border-2 ${
                    isLastWinning
                      ? 'bg-amber-300 text-slate-950 border-white ring-2 ring-amber-400'
                      : 'bg-white/20 text-white border-white/40 backdrop-blur-xs'
                  }`}
                >
                  {ch}
                </div>
              );
            })}
          </div>

          {/* Outcome Attributes */}
          <div className="mt-2.5 flex items-center space-x-2 text-xs font-black">
            <span className="bg-black/30 px-3 py-0.5 rounded-full border border-white/20">
              Winning Number: {latestResult.winningNumber}
            </span>
            <span className="bg-amber-400 text-slate-900 px-2.5 py-0.5 rounded-full">
              {latestResult.size}
            </span>
          </div>
        </div>

        {/* Betting Panel */}
        <div className="bg-white rounded-2xl p-3 shadow-xs border border-slate-100 space-y-3">
          {/* Top 3 Colors: Green (2X), Violet (4.5X), Red (2X) */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => handleOpenBet('color', 'Green', 'green', 2.0, '#10b981')}
              className="py-3 rounded-xl bg-[#10b981] hover:bg-[#059669] text-white font-black text-xs flex flex-col items-center justify-center shadow-xs active:scale-95"
            >
              <span>Green</span>
              <span className="text-[10px] opacity-90 font-medium">2X</span>
            </button>
            <button
              onClick={() => handleOpenBet('color', 'Violet', 'violet', 4.5, '#a855f7')}
              className="py-3 rounded-xl bg-[#a855f7] hover:bg-[#9333ea] text-white font-black text-xs flex flex-col items-center justify-center shadow-xs active:scale-95"
            >
              <span>Violet</span>
              <span className="text-[10px] opacity-90 font-medium">4.5X</span>
            </button>
            <button
              onClick={() => handleOpenBet('color', 'Red', 'red', 2.0, '#ef4444')}
              className="py-3 rounded-xl bg-[#ef4444] hover:bg-[#dc2626] text-white font-black text-xs flex flex-col items-center justify-center shadow-xs active:scale-95"
            >
              <span>Red</span>
              <span className="text-[10px] opacity-90 font-medium">2X</span>
            </button>
          </div>

          {/* Number Balls 0 to 9 */}
          <div className="grid grid-cols-5 gap-2 pt-1">
            {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => {
              const c = getNumberColor(n);
              const bg =
                c === 'green'
                  ? 'bg-[#10b981]'
                  : c === 'red'
                  ? 'bg-[#ef4444]'
                  : c === 'green-violet'
                  ? 'bg-gradient-to-tr from-[#10b981] to-[#a855f7]'
                  : 'bg-gradient-to-tr from-[#ef4444] to-[#a855f7]';

              return (
                <button
                  key={n}
                  onClick={() => handleOpenBet('number', `Number ${n}`, String(n), 9.0, bg)}
                  className="flex flex-col items-center justify-center p-2 rounded-xl bg-slate-50 hover:bg-red-50 border border-slate-100 hover:border-red-200 active:scale-95 transition-all"
                >
                  <div
                    className={`w-9 h-9 rounded-full text-white font-black text-sm flex items-center justify-center shadow-sm ${bg}`}
                  >
                    {n}
                  </div>
                  <span className="text-[10px] text-red-500 font-bold mt-1">9X</span>
                </button>
              );
            })}
          </div>

          {/* Big / Small Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={() => handleOpenBet('size', 'Big', 'big', 2.0, '#f59e0b')}
              className="py-3 rounded-xl bg-[#f59e0b] hover:bg-[#d97706] text-white font-black text-xs flex flex-col items-center justify-center shadow-xs active:scale-95"
            >
              <span>Big</span>
              <span className="text-[10px] opacity-90 font-medium">2X (5-9)</span>
            </button>
            <button
              onClick={() => handleOpenBet('size', 'Small', 'small', 2.0, '#3b82f6')}
              className="py-3 rounded-xl bg-[#3b82f6] hover:bg-[#2563eb] text-white font-black text-xs flex flex-col items-center justify-center shadow-xs active:scale-95"
            >
              <span>Small</span>
              <span className="text-[10px] opacity-90 font-medium">2X (0-4)</span>
            </button>
          </div>
        </div>

        {/* History / Chart / My Bets */}
        <div className="bg-white rounded-2xl shadow-xs border border-slate-100 overflow-hidden">
          <div className="flex border-b border-slate-100">
            {[
              { id: 'history', label: 'Game history' },
              { id: 'chart', label: 'Chart' },
              { id: 'myBets', label: 'My history' }
            ].map((st) => (
              <button
                key={st.id}
                onClick={() => setActiveSubTab(st.id as any)}
                className={`flex-1 py-2.5 text-xs font-bold transition-all border-b-2 ${
                  activeSubTab === st.id
                    ? 'border-[#2196f3] text-[#2196f3]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>

          {activeSubTab === 'history' && (
            <div>
              <div className="divide-y divide-slate-100 text-xs">
                <div className="grid grid-cols-4 px-3 py-2 bg-slate-50 font-bold text-slate-500 text-[11px]">
                  <span>Period</span>
                  <span>Block</span>
                  <span>Hash</span>
                  <span className="text-right">Result</span>
                </div>
                {history.slice((historyPage - 1) * pageSize, historyPage * pageSize).map((h, i) => (
                  <div key={i} className="grid grid-cols-4 px-3 py-2.5 items-center font-medium">
                    <span className="font-mono text-slate-700 truncate">{h.periodId.slice(-6)}</span>
                    <span className="font-mono text-slate-500 text-[11px] truncate">{h.blockHeight}</span>
                    <span className="font-mono text-slate-600 truncate">**{h.hash.slice(-4)}</span>
                    <div className="flex items-center justify-end space-x-1 font-bold">
                      <span className="w-5 h-5 rounded-full bg-[#ff4949] text-white flex items-center justify-center text-[10px]">
                        {h.winningNumber}
                      </span>
                      <span
                        className={`text-[9px] px-1 rounded text-white ${
                          h.size === 'Big' ? 'bg-amber-500' : 'bg-blue-500'
                        }`}
                      >
                        {h.size[0]}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between px-3 py-2 bg-white rounded-b-2xl border-t border-slate-100">
                <button
                  onClick={() => setHistoryPage((p) => Math.max(1, p - 1))}
                  disabled={historyPage <= 1}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center space-x-1"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  <span>Previous</span>
                </button>
                <span className="text-xs font-bold text-slate-600">
                  {historyPage} / {Math.max(1, Math.ceil(history.length / pageSize))}
                </span>
                <button
                  onClick={() => setHistoryPage((p) => Math.min(Math.max(1, Math.ceil(history.length / pageSize)), p + 1))}
                  disabled={historyPage >= Math.max(1, Math.ceil(history.length / pageSize))}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center space-x-1"
                >
                  <span>Next</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {activeSubTab === 'chart' && (
            <div className="p-3 space-y-2 text-xs">
              <div className="space-y-1.5">
                {history.slice((chartPage - 1) * pageSize, chartPage * pageSize).map((h, idx) => (
                  <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-slate-50">
                    <span className="font-mono text-slate-600">{h.periodId.slice(-6)}</span>
                    <span className="font-mono text-slate-500 text-[11px]">Block: {h.blockHeight}</span>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-slate-800">Result: {h.winningNumber}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-bold">
                        {h.size}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <button
                  onClick={() => setChartPage((p) => Math.max(1, p - 1))}
                  disabled={chartPage <= 1}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center space-x-1"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  <span>Previous</span>
                </button>
                <span className="text-xs font-bold text-slate-600">
                  {chartPage} / {Math.max(1, Math.ceil(history.length / pageSize))}
                </span>
                <button
                  onClick={() => setChartPage((p) => Math.min(Math.max(1, Math.ceil(history.length / pageSize)), p + 1))}
                  disabled={chartPage >= Math.max(1, Math.ceil(history.length / pageSize))}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center space-x-1"
                >
                  <span>Next</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {activeSubTab === 'myBets' && (
            <div>
              <div className="divide-y divide-slate-100 text-xs">
                {myBets.length === 0 ? (
                  <div className="py-8 text-center text-slate-400 font-medium">No betting records yet</div>
                ) : (
                  myBets.slice((myBetsPage - 1) * pageSize, myBetsPage * pageSize).map((b) => (
                    <div key={b.id} className="p-3 flex items-center justify-between">
                      <div>
                        <div className="flex items-center space-x-1.5">
                          <span className="font-bold text-slate-800">{b.selectValue.toUpperCase()}</span>
                          <span className="text-[10px] px-1.5 rounded bg-slate-100 text-slate-600 font-mono">
                            {b.multiplierRate}X
                          </span>
                        </div>
                        <span className="text-[10px] font-mono text-slate-400 block mt-0.5">
                          {b.periodId}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-slate-800 block">৳{b.totalAmount.toFixed(2)}</span>
                        <span
                          className={`text-[11px] font-bold ${
                            b.status === 'won'
                              ? 'text-emerald-600'
                              : b.status === 'lost'
                              ? 'text-red-500'
                              : 'text-amber-500'
                          }`}
                        >
                          {b.status === 'won'
                            ? `+৳${(b.winAmount || 0).toFixed(2)}`
                            : b.status === 'lost'
                            ? 'Lost'
                            : 'Pending'}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
              {myBets.length > 0 && (
                <div className="flex items-center justify-between px-3 py-2 bg-white rounded-b-2xl border-t border-slate-100">
                  <button
                    onClick={() => setMyBetsPage((p) => Math.max(1, p - 1))}
                    disabled={myBetsPage <= 1}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center space-x-1"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                    <span>Previous</span>
                  </button>
                  <span className="text-xs font-bold text-slate-600">
                    {myBetsPage} / {Math.max(1, Math.ceil(myBets.length / pageSize))}
                  </span>
                  <button
                    onClick={() => setMyBetsPage((p) => Math.min(Math.max(1, Math.ceil(myBets.length / pageSize)), p + 1))}
                    disabled={myBetsPage >= Math.max(1, Math.ceil(myBets.length / pageSize))}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center space-x-1"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Betting Modal with Free Typing Quantity */}
      {isBetSheetOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end justify-center animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-t-3xl p-4 space-y-3.5 shadow-2xl animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div>
                <h3 className="font-black text-sm text-slate-800">
                  Select: <span className="text-[#ff4949]">{selectedBet.label}</span>
                </h3>
                <span className="text-[11px] text-slate-400">Odds: {selectedBet.rate}X</span>
              </div>
              <button
                onClick={() => setIsBetSheetOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
                id="trx-close-sheet-btn"
              >
                ✕
              </button>
            </div>

            {/* Balance Chips */}
            <div>
              <span className="text-xs font-bold text-slate-600 block mb-1.5">Balance</span>
              <div className="grid grid-cols-4 gap-2">
                {[1, 10, 100, 1000].map((b) => (
                  <button
                    key={b}
                    onClick={() => setBaseBalance(b)}
                    className={`py-1.5 rounded-xl font-bold text-xs transition-all ${
                      baseBalance === b
                        ? 'bg-[#ff4949] text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {b >= 1000 ? `${b / 1000}K` : b}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity Stepper with Free Typing */}
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600">Quantity</span>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    const cur = parseInt(quantityInput, 10) || 1;
                    setQuantityInput(String(Math.max(1, cur - 1)));
                  }}
                  className="w-8 h-8 rounded-lg bg-slate-100 font-bold text-slate-700 flex items-center justify-center active:scale-95"
                >
                  -
                </button>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={quantityInput}
                  placeholder="1"
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val === '' || /^\d+$/.test(val)) {
                      setQuantityInput(val);
                    }
                  }}
                  onBlur={() => {
                    if (!quantityInput || parseInt(quantityInput, 10) < 1) {
                      setQuantityInput('1');
                    }
                  }}
                  className="w-20 text-center font-bold text-slate-800 text-sm py-1 bg-white rounded-lg border border-slate-200 focus:outline-none"
                />
                <button
                  onClick={() => {
                    const cur = parseInt(quantityInput, 10) || 1;
                    setQuantityInput(String(cur + 1));
                  }}
                  className="w-8 h-8 rounded-lg bg-[#ff4949] text-white font-bold flex items-center justify-center active:scale-95"
                >
                  +
                </button>
              </div>
            </div>

            {/* Multipliers */}
            <div className="flex items-center justify-between space-x-1.5 pt-1">
              {[1, 5, 10, 20, 50, 100].map((m) => (
                <button
                  key={m}
                  onClick={() => setMultiplier(m)}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    multiplier === m
                      ? 'bg-[#2196f3] text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  X{m}
                </button>
              ))}
            </div>

            {/* Agreement */}
            <div
              onClick={() => setAgreeRules(!agreeRules)}
              className="flex items-center space-x-2 text-xs text-slate-500 cursor-pointer pt-1"
            >
              <div
                className={`w-4 h-4 rounded-full flex items-center justify-center border ${
                  agreeRules ? 'bg-[#2196f3] border-[#2196f3] text-white' : 'border-slate-300'
                }`}
              >
                {agreeRules && <Check className="w-3 h-3 stroke-[3]" />}
              </div>
              <span>I agree 《Pre-sale rules》</span>
            </div>

            {/* Actions */}
            <div className="flex items-center space-x-2 pt-2">
              <button
                onClick={() => setIsBetSheetOpen(false)}
                className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl active:scale-98"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmBet}
                disabled={isPlacing}
                className="flex-2 py-3 bg-[#2196f3] hover:bg-blue-600 text-white font-black rounded-xl shadow-md active:scale-98 disabled:opacity-50"
                id="trx-confirm-bet-btn"
              >
                Total amount ৳{totalBetAmount.toFixed(2)}
              </button>
            </div>
          </div>
        </div>
      )}

      {lastWinModal && (
        <GameResultModal data={lastWinModal} onClose={closeWinModal} />
      )}
    </div>
  );
};
