import React, { useState } from 'react';
import {
  ChevronLeft,
  Crown,
  Sparkles,
  Shield,
  Gift,
  Coins,
  Lock,
  CheckCircle2,
  HelpCircle,
  TrendingUp,
  Volume2,
  Calendar,
  X,
  Award
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { getVipConfig } from '../utils/vipRules';
import { DEFAULT_VIP_LEVELS } from '../utils/defaultVip';
import { getAvatarById } from '../utils/avatars';
import { VipLevelConfig } from '../types';

interface VipViewProps {
  onBack: () => void;
  onNavigate?: (tab: string) => void;
}

export const VipView: React.FC<VipViewProps> = ({ onBack, onNavigate }) => {
  const { user, settings, claimVipLevelUpBonus, claimVipMonthlyBonus, showToast } = useApp();

  const currentVip = user?.vipLevel || 0;
  const currentAvatar = getAvatarById(user?.avatar || user?.profilePhoto);
  const [selectedLevel, setSelectedLevel] = useState<number>(Math.max(1, Math.min(10, currentVip || 1)));
  const [showRulesModal, setShowRulesModal] = useState<boolean>(false);
  const [isClaimingLevelUp, setIsClaimingLevelUp] = useState<boolean>(false);
  const [isClaimingMonthly, setIsClaimingMonthly] = useState<boolean>(false);

  // Current month key e.g. "2026-09"
  const currentMonthKey = new Date().toISOString().slice(0, 7);

  // Calculate days remaining in current month
  const now = new Date();
  const nextMonthFirstDay = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const diffTime = nextMonthFirstDay.getTime() - now.getTime();
  const daysRemainingInMonth = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));

  const currentExp = Math.floor(user?.totalBets || 0);

  // Get configuration for selected level
  const selectedConfig: VipLevelConfig = getVipConfig(selectedLevel, settings.vipLevels);

  // Status for selected level
  const isAchieved = currentVip >= selectedLevel && currentExp >= selectedConfig.minBet;
  const isLevelUpClaimed = !!user?.levelUpBonusClaimed?.[selectedLevel];
  const isMonthlyClaimed = user?.monthlyBonusClaimed?.[selectedLevel] === currentMonthKey;

  // Level Up claim eligibility
  const canClaimLevelUp = isAchieved && !isLevelUpClaimed && selectedConfig.levelUpBonus > 0;
  // Monthly claim eligibility
  const canClaimMonthly = isAchieved && !isMonthlyClaimed && selectedConfig.monthlyBonus > 0;

  // Progress percentage to selected level
  const prevLevelExp = selectedLevel > 1 ? getVipConfig(selectedLevel - 1, settings.vipLevels).minBet : 0;
  const expSpan = Math.max(1, selectedConfig.minBet - prevLevelExp);
  const progressPercent = isAchieved
    ? 100
    : Math.min(100, Math.max(0, Math.round(((currentExp - prevLevelExp) / expSpan) * 100)));

  const handleClaimLevelUp = async () => {
    if (!canClaimLevelUp || isClaimingLevelUp) return;
    setIsClaimingLevelUp(true);
    try {
      const res = await claimVipLevelUpBonus(selectedLevel);
      showToast(res.message, res.success ? 'success' : 'error');
    } finally {
      setIsClaimingLevelUp(false);
    }
  };

  const handleClaimMonthly = async () => {
    if (!canClaimMonthly || isClaimingMonthly) return;
    setIsClaimingMonthly(true);
    try {
      const res = await claimVipMonthlyBonus(selectedLevel);
      showToast(res.message, res.success ? 'success' : 'error');
    } finally {
      setIsClaimingMonthly(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a111e] text-slate-100 pb-28 select-none font-sans">
      {/* Top App Bar */}
      <header className="sticky top-0 z-30 bg-[#0d1728]/95 backdrop-blur-md border-b border-[#1c2d47] px-4 py-3 flex items-center justify-between shadow-lg">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-slate-300 hover:text-white transition-colors"
          id="vip-back-btn"
        >
          <ChevronLeft className="w-5 h-5 text-amber-400" />
          <span className="font-bold text-sm tracking-wide">VIP</span>
        </button>
        <span className="text-sm font-extrabold tracking-wider bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500 bg-clip-text text-transparent">
          VIP CLUB PRIVILEGES
        </span>
        <button
          onClick={() => setShowRulesModal(true)}
          className="text-slate-400 hover:text-amber-300 transition-colors p-1"
          title="VIP Rules & Privileges"
          id="vip-rules-btn"
        >
          <HelpCircle className="w-5 h-5" />
        </button>
      </header>

      <div className="max-w-md mx-auto px-4 pt-4 space-y-4">
        {/* User VIP Profile Card (Deep Blue theme) */}
        <div className="bg-gradient-to-br from-[#121e33] via-[#101b2f] to-[#0b1322] rounded-2xl p-4 border border-[#1e3458] shadow-xl relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

          {/* User Info Header */}
          <div className="flex items-center space-x-3 relative z-10">
            <div className="relative">
              <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 shadow-md">
                <div className="w-full h-full rounded-full overflow-hidden bg-[#0a111e] flex items-center justify-center">
                  {currentAvatar.photoUrl ? (
                    <img
                      src={currentAvatar.photoUrl}
                      alt={user?.nickname || 'User'}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.currentTarget as HTMLElement).style.display = 'none';
                      }}
                    />
                  ) : (
                    <span className="text-2xl">{currentAvatar.emoji || '👤'}</span>
                  )}
                </div>
              </div>
              <div className="absolute -bottom-1 -right-1 bg-gradient-to-r from-amber-500 to-yellow-500 text-[#0a111e] text-[9px] font-black px-1.5 py-0.5 rounded-full shadow-xs flex items-center space-x-0.5 border border-[#0a111e]">
                <Crown className="w-2.5 h-2.5 fill-current" />
                <span>VIP{currentVip}</span>
              </div>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2">
                <span className="font-bold text-white text-base truncate">
                  {user?.nickname || user?.username || 'Member'}
                </span>
                <span className="bg-[#1e3252] text-amber-400 text-[10px] font-extrabold px-2 py-0.5 rounded-md border border-amber-500/30">
                  VIP {currentVip}
                </span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5 flex items-center space-x-1">
                <span>UID:</span>
                <span className="font-mono text-slate-300 font-semibold">{user?.numericUid || user?.uid?.slice(0, 8)}</span>
              </div>
            </div>
          </div>

          {/* Metrics summary: My experience & Payout time */}
          <div className="grid grid-cols-2 gap-2.5 mt-4 relative z-10">
            {/* Box 1: My Experience */}
            <div className="bg-[#0b1322]/85 rounded-xl p-3 border border-[#192a45]">
              <div className="text-[11px] font-medium text-slate-400 flex items-center space-x-1">
                <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                <span>My experience</span>
              </div>
              <div className="text-base font-extrabold text-white mt-1">
                {currentExp.toLocaleString()} <span className="text-[11px] text-amber-400 font-semibold">EXP</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Bet ৳1 = 1 EXP</div>
            </div>

            {/* Box 2: Payout Time */}
            <div className="bg-[#0b1322]/85 rounded-xl p-3 border border-[#192a45]">
              <div className="text-[11px] font-medium text-slate-400 flex items-center space-x-1">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>Payout time</span>
              </div>
              <div className="text-base font-extrabold text-cyan-400 mt-1">
                {daysRemainingInMonth} <span className="text-[11px] text-slate-300 font-semibold">Days</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Next settlement</div>
            </div>
          </div>

          {/* Settlement Notification Banner */}
          <div className="mt-3 bg-[#0d182b] rounded-xl px-3 py-2 border border-[#1c304f] flex items-center space-x-2 text-[11px] text-slate-300 relative z-10">
            <Volume2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <p className="truncate">VIP level rewards are settled at 2:00 am on the 1st of every month</p>
          </div>
        </div>

        {/* Horizontal VIP Level Selector (VIP1 - VIP10) */}
        <div className="flex space-x-2 overflow-x-auto pb-1.5 scrollbar-none">
          {Array.from({ length: 10 }, (_, i) => i + 1).map((lvl) => {
            const isUnlocked = currentVip >= lvl;
            const isSelected = selectedLevel === lvl;
            return (
              <button
                key={lvl}
                onClick={() => setSelectedLevel(lvl)}
                className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center space-x-1.5 shrink-0 border ${
                  isSelected
                    ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-[#0a111e] border-amber-300 shadow-md scale-105'
                    : isUnlocked
                    ? 'bg-[#121d30] text-amber-300 border-[#22395d] hover:bg-[#182740]'
                    : 'bg-[#0e1624] text-slate-500 border-[#162338] hover:bg-[#131d2e]'
                }`}
                id={`vip-select-${lvl}`}
              >
                <Crown className={`w-3.5 h-3.5 ${isSelected ? 'fill-current text-[#0a111e]' : isUnlocked ? 'text-amber-400' : 'text-slate-600'}`} />
                <span>VIP{lvl}</span>
              </button>
            );
          })}
        </div>

        {/* Selected VIP Level Card with Progress */}
        <div className="bg-gradient-to-br from-[#132238] via-[#101c30] to-[#0c1524] rounded-2xl p-4 border border-[#203a62] shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between relative z-10">
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xl font-black tracking-wider text-white">VIP{selectedLevel}</span>
                {isAchieved ? (
                  <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center space-x-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Achieved</span>
                  </span>
                ) : (
                  <span className="bg-slate-800 text-slate-400 border border-slate-700 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center space-x-1">
                    <Lock className="w-3 h-3" />
                    <span>Not open yet</span>
                  </span>
                )}
              </div>
              <div className="text-xs text-slate-400 mt-0.5">Dear VIP{selectedLevel} customer</div>
            </div>

            {/* Shield badge icon */}
            <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-amber-500/20 to-yellow-500/10 border border-amber-500/30 flex items-center justify-center shadow-inner">
              <Award className="w-7 h-7 text-amber-400 drop-shadow" />
            </div>
          </div>

          {/* Progress requirement */}
          <div className="mt-4 space-y-1.5 relative z-10">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">
                {isAchieved
                  ? `Level unlocked (VIP ${selectedLevel})`
                  : `Upgrading VIP${selectedLevel} requires ${Math.max(0, selectedConfig.minBet - currentExp).toLocaleString()} EXP`}
              </span>
              <span className="text-amber-400 font-bold text-[11px] bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                Bet ৳1 = 1 EXP
              </span>
            </div>

            <div className="w-full h-2.5 bg-[#080d16] rounded-full overflow-hidden border border-[#1b2c47]">
              <div
                className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-300 transition-all duration-500 rounded-full"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-0.5 font-mono">
              <span>{currentExp.toLocaleString()} EXP</span>
              <span>{selectedConfig.minBet.toLocaleString()} EXP</span>
            </div>
          </div>
        </div>

        {/* Section: VIP Benefits Level (Matches Screenshot 4, 6, 8) */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2 px-1">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-bold text-white tracking-wide">
              VIP{selectedLevel} Benefits level
            </h2>
          </div>

          <div className="bg-[#101b2d] rounded-2xl p-3 border border-[#1a2e4c] divide-y divide-[#172740] shadow-lg">
            {/* Benefit 1: Level Up rewards */}
            <div className="py-2.5 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/20 flex items-center justify-center text-amber-400">
                  <Gift className="w-4.5 h-4.5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Level up rewards</div>
                  <div className="text-[10px] text-slate-400">Each account can only receive 1 time</div>
                </div>
              </div>
              <div className="flex items-center space-x-1.5 bg-[#0a111e] px-2.5 py-1 rounded-lg border border-[#1f3659]">
                <Coins className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-xs font-extrabold text-amber-300">৳{selectedConfig.levelUpBonus}</span>
              </div>
            </div>

            {/* Benefit 2: Monthly reward */}
            <div className="py-2.5 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-xl bg-yellow-500/15 border border-yellow-500/20 flex items-center justify-center text-yellow-400">
                  <Calendar className="w-4.5 h-4.5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Monthly reward</div>
                  <div className="text-[10px] text-slate-400">Each account can only receive 1 time per month</div>
                </div>
              </div>
              <div className="flex items-center space-x-1.5 bg-[#0a111e] px-2.5 py-1 rounded-lg border border-[#1f3659]">
                <Coins className="w-3.5 h-3.5 text-yellow-400" />
                <span className="text-xs font-extrabold text-yellow-300">৳{selectedConfig.monthlyBonus}</span>
              </div>
            </div>

            {/* Benefit 3: Safe extra income */}
            <div className="py-2.5 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                  <Shield className="w-4.5 h-4.5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Safe</div>
                  <div className="text-[10px] text-slate-400">Increase the extra income of the safe</div>
                </div>
              </div>
              <div className="bg-[#0a111e] px-2.5 py-1 rounded-lg border border-[#1f3659] text-xs font-extrabold text-cyan-300">
                {selectedConfig.safeRate || 0.1}%
              </div>
            </div>

            {/* Benefit 4: Rebate rate */}
            <div className="py-2.5 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <TrendingUp className="w-4.5 h-4.5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Rebate rate</div>
                  <div className="text-[10px] text-slate-400">Increase income of rebate</div>
                </div>
              </div>
              <div className="bg-[#0a111e] px-2.5 py-1 rounded-lg border border-[#1f3659] text-xs font-extrabold text-emerald-300">
                {selectedConfig.rebateRate || 0.6}%
              </div>
            </div>
          </div>
        </div>

        {/* Section: My benefits (Matches Screenshot 5, 7, 9) */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center space-x-2 px-1">
            <Crown className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-bold text-white tracking-wide">My benefits</h2>
          </div>

          <div className="space-y-3">
            {/* Action Card 1: Level up rewards */}
            <div className="bg-gradient-to-r from-[#101b2d] to-[#122035] rounded-2xl p-4 border border-[#1d3252] shadow-xl flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-sm">
                  <Gift className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs font-black text-white">Level up rewards</div>
                  <div className="text-[10px] text-slate-400">Each account can only receive 1 time</div>
                  <div className="text-sm font-extrabold text-amber-300 mt-1 flex items-center space-x-1">
                    <Coins className="w-3.5 h-3.5 text-amber-400" />
                    <span>৳{selectedConfig.levelUpBonus.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div>
                {isLevelUpClaimed ? (
                  <button
                    disabled
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-500 text-xs font-bold border border-slate-700 cursor-not-allowed flex items-center space-x-1"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Received</span>
                  </button>
                ) : canClaimLevelUp ? (
                  <button
                    onClick={handleClaimLevelUp}
                    disabled={isClaimingLevelUp}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 active:scale-95 text-[#0a111e] text-xs font-black shadow-lg shadow-amber-500/25 transition-all"
                    id="vip-claim-levelup-btn"
                  >
                    {isClaimingLevelUp ? 'Claiming...' : 'Receive'}
                  </button>
                ) : (
                  <button
                    disabled
                    className="px-3.5 py-2 rounded-xl bg-[#131e30] text-slate-500 text-xs font-bold border border-[#1a2a42] cursor-not-allowed flex items-center space-x-1"
                  >
                    <Lock className="w-3 h-3" />
                    <span>VIP{selectedLevel} Req</span>
                  </button>
                )}
              </div>
            </div>

            {/* Action Card 2: Monthly reward */}
            <div className="bg-gradient-to-r from-[#101b2d] to-[#122035] rounded-2xl p-4 border border-[#1d3252] shadow-xl flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-2xl bg-yellow-500/15 border border-yellow-500/30 flex items-center justify-center text-yellow-400 shadow-sm">
                  <Calendar className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs font-black text-white">Monthly reward</div>
                  <div className="text-[10px] text-slate-400">Each account can only receive 1 time per month</div>
                  <div className="text-sm font-extrabold text-yellow-300 mt-1 flex items-center space-x-1">
                    <Coins className="w-3.5 h-3.5 text-yellow-400" />
                    <span>৳{selectedConfig.monthlyBonus.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div>
                {isMonthlyClaimed ? (
                  <button
                    disabled
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-500 text-xs font-bold border border-slate-700 cursor-not-allowed flex items-center space-x-1"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Received</span>
                  </button>
                ) : canClaimMonthly ? (
                  <button
                    onClick={handleClaimMonthly}
                    disabled={isClaimingMonthly}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 active:scale-95 text-[#0a111e] text-xs font-black shadow-lg shadow-yellow-500/25 transition-all"
                    id="vip-claim-monthly-btn"
                  >
                    {isClaimingMonthly ? 'Claiming...' : 'Receive'}
                  </button>
                ) : (
                  <button
                    disabled
                    className="px-3.5 py-2 rounded-xl bg-[#131e30] text-slate-500 text-xs font-bold border border-[#1a2a42] cursor-not-allowed flex items-center space-x-1"
                  >
                    <Lock className="w-3 h-3" />
                    <span>VIP{selectedLevel} Req</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Rules & Privileges Modal */}
      {showRulesModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0e1726] border border-[#1e3250] rounded-3xl w-full max-w-md max-h-[85vh] overflow-y-auto p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#1b2c45] pb-3">
              <div className="flex items-center space-x-2">
                <Crown className="w-5 h-5 text-amber-400" />
                <h3 className="font-extrabold text-white text-base">VIP Level Rules & Details</h3>
              </div>
              <button
                onClick={() => setShowRulesModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
              <div className="bg-[#121f33] p-3 rounded-xl border border-[#1c3050]">
                <h4 className="font-bold text-amber-300 mb-1">1. VIP Level Upgrade (EXP)</h4>
                <p>
                  Every ৳1 valid bet made on any game contributes 1 EXP towards your VIP level progression (Bet ৳1 = 1 EXP). Once you reach the required cumulative EXP, your VIP tier will automatically upgrade!
                </p>
              </div>

              <div className="bg-[#121f33] p-3 rounded-xl border border-[#1c3050]">
                <h4 className="font-bold text-amber-300 mb-1">2. Level Up Bonus</h4>
                <p>
                  Each time your account unlocks a higher VIP level, you can claim that tier&apos;s Level Up Bonus. Each account can claim this reward exactly 1 time per VIP level.
                </p>
              </div>

              <div className="bg-[#121f33] p-3 rounded-xl border border-[#1c3050]">
                <h4 className="font-bold text-amber-300 mb-1">3. Monthly Reward</h4>
                <p>
                  Active VIP members can claim their VIP tier monthly reward once every calendar month. Rewards are refreshed at 2:00 AM on the 1st day of every month.
                </p>
              </div>

              <div className="bg-[#121f33] p-3 rounded-xl border border-[#1c3050]">
                <h4 className="font-bold text-amber-300 mb-1">4. Safe Vault & Rebate Rate Privileges</h4>
                <p>
                  Higher VIP ranks enjoy enhanced daily interest rates in the Safe Vault and higher daily turnover rebate percentages.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowRulesModal(false)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-[#0a111e] font-bold text-xs"
            >
              I Understand
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
