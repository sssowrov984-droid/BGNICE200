import React, { useState } from 'react';
import {
  Wallet,
  ArrowDownToLine,
  ArrowUpFromLine,
  RefreshCw,
  Award,
  Gift,
  Users,
  ShieldCheck,
  ChevronRight,
  TrendingUp,
  CreditCard,
  History
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { BrandLogo } from './BrandLogo';
import { PAYMENT_LOGOS } from '../utils/paymentLogos';

interface WalletViewProps {
  onNavigateDeposit: () => void;
  onNavigateWithdraw: () => void;
  onBack?: () => void;
}

export const WalletView: React.FC<WalletViewProps> = ({
  onNavigateDeposit,
  onNavigateWithdraw,
  onBack
}) => {
  const { user, refreshBalance, isRefreshingBalance, settings } = useApp();

  // Balance metrics
  const totalBalance = Number(user?.balance || 0);
  const depositBalance = Number(user?.depositBalance || 0);
  const referralBonus = Number(user?.referralBalance || 0);
  const giftBonus = Number(user?.giftBonusBalance || user?.bonusBalance || 0);

  // Turnover tracking (Deposit 1x, Gift/Attendance 3x, Referral 0x)
  const turnoverReq = Number(user?.turnoverReq || 0);
  const turnoverDone = Number(user?.turnoverDone || 0);
  const turnoverRemaining = Math.max(0, Number((turnoverReq - turnoverDone).toFixed(2)));

  // Withdrawable balance: referral bonus has 0x turnover, and if turnover is fulfilled, full balance is withdrawable
  const withdrawableBalance = turnoverRemaining <= 0
    ? totalBalance
    : Math.min(totalBalance, Math.max(referralBonus, Number((totalBalance - turnoverRemaining).toFixed(2))));

  const turnoverProgress = turnoverReq > 0
    ? Math.min(100, Math.round((turnoverDone / turnoverReq) * 100))
    : 100;

  return (
    <div className="min-h-screen bg-[#f7f8fc] pb-24 text-slate-800 select-none">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-[#29303d] border-b border-slate-700/80 text-white px-4 py-3 flex items-center justify-between shadow-md">
        <BrandLogo variant="compact" showBadge={false} />
        <h1 className="text-base font-bold">My Wallet</h1>
        <button
          onClick={refreshBalance}
          disabled={isRefreshingBalance}
          className="p-1 rounded-full text-white/90 hover:text-white transition-transform active:scale-95"
          title="Refresh Balance"
          id="wallet-header-refresh-btn"
        >
          <RefreshCw className={`w-4 h-4 ${isRefreshingBalance ? 'animate-spin' : ''}`} />
        </button>
      </div>

      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* Main Total Balance Card */}
        <div className="bg-[#29303d] border border-slate-700/80 rounded-3xl p-5 text-white shadow-xl relative overflow-hidden">
          <div className="absolute -right-8 -bottom-8 w-36 h-36 bg-[#2196f3]/10 rounded-full blur-xl pointer-events-none" />

          <div className="flex items-center justify-between relative z-10">
            <div>
              <div className="flex items-center space-x-1.5 text-xs text-slate-300 font-medium">
                <Wallet className="w-4 h-4 text-[#2196f3]" />
                <span>Total Balance</span>
              </div>
              <div className="text-3xl font-black tracking-tight mt-1 text-white">
                ৳{totalBalance.toFixed(2)}
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] bg-[#2196f3]/20 border border-[#2196f3]/30 text-blue-200 px-2.5 py-1 rounded-full font-bold uppercase tracking-wider">
                UID: {user?.numericUid || user?.uid?.slice(0, 6) || '---'}
              </span>
            </div>
          </div>

          {/* Quick Action Deposit / Withdraw Buttons */}
          <div className="grid grid-cols-2 gap-3 mt-5 relative z-10 pt-4 border-t border-slate-700">
            <button
              onClick={onNavigateDeposit}
              className="py-3 px-4 bg-[#2196f3] text-white hover:bg-[#1e88e5] active:scale-98 font-black rounded-2xl text-xs flex items-center justify-center space-x-2 shadow-md transition-transform"
              id="wallet-btn-deposit"
            >
              <ArrowDownToLine className="w-4 h-4 stroke-[2.5]" />
              <span>Deposit</span>
            </button>

            <button
              onClick={onNavigateWithdraw}
              className="py-3 px-4 bg-white/10 hover:bg-white/20 active:scale-98 text-white border border-slate-600 font-black rounded-2xl text-xs flex items-center justify-center space-x-2 transition-transform"
              id="wallet-btn-withdraw"
            >
              <ArrowUpFromLine className="w-4 h-4 stroke-[2.5]" />
              <span>Withdraw</span>
            </button>
          </div>
        </div>

        {/* 4 Balance Breakdown Grid */}
        <div className="grid grid-cols-2 gap-3">
          {/* Deposit Balance */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 space-y-1">
            <div className="flex items-center space-x-1.5 text-slate-400 text-xs font-semibold">
              <CreditCard className="w-3.5 h-3.5 text-orange-500" />
              <span>Deposit Balance</span>
            </div>
            <div className="text-lg font-black text-slate-900">
              ৳{depositBalance.toFixed(2)}
            </div>
            <div className="text-[10px] text-slate-400">1× turnover requirement</div>
          </div>

          {/* Withdrawable Balance */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 space-y-1">
            <div className="flex items-center space-x-1.5 text-slate-400 text-xs font-semibold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>Withdrawable</span>
            </div>
            <div className="text-lg font-black text-emerald-600">
              ৳{withdrawableBalance.toFixed(2)}
            </div>
            <div className="text-[10px] text-slate-400">Ready for cashout</div>
          </div>

          {/* Referral Bonus */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 space-y-1">
            <div className="flex items-center space-x-1.5 text-slate-400 text-xs font-semibold">
              <Users className="w-3.5 h-3.5 text-blue-500" />
              <span>Referral Bonus</span>
            </div>
            <div className="text-lg font-black text-blue-600">
              ৳{referralBonus.toFixed(2)}
            </div>
            <div className="text-[10px] text-emerald-600 font-bold">0× turnover (unlocked)</div>
          </div>

          {/* Gift Bonus */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 space-y-1">
            <div className="flex items-center space-x-1.5 text-slate-400 text-xs font-semibold">
              <Gift className="w-3.5 h-3.5 text-purple-500" />
              <span>Gift Bonus</span>
            </div>
            <div className="text-lg font-black text-purple-600">
              ৳{giftBonus.toFixed(2)}
            </div>
            <div className="text-[10px] text-slate-400">3× turnover requirement</div>
          </div>
        </div>

        {/* Turnover Remaining Card */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center">
                <Award className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-xs text-slate-900">Turnover Remaining</h3>
                <p className="text-[10px] text-slate-400">Required gameplay before deposit withdrawal</p>
              </div>
            </div>

            <div className="text-right">
              <span className={`text-sm font-black ${turnoverRemaining === 0 ? 'text-emerald-600' : 'text-amber-600'}`}>
                {turnoverRemaining === 0 ? 'Completed' : `৳${turnoverRemaining.toFixed(2)}`}
              </span>
            </div>
          </div>

          <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                turnoverProgress >= 100 ? 'bg-emerald-500' : 'bg-gradient-to-r from-amber-400 to-[#2196f3]'
              }`}
              style={{ width: `${turnoverProgress}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500">
            <span>Progress: {turnoverProgress}%</span>
            <span>
              Done: ৳{turnoverDone.toFixed(2)} / Req: ৳{turnoverReq.toFixed(2)}
            </span>
          </div>

          <div className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
            💡 <strong className="text-slate-700">Turnover Rules:</strong> Deposits require 1× turnover. Gift & attendance bonuses require 3× turnover. Referral bonuses require <strong className="text-emerald-600">0× turnover</strong> and are never locked!
          </div>
        </div>

        {/* Official Payment Channels Logo Showcase */}
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-3">
          <div className="text-xs font-bold text-slate-900 flex items-center space-x-1.5">
            <span>Official 24/7 Payment Gateways</span>
          </div>

          <div className="grid grid-cols-4 gap-2 text-center">
            {/* Nagad */}
            <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col items-center justify-center space-y-1">
              <img
                src={PAYMENT_LOGOS.nagad}
                alt="Nagad"
                className="w-10 h-10 object-contain rounded-lg"
                referrerPolicy="no-referrer"
              />
              <span className="text-[10px] font-bold text-slate-700">Nagad</span>
            </div>

            {/* bKash */}
            <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col items-center justify-center space-y-1">
              <img
                src={PAYMENT_LOGOS.bkash}
                alt="bKash"
                className="w-10 h-10 object-contain rounded-lg"
                referrerPolicy="no-referrer"
              />
              <span className="text-[10px] font-bold text-slate-700">bKash</span>
            </div>

            {/* Rocket */}
            <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col items-center justify-center space-y-1">
              <img
                src={PAYMENT_LOGOS.rocket}
                alt="Rocket"
                className="w-10 h-10 object-contain rounded-lg"
                referrerPolicy="no-referrer"
              />
              <span className="text-[10px] font-bold text-slate-700">Rocket</span>
            </div>

            {/* USDT */}
            <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col items-center justify-center space-y-1">
              <div className="w-10 h-10 rounded-full bg-emerald-600 text-white font-black text-sm flex items-center justify-center shadow-xs">
                ₮
              </div>
              <span className="text-[10px] font-bold text-slate-700">USDT TRC20</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
