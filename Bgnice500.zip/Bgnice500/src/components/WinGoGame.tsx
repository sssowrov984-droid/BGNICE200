import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  RefreshCw,
  Clock,
  BookOpen,
  Volume2,
  VolumeX,
  ChevronRight,
  ChevronDown,
  Check,
  Sparkles,
  TrendingUp,
  Flame,
  ArrowRight,
  Info
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { GameType, BetItem, GameHistoryItem } from '../types';
import { getNumberSize } from '../utils/gameRules';
import { BrandLogo } from './BrandLogo';
import { GameResultModal } from './GameResultModal';

interface WinGoGameProps {
  onDepositClick: () => void;
  onWithdrawClick: () => void;
  onBack: () => void;
}

export const WinGoGame: React.FC<WinGoGameProps> = ({
  onDepositClick,
  onWithdrawClick,
  onBack
}) => {
  const {
    user,
    gameType,
    setGameType,
    periodId,
    timeLeft,
    gameHistory = [],
    userBets = [],
    placeBet,
    lastWinModal,
    closeWinModal,
    refreshBalance,
    isRefreshingBalance,
    recordGameMove
  } = useApp();

  // Wingo Sound System via Web Audio API
  const [soundEnabled, setSoundEnabled] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Initialize or get Web Audio Context safely
  const getAudioContext = () => {
    if (!audioCtxRef.current) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        audioCtxRef.current = new AudioContextClass();
      }
    }
    if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume().catch(() => {});
    }
    return audioCtxRef.current;
  };

  const playBeep = (frequency: number, duration: number = 0.1, type: OscillatorType = 'sine') => {
    if (!soundEnabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(frequency, ctx.currentTime);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {}
  };

  const playClickChime = () => {
    playBeep(880, 0.08, 'sine');
  };

  const playWinCelebration = () => {
    if (!soundEnabled) return;
    playBeep(523.25, 0.15, 'triangle');
    setTimeout(() => playBeep(659.25, 0.15, 'triangle'), 120);
    setTimeout(() => playBeep(783.99, 0.25, 'triangle'), 240);
  };

  const toggleSound = () => {
    setSoundEnabled((prev) => {
      const next = !prev;
      if (next) {
        // Turning ON: play pleasant confirmation chime
        setTimeout(() => {
          try {
            const ctx = getAudioContext();
            if (ctx) {
              const osc = ctx.createOscillator();
              const gain = ctx.createGain();
              osc.type = 'sine';
              osc.frequency.setValueAtTime(660, ctx.currentTime);
              gain.gain.setValueAtTime(0.2, ctx.currentTime);
              gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
              osc.connect(gain);
              gain.connect(ctx.destination);
              osc.start();
              osc.stop(ctx.currentTime + 0.12);
            }
          } catch {}
        }, 10);
      } else {
        // Turning OFF: close or suspend audio context
        if (audioCtxRef.current) {
          try {
            audioCtxRef.current.suspend().catch(() => {});
          } catch {}
        }
      }
      return next;
    });
  };

  // Turn off sound immediately when exiting the game & log move in/out
  useEffect(() => {
    recordGameMove('move_in', 'Win Go Lottery');
    return () => {
      setSoundEnabled(false);
      if (audioCtxRef.current) {
        try {
          audioCtxRef.current.close().catch(() => {});
        } catch {}
        audioCtxRef.current = null;
      }
      recordGameMove('move_out', 'Win Go Lottery');
    };
  }, []);

  // Automatic countdown audio when timeLeft <= 5 and sound is ON
  useEffect(() => {
    if (!soundEnabled) return;
    if (timeLeft > 0 && timeLeft <= 5) {
      if (timeLeft === 1) {
        playBeep(920, 0.25, 'sine'); // High pitch final second
      } else {
        playBeep(600, 0.12, 'sine'); // Regular countdown tick
      }
    }
  }, [timeLeft, soundEnabled]);

  // Win modal sound trigger
  useEffect(() => {
    if (soundEnabled && lastWinModal?.win) {
      playWinCelebration();
    }
  }, [lastWinModal, soundEnabled]);

  type TabOption = 'history' | 'chart' | 'strategy' | 'mybets';
  const [activeTab, setActiveTab] = useState<TabOption>('history');
  const [historyPage, setHistoryPage] = useState<number>(1);
  const historyPageSize = 10;
  const [chartPage, setChartPage] = useState<number>(1);
  const chartPageSize = 10;
  const [myBetsPage, setMyBetsPage] = useState<number>(1);
  const myBetsPageSize = 10;
  const [expandedBetId, setExpandedBetId] = useState<string | null>(null);
  const [myBetsGameTypeFilter, setMyBetsGameTypeFilter] = useState<'all' | GameType>('all');
  const [myBetsStatusFilter, setMyBetsStatusFilter] = useState<'all' | 'won' | 'lost' | 'pending'>('all');

  // Ensure scroll is at the top when entering the game
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
  }, []);

  const isWinGoBet = (b: BetItem) => {
    const gt = (b.gameType || '').toLowerCase();
    const gn = (b.gameName || '').toLowerCase();
    return (
      gt.startsWith('wingo') ||
      gt === 'wingo' ||
      gt === '30s' ||
      gt === '1m' ||
      gt === '3m' ||
      gt === '5m' ||
      gn.includes('wingo') ||
      gn.includes('win go')
    );
  };

  const safeGameHistory: GameHistoryItem[] = Array.isArray(gameHistory) ? gameHistory : Object.values(gameHistory || {});
  const safeUserBets: BetItem[] = (Array.isArray(userBets) ? userBets : Object.values(userBets || {}))
    .filter((b) => !b.id?.startsWith('bet_init_') && isWinGoBet(b));

  const formatBetDate = (timestamp: number) => {
    if (!timestamp) return '';
    const d = new Date(timestamp);
    const pad = (n: number) => String(n).padStart(2, '0');
    const y = d.getFullYear();
    const m = pad(d.getMonth() + 1);
    const day = pad(d.getDate());
    const h = pad(d.getHours());
    const min = pad(d.getMinutes());
    const s = pad(d.getSeconds());
    return `${y}-${m}-${day} ${h}:${min}:${s}`;
  };

  const handleSelectGameType = (gt: GameType) => {
    setGameType(gt);
    setHistoryPage(1);
    setChartPage(1);
    setMyBetsPage(1);
  };

  // Bet Modal State
  const [isBetModalOpen, setIsBetModalOpen] = useState(false);
  const [selectedBetType, setSelectedBetType] = useState<'color' | 'number' | 'size'>('color');
  const [selectedBetValue, setSelectedBetValue] = useState<string>('green');
  const [baseBalance, setBaseBalance] = useState<number>(1);
  const [quantityInput, setQuantityInput] = useState<string>('1');
  const [multiplier, setMultiplier] = useState<number>(1);
  const [agreeRules, setAgreeRules] = useState<boolean>(true);
  const [isPlacing, setIsPlacing] = useState(false);
  const [ruleModalOpen, setRuleModalOpen] = useState(false);

  // Time format
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const minStr = String(minutes).padStart(2, '0');
  const secStr = String(seconds).padStart(2, '0');

  // Total bet amount calculation supporting free typing
  const parsedQuantity = Math.max(1, parseInt(quantityInput, 10) || 1);
  const totalBetAmount = baseBalance * parsedQuantity * multiplier;

  const openBetModal = (type: 'color' | 'number' | 'size', value: string) => {
    setSelectedBetType(type);
    setSelectedBetValue(value);
    setBaseBalance(1);
    setQuantityInput('1');
    setMultiplier(1);
    setIsBetModalOpen(true);
  };

  const handleConfirmBet = async () => {
    if (!agreeRules) {
      alert('Please agree to the pre-sale rules');
      return;
    }
    try {
      setIsPlacing(true);
      const success = await placeBet(selectedBetType, selectedBetValue, baseBalance * parsedQuantity, multiplier);
      if (success) {
        setIsBetModalOpen(false);
      }
    } catch (err) {
      console.error('Bet confirmation error', err);
    } finally {
      setIsPlacing(false);
    }
  };

  const gameTypes: { id: GameType; label: string; sub: string }[] = [
    { id: '30s', label: 'WinGo', sub: '30sec' },
    { id: '1m', label: 'WinGo', sub: '1 Min' },
    { id: '2m', label: 'WinGo', sub: '2 Min' },
    { id: '3m', label: 'WinGo', sub: '3 Min' },
    { id: '5m', label: 'WinGo', sub: '5 Min' },
  ];

  // Number ball styles
  const getBallBadge = (num: number) => {
    if (num === 0) {
      return 'bg-gradient-to-tr from-[#9c27b0] via-[#e91e63] to-[#f44336] text-white';
    }
    if (num === 5) {
      return 'bg-gradient-to-tr from-[#9c27b0] via-[#4caf50] to-[#2e7d32] text-white';
    }
    if ([1, 3, 7, 9].includes(num)) {
      return 'bg-gradient-to-tr from-[#2e7d32] to-[#4caf50] text-white';
    }
    return 'bg-gradient-to-tr from-[#c62828] to-[#f44336] text-white';
  };

  const getNumberColorDot = (num: number) => {
    if (num === 0) {
      return (
        <div className="flex items-center space-x-1 justify-center">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>
          <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
        </div>
      );
    }
    if (num === 5) {
      return (
        <div className="flex items-center space-x-1 justify-center">
          <span className="w-2.5 h-2.5 rounded-full bg-green-500"></span>
          <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
        </div>
      );
    }
    if ([1, 3, 7, 9].includes(num)) {
      return <span className="inline-block w-2.5 h-2.5 rounded-full bg-green-500"></span>;
    }
    return <span className="inline-block w-2.5 h-2.5 rounded-full bg-red-500"></span>;
  };

  return (
    <div className="min-h-screen bg-[#f7f8fc] pb-24 text-slate-800 select-none">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-[#29303d] border-b border-slate-700/40 text-white px-4 py-3 shadow-md flex items-center justify-between">
        <button
          onClick={() => {
            setSoundEnabled(false);
            if (audioCtxRef.current) {
              try {
                audioCtxRef.current.close();
              } catch {}
              audioCtxRef.current = null;
            }
            onBack();
          }}
          className="p-1 -ml-1 text-white hover:bg-white/10 rounded-full"
          id="wingo-back-btn"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <div className="flex items-center space-x-2">
          <BrandLogo variant="compact" showBadge={false} />
          <span className="text-xs bg-white/20 px-2 py-0.5 rounded font-bold uppercase tracking-wider">
            Win Go
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setRuleModalOpen(true)}
            className="p-1 text-white/90 hover:text-white"
            title="Rules"
          >
            <BookOpen className="w-5 h-5" />
          </button>
          <button
            onClick={toggleSound}
            className={`px-2 py-1 rounded-full text-xs font-bold transition flex items-center space-x-1 border ${
              soundEnabled
                ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md'
                : 'bg-white/10 text-white/80 border-white/20 hover:bg-white/20'
            }`}
            title={soundEnabled ? 'Click to Mute Sound' : 'Click to Turn On Sound'}
            id="wingo-sound-toggle-btn"
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-4 h-4 animate-pulse" />
                <span className="text-[10px] uppercase tracking-wider font-black">ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4" />
                <span className="text-[10px] uppercase tracking-wider font-bold">OFF</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="px-3 pt-3 space-y-3 max-w-md mx-auto">
        {/* Wallet Balance Card */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs text-slate-400 font-medium">Wallet balance</div>
              <div className="flex items-center space-x-2 mt-0.5">
                <span className="text-2xl font-extrabold text-slate-900 tracking-tight">
                  ৳{user?.balance.toFixed(2) || '0.00'}
                </span>
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    refreshBalance();
                  }}
                  disabled={isRefreshingBalance}
                  className="p-1 text-slate-400 hover:text-slate-600 active:scale-90 transition-transform"
                  id="wingo-refresh-bal"
                  title="Refresh Balance"
                >
                  <RefreshCw className={`w-4 h-4 ${isRefreshingBalance ? 'animate-spin text-[#2196f3]' : ''}`} />
                </button>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={onWithdrawClick}
                className="px-4 py-1.5 rounded-full text-xs font-bold text-white bg-slate-700 hover:bg-slate-600 shadow-sm active:scale-95 transition-all"
                id="wingo-withdraw-btn"
              >
                Withdraw
              </button>
              <button
                onClick={onDepositClick}
                className="px-4 py-1.5 rounded-full text-xs font-bold text-white bg-gradient-to-r from-[#2196f3] to-[#1976d2] shadow-sm active:scale-95 transition-all"
                id="wingo-deposit-btn"
              >
                Deposit
              </button>
            </div>
          </div>
        </div>

        {/* Game Mode Sub-Tabs (WinGo 30s, 1m, 2m, 3m, 5m) */}
        <div className="grid grid-cols-5 gap-1.5">
          {gameTypes.map((gt) => {
            const isSel = gameType === gt.id;
            return (
              <button
                key={gt.id}
                onClick={() => handleSelectGameType(gt.id)}
                className={`py-2 px-1 rounded-xl flex flex-col items-center justify-center transition-all ${
                  isSel
                    ? 'bg-gradient-to-b from-[#2196f3] to-[#1976d2] text-white shadow-md scale-102'
                    : 'bg-white text-slate-600 border border-slate-100 hover:bg-slate-50'
                }`}
                id={`game-type-${gt.id}`}
              >
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center mb-1 ${
                    isSel ? 'bg-white/20' : 'bg-slate-100'
                  }`}
                >
                  <Clock className={`w-4 h-4 ${isSel ? 'text-white' : 'text-slate-500'}`} />
                </div>
                <span className="text-[11px] font-bold leading-tight">{gt.label}</span>
                <span className={`text-[10px] ${isSel ? 'text-white/90' : 'text-slate-400'}`}>
                  {gt.sub}
                </span>
              </button>
            );
          })}
        </div>

        {/* Ticket Box (Left: How to Play + Balls; Right: Time Remaining) */}
        <div className="relative bg-gradient-to-r from-[#29303d] via-[#353e4f] to-[#29303d] rounded-2xl p-3.5 text-white shadow-md border border-slate-700/60 overflow-hidden">
          {/* Perforated dashed divider */}
          <div className="absolute top-0 bottom-0 left-[55%] border-r border-dashed border-white/30"></div>

          <div className="flex items-center justify-between">
            {/* Left side */}
            <div className="w-[52%] pr-2">
              <button
                onClick={() => setRuleModalOpen(true)}
                className="inline-flex items-center space-x-1 bg-white/20 hover:bg-white/30 px-2 py-0.5 rounded-md text-[11px] font-semibold text-white mb-2"
                id="wingo-how-to-play-btn"
              >
                <BookOpen className="w-3 h-3" />
                <span>How to play</span>
              </button>
              <div className="text-xs font-bold tracking-wide">
                WinGo {gameType === '30s' ? '30sec' : gameType}
              </div>
              {/* Recent 5 balls */}
              <div className="flex items-center space-x-1.5 mt-2 overflow-hidden">
                {gameHistory.slice(0, 5).map((h, i) => (
                  <div
                    key={i}
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black shadow-xs ${getBallBadge(
                      h.number
                    )}`}
                  >
                    {h.number}
                  </div>
                ))}
              </div>
            </div>

            {/* Right side */}
            <div className="w-[45%] pl-3 flex flex-col items-end">
              <span className="text-[11px] font-medium text-white/90">Time remaining</span>
              {/* Countdown Digits */}
              <div className="flex items-center space-x-1 mt-1 font-mono">
                <span className="bg-white text-[#2196f3] font-black text-base px-1.5 py-0.5 rounded shadow-xs">
                  {minStr[0]}
                </span>
                <span className="bg-white text-[#2196f3] font-black text-base px-1.5 py-0.5 rounded shadow-xs">
                  {minStr[1]}
                </span>
                <span className="text-white font-black text-base">:</span>
                <span className="bg-white text-[#2196f3] font-black text-base px-1.5 py-0.5 rounded shadow-xs">
                  {secStr[0]}
                </span>
                <span className="bg-white text-[#2196f3] font-black text-base px-1.5 py-0.5 rounded shadow-xs">
                  {secStr[1]}
                </span>
              </div>
              <span className="text-[10px] text-white/80 font-mono mt-1 tracking-tight truncate max-w-full">
                {periodId}
              </span>
            </div>
          </div>
        </div>

        {/* Betting Board Card (With 5-second drawing overlay covering only betting controls) */}
        <div className="relative bg-white rounded-2xl p-4 shadow-sm border border-slate-100 space-y-4 overflow-hidden">
          {/* 5-second Countdown Overlay: covers ONLY the betting board area */}
          {timeLeft <= 5 && (
            <div
              className="absolute inset-0 z-20 bg-black/75 backdrop-blur-xs rounded-2xl flex flex-col items-center justify-center p-4 animate-in fade-in duration-150 text-center"
              id="betting-closed-overlay"
            >
              <div className="text-white font-black text-xs tracking-widest uppercase mb-3 animate-pulse">
                Drawing Result in
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-16 h-22 bg-white rounded-2xl flex items-center justify-center shadow-2xl border-2 border-white/80">
                  <span className="text-5xl font-black text-[#2196f3] font-mono">
                    {secStr[0]}
                  </span>
                </div>
                <div className="w-16 h-22 bg-white rounded-2xl flex items-center justify-center shadow-2xl border-2 border-white/80">
                  <span className="text-5xl font-black text-[#2196f3] font-mono">
                    {secStr[1]}
                  </span>
                </div>
              </div>
              <p className="text-white/90 text-xs font-semibold mt-3.5">
                Betting closed for period
              </p>
              <span className="text-amber-300 font-mono text-[11px] mt-0.5 font-bold">
                {periodId}
              </span>
            </div>
          )}

          {/* Color buttons (Green 2x, Violet 4.5x, Red 2x) */}
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={() => openBetModal('color', 'green')}
              disabled={timeLeft <= 5}
              className="py-2.5 rounded-xl font-extrabold text-white text-sm bg-gradient-to-r from-[#22c55e] to-[#15803d] shadow-sm hover:brightness-105 active:scale-95 transition-all disabled:opacity-50"
              id="bet-color-green"
            >
              Green
              <span className="block text-[10px] font-normal opacity-90">2X</span>
            </button>
            <button
              onClick={() => openBetModal('color', 'violet')}
              disabled={timeLeft <= 5}
              className="py-2.5 rounded-xl font-extrabold text-white text-sm bg-gradient-to-r from-[#a855f7] to-[#7e22ce] shadow-sm hover:brightness-105 active:scale-95 transition-all disabled:opacity-50"
              id="bet-color-violet"
            >
              Violet
              <span className="block text-[10px] font-normal opacity-90">4.5X</span>
            </button>
            <button
              onClick={() => openBetModal('color', 'red')}
              disabled={timeLeft <= 5}
              className="py-2.5 rounded-xl font-extrabold text-white text-sm bg-gradient-to-r from-[#ef4444] to-[#b91c1c] shadow-sm hover:brightness-105 active:scale-95 transition-all disabled:opacity-50"
              id="bet-color-red"
            >
              Red
              <span className="block text-[10px] font-normal opacity-90">2X</span>
            </button>
          </div>

          {/* Number balls (0-9) */}
          <div className="grid grid-cols-5 gap-3 py-1">
            {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => {
              const bgClass = getBallBadge(num);
              return (
                <button
                  key={num}
                  onClick={() => openBetModal('number', num.toString())}
                  disabled={timeLeft <= 5}
                  className={`w-13 h-13 mx-auto rounded-full flex flex-col items-center justify-center font-black text-lg shadow-sm border-2 border-white transition-transform active:scale-90 hover:scale-105 disabled:opacity-50 ${bgClass}`}
                  id={`bet-number-${num}`}
                >
                  <span>{num}</span>
                  <span className="text-[9px] -mt-1 font-normal opacity-90">9X</span>
                </button>
              );
            })}
          </div>

          {/* Multiplier Chips Row */}
          <div className="flex items-center justify-between space-x-1.5 overflow-x-auto py-1">
            <button
              onClick={() => {
                const rand = Math.floor(Math.random() * 10);
                openBetModal('number', rand.toString());
              }}
              className="px-2.5 py-1 rounded-lg border border-red-300 text-red-500 text-xs font-semibold hover:bg-red-50"
              id="bet-random-btn"
            >
              Random
            </button>
            {[1, 5, 10, 20, 50, 100].map((m) => (
              <button
                key={m}
                onClick={() => setMultiplier(m)}
                className={`px-2 py-1 rounded-lg text-xs font-bold transition-colors ${
                  multiplier === m
                    ? 'bg-[#22c55e] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
                id={`multiplier-chip-x${m}`}
              >
                X{m}
              </button>
            ))}
          </div>

          {/* Big / Small Buttons */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <button
              onClick={() => openBetModal('size', 'Big')}
              disabled={timeLeft <= 5}
              className="py-2.5 rounded-xl font-extrabold text-white text-sm bg-gradient-to-r from-[#f97316] to-[#ea580c] shadow-sm active:scale-95 transition-all disabled:opacity-50"
              id="bet-size-big"
            >
              Big
              <span className="block text-[10px] font-normal opacity-90">1.98X (5-9)</span>
            </button>
            <button
              onClick={() => openBetModal('size', 'Small')}
              disabled={timeLeft <= 5}
              className="py-2.5 rounded-xl font-extrabold text-white text-sm bg-gradient-to-r from-[#3b82f6] to-[#2563eb] shadow-sm active:scale-95 transition-all disabled:opacity-50"
              id="bet-size-small"
            >
              Small
              <span className="block text-[10px] font-normal opacity-90">1.98X (0-4)</span>
            </button>
          </div>
        </div>

        {/* History / Chart / Strategy / My Bets Tabs (Matching Photo UI) */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          {/* Sub-tab Pill Navigation */}
          <div className="flex items-center space-x-2 p-2.5 bg-slate-50 border-b border-slate-100 overflow-x-auto scrollbar-none">
            <button
              onClick={() => { setActiveTab('history'); setHistoryPage(1); }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                activeTab === 'history'
                  ? 'bg-[#2196f3] text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200/80 hover:bg-slate-100'
              }`}
              id="tab-game-history"
            >
              Game history
            </button>
            <button
              onClick={() => { setActiveTab('chart'); setChartPage(1); }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                activeTab === 'chart'
                  ? 'bg-[#2196f3] text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200/80 hover:bg-slate-100'
              }`}
              id="tab-chart"
            >
              Chart Trend
            </button>
            <button
              onClick={() => setActiveTab('strategy')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                activeTab === 'strategy'
                  ? 'bg-[#2196f3] text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200/80 hover:bg-slate-100'
              }`}
              id="tab-strategy"
            >
              Follow Strategy
            </button>
            <button
              onClick={() => { setActiveTab('mybets'); setMyBetsPage(1); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center space-x-1.5 ${
                activeTab === 'mybets'
                  ? 'bg-[#2196f3] text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200/80 hover:bg-slate-100'
              }`}
              id="tab-mybets"
            >
              <span>My history</span>
              {safeUserBets.length > 0 && (
                <span className={`px-1.5 py-0.2 text-[10px] rounded-full font-bold ${
                  activeTab === 'mybets' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                }`}>
                  {safeUserBets.length}
                </span>
              )}
            </button>
          </div>

          {/* 1. Game History Tab (10 results per page with Prev / Next) */}
          {activeTab === 'history' && (
            <div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-center">
                  <thead>
                    <tr className="bg-[#29303d] text-white font-bold">
                      <th className="py-2.5 px-3">Period</th>
                      <th className="py-2.5 px-2">Number</th>
                      <th className="py-2.5 px-2">Big Small</th>
                      <th className="py-2.5 px-3">Color</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {gameHistory.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-8 text-slate-400 text-center">
                          Loading {gameType} history...
                        </td>
                      </tr>
                    ) : (
                      gameHistory
                        .slice((historyPage - 1) * historyPageSize, historyPage * historyPageSize)
                        .map((item, itemIdx) => {
                          const isGreen = [1, 3, 7, 9].includes(item.number);
                          const isRed = [2, 4, 6, 8].includes(item.number);
                          const isSpecial = item.number === 0 || item.number === 5;
                          const isBig = item.bigSmall === 'Big';

                          return (
                            <tr key={`hist-${item.periodId || 'p'}-${itemIdx}`} className="hover:bg-slate-50/80 transition-colors">
                              <td className="py-2.5 px-3 font-mono text-slate-500 font-medium">
                                {item.periodId}
                              </td>
                              <td className="py-2.5 px-2">
                                <span
                                  className={`inline-flex items-center justify-center w-6 h-6 rounded-full font-black text-xs text-white shadow-2xs ${
                                    item.number === 0
                                      ? 'bg-gradient-to-r from-red-500 to-purple-600'
                                      : item.number === 5
                                      ? 'bg-gradient-to-r from-green-500 to-purple-600'
                                      : isGreen
                                      ? 'bg-green-500'
                                      : 'bg-red-500'
                                  }`}
                                >
                                  {item.number}
                                </span>
                              </td>
                              <td className="py-2.5 px-2">
                                <span
                                  className={`px-2.5 py-0.5 rounded-lg text-[11px] font-bold ${
                                    isBig
                                      ? 'bg-amber-100 text-amber-700'
                                      : 'bg-blue-100 text-blue-700'
                                  }`}
                                >
                                  {item.bigSmall}
                                </span>
                              </td>
                              <td className="py-2.5 px-3">
                                <div className="flex items-center justify-center">
                                  {getNumberColorDot(item.number)}
                                </div>
                              </td>
                            </tr>
                          );
                        })
                    )}
                  </tbody>
                </table>
              </div>

              {/* History Pagination Bar (10 results and Prev/Next btn) */}
              <div className="flex items-center justify-between px-3 py-2.5 bg-slate-50 border-t border-slate-100 text-xs">
                <span className="text-slate-400 font-medium text-[11px]">
                  Showing {Math.min(gameHistory.length, (historyPage - 1) * historyPageSize + 1)} - {Math.min(gameHistory.length, historyPage * historyPageSize)} of {gameHistory.length}
                </span>
                <div className="flex items-center space-x-1.5">
                  <button
                    disabled={historyPage <= 1}
                    onClick={() => setHistoryPage((p) => Math.max(1, p - 1))}
                    className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 font-bold disabled:opacity-40 hover:bg-slate-100 active:scale-95 transition-all text-xs"
                    id="history-prev-btn"
                  >
                    &lt; Prev
                  </button>
                  <span className="px-2 font-bold text-slate-600 text-xs">
                    {historyPage} / {Math.ceil(gameHistory.length / historyPageSize) || 1}
                  </span>
                  <button
                    disabled={historyPage >= Math.ceil(gameHistory.length / historyPageSize)}
                    onClick={() => setHistoryPage((p) => p + 1)}
                    className="px-3 py-1 rounded-lg bg-[#2196f3] text-white font-bold disabled:opacity-40 hover:bg-blue-600 active:scale-95 shadow-xs transition-all text-xs"
                    id="history-next-btn"
                  >
                    Next &gt;
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 2. Chart Trend Tab */}
          {activeTab === 'chart' && (
            <div className="p-3 space-y-4">
              {/* Last 10 Numbers Sequence */}
              <div>
                <div className="text-xs text-slate-500 font-semibold mb-2 flex items-center justify-between">
                  <span>Last 10 Drawn Numbers ({gameType})</span>
                  <span className="text-[11px] text-slate-400">Latest &rarr; Oldest</span>
                </div>
                <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  {gameHistory.slice(0, 10).map((h, i) => (
                    <div key={i} className="flex flex-col items-center space-y-1">
                      <span
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black shadow-xs ${getBallBadge(
                          h.number
                        )}`}
                      >
                        {h.number}
                      </span>
                      <span className={`text-[10px] font-bold ${h.bigSmall === 'Big' ? 'text-amber-600' : 'text-blue-600'}`}>
                        {h.bigSmall[0]}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Statistics Overview */}
              <div className="grid grid-cols-4 gap-2 text-center text-xs">
                <div className="bg-red-50/70 border border-red-100 p-2 rounded-xl">
                  <span className="text-slate-400 block text-[10px]">Red</span>
                  <span className="text-base font-black text-red-500">
                    {safeGameHistory.filter((h) => [2, 4, 6, 8, 0].includes(h.number)).length}
                  </span>
                </div>
                <div className="bg-green-50/70 border border-green-100 p-2 rounded-xl">
                  <span className="text-slate-400 block text-[10px]">Green</span>
                  <span className="text-base font-black text-green-500">
                    {safeGameHistory.filter((h) => [1, 3, 7, 9, 5].includes(h.number)).length}
                  </span>
                </div>
                <div className="bg-amber-50/70 border border-amber-100 p-2 rounded-xl">
                  <span className="text-slate-400 block text-[10px]">Big</span>
                  <span className="text-base font-black text-amber-500">
                    {safeGameHistory.filter((h) => h.number >= 5).length}
                  </span>
                </div>
                <div className="bg-blue-50/70 border border-blue-100 p-2 rounded-xl">
                  <span className="text-slate-400 block text-[10px]">Small</span>
                  <span className="text-base font-black text-blue-500">
                    {safeGameHistory.filter((h) => h.number < 5).length}
                  </span>
                </div>
              </div>

              {/* Trend Chart Matrix (10 results per page) */}
              <div className="border border-slate-100 rounded-xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-center text-xs">
                    <thead>
                      <tr className="bg-slate-100 text-slate-600 font-bold border-b border-slate-200 text-[11px]">
                        <th className="py-2 px-2">Period</th>
                        <th className="py-2 px-1">No.</th>
                        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
                          <th key={n} className="py-2 px-1 w-6">{n}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                      {gameHistory
                        .slice((chartPage - 1) * chartPageSize, chartPage * chartPageSize)
                        .map((item, rowIdx) => {
                          return (
                            <tr key={`trend-${item.periodId || 'p'}-${rowIdx}`} className="hover:bg-slate-50/70 transition-colors">
                              <td className="py-2 px-2 text-slate-500 text-[10px]">
                                {item.periodId.slice(-5)}
                              </td>
                              <td className="py-2 px-1 font-bold">
                                <span className={`inline-flex items-center justify-center w-5 h-5 rounded-full text-white text-[10px] font-black ${getBallBadge(item.number)}`}>
                                  {item.number}
                                </span>
                              </td>
                              {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => {
                                const isHit = item.number === digit;
                                return (
                                  <td key={digit} className="py-2 px-1">
                                    {isHit ? (
                                      <span className={`inline-flex items-center justify-center w-5 h-5 rounded-full text-white text-[10px] font-bold shadow-2xs ${getBallBadge(digit)}`}>
                                        {digit}
                                      </span>
                                    ) : (
                                      <span className="text-slate-300 text-[10px]">
                                        {(rowIdx + digit) % 8 + 1}
                                      </span>
                                    )}
                                  </td>
                                );
                              })}
                            </tr>
                          );
                        })}
                    </tbody>
                  </table>
                </div>

                {/* Chart Pagination Bar */}
                <div className="flex items-center justify-between px-3 py-2.5 bg-slate-50 border-t border-slate-100 text-xs">
                  <span className="text-slate-400 font-medium text-[11px]">
                    Page {chartPage} of {Math.ceil(gameHistory.length / chartPageSize) || 1}
                  </span>
                  <div className="flex items-center space-x-1.5">
                    <button
                      disabled={chartPage <= 1}
                      onClick={() => setChartPage((p) => Math.max(1, p - 1))}
                      className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 font-bold disabled:opacity-40 hover:bg-slate-100 active:scale-95 transition-all text-xs"
                    >
                      &lt; Prev
                    </button>
                    <button
                      disabled={chartPage >= Math.ceil(gameHistory.length / chartPageSize)}
                      onClick={() => setChartPage((p) => p + 1)}
                      className="px-3 py-1 rounded-lg bg-[#2196f3] text-white font-bold disabled:opacity-40 hover:bg-blue-600 active:scale-95 shadow-xs transition-all text-xs"
                    >
                      Next &gt;
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 3. Follow Strategy Tab */}
          {activeTab === 'strategy' && (
            <div className="p-3.5 space-y-3.5">
              {/* Algorithmic Recommendation Card */}
              <div className="bg-gradient-to-br from-blue-50/60 to-slate-50 border border-blue-100 rounded-2xl p-3.5 shadow-2xs">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-1.5">
                    <Sparkles className="w-4 h-4 text-[#2196f3]" />
                    <span className="font-bold text-slate-800 text-xs">AI Trend Prediction ({gameType})</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-blue-100 text-[#2196f3] text-[10px] font-bold">
                    84% Confidence
                  </span>
                </div>
                <div className="text-xs text-slate-600 mb-3">
                  Analysis of previous 10 rounds indicates a strong momentum towards:
                </div>
                <div className="flex items-center justify-between bg-white rounded-xl p-2.5 border border-blue-100 shadow-2xs">
                  <div className="flex items-center space-x-2.5">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-[#3b82f6] to-[#2563eb] text-white font-extrabold flex items-center justify-center text-sm shadow-xs">
                      Small
                    </div>
                    <div>
                      <div className="font-bold text-slate-800 text-xs">Recommended: Small (0-4)</div>
                      <div className="text-[11px] text-slate-400">Payout 1.98X &bull; Period #{periodId.slice(-4)}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => openBetModal('size', 'Small')}
                    disabled={timeLeft <= 5}
                    className="px-3.5 py-1.5 rounded-xl bg-[#2196f3] text-white font-bold text-xs hover:bg-blue-600 active:scale-95 shadow-xs disabled:opacity-50 transition-all"
                  >
                    Quick Bet
                  </button>
                </div>
              </div>

              {/* Trend Statistics Cards */}
              <div className="grid grid-cols-2 gap-2.5">
                <div className="bg-white border border-slate-100 rounded-xl p-3 shadow-2xs">
                  <div className="flex items-center space-x-1 text-slate-400 text-[11px] mb-1">
                    <Flame className="w-3.5 h-3.5 text-amber-500" />
                    <span>Hot Numbers</span>
                  </div>
                  <div className="flex items-center space-x-1.5 mt-1">
                    {[8, 9, 5].map((n) => (
                      <span key={n} className={`w-6 h-6 rounded-full text-white font-black text-xs flex items-center justify-center shadow-xs ${getBallBadge(n)}`}>
                        {n}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-white border border-slate-100 rounded-xl p-3 shadow-2xs">
                  <div className="flex items-center space-x-1 text-slate-400 text-[11px] mb-1">
                    <TrendingUp className="w-3.5 h-3.5 text-blue-500" />
                    <span>Pattern Type</span>
                  </div>
                  <div className="font-bold text-slate-700 text-xs mt-1">
                    Dragon Follow (Big &bull; Small)
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 4. My History Tab (Winning and Loss History Matching User Photo) */}
          {activeTab === 'mybets' && (
            <div>
              {/* Filter Sub-Bar */}
              <div className="flex items-center justify-between px-3 py-2 bg-slate-50 border-b border-slate-100 text-xs">
                {/* Game Type Filter */}
                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => { setMyBetsGameTypeFilter('all'); setMyBetsPage(1); }}
                    className={`px-2 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                      myBetsGameTypeFilter === 'all'
                        ? 'bg-slate-800 text-white shadow-xs'
                        : 'text-slate-500 hover:bg-slate-200/60'
                    }`}
                  >
                    All
                  </button>
                  <button
                    onClick={() => { setMyBetsGameTypeFilter(gameType); setMyBetsPage(1); }}
                    className={`px-2 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                      myBetsGameTypeFilter === gameType
                        ? 'bg-slate-800 text-white shadow-xs'
                        : 'text-slate-500 hover:bg-slate-200/60'
                    }`}
                  >
                    {gameType}
                  </button>
                </div>

                {/* Status Filter */}
                <div className="flex items-center space-x-1">
                  {(['all', 'won', 'lost', 'pending'] as const).map((st) => (
                    <button
                      key={st}
                      onClick={() => { setMyBetsStatusFilter(st); setMyBetsPage(1); }}
                      className={`px-2 py-0.5 rounded-md text-[10px] font-bold capitalize transition-all ${
                        myBetsStatusFilter === st
                          ? st === 'won'
                            ? 'bg-emerald-500 text-white'
                            : st === 'lost'
                            ? 'bg-red-500 text-white'
                            : st === 'pending'
                            ? 'bg-amber-500 text-white'
                            : 'bg-slate-600 text-white'
                          : 'text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      {st === 'won' ? 'Succeed' : st === 'lost' ? 'Failed' : st}
                    </button>
                  ))}
                </div>
              </div>

              {/* Bet Cards List */}
              <div className="divide-y divide-slate-100">
                {(() => {
                  const filtered = safeUserBets.filter((b) => {
                    if (myBetsGameTypeFilter !== 'all' && b.gameType !== myBetsGameTypeFilter) return false;
                    if (myBetsStatusFilter === 'won' && b.status !== 'won') return false;
                    if (myBetsStatusFilter === 'lost' && b.status !== 'lost') return false;
                    if (myBetsStatusFilter === 'pending' && b.status !== 'pending') return false;
                    return true;
                  });

                  if (filtered.length === 0) {
                    return (
                      <div className="text-center py-10 text-slate-400 text-xs">
                        No bets found matching your filter. Place your bet above!
                      </div>
                    );
                  }

                  const start = (myBetsPage - 1) * myBetsPageSize;
                  const pageItems = filtered.slice(start, start + myBetsPageSize);

                  return pageItems.map((b, bIdx) => {
                    const isExpanded = expandedBetId === b.id;
                    const isWon = b.status === 'won';
                    const isLost = b.status === 'lost';
                    const isPending = b.status === 'pending';

                    return (
                      <div key={`mybet-${b.id || 'b'}-${bIdx}`} className="hover:bg-slate-50/60 transition-colors">
                        <div
                          onClick={() => setExpandedBetId(isExpanded ? null : b.id)}
                          className="px-3.5 py-3 flex items-center justify-between cursor-pointer"
                        >
                          {/* Left Value Badge (Matching Screenshot) */}
                          <div className="flex items-center space-x-3">
                            {b.selectValue.toLowerCase() === 'small' ? (
                              <div className="w-14 h-9 rounded-xl bg-[#4a90e2] text-white font-bold text-xs flex items-center justify-center shadow-xs">
                                Small
                              </div>
                            ) : b.selectValue.toLowerCase() === 'big' ? (
                              <div className="w-14 h-9 rounded-xl bg-[#f59e0b] text-white font-bold text-xs flex items-center justify-center shadow-xs">
                                Big
                              </div>
                            ) : b.selectValue.toLowerCase() === 'green' ? (
                              <div className="w-14 h-9 rounded-xl bg-[#22c55e] text-white font-bold text-xs flex items-center justify-center shadow-xs">
                                Green
                              </div>
                            ) : b.selectValue.toLowerCase() === 'red' ? (
                              <div className="w-14 h-9 rounded-xl bg-[#ef4444] text-white font-bold text-xs flex items-center justify-center shadow-xs">
                                Red
                              </div>
                            ) : b.selectValue.toLowerCase() === 'violet' ? (
                              <div className="w-14 h-9 rounded-xl bg-[#a855f7] text-white font-bold text-xs flex items-center justify-center shadow-xs">
                                Violet
                              </div>
                            ) : (
                              <div className={`w-14 h-9 rounded-xl text-white font-black text-xs flex items-center justify-center shadow-xs ${getBallBadge(Number(b.selectValue))}`}>
                                No. {b.selectValue}
                              </div>
                            )}

                            {/* Middle Period & Date */}
                            <div>
                              <div className="flex items-center space-x-1 font-mono text-xs font-semibold text-slate-800">
                                <span>{b.periodId}</span>
                                <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
                              </div>
                              <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                                {formatBetDate(b.createdAt)}
                              </div>
                            </div>
                          </div>

                          {/* Right Result Status (Matching Screenshot) */}
                          <div className="text-right">
                            {isWon ? (
                              <div>
                                <span className="border border-emerald-400 text-emerald-500 rounded-lg px-2.5 py-0.5 text-xs font-semibold inline-block">
                                  Succeed
                                </span>
                                <div className="text-emerald-500 font-bold text-xs mt-1">
                                  +৳{(b.winAmount || (b.totalAmount * 1.98)).toFixed(2)}
                                </div>
                              </div>
                            ) : isLost ? (
                              <div>
                                <span className="border border-red-300 text-red-400 rounded-lg px-2.5 py-0.5 text-xs font-semibold inline-block">
                                  Failed
                                </span>
                                <div className="text-red-400 font-medium text-xs mt-1">
                                  -৳{b.totalAmount.toFixed(2)}
                                </div>
                              </div>
                            ) : (
                              <div>
                                <span className="border border-amber-300 text-amber-500 rounded-lg px-2.5 py-0.5 text-xs font-semibold inline-block">
                                  Waiting
                                </span>
                                <div className="text-amber-500 font-medium text-xs mt-1">
                                  Pending
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Accordion Expanded Detail Drawer */}
                        {isExpanded && (
                          <div className="px-3.5 pb-3.5 pt-1 text-xs bg-slate-50/70 border-t border-slate-100">
                            <div className="bg-white rounded-xl p-3 border border-slate-100 shadow-2xs space-y-2">
                              <div className="font-bold text-slate-800 text-xs pb-1.5 border-b border-slate-100 flex items-center justify-between">
                                <span>Order Details</span>
                                <span className="text-[10px] text-slate-400 font-mono">{b.id}</span>
                              </div>
                              <div className="grid grid-cols-2 gap-y-1.5 text-[11px]">
                                <div className="text-slate-400">Game Type:</div>
                                <div className="font-semibold text-right text-slate-700">Win Go {b.gameType}</div>
                                <div className="text-slate-400">Selection:</div>
                                <div className="font-bold text-right text-[#ff4747] capitalize">{b.selectType} ({b.selectValue})</div>
                                <div className="text-slate-400">Unit Amount:</div>
                                <div className="font-medium text-right text-slate-700">৳{b.amount}</div>
                                <div className="text-slate-400">Multiplier:</div>
                                <div className="font-medium text-right text-slate-700">X{b.multiplier}</div>
                                <div className="text-slate-400">Total Purchase:</div>
                                <div className="font-bold text-right text-slate-800">৳{b.totalAmount.toFixed(2)}</div>
                                <div className="text-slate-400">Service Fee (2%):</div>
                                <div className="font-medium text-right text-slate-500">৳{(b.totalAmount * 0.02).toFixed(2)}</div>
                                <div className="text-slate-400">Delivery Amount:</div>
                                <div className="font-medium text-right text-slate-700">৳{(b.totalAmount * 0.98).toFixed(2)}</div>
                                {b.resultNumber !== undefined && (
                                  <>
                                    <div className="text-slate-400">Result Number:</div>
                                    <div className="font-bold text-right flex items-center justify-end space-x-1">
                                      <span className={`w-5 h-5 rounded-full text-white text-[10px] font-black flex items-center justify-center ${getBallBadge(b.resultNumber)}`}>
                                        {b.resultNumber}
                                      </span>
                                      <span className="text-slate-600">({getNumberSize(b.resultNumber)})</span>
                                    </div>
                                  </>
                                )}
                                <div className="text-slate-400">Status:</div>
                                <div className="font-bold text-right">
                                  {isWon ? (
                                    <span className="text-emerald-500">Succeed (+৳{(b.winAmount || (b.totalAmount * 1.98)).toFixed(2)})</span>
                                  ) : isLost ? (
                                    <span className="text-red-400">Failed (-৳{b.totalAmount.toFixed(2)})</span>
                                  ) : (
                                    <span className="text-amber-500">Waiting for Draw</span>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  });
                })()}
              </div>

              {/* My Bets Pagination Bar (10 results per page and Prev/Next btn) */}
              {(() => {
                const filtered = safeUserBets.filter((b) => {
                  if (myBetsGameTypeFilter !== 'all' && b.gameType !== myBetsGameTypeFilter) return false;
                  if (myBetsStatusFilter === 'won' && b.status !== 'won') return false;
                  if (myBetsStatusFilter === 'lost' && b.status !== 'lost') return false;
                  if (myBetsStatusFilter === 'pending' && b.status !== 'pending') return false;
                  return true;
                });
                const totalPages = Math.ceil(filtered.length / myBetsPageSize) || 1;

                return (
                  <div className="flex items-center justify-between px-3 py-2.5 bg-slate-50 border-t border-slate-100 text-xs">
                    <span className="text-slate-400 font-medium text-[11px]">
                      Showing {Math.min(filtered.length, (myBetsPage - 1) * myBetsPageSize + 1)} - {Math.min(filtered.length, myBetsPage * myBetsPageSize)} of {filtered.length}
                    </span>
                    <div className="flex items-center space-x-1.5">
                      <button
                        disabled={myBetsPage <= 1}
                        onClick={() => setMyBetsPage((p) => Math.max(1, p - 1))}
                        className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 font-bold disabled:opacity-40 hover:bg-slate-100 active:scale-95 transition-all text-xs"
                        id="mybets-prev-btn"
                      >
                        &lt; Prev
                      </button>
                      <span className="px-2 font-bold text-slate-600 text-xs">
                        {myBetsPage} / {totalPages}
                      </span>
                      <button
                        disabled={myBetsPage >= totalPages}
                        onClick={() => setMyBetsPage((p) => p + 1)}
                        className="px-3 py-1 rounded-lg bg-[#2196f3] text-white font-bold disabled:opacity-40 hover:bg-blue-600 active:scale-95 shadow-xs transition-all text-xs"
                        id="mybets-next-btn"
                      >
                        Next &gt;
                      </button>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      </div>

      {/* Bet Placement Bottom Sheet Modal (Matching Screenshot_20260910-163045.png) */}
      {isBetModalOpen && (() => {
        // Calculate dynamic color theme based on selected bet
        const getBetColorTheme = () => {
          if (selectedBetType === 'size') {
            if (selectedBetValue.toLowerCase() === 'big') {
              return {
                bgColor: '#f97316',
                textColor: 'text-[#f97316]',
                name: 'Big'
              };
            }
            return {
              bgColor: '#3b82f6',
              textColor: 'text-[#3b82f6]',
              name: 'Small'
            };
          }
          if (selectedBetType === 'color') {
            if (selectedBetValue.toLowerCase() === 'green') {
              return {
                bgColor: '#22c55e',
                textColor: 'text-[#22c55e]',
                name: 'Green'
              };
            }
            if (selectedBetValue.toLowerCase() === 'red') {
              return {
                bgColor: '#ef4444',
                textColor: 'text-[#ef4444]',
                name: 'Red'
              };
            }
            return {
              bgColor: '#a855f7',
              textColor: 'text-[#a855f7]',
              name: 'Violet'
            };
          }
          // Number bets
          const n = parseInt(selectedBetValue, 10);
          if (n === 0) {
            return {
              bgColor: '#9c27b0',
              textColor: 'text-[#9c27b0]',
              name: '0'
            };
          }
          if (n === 5) {
            return {
              bgColor: '#22c55e',
              textColor: 'text-[#22c55e]',
              name: '5'
            };
          }
          if ([1, 3, 7, 9].includes(n)) {
            return {
              bgColor: '#22c55e',
              textColor: 'text-[#22c55e]',
              name: selectedBetValue
            };
          }
          return {
            bgColor: '#ef4444',
            textColor: 'text-[#ef4444]',
            name: selectedBetValue
          };
        };

        const theme = getBetColorTheme();

        return (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col justify-end animate-in fade-in duration-150">
            <div className="bg-white rounded-t-3xl max-w-md w-full mx-auto overflow-hidden shadow-2xl animate-in slide-in-from-bottom duration-200">
              {/* Dynamic Colored Modal Header with Chevron Pointer Notch */}
              <div
                className="relative text-white text-center pt-3 pb-6 px-4 transition-colors"
                style={{ backgroundColor: theme.bgColor }}
              >
                <div className="text-xs font-medium text-white/95">
                  WinGo {gameType === '30s' ? '30sec' : gameType}
                </div>
                <div className="bg-white text-slate-800 font-bold text-xs py-1 px-8 rounded-full inline-block mt-1.5 shadow-xs">
                  Select {selectedBetValue}
                </div>
                {/* Downward triangle notch pointing to white sheet */}
                <div
                  className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[8px]"
                  style={{ borderTopColor: theme.bgColor }}
                />
              </div>

              <div className="p-4 pt-5 space-y-4">
                {/* Balance Selector Row (1, 10, 100, 1000) */}
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-800 font-bold">Balance</span>
                  <div className="flex items-center space-x-2">
                    {[1, 10, 100, 1000].map((val) => {
                      const isSel = baseBalance === val;
                      return (
                        <button
                          key={val}
                          onClick={() => setBaseBalance(val)}
                          className={`w-12 py-1 rounded-lg text-xs font-bold transition-all ${
                            isSel
                              ? 'text-white shadow-xs'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                          style={isSel ? { backgroundColor: theme.bgColor } : undefined}
                          id={`bet-balance-${val}`}
                        >
                          {val}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Quantity Stepper Row */}
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-800 font-bold">Quantity</span>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => {
                        const cur = parseInt(quantityInput, 10) || 1;
                        setQuantityInput(String(Math.max(1, cur - 1)));
                      }}
                      className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 font-bold text-slate-600 flex items-center justify-center active:scale-95 text-base transition-colors"
                      id="quantity-minus-btn"
                    >
                      -
                    </button>
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      value={quantityInput}
                      placeholder="1"
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === '' || /^\d+$/.test(val)) {
                          setQuantityInput(val);
                        }
                      }}
                      onBlur={() => {
                        if (!quantityInput || parseInt(quantityInput, 10) < 1) {
                          setQuantityInput('1');
                        }
                      }}
                      className="w-20 text-center font-bold text-slate-800 text-sm py-1 bg-white rounded-lg border border-slate-200 focus:outline-none focus:ring-1 focus:ring-slate-300"
                    />
                    <button
                      onClick={() => {
                        const cur = parseInt(quantityInput, 10) || 1;
                        setQuantityInput(String(cur + 1));
                      }}
                      className="w-8 h-8 rounded-lg text-white font-bold flex items-center justify-center active:scale-95 text-base shadow-xs transition-transform"
                      style={{ backgroundColor: theme.bgColor }}
                      id="quantity-plus-btn"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Multiplier Chips Row */}
                <div className="flex items-center justify-between space-x-1.5 pt-1">
                  {[1, 5, 10, 20, 50, 100].map((m) => {
                    const isSel = multiplier === m;
                    return (
                      <button
                        key={m}
                        onClick={() => setMultiplier(m)}
                        className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                          isSel
                            ? 'text-white shadow-xs'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                        style={isSel ? { backgroundColor: theme.bgColor } : undefined}
                        id={`modal-mult-x${m}`}
                      >
                        X{m}
                      </button>
                    );
                  })}
                </div>

                {/* Pre-sale Rules Agreement Checkbox */}
                <div
                  onClick={() => setAgreeRules(!agreeRules)}
                  className="flex items-center space-x-2 pt-1 cursor-pointer select-none"
                >
                  <div
                    className={`w-4 h-4 rounded-full flex items-center justify-center transition-colors ${
                      agreeRules ? 'bg-[#2196f3] text-white' : 'border border-slate-300 bg-white'
                    }`}
                  >
                    {agreeRules && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <span className="text-xs text-slate-600 font-medium">
                    I agree <span className="text-[#2196f3]">《Pre-sale rules》</span>
                  </span>
                </div>
              </div>

              {/* Bottom Action Buttons (Cancel / Total Amount) */}
              <div className="grid grid-cols-2 mt-2">
                <button
                  onClick={() => setIsBetModalOpen(false)}
                  className="py-3.5 text-center font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 text-sm transition-colors"
                  id="bet-modal-cancel-btn"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmBet}
                  disabled={isPlacing || timeLeft <= 5}
                  className="py-3.5 text-center font-bold text-white text-sm hover:brightness-105 active:scale-98 transition-all disabled:opacity-50"
                  style={{ backgroundColor: theme.bgColor }}
                  id="bet-modal-confirm-btn"
                >
                  {isPlacing ? 'Placing...' : `Total amount ৳${totalBetAmount.toFixed(2)}`}
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Win Celebration Modal */}
      {/* Settlement Win/Loss Result Modal */}
      <GameResultModal data={lastWinModal} onClose={closeWinModal} />

      {/* Rules Modal */}
      {ruleModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 space-y-3 shadow-2xl">
            <h3 className="font-bold text-slate-900 text-base">Win Go Game Rules</h3>
            <div className="text-xs text-slate-600 space-y-2 leading-relaxed max-h-72 overflow-y-auto">
              <p>
                <strong>Green:</strong> If result shows 1, 3, 7, 9, you win 2X. If 5, you win 1.5X.
              </p>
              <p>
                <strong>Red:</strong> If result shows 2, 4, 6, 8, you win 2X. If 0, you win 1.5X.
              </p>
              <p>
                <strong>Violet:</strong> If result shows 0 or 5, you win 4.5X.
              </p>
              <p>
                <strong>Number (0-9):</strong> If the chosen number matches exactly, you win 9X!
              </p>
              <p>
                <strong>Big / Small:</strong> Big (5,6,7,8,9), Small (0,1,2,3,4) pays 1.98X.
              </p>
              <p>
                <strong>Betting Window:</strong> Each round closes 5 seconds before completion for
                live verification.
              </p>
            </div>
            <button
              onClick={() => setRuleModalOpen(false)}
              className="w-full py-2 bg-[#2196f3] text-white font-bold rounded-xl hover:bg-blue-600 transition-colors"
              id="close-rule-modal-btn"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
