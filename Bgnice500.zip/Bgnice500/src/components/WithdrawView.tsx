import React, { useState } from 'react';
import { ArrowLeft, RefreshCw, Check, Plus, AlertCircle, Trash2, ShieldCheck, CreditCard, Eye, EyeOff, ArrowUpDown, DollarSign } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SavedWithdrawAccount, WithdrawalItem } from '../types';
import { PAYMENT_LOGOS } from '../utils/paymentLogos';

interface WithdrawViewProps {
  onBack: () => void;
}

export const WithdrawView: React.FC<WithdrawViewProps> = ({ onBack }) => {
  const {
    user,
    withdrawals,
    settings,
    showToast,
    submitWithdrawal,
    saveWithdrawAccount,
    deleteWithdrawAccount,
    refreshBalance,
    isRefreshingBalance,
    activeTurnoverReq,
    activeTurnoverRemaining
  } = useApp();

  const [withdrawType, setWithdrawType] = useState<'E-Wallet' | 'USDT'>('E-Wallet');
  const [amount, setAmount] = useState<string>('');
  const [usdtAmount, setUsdtAmount] = useState<string>('');
  const [showHistory, setShowHistory] = useState(false);
  const [showAddMethodModal, setShowAddMethodModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [revealedAccounts, setRevealedAccounts] = useState<{ [id: string]: boolean }>({});

  // Dynamic USDT rate and rules
  const dollarRate = settings.usdtRate || 125;
  const minUsdtWithdraw = settings.minWithdrawUsdt || 10;
  const minBdtWithdraw = minUsdtWithdraw * dollarRate;

  // Real-time bidirectional conversion handlers
  const handleBdtChange = (val: string) => {
    setAmount(val);
    const num = parseFloat(val);
    if (!val || isNaN(num) || num <= 0) {
      setUsdtAmount('');
    } else {
      const convertedUsdt = (num / dollarRate).toFixed(2);
      setUsdtAmount(convertedUsdt);
    }
  };

  const handleUsdtChange = (val: string) => {
    setUsdtAmount(val);
    const num = parseFloat(val);
    if (!val || isNaN(num) || num <= 0) {
      setAmount('');
    } else {
      const convertedBdt = (num * dollarRate).toFixed(2);
      setAmount(convertedBdt);
    }
  };

  const handleSelectUsdtPreset = (presetUsdt: number) => {
    setUsdtAmount(presetUsdt.toString());
    const bdt = (presetUsdt * dollarRate).toFixed(2);
    setAmount(bdt);
  };

  const handleSelectAllUsdt = () => {
    const maxBdt = withdrawableBalance;
    setAmount(maxBdt.toFixed(2));
    const convertedUsdt = (maxBdt / dollarRate).toFixed(2);
    setUsdtAmount(convertedUsdt);
  };

  const handleSwitchTab = (type: 'E-Wallet' | 'USDT') => {
    setWithdrawType(type);
    setNewWalletType(type === 'USDT' ? 'USDT' : 'BKASH');
    setAmount('');
    setUsdtAmount('');
  };

  // Helper to mask account number for privacy
  const maskAccountNumber = (num: string) => {
    if (!num) return '';
    const trimmed = num.trim();
    if (trimmed.length >= 10 && trimmed.length <= 13) {
      return trimmed.slice(0, 3) + '*****' + trimmed.slice(-2);
    }
    if (trimmed.length > 13) {
      return trimmed.slice(0, 4) + '******' + trimmed.slice(-3);
    }
    return trimmed.slice(0, 2) + '***' + trimmed.slice(-1);
  };

  const toggleReveal = (id: string) => {
    setRevealedAccounts((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Saved accounts: strictly from user profile, never auto-filled with dummy or admin numbers
  const allSavedAccounts: SavedWithdrawAccount[] = user?.savedWithdrawAccounts || [];
  const ewalletAccounts = allSavedAccounts.filter((a) => a.type !== 'USDT');
  const usdtAccounts = allSavedAccounts.filter((a) => a.type === 'USDT');

  const currentAccounts = withdrawType === 'E-Wallet' ? ewalletAccounts : usdtAccounts;
  const [selectedAccountId, setSelectedAccountId] = useState<string>(currentAccounts[0]?.id || '');
  const activeAccount = currentAccounts.find((a) => a.id === selectedAccountId) || currentAccounts[0];

  // Add new account form modal
  const [newWalletType, setNewWalletType] = useState<'BKASH' | 'NAGAD' | 'ROCKET' | 'USDT'>(
    withdrawType === 'USDT' ? 'USDT' : 'BKASH'
  );
  const [newWalletName, setNewWalletName] = useState('');
  const [newWalletNumber, setNewWalletNumber] = useState('');
  const [newWalletLogo, setNewWalletLogo] = useState('');

  // Strictly filter user withdrawals to guarantee account privacy
  const userWithdrawals = React.useMemo(() => {
    if (!user) return [];
    return (withdrawals || []).filter((w) => {
      if (!w) return false;
      return Boolean(
        (w.uid && w.uid === user.uid) ||
        ((w as any).userId && (w as any).userId === user.uid) ||
        (user.phone && w.phone && String(w.phone).trim() === String(user.phone).trim())
      );
    });
  }, [withdrawals, user]);

  // Turnover & Withdrawable balance calculation
  const totalBalance = Number(user?.balance || 0);
  const referralBonus = Number(user?.referralBalance || 0);
  const legacyTurnoverReq = Number(user?.turnoverReq || 0);
  const legacyTurnoverDone = Number(user?.turnoverDone || 0);
  const legacyRemaining = Math.max(0, Number((legacyTurnoverReq - legacyTurnoverDone).toFixed(2)));
  const turnoverRemaining = activeTurnoverReq > 0 ? activeTurnoverRemaining : legacyRemaining;

  const formatWithdrawOrderId = (w: WithdrawalItem): string => {
    if (w.orderId && w.orderId.startsWith('D')) return w.orderId;
    if (w.orderId) return 'D' + w.orderId.replace(/^[WD_]+/, '');
    const dateStr = new Date(w.createdAt || Date.now()).toISOString().slice(0, 10).replace(/-/g, '');
    const numPart = (w.id || '').replace(/[^0-9]/g, '').slice(-6).padStart(6, '7');
    return `D${dateStr}${numPart}`;
  };

  // Referral bonus has 0x turnover (never locked)
  const withdrawableBalance = turnoverRemaining <= 0
    ? totalBalance
    : Math.min(totalBalance, Math.max(referralBonus, Number((totalBalance - turnoverRemaining).toFixed(2))));

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(amount);

    if (withdrawType === 'USDT') {
      const numUsdt = parseFloat(usdtAmount);
      if (isNaN(numUsdt) || isNaN(num) || numUsdt < minUsdtWithdraw || num < minBdtWithdraw) {
        showToast(
          `Minimum withdrawal for USDT is $${minUsdtWithdraw}.00 (৳${minBdtWithdraw.toLocaleString()})`,
          'error'
        );
        return;
      }
      if (totalBalance < num) {
        showToast(`Insufficient balance to withdraw! You have ৳${totalBalance.toFixed(2)}`, 'error');
        return;
      }
      if (num > withdrawableBalance) {
        showToast(
          `Turnover remaining: ৳${turnoverRemaining.toFixed(2)}. Withdrawable limit is ৳${withdrawableBalance.toFixed(2)} ($${(withdrawableBalance / dollarRate).toFixed(2)} USDT). Complete gameplay turnover first.`,
          'error'
        );
        return;
      }
      if (!activeAccount) {
        showToast('Please add your USDT TRC20 address first.', 'error');
        return;
      }

      setIsSubmitting(true);
      const ok = await submitWithdrawal(
        num,
        'USDT',
        'USDT',
        activeAccount.accountNumber,
        activeAccount.accountName,
        numUsdt,
        dollarRate
      );
      setIsSubmitting(false);

      if (ok) {
        showToast('USDT withdrawal request submitted! Funds will be transferred shortly.', 'success');
        setAmount('');
        setUsdtAmount('');
        setShowHistory(true);
      }
      return;
    }

    // E-Wallet withdrawal validation
    if (isNaN(num) || num < settings.minWithdraw) {
      showToast(`Minimum withdrawal amount is ৳${settings.minWithdraw}`, 'error');
      return;
    }
    if (num > settings.maxWithdraw) {
      showToast(`Maximum withdrawal amount is ৳${settings.maxWithdraw.toLocaleString()}`, 'error');
      return;
    }
    if (totalBalance < num) {
      showToast('Insufficient balance to withdraw!', 'error');
      return;
    }

    if (num > withdrawableBalance) {
      showToast(
        `Turnover remaining: ৳${turnoverRemaining.toFixed(2)}. Withdrawable limit is ৳${withdrawableBalance.toFixed(2)}. Complete gameplay turnover to unlock deposit balance.`,
        'error'
      );
      return;
    }

    if (!activeAccount) {
      showToast(
        'Please add a withdrawal number first.',
        'error'
      );
      return;
    }

    setIsSubmitting(true);
    const ok = await submitWithdrawal(
      num,
      withdrawType,
      activeAccount.type,
      activeAccount.accountNumber,
      activeAccount.accountName
    );
    setIsSubmitting(false);

    if (ok) {
      showToast('Withdrawal request submitted! Funds will be transferred shortly.', 'success');
      setAmount('');
      setShowHistory(true);
    }
  };

  const handleSaveAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWalletName.trim() || !newWalletNumber.trim()) {
      showToast('Please fill in both Account Name and Number/Address.', 'error');
      return;
    }

    if (allSavedAccounts.length >= 3) {
      showToast('Maximum of 3 withdrawal accounts can be saved.', 'error');
      return;
    }

    const autoLogo = newWalletLogo.trim() || PAYMENT_LOGOS[newWalletType.toLowerCase() as keyof typeof PAYMENT_LOGOS] || '';
    const res = await saveWithdrawAccount(
      newWalletType,
      newWalletName.trim(),
      newWalletNumber.trim(),
      autoLogo
    );
    showToast(res.message, res.success ? 'success' : 'error');
    if (res.success) {
      setShowAddMethodModal(false);
      setNewWalletNumber('');
      setNewWalletName('');
      setNewWalletLogo('');
    }
  };

  const handleDeleteAccount = async (id: string, name: string) => {
    if (window.confirm(`Remove ${name} from your saved withdrawal accounts?`)) {
      await deleteWithdrawAccount(id);
      showToast('Withdrawal account removed.', 'info');
    }
  };

  return (
    <div className="min-h-screen bg-[#f7f8fc] pb-24 text-slate-800 select-none">
      {/* Top Bar */}
      <div className="sticky top-0 z-30 bg-white border-b border-slate-100 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={onBack}
          className="p-1 -ml-1 text-slate-700 hover:text-slate-900 rounded-full"
          id="withdraw-back-btn"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-base font-bold text-slate-900">Withdraw</h1>
        <button
          onClick={() => setShowHistory(!showHistory)}
          className="text-xs font-semibold text-slate-600 hover:text-[#2196f3]"
          id="withdraw-history-toggle-btn"
        >
          {showHistory ? 'Withdraw Form' : 'History'}
        </button>
      </div>

      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* Available Balance Card */}
        <div className="bg-[#29303d] border border-slate-700/80 rounded-3xl p-5 text-white shadow-xl relative overflow-hidden">
          <div className="flex items-center space-x-1.5 text-xs text-slate-300">
            <span>👛</span>
            <span>Available Balance</span>
          </div>
          <div className="flex items-center space-x-2 mt-2">
            <span className="text-3xl font-extrabold tracking-tight text-white">
              ৳{totalBalance.toFixed(2)}
            </span>
            <button
              onClick={refreshBalance}
              disabled={isRefreshingBalance}
              className="text-white/80 hover:text-white"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshingBalance ? 'animate-spin' : ''}`} />
            </button>
          </div>
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-700 text-xs text-slate-300">
            <span>Withdrawable: <strong className="text-[#2196f3]">৳{withdrawableBalance.toFixed(2)}</strong></span>
            <span>Turnover Left: <strong className="text-amber-400">৳{turnoverRemaining.toFixed(2)}</strong></span>
          </div>
        </div>

        {showHistory ? (
          /* Withdrawal History */
          <div className="space-y-3">
            <div className="flex items-center space-x-2 text-sm font-bold text-slate-800">
              <span>📋</span>
              <span>All Withdrawal Requests</span>
            </div>

            {userWithdrawals.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center text-xs text-slate-400 border border-slate-100">
                No withdrawal records found.
              </div>
            ) : (
              userWithdrawals.map((w, wIdx) => (
                <div
                  key={`with-rec-${w.id || wIdx}-${wIdx}`}
                  className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                    <span className="px-2 py-0.5 rounded-md bg-[#2196f3] text-white font-bold text-[11px]">
                      Withdraw
                    </span>
                    <span
                      className={`font-bold px-2 py-0.5 rounded-full text-xs ${
                        w.status === 'completed'
                          ? 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                          : w.status === 'pending'
                          ? 'bg-amber-50 text-amber-600 border border-amber-200'
                          : 'bg-rose-50 text-rose-600 border border-rose-200'
                      }`}
                    >
                      {w.status === 'completed' || w.status === 'approved' || w.status === 'success'
                        ? 'Success'
                        : w.status === 'pending' || w.status === 'processing'
                        ? 'Processing'
                        : 'Rejected'}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 font-medium">Payout Amount</span>
                    <div className="text-right">
                      <span className="font-black text-slate-900 text-sm font-mono block">
                        ৳{w.amount.toFixed(2)}
                      </span>
                      {(w.usdtAmount || w.type === 'USDT' || w.walletMethod === 'USDT') && (
                        <span className="text-[11px] font-bold font-mono text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200/60 inline-block mt-0.5">
                          ${(w.usdtAmount || (w.amount / (w.dollarRate || 125))).toFixed(2)} USDT
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-medium">Method</span>
                    <span className="font-bold text-slate-700">
                      {w.walletMethod} {w.type === 'USDT' && '(TRC20)'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-medium">Request Time</span>
                    <span className="text-slate-500 font-mono text-[11px]">
                      {new Date(w.createdAt).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 font-medium">Order Number</span>
                    <span className="font-mono text-slate-700 font-bold text-[11px]">{formatWithdrawOrderId(w)}</span>
                  </div>

                  {/* Rejection Remark display if rejected by Admin */}
                  {(w.rejectionReason || w.remark) && (
                    <div className="bg-rose-50 border border-rose-200 rounded-xl p-2.5 text-[11px] text-rose-800 mt-2 space-y-1">
                      <div className="flex items-center space-x-1.5 font-bold text-rose-700">
                        <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                        <span>Admin Rejection Remark:</span>
                      </div>
                      <p className="pl-5 text-slate-700 font-medium leading-relaxed">
                        {w.rejectionReason || w.remark}
                      </p>
                      <p className="pl-5 text-[10px] text-rose-600 font-medium">
                        * The requested amount has been refunded to your main balance.
                      </p>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        ) : (
          <>
            {/* Method Tabs: E-Wallet vs USDT */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => handleSwitchTab('E-Wallet')}
                className={`py-3 px-4 rounded-2xl flex flex-col items-center justify-center border transition-all ${
                  withdrawType === 'E-Wallet'
                    ? 'bg-[#2196f3] text-white border-transparent shadow-md'
                    : 'bg-white text-slate-700 border-slate-100 hover:bg-slate-50'
                }`}
                id="withdraw-tab-ewallet"
              >
                <div className="w-8 h-8 rounded-full overflow-hidden bg-white/20 flex items-center justify-center mb-1">
                  <img
                    src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTIygtqM2sAU6oXjYtmZip0A_EVd4zRo99Lnv7SFPXYA&s=10"
                    alt="E-Wallet"
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>
                <span className="font-bold text-xs">E-Wallet (বিকাশ/নগদ)</span>
              </button>

              <button
                onClick={() => handleSwitchTab('USDT')}
                className={`py-3 px-4 rounded-2xl flex flex-col items-center justify-center border transition-all ${
                  withdrawType === 'USDT'
                    ? 'bg-[#009393] text-white border-transparent shadow-md'
                    : 'bg-white text-slate-700 border-slate-100 hover:bg-slate-50'
                }`}
                id="withdraw-tab-usdt"
              >
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center mb-1 text-base font-bold">
                  ₮
                </div>
                <span className="font-bold text-xs">USDT TRC20 (ডলার)</span>
              </button>
            </div>

            {/* Withdrawal Accounts Section */}
            <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center space-x-1.5 font-bold text-slate-800">
                  <span>Saved Accounts ({withdrawType})</span>
                  <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full font-black">
                    {allSavedAccounts.length}/3 MAX
                  </span>
                </div>

                {allSavedAccounts.length < 3 ? (
                  <button
                    onClick={() => {
                      setNewWalletType(withdrawType === 'USDT' ? 'USDT' : 'BKASH');
                      setShowAddMethodModal(true);
                    }}
                    className="text-[#2196f3] font-bold text-xs flex items-center space-x-0.5 hover:underline"
                    id="add-payment-method-btn"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add {withdrawType === 'USDT' ? 'Address' : 'Number'}</span>
                  </button>
                ) : (
                  <span className="text-[10px] text-slate-400 font-semibold">Limit Reached</span>
                )}
              </div>

              {/* List of saved accounts for this tab */}
              {currentAccounts.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400 bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
                  <CreditCard className="w-8 h-8 mx-auto text-slate-300" />
                  <p className="font-semibold text-slate-600">
                    No {withdrawType} account saved yet.
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Click "Add {withdrawType === 'USDT' ? 'Address' : 'Number'}" to securely save your withdrawal account.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setNewWalletType(withdrawType === 'USDT' ? 'USDT' : 'BKASH');
                      setShowAddMethodModal(true);
                    }}
                    className="inline-flex items-center space-x-1 px-3 py-1.5 bg-[#2196f3] text-white rounded-xl text-xs font-bold shadow-xs hover:brightness-105 active:scale-95"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Now</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  {currentAccounts.map((acc, accIdx) => {
                    const isSelected = (activeAccount?.id || '') === acc.id;
                    const logo =
                      acc.logo ||
                      (acc.type === 'BKASH'
                        ? PAYMENT_LOGOS.bkash
                        : acc.type === 'NAGAD'
                        ? PAYMENT_LOGOS.nagad
                        : acc.type === 'ROCKET'
                        ? PAYMENT_LOGOS.rocket
                        : PAYMENT_LOGOS.usdt);

                    return (
                      <div
                        key={acc.id || `acc-${acc.type}-${acc.accountNumber}-${accIdx}`}
                        onClick={() => setSelectedAccountId(acc.id)}
                        className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-blue-50/70 border-[#2196f3] ring-1 ring-[#2196f3]'
                            : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <div className="flex items-center space-x-2.5 min-w-0">
                          {Boolean(logo && logo.trim()) ? (
                            <img
                              src={logo}
                              alt={acc.type}
                              className="w-8 h-8 object-contain rounded-lg bg-white p-0.5 border border-slate-100"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white font-black text-xs flex items-center justify-center">
                              ₮
                            </div>
                          )}
                          <div className="min-w-0">
                            <div className="font-bold text-xs text-slate-900 truncate font-mono flex items-center space-x-1.5">
                              <span>
                                {revealedAccounts[acc.id]
                                  ? acc.accountNumber
                                  : maskAccountNumber(acc.accountNumber)}
                              </span>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleReveal(acc.id);
                                }}
                                className="p-0.5 text-slate-400 hover:text-slate-600 active:scale-95"
                                title={revealedAccounts[acc.id] ? "Hide Number" : "Show Number"}
                              >
                                {revealedAccounts[acc.id] ? (
                                  <EyeOff className="w-3 h-3 text-blue-500" />
                                ) : (
                                  <Eye className="w-3 h-3 text-slate-400" />
                                )}
                              </button>
                            </div>
                            <div className="text-[10px] text-slate-500 truncate">
                              {acc.type} • {acc.accountName}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          {isSelected && <Check className="w-4 h-4 text-[#2196f3] stroke-[3]" />}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteAccount(acc.id, `${acc.type} ${acc.accountNumber}`);
                            }}
                            className="p-1 text-slate-400 hover:text-red-600 active:scale-95"
                            title="Delete account"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Amount Input Form */}
            <form onSubmit={handleWithdraw} className="space-y-4">
              {withdrawType === 'USDT' ? (
                /* ==========================================================
                   USDT DUAL INPUT MODE (BDT ⇄ USDT REAL-TIME DYNAMIC CONVERT)
                   ========================================================== */
                <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-3.5">
                  {/* Exchange Rate & Minimum Info Card */}
                  <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-cyan-50 border border-emerald-200/70 rounded-2xl p-3 flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white font-black text-base flex items-center justify-center shadow-xs">
                        ₮
                      </div>
                      <div>
                        <div className="text-xs font-black text-emerald-950 flex items-center space-x-1.5">
                          <span>USDT TRC20 Fast Exchange</span>
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        </div>
                        <div className="text-xs font-mono font-black text-emerald-700">
                          1 USDT = ৳{dollarRate.toFixed(2)} BDT
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wider">
                        Min Withdraw
                      </span>
                      <span className="text-xs font-black font-mono text-emerald-900 bg-emerald-100/90 px-2 py-0.5 rounded-lg border border-emerald-300">
                        ${minUsdtWithdraw}.00 (৳{minBdtWithdraw.toFixed(0)})
                      </span>
                    </div>
                  </div>

                  {/* Dual Type Boxes */}
                  <div className="space-y-3">
                    {/* TYPE BOX 1: BDT AMOUNT (টাকা) */}
                    <div>
                      <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-1">
                        <label htmlFor="withdraw-bdt-input" className="flex items-center space-x-1">
                          <span>BDT Amount (টাকা)</span>
                          <span className="text-[10px] text-slate-400 font-normal">
                            (ব্যালেন্স থেকে কাটা হবে)
                          </span>
                        </label>
                        <span className="text-[11px] text-slate-500 font-mono">
                          Withdrawable: ৳{withdrawableBalance.toFixed(2)}
                        </span>
                      </div>
                      <div className="relative">
                        <span className="absolute left-3.5 top-3 text-[#2196f3] font-black text-lg select-none">
                          ৳
                        </span>
                        <input
                          type="number"
                          step="any"
                          value={amount}
                          onChange={(e) => handleBdtChange(e.target.value)}
                          placeholder="0.00"
                          className="w-full pl-9 pr-16 py-3 rounded-2xl bg-slate-50 border border-slate-200 font-extrabold text-lg text-slate-900 focus:outline-none focus:border-[#2196f3] focus:bg-white transition-all font-mono"
                          id="withdraw-bdt-input"
                        />
                        <button
                          type="button"
                          onClick={handleSelectAllUsdt}
                          className="absolute right-3 top-2.5 px-2.5 py-1 text-xs font-extrabold text-[#2196f3] hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                          id="withdraw-bdt-all-btn"
                        >
                          All
                        </button>
                      </div>
                    </div>

                    {/* BIDIRECTIONAL CONVERSION INDICATOR */}
                    <div className="relative flex items-center justify-center my-0.5">
                      <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-dashed border-slate-200" />
                      </div>
                      <div className="relative bg-slate-100 border border-slate-200 text-slate-600 px-3 py-0.5 rounded-full text-[10px] font-bold flex items-center space-x-1.5 shadow-2xs">
                        <ArrowUpDown className="w-3 h-3 text-emerald-600 animate-pulse" />
                        <span>Live Bidirectional Conversion</span>
                      </div>
                    </div>

                    {/* TYPE BOX 2: USDT AMOUNT (ডলার) */}
                    <div>
                      <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-1">
                        <label htmlFor="withdraw-usdt-input" className="flex items-center space-x-1.5">
                          <span>USDT Amount (ডলার)</span>
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 font-extrabold px-1.5 py-0.2 rounded">
                            Min ${minUsdtWithdraw}
                          </span>
                        </label>
                        <span className="text-[11px] text-emerald-700 font-bold">
                          TRC20 Wallet Credit
                        </span>
                      </div>
                      <div className="relative">
                        <span className="absolute left-3.5 top-3 text-emerald-600 font-black text-lg select-none">
                          $
                        </span>
                        <input
                          type="number"
                          step="any"
                          value={usdtAmount}
                          onChange={(e) => handleUsdtChange(e.target.value)}
                          placeholder={`${minUsdtWithdraw}.00`}
                          className="w-full pl-9 pr-18 py-3 rounded-2xl bg-emerald-50/40 border border-emerald-300 font-extrabold text-lg text-emerald-950 focus:outline-none focus:border-emerald-600 focus:bg-white transition-all font-mono"
                          id="withdraw-usdt-input"
                        />
                        <span className="absolute right-3.5 top-3.5 text-xs font-black text-emerald-700 font-mono select-none">
                          USDT
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Quick Dollar Presets */}
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 block mb-1.5 uppercase tracking-wider">
                      Quick Dollar Presets (ক্লিক করে সিলেক্ট করুন):
                    </span>
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                      {[10, 25, 50, 100, 200, 500].map((preset) => {
                        const isSelected = parseFloat(usdtAmount) === preset;
                        return (
                          <button
                            key={`usdt-preset-${preset}`}
                            type="button"
                            onClick={() => handleSelectUsdtPreset(preset)}
                            className={`py-2 px-2 rounded-xl text-xs font-black font-mono border transition-all active:scale-95 cursor-pointer ${
                              isSelected
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            <span>${preset}</span>
                            {preset === 10 && (
                              <span className="text-[8px] font-sans font-black text-amber-500 block -mt-0.5">
                                MIN
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Conversion Live Calculation Card */}
                  <div className="bg-slate-50 rounded-2xl p-3 border border-slate-200/80 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between text-slate-500">
                      <span>Rate Applied:</span>
                      <span className="font-mono font-bold text-slate-700">
                        1 USDT = ৳{dollarRate.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-500">
                      <span>Deducted Balance (৳):</span>
                      <span className="font-mono font-bold text-rose-600">
                        ৳{parseFloat(amount || '0').toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between border-t border-slate-200 pt-1.5">
                      <span className="text-slate-800 font-bold">You will receive:</span>
                      <span className="font-mono text-emerald-600 text-sm font-black">
                        ${parseFloat(usdtAmount || '0').toFixed(2)} USDT (TRC20)
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                /* ==========================================================
                   E-WALLET STANDARD MODE (BDT ৳)
                   ========================================================== */
                <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                    <span>Withdrawal Amount (৳)</span>
                    <span className="text-[11px] text-slate-400 font-normal">
                      Min ৳{settings.minWithdraw}
                    </span>
                  </div>
                  <div className="relative">
                    <span className="absolute left-3 top-3 text-[#2196f3] font-extrabold text-base select-none">
                      ৳
                    </span>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0"
                      className="w-full pl-8 pr-16 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-extrabold text-lg text-slate-900 focus:outline-none focus:border-[#2196f3] font-mono"
                      id="withdraw-amount-input"
                    />
                    <button
                      type="button"
                      onClick={() => setAmount(withdrawableBalance.toString())}
                      className="absolute right-3 top-3 text-xs font-bold text-[#2196f3] hover:underline cursor-pointer"
                      id="withdraw-all-btn"
                    >
                      All
                    </button>
                  </div>

                  {/* Quick BDT Presets */}
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                    {[500, 1000, 2000, 5000, 10000, 25000].map((preset) => (
                      <button
                        key={`bdt-preset-${preset}`}
                        type="button"
                        onClick={() => setAmount(preset.toString())}
                        className={`py-1.5 px-2 rounded-xl text-xs font-bold font-mono border transition-all active:scale-95 cursor-pointer ${
                          parseFloat(amount) === preset
                            ? 'bg-[#2196f3] text-white border-[#2196f3]'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        ৳{preset.toLocaleString()}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                    <span>Withdrawable: ৳{withdrawableBalance.toFixed(2)}</span>
                    <span>Amount received: ৳{parseFloat(amount || '0').toFixed(2)}</span>
                  </div>
                </div>
              )}

              {/* Rules List according to active tab */}
              {withdrawType === 'USDT' ? (
                <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-2 text-xs text-slate-500">
                  <div className="font-bold text-slate-800 text-xs flex items-center space-x-1.5 mb-1">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>USDT TRC20 Withdrawal Rules & Conditions</span>
                  </div>
                  <ul className="space-y-1.5 list-disc list-inside">
                    <li>
                      Minimum withdrawal: <strong className="text-emerald-700 font-mono">${minUsdtWithdraw}.00 USDT</strong> (৳{minBdtWithdraw.toFixed(2)})
                    </li>
                    <li>
                      Dollar Rate: <strong className="text-slate-800 font-mono">1 USDT = ৳{dollarRate.toFixed(2)} BDT</strong> (Live automatic conversion)
                    </li>
                    <li>
                      Blockchain Network: <strong className="text-emerald-700">TRC20 (Tron Network)</strong> only.
                    </li>
                    <li>
                      Withdraw time: <span className="text-slate-800 font-mono">00:00-23:50 (24/7 Fast Payout)</span>
                    </li>
                    <li>
                      Turnover requirements: Deposit 1×, Gift 3×, Referral bonus <strong>0× (unlocked)</strong>.
                    </li>
                  </ul>
                </div>
              ) : (
                <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-2 text-xs text-slate-500">
                  <ul className="space-y-2 list-disc list-inside">
                    <li>
                      Withdraw time: <span className="text-slate-800 font-mono">00:00-23:50 (24/7)</span>
                    </li>
                    <li>
                      Maximum saved withdrawal accounts:{' '}
                      <span className="text-[#2196f3] font-bold">3 accounts</span>
                    </li>
                    <li>
                      Withdrawal amount range:{' '}
                      <span className="text-slate-800 font-semibold">
                        ৳{settings.minWithdraw}.00 - ৳{settings.maxWithdraw.toLocaleString()}.00
                      </span>
                    </li>
                    <li>
                      Turnover requirements: Deposit 1×, Gift 3×, Referral bonus <strong>0× (unlocked)</strong>.
                    </li>
                  </ul>
                </div>
              )}

              {/* Submit Button */}
              {withdrawType === 'USDT' ? (
                <button
                  type="submit"
                  disabled={isSubmitting || !usdtAmount || parseFloat(usdtAmount) <= 0 || !activeAccount}
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 hover:brightness-105 active:scale-98 text-white font-extrabold rounded-2xl shadow-md text-sm transition-all disabled:opacity-50 cursor-pointer flex items-center justify-center space-x-1.5"
                  id="submit-withdraw-btn"
                >
                  {isSubmitting ? (
                    <span>Processing USDT Withdrawal...</span>
                  ) : (
                    <span>
                      Submit USDT Withdrawal{' '}
                      {parseFloat(usdtAmount || '0') > 0 &&
                        `($${parseFloat(usdtAmount || '0').toFixed(2)} USDT)`}
                    </span>
                  )}
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={isSubmitting || !amount || parseFloat(amount) <= 0 || !activeAccount}
                  className="w-full py-3.5 bg-gradient-to-r from-[#1976d2] to-[#2196f3] hover:brightness-105 active:scale-98 text-white font-extrabold rounded-2xl shadow-md text-sm transition-all disabled:opacity-50 cursor-pointer flex items-center justify-center space-x-1.5"
                  id="submit-withdraw-btn"
                >
                  {isSubmitting ? (
                    <span>Processing Withdrawal...</span>
                  ) : (
                    <span>
                      Submit Withdrawal{' '}
                      {parseFloat(amount || '0') > 0 &&
                        `(৳${parseFloat(amount || '0').toFixed(2)})`}
                    </span>
                  )}
                </button>
              )}
            </form>
          </>
        )}
      </div>

      {/* Add Payment Method Modal */}
      {showAddMethodModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm">
                Add {newWalletType === 'USDT' ? 'USDT TRC20 Address' : 'Withdrawal Account'}
              </h3>
              <button
                onClick={() => setShowAddMethodModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveAccount} className="space-y-3.5">
              {/* Provider Selection with Pure Logos */}
              <div>
                <label className="text-xs text-slate-500 font-semibold block mb-1.5">Select Payment Method</label>
                <div className="grid grid-cols-4 gap-2">
                  {(['BKASH', 'NAGAD', 'ROCKET', 'USDT'] as const).map((wm) => {
                    const isSelected = newWalletType === wm;
                    const methodLogo = PAYMENT_LOGOS[wm.toLowerCase() as keyof typeof PAYMENT_LOGOS];
                    return (
                      <button
                        key={wm}
                        type="button"
                        onClick={() => {
                          setNewWalletType(wm);
                          setNewWalletLogo(methodLogo);
                        }}
                        className={`h-14 rounded-2xl flex items-center justify-center p-2.5 border transition-all ${
                          isSelected
                            ? 'bg-blue-50/90 border-[#2196f3] ring-2 ring-[#2196f3]/40 shadow-xs'
                            : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <img
                          src={methodLogo}
                          alt={wm}
                          className="w-full h-full object-contain"
                          referrerPolicy="no-referrer"
                        />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Full Name */}
              <div>
                <label className="text-xs text-slate-500 font-semibold block mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={newWalletName}
                  onChange={(e) => setNewWalletName(e.target.value)}
                  placeholder="Full Name"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold uppercase focus:outline-none focus:border-[#2196f3]"
                  required
                />
              </div>

              {/* Account Number */}
              <div>
                <label className="text-xs text-slate-500 font-semibold block mb-1">
                  {newWalletType === 'USDT' ? 'USDT TRC20 Address' : 'Mobile Account Number'}
                </label>
                <input
                  type={newWalletType === 'USDT' ? 'text' : 'tel'}
                  value={newWalletNumber}
                  onChange={(e) => setNewWalletNumber(e.target.value)}
                  placeholder={newWalletType === 'USDT' ? 'T...' : '01XXXXXXXXX'}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold font-mono focus:outline-none focus:border-[#2196f3]"
                  required
                />
              </div>

              <div className="text-[11px] text-amber-700 bg-amber-50 p-2.5 rounded-xl border border-amber-200/50">
                ⚠️ Only up to 3 withdrawal accounts can be saved per account. User must manually add and verify their own accounts.
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#2196f3] text-white font-bold rounded-xl text-xs shadow-md mt-2 active:scale-95 transition-transform"
              >
                Save Withdrawal Account
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
