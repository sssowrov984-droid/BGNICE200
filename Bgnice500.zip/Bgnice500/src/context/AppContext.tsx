import React, { createContext, useContext, useEffect, useState, useCallback, useRef, ReactNode } from 'react';
import { ref, onValue, set, update, push, get, remove } from 'firebase/database';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  onAuthStateChanged
} from 'firebase/auth';
import { rtdb, auth } from '../lib/firebase';
import {
  UserProfile,
  GameHistoryItem,
  BetItem,
  DepositItem,
  WithdrawalItem,
  SystemSettings,
  GameType,
  GameItem,
  SavedWithdrawAccount,
  PaymentChannelConfig,
  BannerItem,
  ActivityBanner,
  GiftCodeItem,
  GiftClaimRecord,
  GameResultModalData,
  AccountTransaction,
  DepositChannel,
  TurnoverRecord
} from '../types';
import { DEFAULT_DEPOSIT_CHANNELS } from '../utils/defaultChannels';
import { PAYMENT_LOGOS } from '../utils/paymentLogos';
import { recordLoginNotification } from '../utils/notifications';
import {
  getNumberColors,
  getNumberSize,
  calculateWin,
  generatePeriodId,
  generateInitialHistoryForType,
  playBeepSound
} from '../utils/gameRules';
import { calculateVipLevel, getVipConfig } from '../utils/vipRules';
import confetti from 'canvas-confetti';

interface ToastState {
  message: string;
  type: 'success' | 'error' | 'warning' | 'info' | 'refresh';
}

interface AppContextType {
  user: UserProfile | null;
  setUser: React.Dispatch<React.SetStateAction<UserProfile | null>>;
  authLoading: boolean;
  isAdmin: boolean;
  setIsAdmin: (val: boolean) => void;
  gameType: GameType;
  setGameType: (t: GameType) => void;
  periodId: string;
  timeLeft: number;
  gameHistory: GameHistoryItem[];
  userBets: BetItem[];
  allBets: BetItem[];
  deposits: DepositItem[];
  withdrawals: WithdrawalItem[];
  depositChannels: DepositChannel[];
  allUsers: Record<string, UserProfile>;
  settings: SystemSettings;
  games: GameItem[];
  banners: BannerItem[];
  activityBanners: ActivityBanner[];
  giftCodes: GiftCodeItem[];
  userGiftClaims: GiftClaimRecord[];
  userTurnovers: TurnoverRecord[];
  activeTurnoverReq: number;
  activeTurnoverDone: number;
  activeTurnoverRemaining: number;
  lastWinModal: GameResultModalData | null;
  setLastWinModal: (modal: GameResultModalData | null) => void;
  closeWinModal: () => void;
  userTransactions: AccountTransaction[];
  // Toast & Balance Refresh
  toast: ToastState | null;
  showToast: (message: string, type?: 'success' | 'error' | 'warning' | 'info' | 'refresh') => void;
  isRefreshingBalance: boolean;
  refreshBalance: (silent?: boolean) => Promise<void>;
  downloadApp: () => void;
  isGameActive: boolean;
  setIsGameActive: (val: boolean) => void;
  // User Profile Actions
  updateNickname: (nickname: string) => Promise<{ success: boolean; message: string }>;
  updateUsername: (username: string) => Promise<{ success: boolean; message: string }>;
  updateAvatar: (avatarId: string) => Promise<{ success: boolean; message: string }>;
  bindEmail: (email: string) => Promise<{ success: boolean; message: string }>;
  // In-Game & Wallet Actions
  recordGameMove: (type: 'move_in' | 'move_out', gameName: string) => Promise<void>;
  placeBet: (selectType: 'color' | 'number' | 'size', selectValue: string, amount: number, multiplier: number) => Promise<boolean>;
  fulfillBetTurnover: (uid: string, betAmount: number) => Promise<void>;
  recordGameBet: (betData: {
    uid: string;
    gameType: string;
    gameName?: string;
    selectType?: string;
    selectValue?: string;
    amount: number;
    totalAmount?: number;
    status?: 'pending' | 'won' | 'lost' | 'cancelled';
    winAmount?: number;
    multiplier?: number;
    periodId?: string;
    outcome?: string;
    betId?: string;
  }) => Promise<string>;
  updateGameBetStatus: (
    betId: string,
    status: 'won' | 'lost' | 'cancelled',
    winAmount?: number,
    outcome?: string,
    multiplier?: number
  ) => Promise<void>;
  submitDeposit: (channel: string, method: 'nagad' | 'bkash' | 'usdt', amount: number, txnId: string) => Promise<boolean>;
  submitDepositChannelRequest: (channel: DepositChannel, amount: number, txnId: string) => Promise<DepositItem | null>;
  submitWithdrawal: (
    amount: number,
    type: 'E-Wallet' | 'USDT',
    walletMethod: 'BKASH' | 'NAGAD' | 'ROCKET' | 'USDT',
    accountNumber: string,
    accountName?: string,
    usdtAmount?: number,
    dollarRate?: number
  ) => Promise<boolean>;
  saveWithdrawAccount: (type: 'BKASH' | 'NAGAD' | 'ROCKET' | 'USDT', accountName: string, accountNumber: string, logo?: string) => Promise<{ success: boolean; message: string }>;
  deleteWithdrawAccount: (accountId: string) => Promise<void>;
  transferSafe: (amount: number, type: 'Transfer In' | 'Transfer Out') => Promise<boolean>;
  claimGiftCode: (code: string) => Promise<{ success: boolean; message: string }>;
  claimDailyAttendance: (day?: number) => Promise<{ success: boolean; message: string }>;
  claimVipLevelUpBonus: (level: number) => Promise<{ success: boolean; message: string }>;
  claimVipMonthlyBonus: (level: number) => Promise<{ success: boolean; message: string }>;
  // Admin actions
  adminApproveDeposit: (id: string) => Promise<void>;
  adminRejectDeposit: (id: string) => Promise<void>;
  adminApproveWithdrawal: (id: string) => Promise<void>;
  adminRejectWithdrawal: (id: string, reason?: string) => Promise<void>;
  adminSetForcedResult: (gameType: GameType, num: number | null) => Promise<void>;
  adminUpdateSettings: (settings: Partial<SystemSettings>) => Promise<void>;
  adminAdjustUserBalance: (uid: string, delta: number) => Promise<void>;
  adminUpdateUserVip: (uid: string, vipLevel: number) => Promise<void>;
  adminToggleUserBan: (uid: string, currentStatus?: string) => Promise<void>;
  // Admin Gift Code Actions
  adminGenerate30CharGiftCode: () => Promise<string>;
  adminSaveGiftCode: (code: string, amount: number, maxClaims: number) => Promise<void>;
  adminUpdateGiftCode: (code: string, data: Partial<GiftCodeItem>) => Promise<void>;
  adminDeleteGiftCode: (code: string) => Promise<void>;
  adminToggleGiftCodeStatus: (code: string, currentStatus: string) => Promise<void>;
  // Admin Games
  adminAddGame: (game: Omit<GameItem, 'id' | 'createdAt'>) => Promise<void>;
  adminUpdateGame: (id: string, game: Partial<GameItem>) => Promise<void>;
  adminDeleteGame: (id: string) => Promise<void>;
  adminToggleGameStatus: (id: string, current: boolean) => Promise<void>;
  // Admin Banners
  adminAddBanner: (banner: Omit<BannerItem, 'id'>) => Promise<void>;
  adminUpdateBanner: (id: string, banner: Partial<BannerItem>) => Promise<void>;
  adminDeleteBanner: (id: string) => Promise<void>;
  adminToggleBannerStatus: (id: string, current: boolean) => Promise<void>;
  adminResetDefaultBanners: () => Promise<void>;
  // Admin Activity Banners (Unlimited add/edit/delete)
  adminAddActivityBanner: (banner: Omit<ActivityBanner, 'id'>) => Promise<void>;
  adminUpdateActivityBanner: (id: string, banner: Partial<ActivityBanner>) => Promise<void>;
  adminDeleteActivityBanner: (id: string) => Promise<void>;
  adminToggleActivityBannerStatus: (id: string, current: boolean) => Promise<void>;
  adminResetDefaultActivityBanners: () => Promise<void>;
  adminToggleMaintenanceMode: (enabled: boolean, message?: string) => Promise<void>;
  adminUpdateSignupBonus: (enabled: boolean, amount: number, multiplier: number) => Promise<void>;
  adminUpdatePaymentChannel: (key: string, data: Partial<PaymentChannelConfig>) => Promise<void>;
  adminSaveDepositChannel: (channel: DepositChannel) => Promise<void>;
  adminDeleteDepositChannel: (channelId: string) => Promise<void>;
  adminResetDefaultChannels: () => Promise<void>;
  // Auth
  login: (identifier: string, pass: string) => Promise<{ success: boolean; message: string }>;
  loginWithPhone: (countryCode: string, phoneDigits: string, pass: string) => Promise<{ success: boolean; message: string }>;
  sendPasswordReset: (email: string) => Promise<{ success: boolean; message: string }>;
  register: (params: {
    username: string;
    email: string;
    country: string;
    countryCode: string;
    phone: string;
    password: string;
    referCode?: string;
    phoneVerified?: boolean;
  }) => Promise<{ success: boolean; message: string }>;
  logout: () => Promise<void>;
}

const defaultPaymentChannels: Record<string, PaymentChannelConfig> = {
  nagad: {
    id: 'nagad',
    name: 'Nagad Agent / Personal',
    type: 'nagad',
    agentNumber: '01745595085',
    active: true,
    minAmount: 100,
    maxAmount: 50000
  },
  bkash: {
    id: 'bkash',
    name: 'bKash Merchant / Agent',
    type: 'bkash',
    agentNumber: '01763760943',
    active: true,
    minAmount: 100,
    maxAmount: 50000
  },
  rocket: {
    id: 'rocket',
    name: 'Rocket Personal / Agent',
    type: 'rocket',
    agentNumber: '01771234430',
    active: true,
    minAmount: 100,
    maxAmount: 50000
  },
  usdt: {
    id: 'usdt',
    name: 'USDT TRC20 Fast Transfer',
    type: 'usdt',
    agentNumber: 'TXF3U5CTradeBd28d85TronNetworkTRC20',
    active: true,
    minAmount: 500,
    maxAmount: 100000
  }
};

const defaultSettings: SystemSettings = {
  nagadNumber: '01745595085',
  bkashNumber: '01763760943',
  rocketNumber: '01771234430',
  usdtAddress: 'TXF3U5CTradeBd28d85TronNetworkTRC20',
  minDeposit: 100,
  maxDeposit: 50000,
  minWithdraw: 100,
  maxWithdraw: 25000,
  usdtRate: 125,
  minWithdrawUsdt: 10,
  platformAnnouncement: 'Dear Valued Members, Welcome to BGNICE! Official 24/7 automated Nagad, bKash & Rocket deposits & withdrawals are active with 100% security guarantee.',
  activeAnnouncementTitle: 'Platform Notice',
  showAnnouncement: true,
  appDownloadUrl: 'https://bgnice.app/download/bgnice.apk',
  appVersion: 'v2.6 Official',
  forcedResults: {},
  paymentChannels: defaultPaymentChannels,
  attendance: {
    enabled: true,
    minDeposit: 500,
    totalDepositTarget: 20000,
    requiredDays: 7,
    rewards: [20, 30, 50, 70, 100, 150, 300],
    turnoverMultiplier: 1,
    cooldownHours: 24
  },
  isMaintenanceMode: false,
  maintenanceMessage: 'BGNICE প্ল্যাটফর্ম সাময়িক রক্ষণাবেক্ষণের জন্য বন্ধ আছে। দ্রুততম সময়ে সার্ভিস পুনরায় চালু করা হবে।',
  signupBonusEnabled: true,
  signupBonusAmount: 50,
  signupBonusTurnoverMultiplier: 1
};

export const defaultBannersSeed: Record<string, BannerItem> = {
  banner1: {
    id: 'banner1',
    image: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80',
    title: 'Largest Online Entertainment Hub',
    subtitle: 'Reputation guarantee • Instant Nagad & bKash payouts',
    buttonText: 'Play Win Go',
    action: 'wingo',
    active: true,
    order: 1
  },
  banner2: {
    id: 'banner2',
    image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&auto=format&fit=crop&q=80',
    title: 'Instant Automated Deposits',
    subtitle: 'Nagad, bKash & Rocket 24/7 Fast Payouts',
    buttonText: 'Deposit Now',
    action: 'deposit',
    active: true,
    order: 2
  },
  banner3: {
    id: 'banner3',
    image: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=800&auto=format&fit=crop&q=80',
    title: 'Win Go Multi-Cycle Lottery',
    subtitle: '30s • 1m • 2m • 3m • 5m Cycles with 9X Multipliers',
    buttonText: 'Bet Now',
    action: 'wingo',
    active: true,
    order: 3
  },
  banner4: {
    id: 'banner4',
    image: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=800&auto=format&fit=crop&q=80',
    title: 'Redeem Free Lucky Gift Codes',
    subtitle: 'Claim instant cash balance with admin promotional codes',
    buttonText: 'Redeem Gift',
    action: 'activity',
    active: true,
    order: 4
  },
  banner5: {
    id: 'banner5',
    image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=80',
    title: 'VIP Club Rewards Tier 1-10',
    subtitle: 'Level up bonuses and monthly rewards up to ৳19,060',
    buttonText: 'Explore VIP',
    action: 'activity',
    active: true,
    order: 5
  }
};

export const defaultActivityBannersSeed: Record<string, ActivityBanner> = {
  act_1: {
    id: 'act_1',
    title: 'BGNICE MEMBERS GET REWARDS ON EXECUTING DAILY CHECK-IN',
    subtitle: '💰 Recharge and Get Daily Check-in Bonus 💰',
    imageUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80',
    badge: 'Check-in Bonus',
    actionType: 'attendance',
    order: 1,
    active: true
  },
  act_2: {
    id: 'act_2',
    title: 'MEMBER ACTIVITIES WINNING STREAK',
    subtitle: '⭐ Member Activities Winning Streak ⭐',
    imageUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&auto=format&fit=crop&q=80',
    badge: 'Winning Streak',
    actionType: 'none',
    order: 2,
    active: true
  },
  act_3: {
    id: 'act_3',
    title: 'YOUTUBE CONTENT - Make a video content about BGNICE',
    subtitle: '🔴 Youtube Creative Video 🔴',
    imageUrl: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&auto=format&fit=crop&q=80',
    badge: 'Creative Video',
    actionType: 'url',
    linkUrl: 'https://youtube.com',
    order: 3,
    active: true
  }
};

const defaultGamesSeed: GameItem[] = [
  {
    id: 'game_cointoss',
    name: 'Casino Head Tail',
    image: 'https://images.unsplash.com/photo-1622979135225-d2ba269bc1df?w=500&auto=format&fit=crop&q=80',
    category: 'Original',
    gamePath: 'games/cointoss/index.html',
    status: true,
    sortOrder: 0,
    badge: 'HOT',
    rtp: 98.8,
    createdAt: Date.now() - 50000
  },
  {
    id: 'game_aviator',
    name: 'Aviator Pro',
    image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=500&auto=format&fit=crop&q=80',
    category: 'Original',
    gamePath: 'games/aviator/index.html',
    status: true,
    sortOrder: 1,
    badge: 'HOT',
    createdAt: Date.now() - 500000
  },
  {
    id: 'game_lucky777',
    name: 'Lucky 777 Slots',
    image: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80',
    category: 'Slots',
    gamePath: 'games/lucky777/index.html',
    status: true,
    sortOrder: 2,
    badge: 'HOT',
    createdAt: Date.now() - 400000
  },
  {
    id: 'game_dragontiger',
    name: 'Dragon Tiger Live',
    image: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=500&auto=format&fit=crop&q=80',
    category: 'Casino',
    gamePath: 'games/dragon-tiger/index.html',
    status: true,
    sortOrder: 3,
    badge: 'NEW',
    createdAt: Date.now() - 300000
  },
  {
    id: 'game_crash',
    name: 'Crash Rocket',
    image: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?w=500&auto=format&fit=crop&q=80',
    category: 'Original',
    gamePath: 'games/crash/index.html',
    status: true,
    sortOrder: 4,
    badge: 'HOT',
    createdAt: Date.now() - 200000
  },
  {
    id: 'game_ludo',
    name: 'Ludo Fast Dice',
    image: 'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?w=500&auto=format&fit=crop&q=80',
    category: 'Rummy',
    gamePath: 'games/ludo/index.html',
    status: true,
    sortOrder: 5,
    badge: 'NEW',
    createdAt: Date.now() - 100000
  },
  {
    id: 'game_cricket',
    name: 'Premier Cricket League',
    image: 'https://images.unsplash.com/photo-1531415074868-036b1c57e32b?w=500&auto=format&fit=crop&q=80',
    category: 'Sports',
    gamePath: 'games/crash/index.html',
    status: true,
    sortOrder: 6,
    badge: 'TOP',
    createdAt: Date.now() - 80000
  },
  {
    id: 'game_fishing',
    name: 'Ocean Hunter Fishing',
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=500&auto=format&fit=crop&q=80',
    category: 'Fishing',
    gamePath: 'games/lucky777/index.html',
    status: true,
    sortOrder: 7,
    badge: 'HOT',
    createdAt: Date.now() - 60000
  },
  {
    id: 'game_lottery_gold',
    name: 'Royal Lottery 30S',
    image: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80',
    category: 'Lottery',
    gamePath: 'games/lucky777/index.html',
    status: true,
    sortOrder: 8,
    badge: 'TOP',
    createdAt: Date.now() - 40000
  }
];

export function stripUndefined<T>(obj: T): T {
  if (obj === null || obj === undefined) return obj;
  if (Array.isArray(obj)) {
    return obj.filter((item) => item !== undefined).map(stripUndefined) as unknown as T;
  }
  if (typeof obj === 'object') {
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(obj)) {
      if (value !== undefined) {
        cleaned[key] = stripUndefined(value);
      }
    }
    return cleaned as T;
  }
  return obj;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Real Firebase User - NEVER HARDCODED
  const [user, setUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return sessionStorage.getItem('tradebd_admin_verified') === 'true';
    }
    return false;
  });
  const [gameType, setGameType] = useState<GameType>('30s');
  const [timeLeft, setTimeLeft] = useState<number>(30);
  const [periodId, setPeriodId] = useState<string>(generatePeriodId('30s'));
  const [gameHistory, setGameHistory] = useState<GameHistoryItem[]>([]);
  const [userBets, setUserBets] = useState<BetItem[]>([]);
  const [allBets, setAllBets] = useState<BetItem[]>([]);
  const [deposits, setDeposits] = useState<DepositItem[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalItem[]>([]);
  const [depositChannels, setDepositChannels] = useState<DepositChannel[]>(DEFAULT_DEPOSIT_CHANNELS);
  const [allUsers, setAllUsers] = useState<Record<string, UserProfile>>({});
  const [settings, setSettings] = useState<SystemSettings>(defaultSettings);
  const [games, setGames] = useState<GameItem[]>([]);
  const [banners, setBanners] = useState<BannerItem[]>([]);
  const [activityBanners, setActivityBanners] = useState<ActivityBanner[]>([]);
  const [giftCodes, setGiftCodes] = useState<GiftCodeItem[]>([]);
  const [userGiftClaims, setUserGiftClaims] = useState<GiftClaimRecord[]>([]);
  const [userTurnovers, setUserTurnovers] = useState<TurnoverRecord[]>([]);
  const [activeTurnoverReq, setActiveTurnoverReq] = useState<number>(0);
  const [activeTurnoverDone, setActiveTurnoverDone] = useState<number>(0);
  const [activeTurnoverRemaining, setActiveTurnoverRemaining] = useState<number>(0);
  const [userTransactions, setUserTransactions] = useState<AccountTransaction[]>([]);
  const [lastWinModal, setLastWinModal] = useState<GameResultModalData | null>(null);
  const [isGameActive, setIsGameActive] = useState<boolean>(false);

  // Toast System
  const [toast, setToast] = useState<ToastState | null>(null);
  const [isRefreshingBalance, setIsRefreshingBalance] = useState<boolean>(false);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'warning' | 'info' | 'refresh' = 'info') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast((current) => (current?.message === message ? null : current));
    }, type === 'refresh' ? 1800 : 3000);
  }, []);

  // Sync admin mode to localStorage
  useEffect(() => {
    localStorage.setItem('hgnice_is_admin', isAdmin ? 'true' : 'false');
  }, [isAdmin]);

  // Keep cached balance in sync for iframe games in public/games/
  useEffect(() => {
    if (user?.balance !== undefined) {
      localStorage.setItem('hgnice_cached_balance', user.balance.toString());
    } else {
      localStorage.removeItem('hgnice_cached_balance');
    }
  }, [user?.balance]);

  // Helper to record account transactions in RTDB
  const recordTransaction = async (
    uid: string,
    type: AccountTransaction['type'],
    amount: number,
    prevBal: number,
    newBal: number,
    description: string,
    refId?: string
  ) => {
    try {
      const txRef = push(ref(rtdb, `users/${uid}/transactions`));
      const tx: AccountTransaction = {
        id: txRef.key || `tx_${Date.now()}`,
        uid,
        type,
        amount,
        previousBalance: prevBal,
        newBalance: newBal,
        description,
        refId,
        createdAt: Date.now()
      };
      await set(txRef, tx);
    } catch (e) {
      console.error('Failed to record transaction', e);
    }
  };

  // Helper to record game move in / move out in account history
  const recordGameMove = async (type: 'move_in' | 'move_out', gameName: string) => {
    if (!user) return;
    const curBal = Number(user.balance || 0);
    const desc = type === 'move_in'
      ? `Game Move In: ${gameName}`
      : `Game Move Out: ${gameName}`;
    await recordTransaction(
      user.uid,
      type,
      0,
      curBal,
      curBal,
      desc,
      `gm_${Date.now()}`
    );
  };

  // Dedicated background resolver for WinGo bets so they are guaranteed to resolve even if user navigates away or disconnects
  const isResolvingPendingBets = useRef(false);

  const settlePendingBets = useCallback(async (betsList: BetItem[]) => {
    if (isResolvingPendingBets.current) return;
    const pending = betsList.filter((b) => b.status === 'pending');
    if (pending.length === 0) return;

    isResolvingPendingBets.current = true;
    try {
      const now = Date.now();
      for (const bet of pending) {
        const stepSec = bet.gameType === '30s' ? 30 : bet.gameType === '1m' ? 60 : bet.gameType === '2m' ? 120 : bet.gameType === '3m' ? 180 : 300;
        const currentExpected = generatePeriodId(bet.gameType);
        const betAgeMs = now - (bet.createdAt || 0);

        // Period has ended if current period ID changed OR sufficient seconds have elapsed
        const isPeriodFinished = currentExpected !== bet.periodId || betAgeMs >= (stepSec * 1000);

        if (!isPeriodFinished) {
          continue;
        }

        // 1. Get or deterministically generate history result for this period
        let winningNum: number;
        const histSnap = await get(ref(rtdb, `history/${bet.gameType}/${bet.periodId}`));
        if (histSnap.exists()) {
          winningNum = Number(histSnap.val().number);
        } else {
          // Check if admin has set forced result
          const settingsSnap = await get(ref(rtdb, 'settings'));
          const forced = settingsSnap.exists() ? settingsSnap.val()?.forcedResults?.[bet.gameType] : null;
          if (typeof forced === 'number' && forced >= 0 && forced <= 9) {
            winningNum = forced;
            update(ref(rtdb, 'settings/forcedResults'), { [bet.gameType]: null }).catch(() => {});
          } else {
            // Seeded deterministic generation from periodId so all clients/evaluators agree on the exact same winning number
            const digits = (bet.periodId || '').replace(/\D/g, '');
            const seed = parseInt(digits.slice(-4) || '7', 10);
            const mult = bet.gameType === '30s' ? 17 : bet.gameType === '1m' ? 23 : bet.gameType === '2m' ? 29 : bet.gameType === '3m' ? 31 : 37;
            winningNum = Math.abs((seed * mult + 13) % 10);
          }

          const colors = getNumberColors(winningNum);
          const bigSmall = getNumberSize(winningNum);
          const historyItem: GameHistoryItem = {
            periodId: bet.periodId,
            number: winningNum,
            bigSmall,
            colors,
            timestamp: bet.createdAt ? bet.createdAt + stepSec * 1000 : Date.now()
          };
          await set(ref(rtdb, `history/${bet.gameType}/${bet.periodId}`), historyItem).catch(() => {});
        }

        // 2. Evaluate win outcome
        const outcome = calculateWin(bet.selectType, bet.selectValue, winningNum, bet.totalAmount);
        const newStatus = outcome.isWin ? 'won' : 'lost';
        const winAmount = outcome.winAmount;

        // 3. Update bet record in RTDB
        await update(ref(rtdb, `bets/${bet.id}`), {
          status: newStatus,
          winAmount,
          resultNumber: winningNum
        }).catch(() => {});

        // 4. Update user balance & stats
        const userSnap = await get(ref(rtdb, `users/${bet.uid}`));
        if (userSnap.exists()) {
          const uData = userSnap.val() as UserProfile;
          if (outcome.isWin && winAmount > 0) {
            const currentBal = Number(uData.balance || 0);
            const updatedBal = Number((currentBal + winAmount).toFixed(2));
            const currentWon = Number(uData.totalWon || 0);
            const updatedWon = Number((currentWon + winAmount).toFixed(2));

            await update(ref(rtdb, `users/${bet.uid}`), {
              balance: updatedBal,
              totalWon: updatedWon
            }).catch(() => {});

            await recordTransaction(
              bet.uid,
              'win',
              winAmount,
              currentBal,
              updatedBal,
              `Win Go Period ${bet.periodId} Victory (+৳${winAmount.toFixed(2)})`,
              bet.id
            );

            if (user && bet.uid === user.uid) {
              try {
                confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
              } catch {}
            }
          } else if (!outcome.isWin) {
            const currentLoss = Number(uData.totalLoss || 0);
            const updatedLoss = Number((currentLoss + bet.totalAmount).toFixed(2));
            await update(ref(rtdb, `users/${bet.uid}`), {
              totalLoss: updatedLoss
            }).catch(() => {});
          }
        }
      }
    } catch (err) {
      console.error('Error settling pending bets in background:', err);
    } finally {
      isResolvingPendingBets.current = false;
    }
  }, [user, showToast]);

  // Periodic fallback resolver ensuring all pending bets settle even if user leaves game or browser tab
  useEffect(() => {
    const timer = setInterval(() => {
      if (allBets && allBets.length > 0) {
        settlePendingBets(allBets);
      }
    }, 4000);
    return () => clearInterval(timer);
  }, [allBets, settlePendingBets]);

  // Firebase Authentication State Observer
  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        // Authenticated user exists - listen to real profile from RTDB
        const userRef = ref(rtdb, `users/${firebaseUser.uid}`);
        const unsubProfile = onValue(userRef, async (snapshot) => {
          if (snapshot.exists()) {
            const profileData = snapshot.val() as UserProfile;
            let needsUpdate = false;
            const updates: Partial<UserProfile> = {};

            // Ensure 6-digit numericUid
            if (!profileData.numericUid) {
              const genUid = Math.floor(100000 + Math.random() * 900000).toString();
              updates.numericUid = genUid;
              profileData.numericUid = genUid;
              needsUpdate = true;
            }

            // Ensure 10-digit referral code
            if (!profileData.referCode || profileData.referCode.length < 10) {
              const genRef = String(Math.floor(1000000000 + Math.random() * 9000000000));
              updates.referCode = genRef;
              profileData.referCode = genRef;
              needsUpdate = true;
            }

            if (!profileData.avatar) {
              updates.avatar = 'avatar_1';
              profileData.avatar = 'avatar_1';
              needsUpdate = true;
            }

            if (needsUpdate) {
              await update(userRef, updates);
            }

            setUser({
              ...profileData,
              uid: firebaseUser.uid,
              balance: Number(profileData.balance || 0),
              safeBalance: Number(profileData.safeBalance || 0),
              vipLevel: Number(profileData.vipLevel ?? 0),
              totalBets: Number(profileData.totalBets || 0),
              turnoverReq: Number(profileData.turnoverReq || 0),
              turnoverDone: Number(profileData.turnoverDone || 0),
              referralBalance: Number(profileData.referralBalance || 0)
            });
            recordLoginNotification(firebaseUser.uid);
          }
          setAuthLoading(false);
        });

        // Listen to user's gift claims
        const claimsRef = ref(rtdb, `users/${firebaseUser.uid}/giftClaims`);
        const unsubClaims = onValue(claimsRef, (snapshot) => {
          if (snapshot.exists()) {
            const list = Object.values(snapshot.val()) as GiftClaimRecord[];
            list.sort((a, b) => (b.claimedAt || 0) - (a.claimedAt || 0));
            setUserGiftClaims(list);
          } else {
            setUserGiftClaims([]);
          }
        });

        // Listen to user's turnover records
        const toRef = ref(rtdb, `users/${firebaseUser.uid}/turnovers`);
        const unsubTurnovers = onValue(toRef, (snapshot) => {
          if (snapshot.exists()) {
            const list = Object.values(snapshot.val()) as TurnoverRecord[];
            list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            setUserTurnovers(list);

            const active = list.filter((t) => t.status === 'active');
            const req = active.reduce((s, t) => s + (t.requiredAmount || 0), 0);
            const done = active.reduce((s, t) => s + (t.completedAmount || 0), 0);
            const rem = active.reduce((s, t) => s + (t.remainingAmount !== undefined ? t.remainingAmount : Math.max(0, (t.requiredAmount || 0) - (t.completedAmount || 0))), 0);

            const roundedReq = Number(req.toFixed(2));
            const roundedDone = Number(done.toFixed(2));
            const roundedRem = Number(rem.toFixed(2));

            setActiveTurnoverReq(roundedReq);
            setActiveTurnoverDone(roundedDone);
            setActiveTurnoverRemaining(roundedRem);

            // Also keep user.turnoverReq and user.turnoverDone in sync so that when remaining <= 0, it's 0 (hidden)
            setUser((prev) => {
              if (!prev) return prev;
              return {
                ...prev,
                turnoverReq: roundedRem <= 0 ? 0 : roundedReq,
                turnoverDone: roundedRem <= 0 ? 0 : roundedDone
              };
            });
          } else {
            setUserTurnovers([]);
            setActiveTurnoverReq(0);
            setActiveTurnoverDone(0);
            setActiveTurnoverRemaining(0);
          }
        });

        // Listen to user's transactions
        const txRef = ref(rtdb, `users/${firebaseUser.uid}/transactions`);
        const unsubTx = onValue(txRef, (snapshot) => {
          if (snapshot.exists()) {
            const list = Object.values(snapshot.val()) as AccountTransaction[];
            list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            setUserTransactions(list);
          } else {
            setUserTransactions([]);
          }
        });

        return () => {
          unsubProfile();
          unsubClaims();
          unsubTurnovers();
          unsubTx();
        };
      } else {
        // No Firebase user authenticated
        setUser(null);
        setUserGiftClaims([]);
        setUserTurnovers([]);
        setActiveTurnoverReq(0);
        setActiveTurnoverDone(0);
        setActiveTurnoverRemaining(0);
        setUserTransactions([]);
        setAuthLoading(false);
      }
    });

    return () => unsubAuth();
  }, []);

  // Global Realtime Listeners (Settings, Games, Banners, Gift Codes, Win Go History)
  useEffect(() => {
    // 1. Settings listener
    const settingsRef = ref(rtdb, 'settings');
    const unsubSettings = onValue(settingsRef, (snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val();
        setSettings({
          ...defaultSettings,
          ...val,
          paymentChannels: val.paymentChannels || defaultPaymentChannels,
          attendance: {
            ...defaultSettings.attendance!,
            ...(val.attendance || {})
          }
        });
      } else {
        set(settingsRef, defaultSettings);
      }
    });

    // 2. Games listener
    const gamesRef = ref(rtdb, 'games');
    const unsubGames = onValue(gamesRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        const list: GameItem[] = Object.entries(data).map(([key, val]: [string, any]) => ({
          ...val,
          id: val?.id || key
        }));
        list.sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
        setGames(list);
      } else {
        const map: Record<string, GameItem> = {};
        defaultGamesSeed.forEach((g) => { map[g.id] = g; });
        set(gamesRef, map);
        setGames(defaultGamesSeed);
      }
    });

    // 3. Banners listener (Admin managed 5 banners)
    const bannersRef = ref(rtdb, 'banners');
    const unsubBanners = onValue(bannersRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        const list: BannerItem[] = Object.entries(data).map(([key, val]: [string, any]) => ({
          ...val,
          id: val?.id || key
        }));
        list.sort((a, b) => (a.order || 0) - (b.order || 0));
        setBanners(list);
      } else {
        set(bannersRef, defaultBannersSeed);
        setBanners(Object.values(defaultBannersSeed));
      }
    });

    // 3b. Activity Banners listener (Unlimited admin managed activity banners)
    const actBannersRef = ref(rtdb, 'activityBanners');
    const unsubActBanners = onValue(actBannersRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        const list: ActivityBanner[] = Object.entries(data).map(([key, val]: [string, any]) => ({
          ...val,
          id: val?.id || key
        }));
        list.sort((a, b) => (a.order || 0) - (b.order || 0));
        setActivityBanners(list);
      } else {
        set(actBannersRef, defaultActivityBannersSeed);
        setActivityBanners(Object.values(defaultActivityBannersSeed));
      }
    });

    // 4. Gift Codes listener (Admin managed)
    const giftCodesRef = ref(rtdb, 'giftCodes');
    const unsubGiftCodes = onValue(giftCodesRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        const list: GiftCodeItem[] = Object.entries(data).map(([key, val]: [string, any]) => ({
          ...val,
          code: val?.code || key
        }));
        list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setGiftCodes(list);
      } else {
        setGiftCodes([]);
      }
    });

    // 5. Win Go History listener (distinct per gameType: 30s, 1m, 2m, 3m, 5m)
    const historyRef = ref(rtdb, `history/${gameType}`);
    const unsubHistory = onValue(historyRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        const list: GameHistoryItem[] = Object.values(data);
        list.sort((a, b) => b.timestamp - a.timestamp);
        if (list.length >= 10) {
          setGameHistory(list.slice(0, 100));
        } else {
          // If fewer than 10, seed more historical records for this specific gameType
          const initialSeed = generateInitialHistoryForType(gameType, 30);
          const merged = [...list];
          initialSeed.forEach((seedItem) => {
            if (!merged.some((m) => m.periodId === seedItem.periodId)) {
              merged.push(seedItem);
            }
          });
          merged.sort((a, b) => b.timestamp - a.timestamp);
          const seedMap: Record<string, GameHistoryItem> = {};
          merged.forEach((item) => { seedMap[item.periodId] = item; });
          set(historyRef, seedMap);
          setGameHistory(merged.slice(0, 100));
        }
      } else {
        const seedHistory = generateInitialHistoryForType(gameType, 30);
        const seedMap: Record<string, GameHistoryItem> = {};
        seedHistory.forEach((item) => { seedMap[item.periodId] = item; });
        set(historyRef, seedMap);
        setGameHistory(seedHistory);
      }
    });

    // 6. Bets listener
    const betsRef = ref(rtdb, 'bets');
    const unsubBets = onValue(betsRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        const list: BetItem[] = Object.entries(data).map(([key, val]: [string, any]) => ({
          ...val,
          id: val?.id || key
        }));
        list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setAllBets(list);
        settlePendingBets(list);
        if (user?.uid) {
          // Only show actual user bets, never demo/mock bets
          const userSpecificBets = list.filter((b) => b.uid === user.uid && !b.id.startsWith('bet_init_'));
          setUserBets(userSpecificBets);
        } else {
          setUserBets([]);
        }
      } else {
        setAllBets([]);
        setUserBets([]);
      }
    });

    // 7. Deposits listener
    const depositsRef = ref(rtdb, 'deposits');
    const unsubDeposits = onValue(depositsRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        const list: DepositItem[] = Object.entries(data).map(([key, val]: [string, any]) => ({
          ...val,
          id: val?.id || key
        }));
        list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setDeposits(list);
      } else {
        setDeposits([]);
      }
    });

    // 8. Withdrawals listener
    const withRef = ref(rtdb, 'withdrawals');
    const unsubWith = onValue(withRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        const list: WithdrawalItem[] = Object.entries(data).map(([key, val]: [string, any]) => ({
          ...val,
          id: val?.id || key
        }));
        list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setWithdrawals(list);
      } else {
        setWithdrawals([]);
      }
    });

    // 9. All users listener (for admin and username validation)
    const allUsersRef = ref(rtdb, 'users');
    const unsubAllUsers = onValue(allUsersRef, (snapshot) => {
      if (snapshot.exists()) {
        const raw = snapshot.val() || {};
        const normalized: Record<string, UserProfile> = {};
        for (const [key, val] of Object.entries<any>(raw)) {
          if (val && typeof val === 'object') {
            normalized[key] = {
              ...val,
              uid: val.uid || key
            };
          }
        }
        setAllUsers(normalized);
      }
    });

    // 10. Deposit Channels listener
    const channelsRef = ref(rtdb, 'depositChannels');
    const unsubChannels = onValue(channelsRef, (snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val();
        const list: DepositChannel[] = (Array.isArray(val) ? val : Object.entries(val)).map((item: any, idx: number) => {
          if (Array.isArray(val)) {
            return {
              ...item,
              channelId: item?.channelId || `channel_${idx}`
            };
          } else {
            const [key, ch] = item;
            return {
              ...ch,
              channelId: ch?.channelId || key
            };
          }
        });
        if (list.length > 0) {
          setDepositChannels(list);
        }
      }
    });

    return () => {
      unsubSettings();
      unsubGames();
      unsubBanners();
      unsubActBanners();
      unsubGiftCodes();
      unsubHistory();
      unsubBets();
      unsubDeposits();
      unsubWith();
      unsubAllUsers();
      unsubChannels();
    };
  }, [gameType, user?.uid]);

  // Continuous background checker to ensure all expired pending bets resolve immediately, even if user left WinGo or was away
  useEffect(() => {
    const timer = setInterval(() => {
      if (allBets && allBets.length > 0) {
        const hasPending = allBets.some((b) => b.status === 'pending');
        if (hasPending) {
          settlePendingBets(allBets);
        }
      }
    }, 3000);
    return () => clearInterval(timer);
  }, [allBets, settlePendingBets]);

  // Balance Refresh: Default silent=true to prevent unsolicited Refresh toasts during game bets/play!
  // Explicitly pass silent=false when user clicks the manual refresh icon in UI.
  const refreshBalance = async (silent = true) => {
    if (!user?.uid) {
      if (!silent) showToast('Please log in first', 'info');
      return;
    }
    setIsRefreshingBalance(true);
    try {
      const snap = await get(ref(rtdb, `users/${user.uid}/balance`));
      if (snap.exists()) {
        const freshBal = Number(snap.val() || 0);
        setUser((prev) => (prev ? { ...prev, balance: freshBal } : null));
      }
      if (!silent) showToast('Refresh successfully', 'refresh');
    } catch {
      if (!silent) showToast('Refresh successfully', 'refresh');
    } finally {
      setTimeout(() => {
        setIsRefreshingBalance(false);
      }, 400);
    }
  };

  // Direct App Download Handler (Configurable by Admin)
  const downloadApp = useCallback(() => {
    const rawUrl = (settings.appDownloadUrl || '').trim();
    if (!rawUrl) {
      showToast('App download link is currently being configured by the admin.', 'info');
      return;
    }

    showToast('Starting BGNICE Official App download...', 'success');

    try {
      const link = document.createElement('a');
      link.href = rawUrl;
      const fileName = rawUrl.split('/').pop()?.split('?')[0] || 'BGNICE.apk';
      link.setAttribute('download', fileName.endsWith('.apk') ? fileName : `${fileName}.apk`);
      link.setAttribute('target', '_blank');
      link.setAttribute('rel', 'noopener noreferrer');
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) {
          document.body.removeChild(link);
        }
      }, 200);
    } catch {
      window.open(rawUrl, '_blank');
    }
  }, [settings.appDownloadUrl, showToast]);

  // User Profile: Update Nickname
  const updateNickname = async (newNickname: string): Promise<{ success: boolean; message: string }> => {
    if (!user?.uid) {
      return { success: false, message: 'Please log in first' };
    }
    const clean = newNickname.trim();
    if (!clean) {
      return { success: false, message: 'Nickname cannot be empty' };
    }
    await update(ref(rtdb, `users/${user.uid}`), { nickname: clean });
    setUser((prev) => (prev ? { ...prev, nickname: clean } : null));
    return { success: true, message: 'Nickname updated successfully' };
  };

  // User Profile: Update Username (With unique check)
  const updateUsername = async (newUsername: string): Promise<{ success: boolean; message: string }> => {
    if (!user?.uid) {
      return { success: false, message: 'Please log in first' };
    }
    const clean = newUsername.trim().toLowerCase();
    if (clean.length < 3) {
      return { success: false, message: 'Username must be at least 3 characters' };
    }
    if (clean === user.username.toLowerCase()) {
      return { success: true, message: 'Username unchanged' };
    }

    // Check Firebase RTDB whether username is already taken
    const usersSnap = await get(ref(rtdb, 'users'));
    if (usersSnap.exists()) {
      const usersData = usersSnap.val() as Record<string, UserProfile>;
      for (const [otherUid, u] of Object.entries(usersData)) {
        if (otherUid !== user.uid && (u.username || '').trim().toLowerCase() === clean) {
          return { success: false, message: 'Username already exists' };
        }
      }
    }

    await update(ref(rtdb, `users/${user.uid}`), { username: clean });
    setUser((prev) => (prev ? { ...prev, username: clean } : null));
    return { success: true, message: 'Username updated successfully' };
  };

  // User Profile: Update Avatar
  const updateAvatar = async (avatarId: string): Promise<{ success: boolean; message: string }> => {
    if (!user?.uid) {
      return { success: false, message: 'Please log in first' };
    }
    await update(ref(rtdb, `users/${user.uid}`), { avatar: avatarId });
    setUser((prev) => (prev ? { ...prev, avatar: avatarId } : null));
    showToast('Avatar updated successfully', 'success');
    return { success: true, message: 'Avatar updated' };
  };

  // User Profile: Bind Real Email (Gmail with OTP verification)
  const bindEmail = async (emailToBind: string): Promise<{ success: boolean; message: string }> => {
    if (!user?.uid) {
      return { success: false, message: 'Please log in first' };
    }
    const clean = emailToBind.trim().toLowerCase();
    if (!clean || !clean.includes('@') || !clean.includes('.')) {
      return { success: false, message: 'Please enter a valid Gmail / email address' };
    }

    // Check if email is already bound to another user in RTDB
    const usersSnap = await get(ref(rtdb, 'users'));
    if (usersSnap.exists()) {
      const usersData = usersSnap.val() as Record<string, UserProfile>;
      for (const [otherUid, u] of Object.entries(usersData)) {
        if (otherUid !== user.uid) {
          if (
            (u.email && u.email.toLowerCase() === clean) ||
            (u.boundEmail && u.boundEmail.toLowerCase() === clean)
          ) {
            return { success: false, message: 'This email is already linked to another account' };
          }
        }
      }
    }

    await update(ref(rtdb, `users/${user.uid}`), {
      boundEmail: clean,
      emailVerified: true
    });
    setUser((prev) => (prev ? { ...prev, boundEmail: clean, emailVerified: true } : null));
    showToast('Email bound successfully!', 'success');
    return { success: true, message: 'Email bound successfully!' };
  };

  // Auth: Register Account (Supports background Phone -> Email conversion e.g. 01700000000@mygame.com)
  const register = async (params: {
    username?: string;
    email?: string;
    country?: string;
    countryCode?: string;
    phone: string;
    password: string;
    referCode?: string;
    phoneVerified?: boolean;
  }): Promise<{ success: boolean; message: string }> => {
    // 1. Normalize Phone Number
    let cleanPhone = params.phone.trim();
    let digits = cleanPhone.replace(/\D/g, '');
    if (digits.startsWith('880')) digits = digits.slice(3);
    if (!digits.startsWith('0') && digits.length === 10) digits = '0' + digits;
    cleanPhone = digits || cleanPhone;

    // Background email generation: 017XXXXXXXX@mygame.com
    const cleanEmail = (params.email || (digits ? `${digits}@mygame.com` : '')).trim().toLowerCase();
    const cleanUsername = (params.username || (digits ? `u_${digits}` : `u_${Date.now().toString().slice(-6)}`)).trim().toLowerCase();
    const cleanPass = params.password;

    // Validations
    if (!cleanPhone || cleanPhone.length < 8) {
      return { success: false, message: 'Please enter a valid phone number' };
    }
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      return { success: false, message: 'Please enter a valid phone number or email address' };
    }
    if (!cleanPass || cleanPass.length < 6) {
      return { success: false, message: 'Password must be at least 6 characters' };
    }

    // 2. Check username, email & phone uniqueness in RTDB
    const usersSnap = await get(ref(rtdb, 'users'));
    let existingNumericUids = new Set<string>();
    let existingReferCodes = new Set<string>();
    let validatedReferrer: string | null = null;

    if (usersSnap.exists()) {
      const usersData = usersSnap.val() as Record<string, UserProfile>;
      for (const u of Object.values(usersData)) {
        const uPhoneDigits = (u.phone || '').replace(/\D/g, '');
        if (
          (u.phone || '').trim() === cleanPhone ||
          (digits.length >= 8 && uPhoneDigits && (uPhoneDigits === digits || uPhoneDigits.endsWith(digits) || digits.endsWith(uPhoneDigits)))
        ) {
          return { success: false, message: 'এই ফোন নম্বর দিয়ে ইতিমধ্যে অ্যাকাউন্ট আছে (Phone number already registered)' };
        }
        if (params.username && (u.username || '').trim().toLowerCase() === cleanUsername) {
          return { success: false, message: 'Username already exists' };
        }
        if ((u.email || '').trim().toLowerCase() === cleanEmail) {
          return { success: false, message: 'This phone/email is already registered.' };
        }
        if (u.numericUid) existingNumericUids.add(u.numericUid);
        if (u.referCode) existingReferCodes.add(u.referCode);
        if (u.referralCode) existingReferCodes.add(u.referralCode);
      }

      // Check referral code validity - strictly mandatory
      const refInput = params.referCode?.trim();
      if (!refInput) {
        return {
          success: false,
          message: 'রেফার কোড ছাড়া একাউন্ট রেজিস্টার করা সম্ভব নয়। অনুগ্রহ করে রেফার কোড দিন (Refer code is required).'
        };
      }

      let foundRefUser: UserProfile | null = null;
      for (const u of Object.values(usersData)) {
        if (
          u.referCode === refInput ||
          u.referralCode === refInput ||
          u.inviteCode === refInput ||
          u.numericUid === refInput ||
          u.uid === refInput
        ) {
          foundRefUser = u;
          break;
        }
      }

      const isMasterRef = refInput === '1137623631' || refInput.toUpperCase() === 'BGNICE' || refInput.toUpperCase() === 'TRADEBD' || refInput.toUpperCase() === 'ADMIN888';
      if (!foundRefUser && !isMasterRef && Object.keys(usersData).length > 0) {
        return {
          success: false,
          message: 'প্রদত্ত রেফার কোডটি সঠিক নয়। অনুগ্রহ করে একটি সক্রিয় রেফার কোড দিন (Invalid referral code).'
        };
      }
      validatedReferrer = foundRefUser ? (foundRefUser.numericUid || foundRefUser.uid) : (isMasterRef ? 'ADMIN_DIRECT' : null);
    } else {
      // If no users in database yet
      const refInput = params.referCode?.trim();
      if (!refInput) {
        return {
          success: false,
          message: 'রেফার কোড ছাড়া একাউন্ট রেজিস্টার করা সম্ভব নয়। অনুগ্রহ করে রেফার কোড দিন (Refer code is required).'
        };
      }
      validatedReferrer = 'ADMIN_DIRECT';
    }

    // Generate unique 6-digit numeric UID (100000 - 999999)
    let generatedNumericUid = Math.floor(100000 + Math.random() * 900000).toString();
    while (existingNumericUids.has(generatedNumericUid)) {
      generatedNumericUid = Math.floor(100000 + Math.random() * 900000).toString();
    }

    // Generate unique 10-digit numeric referral code (1000000000 - 9999999999)
    let generatedReferCode = String(Math.floor(1000000000 + Math.random() * 9000000000));
    while (existingReferCodes.has(generatedReferCode)) {
      generatedReferCode = String(Math.floor(1000000000 + Math.random() * 9000000000));
    }

    try {
      // 3. Create Firebase Authentication User
      const userCredential = await createUserWithEmailAndPassword(auth, cleanEmail, cleanPass);
      const newUid = userCredential.user.uid;

      // 4. Check Signup Bonus Settings
      const isBonusActive = settings?.signupBonusEnabled !== false;
      const bonusAmount = isBonusActive ? Number(settings?.signupBonusAmount ?? 50) : 0;
      const turnoverMultiplier = Number(settings?.signupBonusTurnoverMultiplier ?? 1);
      const bonusTurnover = Number((bonusAmount * turnoverMultiplier).toFixed(2));

      // 5. Generate HGNICE / MV style gaming nickname (e.g. M_V7298) and random human avatar
      const random4Digits = Math.floor(1000 + Math.random() * 9000);
      const initialNickname = `M_V${random4Digits}`;
      const randomAvatarIdx = Math.floor(1 + Math.random() * 10);
      const initialAvatar = `avatar_${randomAvatarIdx}`;

      // 6. Create User Profile in Realtime Database
      const newUserProfile: UserProfile = {
        uid: newUid,
        numericUid: generatedNumericUid,
        username: cleanUsername,
        nickname: initialNickname,
        email: cleanEmail,
        country: params.country || 'Bangladesh',
        countryCode: params.countryCode || '+880',
        phone: cleanPhone,
        phoneVerified: !!params.phoneVerified,
        avatar: initialAvatar,
        profilePhoto: initialAvatar,
        referCode: generatedReferCode,
        referralCode: generatedReferCode,
        referredBy: validatedReferrer,
        inviteCode: generatedReferCode,
        vipLevel: 0,
        balance: bonusAmount,
        depositBalance: 0.00,
        withdrawBalance: 0.00,
        bonusBalance: bonusAmount,
        safeBalance: 0.00,
        totalBets: 0,
        totalWon: 0,
        totalLoss: 0,
        turnoverReq: bonusTurnover,
        turnoverDone: 0,
        turnoverRequired: bonusTurnover,
        turnoverCompleted: 0,
        referralBalance: 0,
        role: 'user',
        status: 'active',
        createdAt: Date.now(),
        lastLogin: Date.now(),
        savedWithdrawAccounts: []
      };

      await set(ref(rtdb, `users/${newUid}`), newUserProfile);
      setUser(newUserProfile);

      // Record Signup Bonus Turnover & Transaction if credited
      if (bonusAmount > 0) {
        try {
          const turnoverRef = push(ref(rtdb, `users/${newUid}/turnovers`));
          const turnoverRec: TurnoverRecord = {
            id: turnoverRef.key || `to_sb_${Date.now()}`,
            sourceType: 'bonus',
            sourceId: 'SIGNUP_BONUS',
            requiredAmount: bonusTurnover,
            completedAmount: 0,
            remainingAmount: bonusTurnover,
            status: 'active',
            createdAt: Date.now()
          };
          await set(turnoverRef, turnoverRec);

          await recordTransaction(
            newUid,
            'gift_code',
            bonusAmount,
            0,
            bonusAmount,
            `নতুন সাইনআপ বোনাস (Welcome Bonus: ৳${bonusAmount.toFixed(2)})`,
            'SIGNUP_BONUS'
          );
        } catch (e) {
          console.error('Failed to log signup bonus record:', e);
        }
        showToast(`স্বাগতম! নতুন সাইনআপ বোনাস ৳${bonusAmount} আপনার ব্যালেন্সে যোগ হয়েছে!`, 'success');
      } else {
        showToast('Welcome to BGNICE', 'success');
      }
      return { success: true, message: 'Account created successfully' };
    } catch (err: any) {
      let msg = err.message || 'Registration failed';
      if (err.code === 'auth/email-already-in-use') {
        msg = 'This email is already registered.';
      } else if (err.code === 'auth/weak-password') {
        msg = 'Password should be at least 6 characters';
      } else if (err.code === 'auth/invalid-email') {
        msg = 'Invalid email address format';
      }
      return { success: false, message: msg };
    }
  };

  // Auth: Login Account (Gmail / Email OR Username + Password)
  const login = async (identifier: string, pass: string): Promise<{ success: boolean; message: string }> => {
    const cleanId = identifier.trim().toLowerCase();
    if (!cleanId || !pass) {
      return { success: false, message: 'Please enter your username/email and password' };
    }

    let emailToAuth = cleanId;

    // If identifier is NOT an email (doesn't contain '@'), look up user's email in RTDB by username or phone number
    if (!cleanId.includes('@')) {
      let digitsOnly = cleanId.replace(/\D/g, '');
      if (digitsOnly.startsWith('880')) digitsOnly = digitsOnly.slice(3);
      if (!digitsOnly.startsWith('0') && digitsOnly.length === 10) digitsOnly = '0' + digitsOnly;

      const usersSnap = await get(ref(rtdb, 'users'));
      let foundEmail = '';
      if (usersSnap.exists()) {
        const usersData = usersSnap.val() as Record<string, UserProfile>;
        for (const u of Object.values(usersData)) {
          const userPhoneDigits = (u.phone || '').replace(/\D/g, '');
          if (
            (u.phone && (u.phone === cleanId || u.phone === digitsOnly || (digitsOnly.length >= 7 && (userPhoneDigits === digitsOnly || userPhoneDigits.endsWith(digitsOnly) || digitsOnly.endsWith(userPhoneDigits))))) ||
            (u.username && u.username.toLowerCase() === cleanId)
          ) {
            foundEmail = u.email;
            break;
          }
        }
      }

      // If found in RTDB, use their email. Otherwise try direct background email format ${digitsOnly}@mygame.com
      emailToAuth = foundEmail || (digitsOnly ? `${digitsOnly}@mygame.com` : cleanId);
    }

    try {
      const credential = await signInWithEmailAndPassword(auth, emailToAuth, pass);
      const userSnap = await get(ref(rtdb, `users/${credential.user.uid}`));
      if (userSnap.exists()) {
        const p = userSnap.val() as UserProfile;
        if (p.status === 'banned') {
          await signOut(auth);
          return { success: false, message: 'This account has been suspended by administration.' };
        }
        await update(ref(rtdb, `users/${credential.user.uid}`), { lastLogin: Date.now() });
        setUser(p);
        recordLoginNotification(credential.user.uid);
      }
      showToast('Welcome to BGNICE', 'success');
      return { success: true, message: 'Login successful' };
    } catch (err: any) {
      let msg = 'Invalid email or password';
      if (err.code === 'auth/user-not-found') {
        msg = 'Account not found. Please Sign Up.';
      } else if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        msg = 'Invalid email or password';
      }
      return { success: false, message: msg };
    }
  };

  // Auth: Phone Login (Country Code + Phone Digits + Password)
  const loginWithPhone = async (
    countryCode: string,
    phoneDigits: string,
    pass: string
  ): Promise<{ success: boolean; message: string }> => {
    const cleanDigits = phoneDigits.trim();
    if (!cleanDigits) {
      return { success: false, message: 'Please enter your phone number' };
    }
    if (!pass) {
      return { success: false, message: 'Please enter your password' };
    }

    let digits = cleanDigits.replace(/\D/g, '');
    if (digits.startsWith('880')) digits = digits.slice(3);
    if (!digits.startsWith('0') && digits.length === 10) digits = '0' + digits;

    const normalizedPhone = `${countryCode}${digits}`;

    // Lookup user in RTDB by normalized phone or digits
    const usersSnap = await get(ref(rtdb, 'users'));
    let emailToAuth = digits ? `${digits}@mygame.com` : '';

    if (usersSnap.exists()) {
      const usersData = usersSnap.val() as Record<string, UserProfile>;
      for (const u of Object.values(usersData)) {
        const uDigits = (u.phone || '').replace(/\D/g, '');
        if (
          (u.phone || '').trim() === normalizedPhone ||
          (u.phone || '').trim() === digits ||
          (u.phone || '').trim() === cleanDigits ||
          (digits.length >= 7 && (uDigits === digits || uDigits.endsWith(digits) || digits.endsWith(uDigits)))
        ) {
          emailToAuth = u.email;
          break;
        }
      }
    }

    if (!emailToAuth) {
      return { success: false, message: 'Account not found. Please Sign Up.' };
    }

    try {
      const credential = await signInWithEmailAndPassword(auth, emailToAuth, pass);
      const userSnap = await get(ref(rtdb, `users/${credential.user.uid}`));
      if (userSnap.exists()) {
        const p = userSnap.val() as UserProfile;
        if (p.status === 'banned') {
          await signOut(auth);
          return { success: false, message: 'This account has been suspended by administration.' };
        }
        await update(ref(rtdb, `users/${credential.user.uid}`), { lastLogin: Date.now() });
        setUser(p);
        recordLoginNotification(credential.user.uid);
      }
      showToast('Welcome to BGNICE', 'success');
      return { success: true, message: 'Login successful' };
    } catch (err: any) {
      let msg = 'Invalid email or password';
      if (err.code === 'auth/user-not-found') {
        msg = 'Account not found. Please Sign Up.';
      } else if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        msg = 'Invalid email or password';
      }
      return { success: false, message: msg };
    }
  };

  // Auth: Send Password Reset Email
  const sendPasswordReset = async (email: string): Promise<{ success: boolean; message: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      return { success: false, message: 'Please enter a valid email address' };
    }

    try {
      await sendPasswordResetEmail(auth, cleanEmail);
      showToast('Password reset link sent to your email', 'success');
      return { success: true, message: 'Password reset link sent! Check your inbox.' };
    } catch (err: any) {
      let msg = 'Failed to send password reset email';
      if (err.code === 'auth/user-not-found') {
        msg = 'Account not found. Please Sign Up.';
      }
      return { success: false, message: msg };
    }
  };

  // Auth: Logout
  const logout = async () => {
    await signOut(auth);
    setUser(null);
    showToast('Logged out successfully', 'info');
  };

  // Win Go Cycle Resolver
  const resolveGameRound = useCallback(async (currentPeriod: string, currentType: GameType) => {
    const existingRef = ref(rtdb, `history/${currentType}/${currentPeriod}`);
    const snap = await get(existingRef);
    let winningNum: number;

    if (snap.exists()) {
      winningNum = snap.val().number;
    } else {
      const settingsSnap = await get(ref(rtdb, 'settings'));
      const forced = settingsSnap.exists() ? settingsSnap.val()?.forcedResults?.[currentType] : null;

      if (typeof forced === 'number' && forced >= 0 && forced <= 9) {
        winningNum = forced;
        update(ref(rtdb, 'settings/forcedResults'), { [currentType]: null });
      } else {
        winningNum = Math.floor(Math.random() * 10);
      }

      const colors = getNumberColors(winningNum);
      const bigSmall = getNumberSize(winningNum);

      const historyItem: GameHistoryItem = {
        periodId: currentPeriod,
        number: winningNum,
        bigSmall,
        colors,
        timestamp: Date.now()
      };

      await set(ref(rtdb, `history/${currentType}/${currentPeriod}`), historyItem);
    }

    // Settle bets for this period
    const betsSnap = await get(ref(rtdb, 'bets'));
    if (betsSnap.exists()) {
      const allBetsData = betsSnap.val();
      let totalUserWin = 0;
      let totalUserBet = 0;
      let userWonAny = false;
      let userHadBet = false;
      const colors = getNumberColors(winningNum);
      const bigSmall = getNumberSize(winningNum);

      for (const [key, betVal] of Object.entries<BetItem>(allBetsData)) {
        if (betVal.periodId === currentPeriod && betVal.gameType === currentType && betVal.status === 'pending') {
          const outcome = calculateWin(betVal.selectType, betVal.selectValue, winningNum, betVal.totalAmount);
          const newStatus = outcome.isWin ? 'won' : 'lost';
          const winAmount = outcome.winAmount;

          await update(ref(rtdb, `bets/${key}`), {
            status: newStatus,
            winAmount,
            resultNumber: winningNum
          });

          if (outcome.isWin && winAmount > 0) {
            const userSnap = await get(ref(rtdb, `users/${betVal.uid}`));
            if (userSnap.exists()) {
              const uData = userSnap.val() as UserProfile;
              const currentBal = Number(uData.balance || 0);
              const updatedBal = Number((currentBal + winAmount).toFixed(2));
              const currentWon = Number(uData.totalWon || 0);
              const updatedWon = Number((currentWon + winAmount).toFixed(2));

              await update(ref(rtdb, `users/${betVal.uid}`), {
                balance: updatedBal,
                totalWon: updatedWon
              });

              await recordTransaction(
                betVal.uid,
                'win',
                winAmount,
                currentBal,
                updatedBal,
                `Win Go Period ${currentPeriod} Victory (+৳${winAmount.toFixed(2)})`,
                key
              );
            }

            if (user && betVal.uid === user.uid) {
              totalUserWin += winAmount;
              userWonAny = true;
            }
          } else if (!outcome.isWin) {
            const userSnap = await get(ref(rtdb, `users/${betVal.uid}`));
            if (userSnap.exists()) {
              const uData = userSnap.val() as UserProfile;
              const currentLoss = Number(uData.totalLoss || 0);
              const updatedLoss = Number((currentLoss + betVal.totalAmount).toFixed(2));
              await update(ref(rtdb, `users/${betVal.uid}`), { totalLoss: updatedLoss });
            }

            if (user && betVal.uid === user.uid) {
              totalUserBet += betVal.totalAmount;
              userHadBet = true;
            }
          }
        }
      }

      const durLabel = gameType === '30s' ? '30s' : gameType === '1m' ? '1Min' : gameType === '2m' ? '2Min' : gameType === '3m' ? '3Min' : '5Min';

      if (userWonAny) {
        confetti({ particleCount: 90, spread: 75, origin: { y: 0.6 } });
        const curBal = Number(user?.balance || 0);
        const prevBal = Number(Math.max(0, curBal - totalUserWin).toFixed(2));
        setLastWinModal({
          win: true,
          amount: totalUserWin,
          period: currentPeriod,
          gameName: 'Win Go',
          duration: durLabel,
          resultNumber: winningNum,
          resultBigSmall: bigSmall,
          resultColors: colors,
          previousBalance: prevBal,
          newBalance: curBal
        });
        // Black toast removed per user request so result modal displays cleanly
      } else if (userHadBet && totalUserBet > 0) {
        const curBal = Number(user?.balance || 0);
        const prevBal = Number((curBal + totalUserBet).toFixed(2));
        setLastWinModal({
          win: false,
          amount: totalUserBet,
          period: currentPeriod,
          gameName: 'Win Go',
          duration: durLabel,
          resultNumber: winningNum,
          resultBigSmall: bigSmall,
          resultColors: colors,
          previousBalance: prevBal,
          newBalance: curBal
        });
        // Black toast 'Better luck next time' removed per user request
      }
    }
  }, [user, showToast]);

  // Win Go Timer Loop
  useEffect(() => {
    const cycleSec = gameType === '30s' ? 30 : gameType === '1m' ? 60 : gameType === '2m' ? 120 : gameType === '3m' ? 180 : 300;

    const interval = setInterval(() => {
      const now = Math.floor(Date.now() / 1000);
      const rem = cycleSec - (now % cycleSec);
      setTimeLeft(rem);

      const currentExpectedPeriod = generatePeriodId(gameType);
      setPeriodId(currentExpectedPeriod);

      if (rem <= 5 && rem > 0) {
        playBeepSound(rem === 1);
      }

      if (rem === 1) {
        resolveGameRound(currentExpectedPeriod, gameType);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [gameType, resolveGameRound]);

  // Centralized turnover fulfillment for ANY game (Aviator, Aviator X, Crash, K3, 5D, TRX, WinGo, Casino, etc.)
  const fulfillBetTurnover = async (uid: string, betAmount: number) => {
    if (!uid || betAmount <= 0) return;
    try {
      const userSnap = await get(ref(rtdb, `users/${uid}`));
      if (!userSnap.exists()) return;
      const uData = userSnap.val();
      const curTurnoverDone = Number(uData.turnoverDone || 0);
      const newTurnoverDone = Number((curTurnoverDone + betAmount).toFixed(2));
      const curTotalBets = Number(uData.totalBets || 0);
      const newTotalBets = Number((curTotalBets + betAmount).toFixed(2));
      const newVip = Math.max(uData.vipLevel ?? 0, calculateVipLevel(newTotalBets, settings.vipLevels));

      await update(ref(rtdb, `users/${uid}`), {
        turnoverDone: newTurnoverDone,
        totalBets: newTotalBets,
        vipLevel: newVip
      });

      // Sequentially fulfill active turnover records in RTDB
      const turnoversSnap = await get(ref(rtdb, `users/${uid}/turnovers`));
      if (turnoversSnap.exists()) {
        const turnoversMap = turnoversSnap.val() as Record<string, TurnoverRecord>;
        let betContribution = betAmount;
        const updates: Record<string, any> = {};

        const sortedEntries = Object.entries(turnoversMap).sort(
          ([, a], [, b]) => (a?.createdAt || 0) - (b?.createdAt || 0)
        );

        for (const [tId, tRec] of sortedEntries) {
          if (tRec && tRec.status === 'active' && betContribution > 0) {
            const currentCompleted = Number(tRec.completedAmount || 0);
            const needed = tRec.remainingAmount !== undefined
              ? Number(tRec.remainingAmount)
              : Math.max(0, Number(tRec.requiredAmount || 0) - currentCompleted);

            if (needed > 0) {
              const contribution = Math.min(betContribution, needed);
              const newCompleted = Number((currentCompleted + contribution).toFixed(2));
              const newRemaining = Number(Math.max(0, needed - contribution).toFixed(2));
              betContribution = Number(Math.max(0, betContribution - contribution).toFixed(2));

              updates[`${tId}/completedAmount`] = newCompleted;
              updates[`${tId}/remainingAmount`] = newRemaining;

              if (newRemaining <= 0) {
                updates[`${tId}/status`] = 'completed';
                updates[`${tId}/completedAt`] = Date.now();
              }
            }
          }
        }

        if (Object.keys(updates).length > 0) {
          await update(ref(rtdb, `users/${uid}/turnovers`), updates);
        }
      }
    } catch (toErr) {
      console.error('Turnover fulfillment error:', toErr);
    }
  };

  // Record unified game bet in `bets/` so all games appear in Game History
  const recordGameBet = async (betData: {
    uid: string;
    gameType: string;
    gameName?: string;
    selectType?: string;
    selectValue?: string;
    amount: number;
    totalAmount?: number;
    status?: 'pending' | 'won' | 'lost' | 'cancelled';
    winAmount?: number;
    multiplier?: number;
    periodId?: string;
    outcome?: string;
    betId?: string;
  }): Promise<string> => {
    try {
      const id = betData.betId || push(ref(rtdb, 'bets')).key || `bet_${Date.now()}`;
      const betItem: BetItem = {
        id,
        uid: betData.uid,
        phone: user?.phone || user?.username || 'User',
        periodId: betData.periodId || `rd_${Date.now()}`,
        gameType: betData.gameType,
        gameName: betData.gameName || betData.gameType,
        selectType: betData.selectType || 'standard',
        selectValue: betData.selectValue || 'Standard Bet',
        amount: betData.amount,
        multiplier: betData.multiplier || 1,
        totalAmount: betData.totalAmount || betData.amount,
        status: betData.status || 'pending',
        winAmount: betData.winAmount || 0,
        createdAt: Date.now()
      };
      if (betData.outcome !== undefined) {
        betItem.outcome = betData.outcome;
      }
      await set(ref(rtdb, `bets/${id}`), stripUndefined(betItem));
      return id;
    } catch (e) {
      console.error('Failed to record game bet:', e);
      return betData.betId || `bet_${Date.now()}`;
    }
  };

  // Update game bet status in `bets/`
  const updateGameBetStatus = async (
    betId: string,
    status: 'won' | 'lost' | 'cancelled',
    winAmount?: number,
    outcome?: string,
    multiplier?: number
  ) => {
    try {
      if (status === 'lost') {
        // Guard: Check if the bet is already won or cashed out so it can NEVER be overwritten with lost
        const betSnap = await get(ref(rtdb, `bets/${betId}`)).catch(() => null);
        if (betSnap && betSnap.exists()) {
          const currentData = betSnap.val();
          if (currentData.status === 'won' || (currentData.winAmount && currentData.winAmount > 0)) {
            return; // Never overwrite a won bet
          }
        }
      }
      const updates: Record<string, any> = { status };
      if (winAmount !== undefined) updates.winAmount = winAmount;
      if (outcome !== undefined) updates.outcome = outcome;
      if (multiplier !== undefined) updates.multiplier = multiplier;
      await update(ref(rtdb, `bets/${betId}`), stripUndefined(updates));
    } catch (e) {
      console.error('Failed to update game bet status:', e);
    }
  };

  // Place Bet
  const placeBet = async (
    selectType: 'color' | 'number' | 'size',
    selectValue: string,
    amount: number,
    multiplier: number
  ): Promise<boolean> => {
    try {
      if (!user) {
        showToast('Please sign up or log in first', 'error');
        return false;
      }
      const total = Number((amount * multiplier).toFixed(2));
      if (user.balance < total) {
        showToast('Insufficient balance! Please deposit to continue', 'error');
        return false;
      }
      if (timeLeft <= 5) {
        showToast('Betting is closed for current period! Wait for next round', 'info');
        return false;
      }

      const prevBal = Number(user.balance || 0);
      const newBal = Number((prevBal - total).toFixed(2));

      // 1. Instant local optimistic update (immediate acceptance without delay)
      setUser((prev) => (prev ? { ...prev, balance: newBal } : null));
      showToast('Bet placed successfully', 'success');

      // 2. Non-blocking parallel DB sync
      const newBetRef = push(ref(rtdb, 'bets'));
      const betItem: BetItem = {
        id: newBetRef.key || Date.now().toString(),
        uid: user.uid,
        phone: user.phone || user.username || 'User',
        periodId,
        gameType,
        gameName: `Win Go (${gameType})`,
        selectType,
        selectValue,
        amount,
        multiplier,
        totalAmount: total,
        status: 'pending',
        createdAt: Date.now()
      };

      Promise.all([
        update(ref(rtdb, `users/${user.uid}`), { balance: newBal }),
        set(newBetRef, stripUndefined(betItem)),
        fulfillBetTurnover(user.uid, total),
        recordTransaction(
          user.uid,
          'bet',
          -total,
          prevBal,
          newBal,
          `Win Go bet placed: ${selectValue} (${gameType})`,
          betItem.id
        )
      ]).catch((err) => {
        console.error('Background bet sync error:', err);
      });

      return true;
    } catch (err: any) {
      console.error('Bet error', err);
      showToast(err.message || 'Failed to place bet. Please try again.', 'error');
      return false;
    }
  };

  // Submit Deposit
  const submitDeposit = async (
    channel: string,
    method: 'nagad' | 'bkash' | 'usdt',
    amount: number,
    txnId: string
  ): Promise<boolean> => {
    if (!user) return false;
    const newDepRef = push(ref(rtdb, 'deposits'));
    const channelConfig = settings.paymentChannels?.[method];
    const agentNum = channelConfig?.agentNumber || (method === 'nagad' ? settings.nagadNumber : method === 'bkash' ? settings.bkashNumber : settings.usdtAddress);
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randDigits = Math.floor(100000 + Math.random() * 900000);
    const orderId = `D${dateStr}${randDigits}`;

    const depItem: DepositItem = {
      id: newDepRef.key || `RC${Date.now()}`,
      orderId,
      uid: user.uid,
      phone: user.phone,
      amount,
      channel,
      method,
      agentNumber: agentNum,
      txnId,
      status: 'pending',
      createdAt: Date.now()
    };

    await set(newDepRef, depItem);
    showToast('Deposit request submitted! Awaiting agent confirmation.', 'success');
    return true;
  };

  // Submit Deposit Channel Request with Dynamic DepositChannel configuration
  const submitDepositChannelRequest = async (
    channel: DepositChannel,
    amount: number,
    txnId: string
  ): Promise<DepositItem | null> => {
    if (!user) return null;
    const newDepRef = push(ref(rtdb, 'deposits'));
    const depId = newDepRef.key || `DEP_${Date.now()}`;
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randDigits = Math.floor(100000 + Math.random() * 900000);
    const orderId = `D${dateStr}${randDigits}`;
    const method = (
      channel.paymentType.toLowerCase() === 'bkash'
        ? 'bkash'
        : channel.paymentType.toLowerCase() === 'rocket'
        ? 'rocket'
        : channel.paymentType.toLowerCase() === 'usdt'
        ? 'usdt'
        : 'nagad'
    );

    const depItem: DepositItem = {
      id: depId,
      orderId,
      uid: user.uid,
      phone: user.phone || user.numericUid || '',
      username: user.username || user.nickname || '',
      amount,
      channel: channel.channelName,
      method,
      agentNumber: channel.paymentNumber || channel.walletAddress || '',
      txnId,
      status: 'pending',
      createdAt: Date.now()
    };

    await set(newDepRef, depItem);
    // Also store in depositRequests/{depId} as required
    await set(ref(rtdb, `depositRequests/${depId}`), depItem).catch(() => {});
    return depItem;
  };

  // Submit Withdrawal
  const submitWithdrawal = async (
    amount: number,
    type: 'E-Wallet' | 'USDT',
    walletMethod: 'BKASH' | 'NAGAD' | 'ROCKET' | 'USDT',
    accountNumber: string,
    accountName?: string,
    usdtAmount?: number,
    dollarRate?: number
  ): Promise<boolean> => {
    if (!user) return false;

    const rate = dollarRate || settings.usdtRate || 125;
    if (type === 'USDT') {
      const minUsdt = settings.minWithdrawUsdt || 10;
      const minBdt = minUsdt * rate;
      const calcUsdt = usdtAmount !== undefined ? usdtAmount : amount / rate;
      if (calcUsdt < minUsdt || amount < minBdt) {
        showToast(`Minimum withdrawal for USDT is $${minUsdt}.00 (৳${minBdt.toFixed(2)})`, 'error');
        return false;
      }
    } else {
      if (amount < settings.minWithdraw) {
        showToast(`Minimum withdrawal amount is ৳${settings.minWithdraw}`, 'error');
        return false;
      }
    }

    if (user.balance < amount) {
      showToast('Insufficient withdrawable balance', 'error');
      return false;
    }

    const newBal = Number((user.balance - amount).toFixed(2));
    await update(ref(rtdb, `users/${user.uid}`), { balance: newBal });

    const newWithRef = push(ref(rtdb, 'withdrawals'));
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randDigits = Math.floor(100000 + Math.random() * 900000);
    const orderId = `W${dateStr}${randDigits}`;
    const calculatedUsdt = type === 'USDT'
      ? (usdtAmount !== undefined ? Number(usdtAmount.toFixed(2)) : Number((amount / rate).toFixed(2)))
      : undefined;

    const withItem: WithdrawalItem = {
      id: newWithRef.key || `WD${Date.now()}`,
      orderId,
      uid: user.uid,
      phone: user.phone,
      amount,
      type,
      walletMethod,
      accountName,
      accountNumber,
      status: 'pending',
      createdAt: Date.now(),
      usdtAmount: calculatedUsdt,
      dollarRate: type === 'USDT' ? rate : undefined
    };

    await set(newWithRef, stripUndefined(withItem));

    const transDesc = type === 'USDT'
      ? `Withdrawal transfer out (USDT TRC20: ${accountNumber} - $${calculatedUsdt} USDT @ ৳${rate})`
      : `Withdrawal transfer out (${walletMethod}: ${accountNumber})`;

    await recordTransaction(
      user.uid,
      'withdraw_out',
      -amount,
      user.balance,
      newBal,
      transDesc,
      withItem.id
    );

    showToast('Withdrawal request submitted successfully', 'success');
    return true;
  };

  // Save Withdrawal Account (Strictly max 3)
  const saveWithdrawAccount = async (
    type: 'BKASH' | 'NAGAD' | 'ROCKET' | 'USDT',
    accountName: string,
    accountNumber: string,
    logo?: string
  ): Promise<{ success: boolean; message: string }> => {
    if (!user) return { success: false, message: 'Please login first' };
    const currentList = user.savedWithdrawAccounts || [];
    if (currentList.length >= 3) {
      return {
        success: false,
        message: 'Maximum limit reached! You can only save up to 3 withdrawal numbers.'
      };
    }
    const finalLogo = (logo && logo.trim()) || PAYMENT_LOGOS[type.toLowerCase() as keyof typeof PAYMENT_LOGOS] || '';
    const newAccount: SavedWithdrawAccount = {
      id: `acc_${Date.now()}`,
      type,
      accountName: accountName.trim(),
      accountNumber: accountNumber.trim(),
      ...(finalLogo ? { logo: finalLogo } : {})
    };
    const updated = [...currentList, newAccount];
    await update(ref(rtdb, `users/${user.uid}`), stripUndefined({ savedWithdrawAccounts: updated }));
    return { success: true, message: 'Withdrawal account saved successfully' };
  };

  // Delete Withdrawal Account
  const deleteWithdrawAccount = async (accountId: string) => {
    if (!user) return;
    const currentList = user.savedWithdrawAccounts || [];
    const updated = currentList.filter((a) => a.id !== accountId);
    await update(ref(rtdb, `users/${user.uid}`), { savedWithdrawAccounts: updated });
    showToast('Account removed', 'info');
  };

  // Transfer Safe
  const transferSafe = async (amount: number, type: 'Transfer In' | 'Transfer Out'): Promise<boolean> => {
    if (!user || amount <= 0) return false;
    if (type === 'Transfer In') {
      if (user.balance < amount) {
        showToast('Insufficient main balance to transfer into safe', 'error');
        return false;
      }
      const newBal = Number((user.balance - amount).toFixed(2));
      const newSafe = Number((user.safeBalance + amount).toFixed(2));
      await update(ref(rtdb, `users/${user.uid}`), { balance: newBal, safeBalance: newSafe });
    } else {
      if (user.safeBalance < amount) {
        showToast('Insufficient safe balance to transfer out', 'error');
        return false;
      }
      const newSafe = Number((user.safeBalance - amount).toFixed(2));
      const newBal = Number((user.balance + amount).toFixed(2));
      await update(ref(rtdb, `users/${user.uid}`), { balance: newBal, safeBalance: newSafe });
    }
    showToast('Transfer completed', 'success');
    return true;
  };

  // Claim Gift Code (With Realtime Database claim records)
  const claimGiftCode = async (code: string): Promise<{ success: boolean; message: string }> => {
    if (!user) return { success: false, message: 'Please log in first' };
    const clean = code.trim().toUpperCase();
    const codeRef = ref(rtdb, `giftCodes/${clean}`);
    const snap = await get(codeRef);

    if (!snap.exists()) {
      return { success: false, message: 'Gift code is invalid' };
    }

    const gift = snap.val() as GiftCodeItem;
    if (gift.status !== 'active') {
      return { success: false, message: 'Gift code is inactive or expired' };
    }

    if (gift.claimedUsers && gift.claimedUsers[user.uid]) {
      return { success: false, message: 'Gift code already claimed' };
    }

    const currentClaims = gift.claimCount ?? gift.totalClaims ?? 0;
    if (currentClaims >= gift.maxClaims) {
      return { success: false, message: 'Gift code has reached maximum claim limit' };
    }

    const reward = gift.amount ?? gift.rewardAmount ?? 0;
    const newBal = Number((user.balance + reward).toFixed(2));
    const claimId = `claim_${Date.now()}`;

    const claimRecord: GiftClaimRecord = {
      id: claimId,
      uid: user.uid,
      code: clean,
      amount: reward,
      claimedAt: Date.now(),
      status: 'Claimed'
    };

    // Credit balance & record history in RTDB
    await update(ref(rtdb, `users/${user.uid}`), { balance: newBal });
    await set(ref(rtdb, `users/${user.uid}/giftClaims/${claimId}`), claimRecord);
    await set(ref(rtdb, `giftClaims/${claimId}`), claimRecord);

    await recordTransaction(
      user.uid,
      'gift_code',
      reward,
      user.balance,
      newBal,
      `Gift code bonus redeemed (${clean})`,
      claimId
    );

    // Create separate turnover record for this gift code bonus
    const toGiftId = `to_gift_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const giftTurnover: TurnoverRecord = {
      id: toGiftId,
      sourceType: 'bonus',
      sourceId: `gift_${clean}`,
      requiredAmount: Number(reward.toFixed(2)),
      completedAmount: 0,
      remainingAmount: Number(reward.toFixed(2)),
      status: 'active',
      createdAt: Date.now()
    };
    await set(ref(rtdb, `users/${user.uid}/turnovers/${toGiftId}`), giftTurnover);

    await update(codeRef, {
      claimCount: currentClaims + 1,
      totalClaims: currentClaims + 1,
      [`claimedUsers/${user.uid}`]: true
    });

    confetti({ particleCount: 70, spread: 60 });
    return { success: true, message: `Gift code claimed successfully! ৳${reward} credited.` };
  };

  // Claim Daily Attendance (7-Day Streak & Admin Configured Requirements)
  const claimDailyAttendance = async (specifiedDay?: number): Promise<{ success: boolean; message: string }> => {
    if (!user) {
      showToast('Please log in first', 'error');
      return { success: false, message: 'Please log in first' };
    }

    const attConfig = settings.attendance || {
      enabled: true,
      minDeposit: 500,
      totalDepositTarget: 20000,
      requiredDays: 7,
      rewards: [20, 30, 50, 70, 100, 150, 300],
      turnoverMultiplier: 1,
      cooldownHours: 24
    };

    if (attConfig.enabled === false) {
      const msg = 'Attendance bonus is currently disabled by Admin.';
      showToast(msg, 'info');
      return { success: false, message: msg };
    }

    const todayStr = new Date().toISOString().slice(0, 10);
    const claimedDays = user.claimedAttendanceDays || {};
    const lastClaimDate = user.lastAttendanceDate;

    // Check streak / target day
    let streak = user.attendanceStreak || 0;
    if (lastClaimDate) {
      const lastDate = new Date(lastClaimDate);
      const today = new Date(todayStr);
      const diffDays = Math.round((today.getTime() - lastDate.getTime()) / (1000 * 3600 * 24));
      if (diffDays === 0) {
        const msg = 'You have already claimed today’s attendance bonus!';
        showToast(msg, 'info');
        return { success: false, message: msg };
      } else if (diffDays > 1) {
        // Streak reset if missed a day
        streak = 0;
      }
    }

    const expectedDay = (streak % 7) + 1;
    const targetDay = specifiedDay || expectedDay;

    // Rule: User cannot claim future days
    if (targetDay > expectedDay) {
      const msg = `Cannot claim Day ${targetDay} yet! Please complete Day ${expectedDay} first.`;
      showToast(msg, 'error');
      return { success: false, message: msg };
    }

    // Rule: User cannot claim the same day twice in current streak
    if (claimedDays[targetDay]) {
      const msg = `Day ${targetDay} attendance bonus has already been claimed!`;
      showToast(msg, 'error');
      return { success: false, message: msg };
    }

    // 7-day deposit check from real approved Firebase deposits
    const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    const userDeposits7Day = deposits.filter(
      (d) => d.uid === user.uid && d.status === 'completed' && (d.createdAt || 0) >= sevenDaysAgo
    );
    const total7DayDeposits = userDeposits7Day.reduce((acc, d) => acc + (d.amount || 0), 0);

    // 1. Min deposit requirement (e.g. ৳500)
    if (attConfig.minDeposit && attConfig.minDeposit > 0) {
      const hasEligibleDeposit = deposits.some(
        (d) => d.uid === user.uid && d.status === 'completed' && d.amount >= attConfig.minDeposit
      ) || total7DayDeposits >= attConfig.minDeposit;

      if (!hasEligibleDeposit) {
        const msg = `Minimum deposit requirement of ৳${attConfig.minDeposit} required to claim attendance bonus.`;
        showToast(msg, 'error');
        return { success: false, message: msg };
      }
    }

    // 2. 20,000 Deposit / 7-Day target check (if configured)
    if (attConfig.totalDepositTarget && attConfig.totalDepositTarget > 0) {
      if (total7DayDeposits < attConfig.totalDepositTarget) {
        const msg = `7-Day deposit target: ৳${total7DayDeposits.toLocaleString()} / ৳${attConfig.totalDepositTarget.toLocaleString()} completed. Deposit more to unlock!`;
        showToast(msg, 'error');
        return { success: false, message: msg };
      }
    }

    // Calculate reward for targetDay
    const defaultRewards = [20, 30, 50, 70, 100, 150, 300];
    const rewardsList = attConfig.rewards && attConfig.rewards.length >= 7 ? attConfig.rewards : defaultRewards;
    const reward = rewardsList[targetDay - 1] || 20;

    const newBal = Number((user.balance + reward).toFixed(2));
    const newStreak = targetDay === 7 ? 0 : streak + 1;
    const newClaimedDays = targetDay === 7 ? {} : { ...claimedDays, [targetDay]: true };

    await update(ref(rtdb, `users/${user.uid}`), {
      balance: newBal,
      bonusBalance: Number(((user.bonusBalance || 0) + reward).toFixed(2)),
      attendanceStreak: newStreak,
      lastAttendanceDate: todayStr,
      claimedAttendanceDays: newClaimedDays
    });

    // Create separate TurnoverRecord for this attendance bonus
    const turnoverMultiplier = attConfig.turnoverMultiplier || 1;
    const reqTurnover = Number((reward * turnoverMultiplier).toFixed(2));
    const toAttId = `to_att_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const attTurnover: TurnoverRecord = {
      id: toAttId,
      sourceType: 'bonus',
      sourceId: `attendance_day_${targetDay}`,
      requiredAmount: reqTurnover,
      completedAmount: 0,
      remainingAmount: reqTurnover,
      status: 'active',
      createdAt: Date.now()
    };
    await set(ref(rtdb, `users/${user.uid}/turnovers/${toAttId}`), attTurnover);

    await recordTransaction(
      user.uid,
      'attendance',
      reward,
      user.balance,
      newBal,
      `Day ${targetDay} Attendance Reward (Turnover: ৳${reqTurnover})`,
      toAttId
    );

    confetti({ particleCount: 70, spread: 60 });
    const successMsg = `Day ${targetDay} Attendance Reward of ৳${reward} claimed successfully!`;
    showToast(successMsg, 'success');
    return { success: true, message: successMsg };
  };

  // Claim VIP Level Up Bonus
  const claimVipLevelUpBonus = async (level: number): Promise<{ success: boolean; message: string }> => {
    if (!user) return { success: false, message: 'Please log in first' };
    const currentVip = user.vipLevel || 0;
    const config = getVipConfig(level, settings.vipLevels);
    if (!config || config.levelUpBonus <= 0) {
      return { success: false, message: 'No bonus available for this level.' };
    }
    if (currentVip < level || (user.totalBets || 0) < config.minBet) {
      return { success: false, message: `Reach VIP ${level} (Bet ৳${config.minBet} EXP required) to claim this bonus!` };
    }
    const claimedMap = user.levelUpBonusClaimed || {};
    if (claimedMap[level]) {
      return { success: false, message: `VIP ${level} Level Up bonus already claimed.` };
    }

    const bonus = config.levelUpBonus;
    const newBal = Number((user.balance + bonus).toFixed(2));
    const newClaimed = { ...claimedMap, [level]: true };

    await update(ref(rtdb, `users/${user.uid}`), {
      balance: newBal,
      levelUpBonusClaimed: newClaimed
    });

    // Create separate turnover record for VIP bonus
    const toVipId = `to_vip_lvl_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const vipTurnover: TurnoverRecord = {
      id: toVipId,
      sourceType: 'bonus',
      sourceId: `vip_level_${level}`,
      requiredAmount: Number(bonus.toFixed(2)),
      completedAmount: 0,
      remainingAmount: Number(bonus.toFixed(2)),
      status: 'active',
      createdAt: Date.now()
    };
    await set(ref(rtdb, `users/${user.uid}/turnovers/${toVipId}`), vipTurnover);

    confetti({ particleCount: 100, spread: 70 });
    return { success: true, message: `Congratulations! VIP ${level} Level Up bonus of ৳${bonus} added!` };
  };

  // Claim VIP Monthly Bonus
  const claimVipMonthlyBonus = async (level: number): Promise<{ success: boolean; message: string }> => {
    if (!user) return { success: false, message: 'Please log in first' };
    const currentVip = user.vipLevel || 0;
    const config = getVipConfig(level, settings.vipLevels);
    if (!config || config.monthlyBonus <= 0) {
      return { success: false, message: 'No monthly bonus available for this level.' };
    }
    if (currentVip < level || (user.totalBets || 0) < config.minBet) {
      return { success: false, message: `Reach VIP ${level} to claim this monthly reward!` };
    }

    const currentMonthKey = new Date().toISOString().slice(0, 7);
    const claimedMap = user.monthlyBonusClaimed || {};
    if (claimedMap[level] === currentMonthKey) {
      return { success: false, message: `Monthly bonus for ${currentMonthKey} already claimed.` };
    }

    const bonus = config.monthlyBonus;
    const newBal = Number((user.balance + bonus).toFixed(2));
    const newClaimed = { ...claimedMap, [level]: currentMonthKey };

    await update(ref(rtdb, `users/${user.uid}`), {
      balance: newBal,
      monthlyBonusClaimed: newClaimed
    });

    // Create separate turnover record for VIP monthly bonus
    const toVipMonthId = `to_vip_month_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const vipMonthTurnover: TurnoverRecord = {
      id: toVipMonthId,
      sourceType: 'bonus',
      sourceId: `vip_month_${level}_${currentMonthKey}`,
      requiredAmount: Number(bonus.toFixed(2)),
      completedAmount: 0,
      remainingAmount: Number(bonus.toFixed(2)),
      status: 'active',
      createdAt: Date.now()
    };
    await set(ref(rtdb, `users/${user.uid}/turnovers/${toVipMonthId}`), vipMonthTurnover);

    confetti({ particleCount: 100, spread: 70 });
    return { success: true, message: `VIP ${level} Monthly Bonus of ৳${bonus} claimed!` };
  };

  // ================= ADMIN ACTIONS =================
  const adminApproveDeposit = async (id: string) => {
    const depSnap = await get(ref(rtdb, `deposits/${id}`));
    if (!depSnap.exists()) {
      showToast('Deposit record not found', 'error');
      return;
    }
    const item: DepositItem = depSnap.val();

    // STRICT CHECK: Only pending requests can be approved. Prevents double crediting!
    if (item.status !== 'pending') {
      showToast('This deposit request has already been processed!', 'warning');
      return;
    }

    // Mark as completed immediately to prevent race conditions / duplicate clicks
    await update(ref(rtdb, `deposits/${id}`), {
      status: 'completed',
      processedAt: Date.now()
    });
    await update(ref(rtdb, `depositRequests/${id}`), {
      status: 'success',
      processedAt: Date.now()
    }).catch(() => {});

    const userSnap = await get(ref(rtdb, `users/${item.uid}`));
    if (userSnap.exists()) {
      const uData = userSnap.val() as UserProfile;
      const cur = Number(uData.balance || 0);
      const newBal = Number((cur + item.amount).toFixed(2));
      const curReq = Number(uData.turnoverReq || 0);
      const newReq = Number((curReq + item.amount).toFixed(2)); // 1X turnover requirement

      await update(ref(rtdb, `users/${item.uid}`), {
        balance: newBal,
        turnoverReq: newReq
      });

      // Create individual TurnoverRecord in RTDB
      const depTurnoverId = `to_dep_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const depTurnover: TurnoverRecord = {
        id: depTurnoverId,
        sourceType: 'deposit',
        sourceId: id,
        requiredAmount: Number(item.amount.toFixed(2)),
        completedAmount: 0,
        remainingAmount: Number(item.amount.toFixed(2)),
        status: 'active',
        createdAt: Date.now()
      };
      await set(ref(rtdb, `users/${item.uid}/turnovers/${depTurnoverId}`), depTurnover);

      await recordTransaction(
        item.uid,
        'deposit',
        item.amount,
        cur,
        newBal,
        `Deposit approved via ${item.channel} (${item.txnId})`,
        id
      );

      // Multi-Level Recursive Referral Commission Distribution (Level 1: 5%, Level 2: 2%, Level 3: 1%, Level 4: 0.5%, Level 5+: 0.2%)
      const allUsersSnap = await get(ref(rtdb, 'users'));
      if (allUsersSnap.exists()) {
        const allUsersMap = allUsersSnap.val() as Record<string, UserProfile>;
        let currentMemberData = uData;
        let level = 1;
        const visitedUids = new Set<string>([item.uid]);

        while (level <= 10) {
          const parentRefCode = (currentMemberData.referredBy || currentMemberData.invitedBy || '').trim();
          if (!parentRefCode) break;

          const parentEntry = Object.entries(allUsersMap).find(
            ([uid, u]) =>
              !visitedUids.has(uid) &&
              ((u.referCode && u.referCode.trim() === parentRefCode) ||
               (u.numericUid && u.numericUid.trim() === parentRefCode) ||
               uid === parentRefCode ||
               (u.inviteCode && u.inviteCode.trim() === parentRefCode))
          );

          if (!parentEntry) break;

          const [parentUid, parentProfile] = parentEntry;
          visitedUids.add(parentUid);

          // Commission tier rate based on level depth
          const commissionRate =
            level === 1 ? 0.05 :
            level === 2 ? 0.02 :
            level === 3 ? 0.01 :
            level === 4 ? 0.005 : 0.002;

          const commission = Number((item.amount * commissionRate).toFixed(2));
          if (commission > 0) {
            const pCurBal = Number(parentProfile.balance || 0);
            const pNewBal = Number((pCurBal + commission).toFixed(2));
            const pCurCommission = Number(parentProfile.referralBalance || 0);
            const pNewCommission = Number((pCurCommission + commission).toFixed(2));

            // Update in-memory map copy for subsequent levels if needed
            parentProfile.balance = pNewBal;
            parentProfile.referralBalance = pNewCommission;

            await update(ref(rtdb, `users/${parentUid}`), {
              balance: pNewBal,
              referralBalance: pNewCommission
            }).catch(() => {});

            await recordTransaction(
              parentUid,
              'referral_commission',
              commission,
              pCurBal,
              pNewBal,
              `Level ${level} (${(commissionRate * 100).toFixed(1)}%) referral commission from team member ${uData.numericUid || item.uid.slice(0, 6)} deposit ৳${item.amount}`,
              id
            );
          }

          currentMemberData = parentProfile;
          level++;
        }
      }
    }

    showToast(`Deposit approved! ৳${item.amount.toFixed(2)} credited to user.`, 'success');
  };

  const adminRejectDeposit = async (id: string) => {
    const depSnap = await get(ref(rtdb, `deposits/${id}`));
    if (!depSnap.exists()) {
      showToast('Deposit record not found', 'error');
      return;
    }
    const item: DepositItem = depSnap.val();

    if (item.status !== 'pending') {
      showToast('This deposit request has already been processed!', 'warning');
      return;
    }

    await update(ref(rtdb, `deposits/${id}`), {
      status: 'rejected',
      processedAt: Date.now()
    });
    await update(ref(rtdb, `depositRequests/${id}`), {
      status: 'failed',
      processedAt: Date.now()
    }).catch(() => {});

    // Create rejection audit in transaction records
    const userSnap = await get(ref(rtdb, `users/${item.uid}`));
    if (userSnap.exists()) {
      const uData = userSnap.val() as UserProfile;
      const cur = Number(uData.balance || 0);
      await recordTransaction(
        item.uid,
        'deposit',
        0,
        cur,
        cur,
        `Deposit request rejected (${item.channel} - Txn: ${item.txnId})`,
        id
      );
    }

    showToast('Deposit request rejected', 'info');
  };

  const adminSaveDepositChannel = async (channel: DepositChannel) => {
    await set(ref(rtdb, `depositChannels/${channel.channelId}`), channel);
    showToast(`Channel "${channel.channelName}" saved successfully!`, 'success');
  };

  const adminDeleteDepositChannel = async (channelId: string) => {
    await remove(ref(rtdb, `depositChannels/${channelId}`));
    showToast('Channel removed from active channels', 'info');
  };

  const adminResetDefaultChannels = async () => {
    const updates: Record<string, DepositChannel> = {};
    DEFAULT_DEPOSIT_CHANNELS.forEach((ch) => {
      updates[ch.channelId] = ch;
    });
    await set(ref(rtdb, 'depositChannels'), updates);
    showToast('Deposit channels reset to default presets!', 'success');
  };

  const adminApproveWithdrawal = async (id: string) => {
    await update(ref(rtdb, `withdrawals/${id}`), {
      status: 'completed',
      processedAt: Date.now()
    });
    showToast('Withdrawal marked completed', 'success');
  };

  const adminRejectWithdrawal = async (id: string, reason?: string) => {
    const withSnap = await get(ref(rtdb, `withdrawals/${id}`));
    if (!withSnap.exists()) return;
    const item: WithdrawalItem = withSnap.val();
    const rejectionReason = reason?.trim() || 'Reviewed by Admin (তথ্যগত অসঙ্গতি)';

    const userSnap = await get(ref(rtdb, `users/${item.uid}`));
    if (userSnap.exists()) {
      const cur = Number(userSnap.val().balance || 0);
      const newBal = Number((cur + item.amount).toFixed(2));
      await update(ref(rtdb, `users/${item.uid}`), {
        balance: newBal
      });
      await recordTransaction(
        item.uid,
        'withdrawal',
        item.amount,
        cur,
        newBal,
        `উত্তোলন বাতিল ও রিফান্ড: ${rejectionReason} (৳${item.amount.toFixed(2)})`,
        id
      );
    }

    await update(ref(rtdb, `withdrawals/${id}`), {
      status: 'rejected',
      rejectionReason,
      remark: rejectionReason,
      processedAt: Date.now()
    });
    showToast(`উত্তোলন প্রত্যাখ্যাত ও রিফান্ড সম্পন্ন (কারণ: ${rejectionReason})`, 'info');
  };

  const adminResetDefaultBanners = async () => {
    await set(ref(rtdb, 'banners'), defaultBannersSeed);
    setBanners(Object.values(defaultBannersSeed));
    showToast('৫টি অফিশিয়াল প্রোমোশনাল ব্যানার সফলভাবে রিসেট করা হয়েছে!', 'success');
  };

  const adminToggleMaintenanceMode = async (enabled: boolean, message?: string) => {
    const updates: Partial<SystemSettings> = {
      isMaintenanceMode: enabled
    };
    if (message !== undefined) {
      updates.maintenanceMessage = message;
    }
    await update(ref(rtdb, 'settings'), updates);
    showToast(
      `সাইট মেইনটেন্যান্স মোড ${enabled ? 'চালু (সাইট বন্ধ)' : 'বন্ধ (সাইট লাইভ)'} করা হয়েছে!`,
      enabled ? 'info' : 'success'
    );
  };

  const adminUpdateSignupBonus = async (enabled: boolean, amount: number, multiplier: number) => {
    await update(ref(rtdb, 'settings'), {
      signupBonusEnabled: enabled,
      signupBonusAmount: amount,
      signupBonusTurnoverMultiplier: multiplier
    });
    showToast('নতুন সাইনআপ বোনাস সেটিংস সেভ করা হয়েছে!', 'success');
  };

  const adminSetForcedResult = async (type: GameType, num: number | null) => {
    await update(ref(rtdb, 'settings/forcedResults'), { [type]: num });
    showToast(`Next outcome for ${type} configured`, 'info');
  };

  const adminUpdateSettings = async (newSet: Partial<SystemSettings>) => {
    await update(ref(rtdb, 'settings'), stripUndefined(newSet));
    showToast('Settings saved to Firebase', 'success');
  };

  const adminAdjustUserBalance = async (uid: string, delta: number) => {
    const userSnap = await get(ref(rtdb, `users/${uid}`));
    if (userSnap.exists()) {
      const cur = Number(userSnap.val().balance || 0);
      const nextVal = Math.max(0, Number((cur + delta).toFixed(2)));
      await update(ref(rtdb, `users/${uid}`), { balance: nextVal });
      showToast(`User balance adjusted by ৳${delta}`, 'success');
    }
  };

  const adminUpdateUserVip = async (uid: string, vipLevel: number) => {
    await update(ref(rtdb, `users/${uid}`), { vipLevel });
    showToast(`User VIP level updated to VIP ${vipLevel}`, 'success');
  };

  const adminToggleUserBan = async (uid: string, currentStatus?: string) => {
    const nextStatus = currentStatus === 'banned' ? 'active' : 'banned';
    await update(ref(rtdb, `users/${uid}`), { status: nextStatus });
    showToast(`User status set to ${nextStatus}`, 'info');
  };

  // Auto 30-character Gift Code Generator
  const adminGenerate30CharGiftCode = async (): Promise<string> => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    let isUnique = false;

    while (!isUnique) {
      code = '';
      for (let i = 0; i < 30; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      const checkSnap = await get(ref(rtdb, `giftCodes/${code}`));
      if (!checkSnap.exists()) {
        isUnique = true;
      }
    }
    return code;
  };

  const adminSaveGiftCode = async (code: string, amount: number, maxClaims: number) => {
    const clean = code.trim().toUpperCase();
    const now = new Date();
    const giftData: GiftCodeItem = {
      code: clean,
      amount,
      rewardAmount: amount,
      status: 'active',
      createdAt: Date.now(),
      createdDate: now.toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' }),
      createdTime: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      maxClaims,
      claimCount: 0,
      totalClaims: 0,
      createdBy: 'Admin',
      claimedUsers: {}
    };

    await set(ref(rtdb, `giftCodes/${clean}`), giftData);
    showToast(`Gift code ${clean.slice(0, 8)}... saved successfully!`, 'success');
  };

  const adminUpdateGiftCode = async (code: string, data: Partial<GiftCodeItem>) => {
    await update(ref(rtdb, `giftCodes/${code}`), data);
    showToast('Gift code updated', 'success');
  };

  const adminDeleteGiftCode = async (code: string) => {
    await remove(ref(rtdb, `giftCodes/${code}`));
    showToast('Gift code deleted', 'info');
  };

  const adminToggleGiftCodeStatus = async (code: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'active' ? 'inactive' : 'active';
    await update(ref(rtdb, `giftCodes/${code}`), { status: nextStatus });
    showToast(`Gift code marked ${nextStatus}`, 'info');
  };

  // Game Management (CRUD)
  const adminAddGame = async (gameData: Omit<GameItem, 'id' | 'createdAt'>) => {
    const newRef = push(ref(rtdb, 'games'));
    const item: GameItem = {
      id: newRef.key || `game_${Date.now()}`,
      ...gameData,
      createdAt: Date.now()
    };
    await set(newRef, item);
    showToast('Game created', 'success');
  };

  const adminUpdateGame = async (id: string, gameData: Partial<GameItem>) => {
    await update(ref(rtdb, `games/${id}`), gameData);
    showToast('Game updated', 'success');
  };

  const adminDeleteGame = async (id: string) => {
    await remove(ref(rtdb, `games/${id}`));
    showToast('Game deleted', 'info');
  };

  const adminToggleGameStatus = async (id: string, current: boolean) => {
    await update(ref(rtdb, `games/${id}`), { status: !current });
    showToast(`Game status toggled`, 'info');
  };

  // Banner Management (CRUD)
  const adminAddBanner = async (bannerData: Omit<BannerItem, 'id'>) => {
    const newRef = push(ref(rtdb, 'banners'));
    const item: BannerItem = {
      id: newRef.key || `banner_${Date.now()}`,
      ...bannerData
    };
    await set(newRef, item);
    showToast('Banner added', 'success');
  };

  const adminUpdateBanner = async (id: string, bannerData: Partial<BannerItem>) => {
    await update(ref(rtdb, `banners/${id}`), bannerData);
    showToast('Banner updated', 'success');
  };

  const adminDeleteBanner = async (id: string) => {
    await remove(ref(rtdb, `banners/${id}`));
    showToast('Banner deleted', 'info');
  };

  const adminToggleBannerStatus = async (id: string, current: boolean) => {
    await update(ref(rtdb, `banners/${id}`), { active: !current });
    showToast('Banner status updated', 'info');
  };

  // Activity Banner Management (CRUD - unlimited)
  const adminAddActivityBanner = async (bannerData: Omit<ActivityBanner, 'id'>) => {
    const newRef = push(ref(rtdb, 'activityBanners'));
    const item: ActivityBanner = {
      id: newRef.key || `act_banner_${Date.now()}`,
      ...bannerData,
      createdAt: Date.now()
    };
    await set(newRef, item);
    showToast('Activity banner added successfully', 'success');
  };

  const adminUpdateActivityBanner = async (id: string, bannerData: Partial<ActivityBanner>) => {
    await update(ref(rtdb, `activityBanners/${id}`), bannerData);
    showToast('Activity banner updated successfully', 'success');
  };

  const adminDeleteActivityBanner = async (id: string) => {
    await remove(ref(rtdb, `activityBanners/${id}`));
    showToast('Activity banner deleted', 'info');
  };

  const adminToggleActivityBannerStatus = async (id: string, current: boolean) => {
    await update(ref(rtdb, `activityBanners/${id}`), { active: !current });
    showToast('Activity banner status updated', 'info');
  };

  const adminResetDefaultActivityBanners = async () => {
    await set(ref(rtdb, 'activityBanners'), defaultActivityBannersSeed);
    setActivityBanners(Object.values(defaultActivityBannersSeed));
    showToast('Activity banners reset to official defaults', 'success');
  };

  const adminUpdatePaymentChannel = async (key: string, data: Partial<PaymentChannelConfig>) => {
    await update(ref(rtdb, `settings/paymentChannels/${key}`), data);
    showToast('Payment channel updated', 'success');
  };

  const closeWinModal = () => setLastWinModal(null);

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        authLoading,
        isAdmin,
        setIsAdmin,
        gameType,
        setGameType,
        periodId,
        timeLeft,
        gameHistory,
        userBets,
        allBets,
        deposits,
        withdrawals,
        depositChannels,
        allUsers,
        settings,
        games,
        banners,
        activityBanners,
        giftCodes,
        userGiftClaims,
        userTurnovers,
        activeTurnoverReq,
        activeTurnoverDone,
        activeTurnoverRemaining,
        userTransactions,
        lastWinModal,
        setLastWinModal,
        closeWinModal,
        toast,
        showToast,
        isRefreshingBalance,
        refreshBalance,
        downloadApp,
        updateNickname,
        updateUsername,
        updateAvatar,
        bindEmail,
        recordGameMove,
        placeBet,
        fulfillBetTurnover,
        recordGameBet,
        updateGameBetStatus,
        submitDeposit,
        submitDepositChannelRequest,
        submitWithdrawal,
        saveWithdrawAccount,
        deleteWithdrawAccount,
        transferSafe,
        claimGiftCode,
        claimDailyAttendance,
        claimVipLevelUpBonus,
        claimVipMonthlyBonus,
        adminApproveDeposit,
        adminRejectDeposit,
        adminApproveWithdrawal,
        adminRejectWithdrawal,
        adminSetForcedResult,
        adminUpdateSettings,
        adminAdjustUserBalance,
        adminUpdateUserVip,
        adminToggleUserBan,
        adminGenerate30CharGiftCode,
        adminSaveGiftCode,
        adminUpdateGiftCode,
        adminDeleteGiftCode,
        adminToggleGiftCodeStatus,
        adminAddGame,
        adminUpdateGame,
        adminDeleteGame,
        adminToggleGameStatus,
        adminAddBanner,
        adminUpdateBanner,
        adminDeleteBanner,
        adminToggleBannerStatus,
        adminResetDefaultBanners,
        adminAddActivityBanner,
        adminUpdateActivityBanner,
        adminDeleteActivityBanner,
        adminToggleActivityBannerStatus,
        adminResetDefaultActivityBanners,
        adminToggleMaintenanceMode,
        adminUpdateSignupBonus,
        adminUpdatePaymentChannel,
        adminSaveDepositChannel,
        adminDeleteDepositChannel,
        adminResetDefaultChannels,
        isGameActive,
        setIsGameActive,
        login,
        loginWithPhone,
        sendPasswordReset,
        register,
        logout
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
