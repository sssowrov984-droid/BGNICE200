import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type Language = 'en' | 'bn';

export const translations = {
  en: {
    appName: 'BGNICE',
    slogan: 'Withdraw fast, safe and stable',
    adminMode: 'Admin Mode',
    admin: 'Admin',
    deposit: 'Deposit',
    withdraw: 'Withdraw',
    wallet: 'Wallet',
    safe: 'Safe Vault',
    activity: 'Activity',
    promotion: 'Promotion',
    account: 'Account',
    home: 'Home',
    wingo: 'Win Go',
    support: 'Support',
    customerService: 'Customer Service (Live Chat)',
    language: 'Language',
    selectLanguage: 'Select Language',
    settings: 'Settings',
    accountSettings: 'Account Settings',
    gameHistory: 'Game History',
    depositHistory: 'Deposit History',
    withdrawHistory: 'Withdraw History',
    transactionRecords: 'Financial & Transaction Records',
    subordinateData: 'Subordinate & Referral Data',
    giftsRedemption: 'Gifts & Redemption',
    downloadApp: 'Download Official App',
    logout: 'Log out / Switch Account',
    logoutConfirmTitle: 'Log Out of Account?',
    logoutConfirmDesc: 'You can sign back in at any time with your credentials.',
    cancel: 'Cancel',
    confirmLogout: 'Yes, Log Out',
    welcome: 'Welcome',
    balance: 'Total Balance',
    safeBalance: 'Safe Vault Balance',
    recharge: 'Recharge',
    inviteFriends: 'Invite Friends',
    totalReward: 'Total Bonus',
    dailyAttendance: 'Daily Attendance',
    vipPrivileges: 'VIP Privileges',
    liveChat247: '24/7 Live Support',
    officialSupport: 'Official Support',
    startNewChat: 'Start New Chat',
    typeMessage: 'Type your message...',
    send: 'Send',
    activeChat: 'Active Conversation',
    chatHistory: 'Chat History',
    closeChat: 'Close Chat',
    adminLiveChatManagement: 'Live Chat Management & Reply',
    adminLiveChats: 'Live Chats',
    allErrorFixed: 'System Operational & Error Free',
    english: 'English',
    bengali: 'বাংলা (Bengali)',
    copyUid: 'Copy UID',
    copied: 'Copied!',
    turnoverReq: 'Turnover Requirement',
    completed: 'Completed',
    remaining: 'Remaining',
    search: 'Search',
    all: 'All',
    pending: 'Pending',
    approved: 'Approved',
    rejected: 'Rejected',
  },
  bn: {
    appName: 'BGNICE',
    slogan: 'দ্রুত, নিরাপদ এবং বিশ্বস্ত লেনদেন',
    adminMode: 'অ্যাডমিন মোড',
    admin: 'অ্যাডমিন',
    deposit: 'ডিপোজিট',
    withdraw: 'উইথড্র',
    wallet: 'ওয়ালেট',
    safe: 'সেফ ভল্ট',
    activity: 'অ্যাক্টিভিটি',
    promotion: 'প্রমোশন',
    account: 'অ্যাকাউন্ট',
    home: 'হোম',
    wingo: 'উইন গো',
    support: 'সাপোর্ট',
    customerService: 'কাস্টমার সার্ভিস (লাইভ চ্যাট)',
    language: 'ভাষা',
    selectLanguage: 'ভাষা নির্বাচন করুন',
    settings: 'সেটিংস',
    accountSettings: 'অ্যাকাউন্ট সেটিংস',
    gameHistory: 'গেম হিস্ট্রি',
    depositHistory: 'ডিপোজিট হিস্ট্রি',
    withdrawHistory: 'উইথড্র হিস্ট্রি',
    transactionRecords: 'আর্থিক ও ট্রানজেকশন রেকর্ড',
    subordinateData: 'রেফারেল ও সাবঅর্ডিনেট ডাটা',
    giftsRedemption: 'গিফট কোড রিডিম',
    downloadApp: 'অফিসিয়াল অ্যাপ ডাউনলোড',
    logout: 'লগআউট / অ্যাকাউন্ট পরিবর্তন',
    logoutConfirmTitle: 'লগআউট করতে চান?',
    logoutConfirmDesc: 'আপনি যেকোনো সময় পুনরায় আপনার তথ্য দিয়ে লগইন করতে পারবেন।',
    cancel: 'বাতিল',
    confirmLogout: 'হ্যাঁ, লগআউট করুন',
    welcome: 'স্বাগতম',
    balance: 'মোট ব্যালেন্স',
    safeBalance: 'সেফ ভল্ট ব্যালেন্স',
    recharge: 'রিচার্জ',
    inviteFriends: 'বন্ধু ইনভাইট করুন',
    totalReward: 'মোট বোনাস',
    dailyAttendance: 'দৈনিক হাজিরা',
    vipPrivileges: 'ভিআইপি সুবিধা',
    liveChat247: '২৪/৭ লাইভ সাপোর্ট',
    officialSupport: 'অফিসিয়াল কাস্টমার সাপোর্ট',
    startNewChat: 'নতুন চ্যাট শুরু করুন',
    typeMessage: 'আপনার বার্তা লিখুন...',
    send: 'পাঠান',
    activeChat: 'চলতি চ্যাট',
    chatHistory: 'চ্যাট ইতিহাস',
    closeChat: 'চ্যাট বন্ধ করুন',
    adminLiveChatManagement: 'লাইভ চ্যাট ম্যানেজমেন্ট ও রিপ্লাই',
    adminLiveChats: 'লাইভ চ্যাটসমূহ',
    allErrorFixed: 'সিস্টেম সক্রিয় ও ত্রুটিমুক্ত',
    english: 'English (ইংরেজি)',
    bengali: 'বাংলা',
    copyUid: 'UID কপি করুন',
    copied: 'কপি হয়েছে!',
    turnoverReq: 'টার্নওভার শর্ত',
    completed: 'সম্পন্ন',
    remaining: 'বাকি',
    search: 'অনুসন্ধান',
    all: 'সকল',
    pending: 'অপেক্ষমাণ',
    approved: 'অনুমোদিত',
    rejected: 'বাতিল',
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations['en']) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('tradebd_language');
      if (saved === 'bn' || saved === 'en') return saved;
    } catch {}
    return 'bn'; // Default to Bengali as requested by the user
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('tradebd_language', lang);
    } catch {}
  };

  const t = (key: keyof typeof translations['en']): string => {
    const langDict = translations[language] || translations['en'];
    return (langDict as any)[key] || translations['en'][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
