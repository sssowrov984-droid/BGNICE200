export interface FeaturedGameCard {
  id: 'wingo' | 'k3' | 'fiveD' | 'trx' | 'aviator' | 'aviatorX';
  name: string;
  category: 'Lottery' | 'Original';
  defaultImage: string;
  badge: string;
  description: string;
  payout: string;
  actionType: 'wingo' | 'aviator' | 'k3' | 'fiveD' | 'trx';
}

export const DEFAULT_FEATURED_GAMES: FeaturedGameCard[] = [
  {
    id: 'wingo',
    name: 'Wingo Lottery',
    category: 'Lottery',
    defaultImage: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    badge: 'HOT',
    description: 'Color & Number Multi-cycle Lottery',
    payout: '1.98X - 9X',
    actionType: 'wingo'
  },
  {
    id: 'k3',
    name: 'K3 Lottery',
    category: 'Lottery',
    defaultImage: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=600&auto=format&fit=crop&q=80',
    badge: 'WIN',
    description: 'Fast 3-Dice Instant Lottery',
    payout: '1.98X - 207X',
    actionType: 'k3'
  },
  {
    id: 'fiveD',
    name: '5D Lottery',
    category: 'Lottery',
    defaultImage: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=600&auto=format&fit=crop&q=80',
    badge: 'TOP',
    description: '5-Digit Precision Jackpot Draw',
    payout: '1.98X - 9X',
    actionType: 'fiveD'
  },
  {
    id: 'trx',
    name: 'TRX Wingo',
    category: 'Lottery',
    defaultImage: 'https://images.unsplash.com/photo-1622979135225-d2ba269bc1df?w=600&auto=format&fit=crop&q=80',
    badge: 'FAST',
    description: 'Decentralized Hash Block Lottery',
    payout: '1.98X - 9X',
    actionType: 'trx'
  },
  {
    id: 'aviator',
    name: 'Aviator',
    category: 'Original',
    defaultImage: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=600&auto=format&fit=crop&q=80',
    badge: 'HOT',
    description: 'Multiply Cash Before Crash',
    payout: 'Up to 100X',
    actionType: 'aviator'
  },
  {
    id: 'aviatorX',
    name: 'Aviator X',
    category: 'Original',
    defaultImage: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?w=600&auto=format&fit=crop&q=80',
    badge: 'NEW',
    description: 'Supercharged Turbo Aviator Flight',
    payout: 'Up to 250X',
    actionType: 'aviator'
  }
];
