export interface PopularGameItem {
  id: string;
  name: string;
  provider?: string;
  rtp?: string;
  image: string;
  badge?: string;
  category: string;
  gamePath: string;
}

export const POPULAR_JILI_GAMES: PopularGameItem[] = [
  {
    id: 'jili_super_ace',
    name: 'SUPER ACE',
    provider: 'JILI',
    rtp: '96.2%',
    image: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    category: 'Slots',
    gamePath: 'games/lucky777/index.html',
    badge: 'HOT'
  },
  {
    id: 'game_aviator_red',
    name: 'AVIATOR',
    provider: 'SPRIBE',
    rtp: '96.8%',
    image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=600&auto=format&fit=crop&q=80',
    category: 'Original',
    gamePath: 'games/aviator/index.html',
    badge: 'HOT'
  },
  {
    id: 'game_aviator_wire',
    name: 'AVIATOR PRO',
    provider: 'PRO',
    rtp: '96.9%',
    image: 'https://images.unsplash.com/photo-1519074069444-1ba4fff16def?w=600&auto=format&fit=crop&q=80',
    category: 'Original',
    gamePath: 'games/aviator/index.html',
    badge: 'NEW'
  },
  {
    id: 'jili_cai_shen',
    name: 'CAI SHEN FISHING',
    provider: 'JILI',
    rtp: '97.1%',
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=600&auto=format&fit=crop&q=80',
    category: 'Fishing',
    gamePath: 'games/lucky777/index.html',
    badge: 'HOT'
  },
  {
    id: 'jili_fortune_totem',
    name: 'FORTUNE TOTEM',
    provider: 'JILI',
    rtp: '96.5%',
    image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=600&auto=format&fit=crop&q=80',
    category: 'Slots',
    gamePath: 'games/lucky777/index.html',
    badge: 'NEW'
  },
  {
    id: 'game_dungeon_quest',
    name: 'DUNGEON QUEST',
    provider: 'QUEST',
    rtp: '96.4%',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=600&auto=format&fit=crop&q=80',
    category: 'Slots',
    gamePath: 'games/lucky777/index.html',
    badge: 'HOT'
  },
  {
    id: 'jili_money_coming',
    name: 'MONEY COMING',
    provider: 'JILI',
    rtp: '96.6%',
    image: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&auto=format&fit=crop&q=80',
    category: 'Slots',
    gamePath: 'games/lucky777/index.html',
    badge: 'HOT'
  },
  {
    id: 'jili_fortune_gems',
    name: 'FORTUNE GEMS',
    provider: 'JILI',
    rtp: '96.75%',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80',
    category: 'Slots',
    gamePath: 'games/lucky777/index.html',
    badge: 'HOT'
  },
  {
    id: 'jili_boxing_king',
    name: 'BOXING KING',
    provider: 'JILI',
    rtp: '97.96%',
    image: 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=600&auto=format&fit=crop&q=80',
    category: 'Slots',
    gamePath: 'games/crash/index.html',
    badge: 'TOP'
  },
  {
    id: 'jili_crazy_777',
    name: 'CRAZY 777',
    provider: 'JILI',
    rtp: '97.3%',
    image: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    category: 'Slots',
    gamePath: 'games/lucky777/index.html',
    badge: 'HOT'
  },
  {
    id: 'jili_mega_ace',
    name: 'MEGA ACE',
    provider: 'JILI',
    rtp: '96.8%',
    image: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=600&auto=format&fit=crop&q=80',
    category: 'Slots',
    gamePath: 'games/lucky777/index.html',
    badge: 'HOT'
  },
  {
    id: 'game_hot_spin',
    name: 'HOT SPIN',
    provider: 'JILI',
    rtp: '96.5%',
    image: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    category: 'Casino',
    gamePath: 'games/dragon-tiger/index.html',
    badge: 'NEW'
  },
  {
    id: 'jili_buffalo',
    name: 'BUFFALO',
    provider: 'JILI',
    rtp: '96.7%',
    image: 'https://images.unsplash.com/photo-1534188753412-3e26d0d618d6?w=600&auto=format&fit=crop&q=80',
    category: 'Slots',
    gamePath: 'games/lucky777/index.html',
    badge: 'HOT'
  },
  {
    id: 'game_7up_7down',
    name: '7UP 7DOWN',
    provider: 'JILI',
    rtp: '97.0%',
    image: 'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?w=600&auto=format&fit=crop&q=80',
    category: 'Original',
    gamePath: 'games/ludo/index.html',
    badge: 'TOP'
  }
];
