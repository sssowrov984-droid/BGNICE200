import { initializeApp, getApps, getApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';
import { getAuth, setPersistence, browserLocalPersistence } from 'firebase/auth';

export const firebaseConfig = {
  apiKey: "AIzaSyBhG50onze_ewTWQy6ZefAmsLO4NBoJLrw",
  authDomain: "bgnice-a3981.firebaseapp.com",
  databaseURL: "https://bgnice-a3981-default-rtdb.firebaseio.com",
  projectId: "bgnice-a3981",
  storageBucket: "bgnice-a3981.firebasestorage.app",
  messagingSenderId: "1085530227210",
  appId: "1:1085530227210:web:a38e0c7a55087d61b055f3",
  measurementId: "G-SBP38GE86G"
};

// Initialize Firebase safely
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const rtdb = getDatabase(app);
export const auth = getAuth(app);

// Guarantee browserLocalPersistence across page refresh and browser reopen
setPersistence(auth, browserLocalPersistence).catch((err) => {
  console.warn('Firebase setPersistence warning:', err);
});

export default app;

