export interface AvatarOption {
  id: string;
  name: string;
  photoUrl: string;
  emoji?: string;
  gradient: string;
  border: string;
}

export const PREDEFINED_AVATARS: AvatarOption[] = [
  {
    id: 'avatar_1',
    name: 'Sophia',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    emoji: '👩',
    gradient: 'from-amber-500 to-red-600',
    border: 'border-amber-300'
  },
  {
    id: 'avatar_2',
    name: 'Alexander',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    emoji: '👨',
    gradient: 'from-blue-600 to-indigo-900',
    border: 'border-sky-300'
  },
  {
    id: 'avatar_3',
    name: 'Emily',
    photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    emoji: '👩',
    gradient: 'from-pink-500 to-rose-600',
    border: 'border-pink-300'
  },
  {
    id: 'avatar_4',
    name: 'Ethan',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
    emoji: '👨',
    gradient: 'from-orange-500 to-amber-600',
    border: 'border-orange-300'
  },
  {
    id: 'avatar_5',
    name: 'Olivia',
    photoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    emoji: '👩',
    gradient: 'from-emerald-500 to-teal-800',
    border: 'border-emerald-300'
  },
  {
    id: 'avatar_6',
    name: 'Daniel',
    photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    emoji: '👨',
    gradient: 'from-slate-700 to-slate-950',
    border: 'border-slate-400'
  },
  {
    id: 'avatar_7',
    name: 'Mia',
    photoUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=200&auto=format&fit=crop&q=80',
    emoji: '👩',
    gradient: 'from-red-600 to-rose-700',
    border: 'border-red-400'
  },
  {
    id: 'avatar_8',
    name: 'David',
    photoUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&auto=format&fit=crop&q=80',
    emoji: '👨',
    gradient: 'from-cyan-500 to-blue-600',
    border: 'border-cyan-300'
  },
  {
    id: 'avatar_9',
    name: 'Lucas',
    photoUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&auto=format&fit=crop&q=80',
    emoji: '👨',
    gradient: 'from-indigo-600 to-violet-800',
    border: 'border-indigo-300'
  },
  {
    id: 'avatar_10',
    name: 'Charlotte',
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80',
    emoji: '👩',
    gradient: 'from-purple-600 to-pink-600',
    border: 'border-pink-300'
  }
];

export const getAvatarById = (id?: string): AvatarOption => {
  if (!id || typeof id !== 'string' || !id.trim()) return PREDEFINED_AVATARS[0];
  const cleanId = id.trim();
  // If id is a direct URL or data URI
  if (cleanId.startsWith('http://') || cleanId.startsWith('https://') || cleanId.startsWith('data:image/')) {
    return {
      id: cleanId,
      name: 'Player',
      photoUrl: cleanId,
      gradient: 'from-blue-600 to-indigo-800',
      border: 'border-blue-300'
    };
  }
  return PREDEFINED_AVATARS.find((a) => a.id === cleanId) || PREDEFINED_AVATARS[0];
};
