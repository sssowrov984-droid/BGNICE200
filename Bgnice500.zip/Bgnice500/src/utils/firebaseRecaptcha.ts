import { RecaptchaVerifier, ConfirmationResult, signInWithPhoneNumber } from 'firebase/auth';
import { auth } from '../lib/firebase';

let recaptchaVerifier: RecaptchaVerifier | null = null;
let confirmationResult: ConfirmationResult | null = null;
let otpSending = false;

/**
 * Initializes the Firebase invisible RecaptchaVerifier ONLY ONCE.
 * Binds directly to the single dedicated #recaptcha-container in index.html.
 */
export function initRecaptcha(): RecaptchaVerifier | null {
  if (recaptchaVerifier) {
    return recaptchaVerifier;
  }

  const container = document.getElementById('recaptcha-container');
  if (!container) {
    console.error('reCAPTCHA container not found');
    return null;
  }

  // Ensure inner content is pristine before attaching verifier
  container.innerHTML = '';

  try {
    recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
      size: 'invisible',
      callback: (response: any) => {
        console.log('reCAPTCHA verified successfully', response);
      },
      'expired-callback': () => {
        console.log('reCAPTCHA expired');
        destroyRecaptcha();
      }
    });

    return recaptchaVerifier;
  } catch (err) {
    console.error('Failed to initialize RecaptchaVerifier:', err);
    destroyRecaptcha();
    return null;
  }
}

/**
 * Safely clears and resets the singleton RecaptchaVerifier.
 */
export function destroyRecaptcha(): void {
  if (recaptchaVerifier) {
    try {
      recaptchaVerifier.clear();
    } catch (e) {
      console.warn('Error clearing recaptchaVerifier:', e);
    }
    recaptchaVerifier = null;
  }

  const container = document.getElementById('recaptcha-container');
  if (container) {
    container.innerHTML = '';
  }
}

/**
 * Get the currently stored phone confirmation result
 */
export function getConfirmationResult(): ConfirmationResult | null {
  return confirmationResult;
}

/**
 * Set or update the active phone confirmation result
 */
export function setConfirmationResult(cr: ConfirmationResult | null): void {
  confirmationResult = cr;
}

/**
 * OTP sending state tracker
 */
export function isOtpSending(): boolean {
  return otpSending;
}

export function setOtpSendingState(sending: boolean): void {
  otpSending = sending;
}

/**
 * Maps Firebase Auth error codes to user-friendly Bengali and English messages
 */
export function getFirebaseErrorMessage(error: any): string {
  if (!error) return 'একটি অজানা সমস্যা হয়েছে। আবার চেষ্টা করুন।';
  const code = error.code || '';

  switch (code) {
    case 'auth/invalid-phone-number':
      return 'সঠিক ফোন নম্বর দিন (Invalid phone number format)';
    case 'auth/missing-phone-number':
      return 'Phone number দিন (Phone number is required)';
    case 'auth/quota-exceeded':
      return 'আজকের SMS সীমা শেষ হয়েছে। অনুগ্রহ করে কিছুক্ষণ পর চেষ্টা করুন। (SMS quota exceeded)';
    case 'auth/too-many-requests':
      return 'অতিরিক্ত অনুরোধ করা হয়েছে। কিছুক্ষণ পর চেষ্টা করুন। (Too many attempts)';
    case 'auth/captcha-check-failed':
      return 'reCAPTCHA verification failed. আবার চেষ্টা করুন';
    case 'auth/invalid-app-credential':
      return 'reCAPTCHA verification failed. আবার চেষ্টা করুন';
    case 'auth/invalid-verification-code':
      return 'OTP সঠিক নয় (Invalid verification code)';
    case 'auth/code-expired':
      return 'OTP মেয়াদ শেষ হয়েছে। নতুন OTP নিন। (Code expired)';
    case 'auth/session-expired':
      return 'OTP সেশন শেষ হয়েছে। আবার OTP পাঠান। (Session expired)';
    case 'auth/billing-not-enabled':
      return 'Firebase SMS বিলিং সক্রিয় নেই (auth/billing-not-enabled)। ডেমো ভেরিফিকেশন কোড পাঠানো হয়েছে।';
    default:
      return error.message || 'OTP প্রক্রিয়ায় সমস্যা হয়েছে। আবার চেষ্টা করুন।';
  }
}

// Backward compatibility alias for legacy imports
export const getOrCreateInvisibleRecaptcha = initRecaptcha;
export const clearInvisibleRecaptcha = destroyRecaptcha;
