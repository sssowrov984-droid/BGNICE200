export function getNumberColors(num: number): ('green' | 'red' | 'violet')[] {
  if (num === 0) return ['red', 'violet'];
  if (num === 5) return ['green', 'violet'];
  if ([1, 3, 7, 9].includes(num)) return ['green'];
  return ['red'];
}

export function getNumberSize(num: number): 'Big' | 'Small' {
  return num >= 5 ? 'Big' : 'Small';
}

export function calculateWin(
  selectType: 'color' | 'number' | 'size' | string | undefined,
  selectValue: string | undefined,
  resultNumber: number,
  betAmount: number
): { isWin: boolean; winAmount: number } {
  if (!selectType || !selectValue) {
    return { isWin: false, winAmount: 0 };
  }
  const colors = getNumberColors(resultNumber);
  const size = getNumberSize(resultNumber);

  if (selectType === 'number') {
    if (parseInt(selectValue, 10) === resultNumber) {
      return { isWin: true, winAmount: betAmount * 9 };
    }
    return { isWin: false, winAmount: 0 };
  }

  if (selectType === 'size') {
    if (selectValue.toLowerCase() === size.toLowerCase()) {
      return { isWin: true, winAmount: betAmount * 1.98 };
    }
    return { isWin: false, winAmount: 0 };
  }

  if (selectType === 'color') {
    const val = selectValue.toLowerCase();
    if (val === 'violet' && colors.includes('violet')) {
      return { isWin: true, winAmount: betAmount * 4.5 };
    }
    if (val === 'green') {
      if (resultNumber === 5) {
        return { isWin: true, winAmount: betAmount * 1.5 };
      } else if (colors.includes('green')) {
        return { isWin: true, winAmount: betAmount * 2 };
      }
    }
    if (val === 'red') {
      if (resultNumber === 0) {
        return { isWin: true, winAmount: betAmount * 1.5 };
      } else if (colors.includes('red')) {
        return { isWin: true, winAmount: betAmount * 2 };
      }
    }
  }

  return { isWin: false, winAmount: 0 };
}

export function generatePeriodId(gameType: string = '30s'): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  // total seconds of the day
  const secondsToday = d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds();
  const step = gameType === '30s' ? 30 : gameType === '1m' ? 60 : gameType === '2m' ? 120 : gameType === '3m' ? 180 : 300;
  const index = Math.floor(secondsToday / step) + 1;
  return `${y}${m}${day}1000${String(index).padStart(5, '0')}`;
}

export function generateInitialHistoryForType(gameType: string = '30s', count: number = 30) {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const secondsToday = d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds();
  const step = gameType === '30s' ? 30 : gameType === '1m' ? 60 : gameType === '2m' ? 120 : gameType === '3m' ? 180 : 300;
  const currentIndex = Math.floor(secondsToday / step);

  const history = [];
  const now = Date.now();

  const multipliers: Record<string, number> = {
    '30s': 17,
    '1m': 23,
    '2m': 29,
    '3m': 31,
    '5m': 37
  };
  const mult = multipliers[gameType] || 19;

  for (let i = 1; i <= count; i++) {
    const periodIndex = Math.max(1, currentIndex - i);
    const periodId = `${y}${m}${day}1000${String(periodIndex).padStart(5, '0')}`;
    const num = Math.abs((periodIndex * mult + i * 13) % 10);
    const colors = getNumberColors(num);
    const bigSmall = getNumberSize(num);

    history.push({
      periodId,
      number: num,
      bigSmall,
      colors,
      timestamp: now - i * step * 1000
    });
  }

  return history;
}

export function playBeepSound(isEnd: boolean = false) {
  try {
    const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.setValueAtTime(isEnd ? 880 : 440, ctx.currentTime);
    gain.gain.setValueAtTime(0.05, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
    osc.start();
    osc.stop(ctx.currentTime + 0.15);
  } catch {
    // Audio context may require gesture
  }
}
