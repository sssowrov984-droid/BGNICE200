/**
 * ImgBB Image Upload Utility for TRADE BD
 * Enables direct image hosting without Firebase Storage
 */

// User provided ImgBB API key for Trade BD image hosting
export const DEFAULT_IMGBB_API_KEY = 'af0fb43358ce6f93bf96a854dc1808a5';

export interface ImgBBUploadResponse {
  success: boolean;
  url?: string;
  displayUrl?: string;
  deleteUrl?: string;
  error?: string;
}

/**
 * Upload a file (File object or Base64 string) to ImgBB
 * @param file File or Blob or base64 string
 * @param customApiKey Optional custom API key from settings
 */
export async function uploadToImgBB(
  file: File | Blob | string,
  customApiKey?: string
): Promise<ImgBBUploadResponse> {
  const apiKey = (customApiKey && customApiKey.trim().length > 5) ? customApiKey.trim() : DEFAULT_IMGBB_API_KEY;

  try {
    const formData = new FormData();
    formData.append('key', apiKey);

    if (typeof file === 'string') {
      // If it's a data URL, strip the prefix
      const base64Clean = file.replace(/^data:image\/[a-z]+;base64,/, '');
      formData.append('image', base64Clean);
    } else {
      formData.append('image', file);
    }

    const res = await fetch(`https://api.imgbb.com/1/upload?key=${encodeURIComponent(apiKey)}`, {
      method: 'POST',
      body: formData,
    });

    const data = await res.json();

    if (data.success && data.data) {
      return {
        success: true,
        url: data.data.url || data.data.display_url,
        displayUrl: data.data.display_url || data.data.url,
        deleteUrl: data.data.delete_url,
      };
    } else {
      const errorMsg = data.error?.message || 'ImgBB upload failed';
      console.warn('ImgBB API error:', errorMsg);
      return {
        success: false,
        error: errorMsg,
      };
    }
  } catch (err: any) {
    console.error('ImgBB upload network error:', err);
    return {
      success: false,
      error: err.message || 'Network error during image upload',
    };
  }
}
