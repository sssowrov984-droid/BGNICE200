export interface AppNotification {
  id: string;
  type: 'login' | 'deposit' | 'withdrawal' | 'system';
  title: string;
  message: string;
  timestamp: number;
  status?: 'success' | 'processing' | 'rejected';
  amount?: number;
}

export function formatNotificationDateTime(timestamp: number | string | Date): string {
  const d = new Date(timestamp);
  if (isNaN(d.getTime())) return '';
  const dateStr = d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
  const timeStr = d.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });
  return `${dateStr} • ${timeStr}`;
}

export function recordLoginNotification(uid: string) {
  if (!uid) return;
  const storageKey = `bgnice_login_history_${uid}`;
  try {
    const raw = localStorage.getItem(storageKey);
    const existing: Array<{ id: string; timestamp: number }> = raw ? JSON.parse(raw) : [];
    const now = Date.now();

    // Only record new login notification if the last one was recorded > 3 minutes ago
    // or if no login records exist
    const lastRecord = existing[0];
    if (!lastRecord || now - lastRecord.timestamp > 3 * 60 * 1000) {
      const updated = [{ id: `login_${now}`, timestamp: now }, ...existing].slice(0, 30);
      localStorage.setItem(storageKey, JSON.stringify(updated));
    }
  } catch (e) {
    console.error('Failed to save login notification', e);
  }
}

export function getStoredLoginNotifications(uid: string): AppNotification[] {
  if (!uid) return [];
  const storageKey = `bgnice_login_history_${uid}`;
  try {
    const raw = localStorage.getItem(storageKey);
    const records: Array<{ id: string; timestamp: number }> = raw ? JSON.parse(raw) : [];
    return records.map((r) => ({
      id: r.id,
      type: 'login',
      title: 'Login Successful',
      message: 'You have successfully logged in to your BGNICE account.',
      timestamp: r.timestamp,
      status: 'success'
    }));
  } catch (e) {
    return [];
  }
}

export function getReadNotificationIds(uid: string): Set<string> {
  if (!uid) return new Set();
  const key = `bgnice_read_notifs_${uid}`;
  try {
    const raw = localStorage.getItem(key);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch {
    return new Set();
  }
}

export function markNotificationsAsRead(uid: string, ids: string[]) {
  if (!uid || ids.length === 0) return;
  const key = `bgnice_read_notifs_${uid}`;
  try {
    const readSet = getReadNotificationIds(uid);
    ids.forEach((id) => readSet.add(id));
    localStorage.setItem(key, JSON.stringify(Array.from(readSet)));
  } catch (e) {
    console.error('Failed to mark notifications as read', e);
  }
}
