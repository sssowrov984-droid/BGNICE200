export const PAYMENT_LOGOS = {
  nagad: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTzdXhHFNuSEgc2CbDodLCWnanEnl6rJ6tckpdkfxcJMg&s=10',
  rocket: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRjLKFIaosuj-vNEvtthR826bf6pSeHyQWAL_EWTo6-CA&s=10',
  bkash: 'https://download.logo.wine/logo/BKash/BKash-Icon-Logo.wine.png',
  ewallet: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTIygtqM2sAU6oXjYtmZip0A_EVd4zRo99Lnv7SFPXYA&s=10',
  usdt: 'https://cryptologos.cc/logos/tether-usdt-logo.png'
};

export function getPaymentLogo(channel: string, customUrl?: string): string {
  if (customUrl && customUrl.trim()) return customUrl;
  const lower = channel.toLowerCase();
  if (lower.includes('nagad')) return PAYMENT_LOGOS.nagad;
  if (lower.includes('bkash')) return PAYMENT_LOGOS.bkash;
  if (lower.includes('rocket')) return PAYMENT_LOGOS.rocket;
  if (lower.includes('usdt') || lower.includes('trc20')) return PAYMENT_LOGOS.usdt;
  return PAYMENT_LOGOS.ewallet;
}
