import { VipLevelConfig } from '../types';
import { DEFAULT_VIP_LEVELS } from './defaultVip';

export type { VipLevelConfig };

export const VIP_LEVELS: VipLevelConfig[] = [
  {
    level: 0,
    name: 'VIP 0',
    minRecharge: 0,
    minBet: 0,
    levelUpBonus: 0,
    weeklyBonus: 0,
    monthlyBonus: 0,
    safeRate: 0,
    rebateRate: 0,
    enabled: true
  },
  ...Object.values(DEFAULT_VIP_LEVELS)
];

/**
 * Calculates current VIP level based on cumulative betting turnover (1 Taka = 1 EXP).
 * Note: VIP 1 strictly requires completing the full minBet (default ৳1,000 EXP), NOT ৳100!
 */
export function calculateVipLevel(
  totalBet: number,
  customLevels?: Record<number, VipLevelConfig>
): number {
  const levels = customLevels && Object.keys(customLevels).length > 0 ? customLevels : DEFAULT_VIP_LEVELS;
  
  // Check from VIP 10 down to VIP 1
  for (let lvl = 10; lvl >= 1; lvl--) {
    const cfg = levels[lvl];
    if (cfg && cfg.enabled !== false && cfg.minBet > 0) {
      if (totalBet >= cfg.minBet) {
        return lvl;
      }
    }
  }
  return 0; // VIP 0 if below VIP 1 requirement (e.g. < 1000)
}

/**
 * Returns configuration for a given VIP level.
 */
export function getVipConfig(
  level: number,
  customLevels?: Record<number, VipLevelConfig>
): VipLevelConfig {
  const levels = customLevels && Object.keys(customLevels).length > 0 ? customLevels : DEFAULT_VIP_LEVELS;
  if (level === 0) {
    return {
      level: 0,
      name: 'VIP 0',
      minRecharge: 0,
      minBet: 0,
      levelUpBonus: 0,
      weeklyBonus: 0,
      monthlyBonus: 0,
      safeRate: 0,
      rebateRate: 0,
      enabled: true
    };
  }
  return (
    levels[level] ||
    DEFAULT_VIP_LEVELS[level] || {
      level,
      name: `VIP ${level}`,
      minRecharge: 0,
      minBet: 0,
      levelUpBonus: 0,
      weeklyBonus: 0,
      monthlyBonus: 0,
      safeRate: 0,
      rebateRate: 0,
      enabled: true
    }
  );
}
